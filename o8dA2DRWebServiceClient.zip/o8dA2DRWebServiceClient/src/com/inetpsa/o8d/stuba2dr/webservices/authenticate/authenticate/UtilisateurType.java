/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: UtilisateurType.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class UtilisateurType.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class UtilisateurType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = 114182800572243991L;

	/**
     * Field _identifiant
     */
    private java.lang.String _identifiant;

    /**
     * Field _motDePasse
     */
    private java.lang.String _motDePasse;

    /**
     * Field _erreur
     */
    private java.lang.String _erreur;


      //----------------/
     //- Constructors -/
    //----------------/

    public UtilisateurType() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.UtilisateurType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'erreur'.
     * 
     * @return the value of field 'Erreur'.
     */
    public java.lang.String getErreur()
    {
        return this._erreur;
    } //-- java.lang.String getErreur() 

    /**
     * Returns the value of field 'identifiant'.
     * 
     * @return the value of field 'Identifiant'.
     */
    public java.lang.String getIdentifiant()
    {
        return this._identifiant;
    } //-- java.lang.String getIdentifiant() 

    /**
     * Returns the value of field 'motDePasse'.
     * 
     * @return the value of field 'MotDePasse'.
     */
    public java.lang.String getMotDePasse()
    {
        return this._motDePasse;
    } //-- java.lang.String getMotDePasse() 

    /**
     * Sets the value of field 'erreur'.
     * 
     * @param erreur the value of field 'erreur'.
     */
    public void setErreur(java.lang.String erreur)
    {
        this._erreur = erreur;
    } //-- void setErreur(java.lang.String) 

    /**
     * Sets the value of field 'identifiant'.
     * 
     * @param identifiant the value of field 'identifiant'.
     */
    public void setIdentifiant(java.lang.String identifiant)
    {
        this._identifiant = identifiant;
    } //-- void setIdentifiant(java.lang.String) 

    /**
     * Sets the value of field 'motDePasse'.
     * 
     * @param motDePasse the value of field 'motDePasse'.
     */
    public void setMotDePasse(java.lang.String motDePasse)
    {
        this._motDePasse = motDePasse;
    } //-- void setMotDePasse(java.lang.String) 

}
