/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: ParametersType.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class ParametersType.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class ParametersType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -9134443097997859494L;
	/**
     * Field _utilisateur
     */
    private com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur _utilisateur;


      //----------------/
     //- Constructors -/
    //----------------/

    public ParametersType() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.ParametersType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'utilisateur'.
     * 
     * @return the value of field 'Utilisateur'.
     */
    public com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur getUtilisateur()
    {
        return this._utilisateur;
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur getUtilisateur() 

    /**
     * Sets the value of field 'utilisateur'.
     * 
     * @param utilisateur the value of field 'utilisateur'.
     */
    public void setUtilisateur(com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur utilisateur)
    {
        this._utilisateur = utilisateur;
    } //-- void setUtilisateur(com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur) 

}
