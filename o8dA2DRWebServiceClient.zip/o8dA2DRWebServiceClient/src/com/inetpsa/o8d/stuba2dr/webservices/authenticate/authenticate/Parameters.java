/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: Parameters.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class Parameters.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class Parameters extends ParametersType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -8504174341317691414L;

	public Parameters() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Parameters()

}
