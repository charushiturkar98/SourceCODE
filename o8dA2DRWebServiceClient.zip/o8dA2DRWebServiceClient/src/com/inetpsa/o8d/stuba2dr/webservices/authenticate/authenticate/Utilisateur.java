/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: Utilisateur.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class Utilisateur.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class Utilisateur extends UtilisateurType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = 6756886601405560500L;

	public Utilisateur() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur()

}
