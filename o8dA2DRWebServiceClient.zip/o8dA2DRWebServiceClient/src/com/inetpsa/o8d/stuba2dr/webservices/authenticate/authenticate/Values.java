/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: Values.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class Values.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class Values extends ValuesType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -1497071423372753026L;

	public Values() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Values()

}
