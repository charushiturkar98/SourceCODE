/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: ValuesType.java,v 1.1 2009-04-03 13:21:09 cedric Exp $
 */

package com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate;

/**
 * Class ValuesType.
 * 
 * @version $Revision: 1.1 $ $Date: 2009-04-03 13:21:09 $
 */
public class ValuesType implements java.io.Serializable {


      /**
	 * 
	 */
	private static final long serialVersionUID = -6072685767990623677L;
	//--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _fichePersonalisee
     */
    private com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee _fichePersonalisee;


      //----------------/
     //- Constructors -/
    //----------------/

    public ValuesType() 
     {
        super();
    } //-- com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.ValuesType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'fichePersonalisee'.
     * 
     * @return the value of field 'FichePersonalisee'.
     */
    public com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee getFichePersonalisee()
    {
        return this._fichePersonalisee;
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee getFichePersonalisee() 

    /**
     * Sets the value of field 'fichePersonalisee'.
     * 
     * @param fichePersonalisee the value of field
     * 'fichePersonalisee'.
     */
    public void setFichePersonalisee(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee fichePersonalisee)
    {
        this._fichePersonalisee = fichePersonalisee;
    } //-- void setFichePersonalisee(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee) 

}
