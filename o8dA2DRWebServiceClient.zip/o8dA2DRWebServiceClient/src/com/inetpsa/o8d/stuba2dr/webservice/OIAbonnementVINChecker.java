package com.inetpsa.o8d.stuba2dr.webservice;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.stuba2dr.config.ProxyBean;
import com.inetpsa.o8d.stuba2dr.config.WebServiceClientConfigurationManager;

/**
 * Prise de service de DiagUser vers A2DR permettant de v�rifier qu'un utilisateur dispose d'un abonnement VIN en cours de validit�. Cette prise de
 * service utilise la librairie : http d'apache Elle est bas�e sur la pattern Singleton et utilise des fichiers de propri�t�s lors de son
 * instanciation.
 * 
 * @author e358045
 */
public class OIAbonnementVINChecker {

    /** Log de la classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(OIAbonnementVINChecker.class);

    /**
     * Prefixe des parametres.
     */
    private static final String PARAMS_PREFIX = "?Vin=";
    /**
     * Suffixe des parametres.
     */
    private static final String PARAMS_SUFFIX = "&AccordConsommation=False";
    /**
     * Chaine a rechercher.
     */
    private static final String SEARCH_STR = "Autorise=";

    /**
     * Client http.
     */
    private DefaultHttpClient httpClient;
    /**
     * L'abonnement est-il valide ?
     */
    private boolean aboValide;

    /**
     * Getter aboValide
     * 
     * @return the aboValide
     */
    public boolean isAboValide() {
        return aboValide;
    }

    /**
     * Initialisation de la connexion.
     */
    public void initConnection() {
        LOGGER.debug("Connection init - start");

        httpClient = new DefaultHttpClient();

        WebServiceClientConfigurationManager webServiceClientConfigurationManager = WebServiceClientConfigurationManager.getInstance();

        ProxyBean proxyBean = webServiceClientConfigurationManager.getProxy();

        if (proxyBean != null) {
            LOGGER.debug("Proxy is used");

            httpClient.getCredentialsProvider().setCredentials(new AuthScope(proxyBean.getHostname(), proxyBean.getPort()),
                    webServiceClientConfigurationManager.getProxyAuthentication());

            HttpHost proxy = new HttpHost(proxyBean.getHostname(), proxyBean.getPort());

            httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);

            LOGGER.debug("via proxy: {}", proxy);
        }

        LOGGER.debug("Connection init - end");
    }

    /**
     * Fermeture de la connexion http.
     */
    public void closeConnection() {
        if (httpClient != null) {
            httpClient.getConnectionManager().shutdown();

            LOGGER.debug("Connection shutdown done");
        }
    }

    /**
     * M�thode permettant de r�cup�rer la r�ponse � la prise de service sur A2DR (UsageDiagBoxAction)
     * 
     * @param vin         Vehicle Identification Number (identifiant unique par v�hicule)
     * @param credentials credentials de l'utilisateur
     * @throws IOException si une erreur survient
     */
    public void checkAbo(final String vin, UsernamePasswordCredentials credentials) throws IOException {
        LOGGER.debug("CheckAbo - start");

        WebServiceClientConfigurationManager webServiceClientConfigurationManager = WebServiceClientConfigurationManager.getInstance();

        StringBuilder urlBuilder = new StringBuilder();
        urlBuilder.append(webServiceClientConfigurationManager.getCheckAboContext());
        urlBuilder.append(StringUtils.defaultIfEmpty(webServiceClientConfigurationManager.getCheckAboUrl(), StringUtils.EMPTY));
        urlBuilder.append(PARAMS_PREFIX);
        urlBuilder.append(vin);
        urlBuilder.append(PARAMS_SUFFIX);
        String urlHttpGet = urlBuilder.toString();
        urlBuilder.setLength(0); // CAP-29321 Resetting StringBuilder to null
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Url: {}", urlHttpGet);

        HttpGet httpget = new HttpGet(urlHttpGet);

        httpClient.getCredentialsProvider().setCredentials(
                new AuthScope(webServiceClientConfigurationManager.getCheckAboHostname(), webServiceClientConfigurationManager.getCheckAboPort()),
                credentials);

        HttpHost targetHost = new HttpHost(webServiceClientConfigurationManager.getCheckAboHostname(),
                webServiceClientConfigurationManager.getCheckAboPort(), webServiceClientConfigurationManager.getCheckAboScheme());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Executing request: {}", httpget.getRequestLine());

            LOGGER.debug("To target: {}", targetHost);
        }

        HttpResponse response = httpClient.execute(targetHost, httpget);
        HttpEntity entity = response.getEntity();

        if (LOGGER.isDebugEnabled())
            LOGGER.debug("Status: {}", response.getStatusLine());

        String reponse;

        if (entity != null) {
            reponse = EntityUtils.toString(entity);
        } else {
            reponse = StringUtils.EMPTY;
        }

        int autoriseIndex = reponse.indexOf(SEARCH_STR);

        if (autoriseIndex > -1) {
            if (reponse.substring(autoriseIndex + SEARCH_STR.length()).startsWith("True")) {
                aboValide = true;
            }
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("Abo valide = {}, Affichage de la reponse:\n{}", aboValide, reponse);
        } else {
            LOGGER.error("Error accessing server : 'Autorise=' not found in response\n" + response);
        }
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("CheckAbo - end");
    }
}
