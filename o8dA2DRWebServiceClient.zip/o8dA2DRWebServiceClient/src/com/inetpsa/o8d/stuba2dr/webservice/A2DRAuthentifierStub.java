package com.inetpsa.o8d.stuba2dr.webservice;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.cxl.call.SoapCall;
import com.inetpsa.cxl.commons.CxlException;
import com.inetpsa.cxl.commons.xmlbinding.PsaMarshalException;
import com.inetpsa.cxl.message.actionresponse.IStatus;
import com.inetpsa.cxl.message.actionresponse.PsaAction;
import com.inetpsa.cxl.message.actionresponse.PsaResponseInput;
import com.inetpsa.cxl.message.soap.ISoapUnwrapper;
import com.inetpsa.cxl.message.soap.ISoapWrapper;
import com.inetpsa.cxl.message.soap.SoapWrapperFactory;
import com.inetpsa.cxl.message.wrapper.PsaHeader;
import com.inetpsa.cxl.transport.HttpCommonsDelivery;
import com.inetpsa.o8d.stuba2dr.config.ProxyBean;
import com.inetpsa.o8d.stuba2dr.config.WebServiceClientConfigurationManager;
import com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * Classe qui permet d'interroger le webservice d'authentification A2DR.
 * 
 * @author H.ELKHALFI(E298062) / D.PICCOLI(U188683)
 */
public class A2DRAuthentifierStub {

    /** Log objet pour cette classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(A2DRAuthentifierStub.class);

    /** Nom par defaut de l'action */
    private static final String ACTION = "authentifier";

    /** Nombre de fois que le stub a ete sollicite */
    private AtomicInteger callCount = new AtomicInteger(0);

    /** objet qui permet d'emettre des messages SOAP sur du HTTP */
    private HttpCommonsDelivery soapDelivery;

    /**
     * Constructeur A2DRAuthentifierStub.
     * 
     * @param endpointUrl url du service distant.
     */
    public A2DRAuthentifierStub(String endpointUrl) {
        LOGGER.info("Creation d'un client A2DRAuthentifier stub qui pointe vers : {}", endpointUrl);
        soapDelivery = new HttpCommonsDelivery(endpointUrl);
    }

    /**
     * Methode qui permet d'authentifier un utilisateur par le biais d'un webservice.
     * 
     * @param utilisateur utilisateur que l'on veut authentifier
     * @param applicationName nom de l'application qui veut authentifier
     * @return FichePersonalisee fiche personnalise qui renseigne divers renseignement : nom, prenom, email, etc... .
     * @throws CxlException si une erreur survient
     */
    public FichePersonalisee authenticate(final Utilisateur utilisateur, final String applicationName) throws CxlException {
        LOGGER.info("A2DRAuthentifierStub.authenticate():Begin with utilisateur=[{}], applicationName=[{}]", utilisateur, applicationName);

        WebServiceClientConfigurationManager webServiceClientConfigurationManager = WebServiceClientConfigurationManager.getInstance();

        boolean modeBouchon = webServiceClientConfigurationManager.isMockModeEnabled();

        LOGGER.warn("Mode Bouchon for A2DR access:{}", modeBouchon);

        if (modeBouchon) {
            try {
                return loadFichePersoLocal(utilisateur, applicationName);
            } catch (IOException ex) {
                throw new CxlException("Exception lors de la cr�ation d'une fiche perso en mode local", ex);
            }
        }

        FichePersonalisee fiche = null;
        long callServiceBeginAt = System.currentTimeMillis();
        int callId = callCount.incrementAndGet();

        LOGGER.debug("appel id : {}", callId);

        // Create Initial Message
        ISoapWrapper wrapper = SoapWrapperFactory.getFactory().createWrapper();
        wrapper.addNamespaceMapping("diag", "http://xml.inetpsa.com/Commerce/APVTechnique/Diagnostique");

        // add PSA Header
        PsaHeader header = new PsaHeader(callId, applicationName, ACTION);

        if (null == header.getFrom()) {
            LOGGER.info("utilisation du header from O8D par defaut ");
            header.setFrom("O8D");
        }

        LOGGER.debug("header : from=[{}], to=[{}]", header.getFrom(), header.getTo());

        wrapper.setHeader(header);

        // Create Action GetList (campagnes)
        PsaAction action = new PsaAction(ACTION);
        wrapper.addAction(action);

        // on construit notre HTTP Basic auth
        soapDelivery.setUsernameAndPassword(utilisateur.getIdentifiant(), utilisateur.getMotDePasse());

        // On positionne le proxy si n�cessaire
        setProxy();

        SoapCall call = new SoapCall(soapDelivery);

        // Invoke Call
        ISoapUnwrapper responseUnwrapper = call.invokeSync(wrapper);

        // Check Fault (an exception is thrown if the response contains a fault part)
        responseUnwrapper.checkForFault();

        // Get Result
        PsaResponseInput response = responseUnwrapper.getFirstResponse();

        if (response != null) {
            if (response.hasValues()) {
                try {
                    fiche = (FichePersonalisee) response.getValueAt(0, FichePersonalisee.class);
                } catch (PsaMarshalException ex) {
                    LOGGER.warn("A2DRAuthentifierStub Exception", ex);
                }
            }

            IStatus status = response.getStatus();
            if (!status.isOk()) {
                throw new CxlException("The response status is not OK : " + response.getStatus().getLabel());
            }
        } else {
            throw new CxlException("The webservice response is null");
        }

        LOGGER.info("Ellapsed time=[{}]", System.currentTimeMillis() - callServiceBeginAt);

        return fiche;
    }

    /**
     * Chargement de la fiche locale
     * 
     * @param utilisateur utilisateur
     * @param applicationName nom de l'application
     * @return fiche
     * @throws IOException si une erreur survient
     */
    private FichePersonalisee loadFichePersoLocal(final Utilisateur utilisateur, final String applicationName) throws IOException {

        String idFile = utilisateur.getIdentifiant() + "-" + applicationName;

        LOGGER.info("Nom du fichier � lire :'{}'", idFile);

        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(idFile);

        if (is == null) {
            throw new IOException("Erreur lors de la lecture du fichier '" + idFile + "', verifier que le fichier existe bien");
        }

        Properties prop = new Properties();
        prop.load(is);

        LOGGER.info("Fichier contenant :'{}' properties", prop.size());
        LOGGER.info("Les properties sont : {}", prop);

        String password = prop.getProperty("password");

        if ((password == null) || (password.length() == 0)) {
            throw new IllegalArgumentException("password ne peut �tre vide");
        }

        if (!password.equals(utilisateur.getMotDePasse())) {
            throw new IllegalArgumentException("password n'est pas correct");
        }

        FichePersonalisee fiche = new FichePersonalisee();

        Set<java.util.Map.Entry<Object, Object>> set = prop.entrySet();

        for (java.util.Map.Entry<Object, Object> propEntry : set) {
            Entry en = new Entry();
            en.setKey((String) propEntry.getKey());
            en.setValue((String) propEntry.getValue());
            fiche.addEntry(en);
        }

        return fiche;
    }

    /**
     * Initialisation du proxy.
     */
    private void setProxy() {
        WebServiceClientConfigurationManager webServiceClientConfigurationManager = WebServiceClientConfigurationManager.getInstance();

        ProxyBean proxy = webServiceClientConfigurationManager.getProxy();

        if (proxy != null) {
            LOGGER.info("Utilisation du proxy pour acceder au WS d'authentification A2DR");

            String hostname = StringUtils.defaultIfEmpty(proxy.getHostname(), StringUtils.EMPTY);
            String port = String.valueOf(proxy.getPort());
            String username = StringUtils.EMPTY;
            String password = StringUtils.EMPTY;

            UsernamePasswordCredentials proxyAuth = webServiceClientConfigurationManager.getProxyAuthentication();

            if (proxyAuth != null) {
                username = StringUtils.defaultIfEmpty(proxyAuth.getUserName(), StringUtils.EMPTY);
                password = StringUtils.defaultIfEmpty(proxyAuth.getPassword(), StringUtils.EMPTY);
            }

            LOGGER.info("hostname : {}, port : {}, username : {}", hostname, port, username);

            soapDelivery.setProxy(hostname, port, username, password);
        }
    }
}
