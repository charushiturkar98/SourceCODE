package com.inetpsa.o8d.stuba2dr.config;

/**
 * Erreur lors de la configuration du client.
 * 
 * @author E331258
 */
public class WebServiceClientConfigurationException extends RuntimeException {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -8389027288345747492L;

    /**
     * Constructeur.
     * 
     * @param message message
     * @param cause erreur cause
     */
    public WebServiceClientConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
