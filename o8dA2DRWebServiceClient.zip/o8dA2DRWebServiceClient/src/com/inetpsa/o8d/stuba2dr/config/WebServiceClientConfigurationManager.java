package com.inetpsa.o8d.stuba2dr.config;

import org.apache.commons.configuration.AbstractConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Classe qui gere la configuration du serveur.
 * 
 * @author e331258
 */
public final class WebServiceClientConfigurationManager {

    /**
     * log de la classe
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(WebServiceClientConfigurationManager.class);

    /**
     * nom du fichier de configuration du client WS.
     */
    private static final String WS_CLIENT_CONFIGURATION_FILENAME = "diaguser_a2drws_configuration.properties";

    /** instance singleton */
    private static WebServiceClientConfigurationManager instance = new WebServiceClientConfigurationManager();

    /**
     * Param�tre d'activation du proxy.
     */
    private static final String PROXY_ENABLE_PROPERTY = "a2drws.proxy.enable";
    /**
     * Param�tre de definition de l'hote du proxy.
     */
    private static final String PROXY_HOSTNAME_PROPERTY = "a2drws.proxy.hostname";
    /**
     * Param�tre de definition du port du proxy.
     */
    private static final String PROXY_PORT_PROPERTY = "a2drws.proxy.port";
    /**
     * Param�tre de definition de l'utilisateur du proxy.
     */
    private static final String PROXY_USERNAME_PROPERTY = "a2drws.proxy.username";
    /**
     * Param�tre de definition du mot de passe du proxy.
     */
    private static final String PROXY_PASSWORD_PROPERTY = "a2drws.proxy.password";
    /**
     * Param�tre d'activation du mode bouchon.
     */
    private static final String MOCK_MODE_PROPERTY = "a2drws.mockmode.enable";
    /**
     * Param�tre de definition du scheme de l'url checkabo.
     */
    private static final String CHECKABO_SCHEME_PROPERTY = "a2drws.checkabo.scheme";
    /**
     * Param�tre de definition de l'hote de l'url checkabo.
     */
    private static final String CHECKABO_HOSTNAME_PROPERTY = "a2drws.checkabo.hostname";
    /**
     * Param�tre de definition du port de l'url checkabo.
     */
    private static final String CHECKABO_PORT_PROPERTY = "a2drws.checkabo.port";
    /**
     * Param�tre de definition du contexte de l'url checkabo.
     */
    private static final String CHECKABO_CONTEXT_PROPERTY = "a2drws.checkabo.context";
    /**
     * Param�tre de definition l'url checkabo.
     */
    private static final String CHECKABO_URL_PROPERTY = "a2drws.checkabo.url";
    /**
     * Authentification du proxy.
     */
    private final UsernamePasswordCredentials proxyAuthentication;
    /**
     * Proxy.
     */
    private final ProxyBean proxy;
    /**
     * Statut d'activation du mode bouchon.
     */
    private final boolean mockModeEnabled;
    /**
     * Scheme du checkabo.
     */
    private final String checkAboScheme;
    /**
     * Hote du checkabo.
     */
    private final String checkAboHostname;
    /**
     * Port du checkabo.
     */
    private final int checkAboPort;
    /**
     * Contexte du checkabo.
     */
    private final String checkAboContext;
    /**
     * Url du checkabo.
     */
    private final String checkAboUrl;

    /**
     * Constructeur de la classe.
     */
    private WebServiceClientConfigurationManager() {
        LOGGER.info("Web Service client configuration initialisation with {}", WS_CLIENT_CONFIGURATION_FILENAME);

        AbstractConfiguration wsClientConfiguration;
        try {
            wsClientConfiguration = new PropertiesConfiguration(Thread.currentThread().getContextClassLoader()
                    .getResource(WS_CLIENT_CONFIGURATION_FILENAME));
            wsClientConfiguration.setThrowExceptionOnMissing(true);
        } catch (ConfigurationException e) {
            LOGGER.error("Init error", e);
            throw new WebServiceClientConfigurationException("Client init error", e);
        }

        // L'acc�s par proxy est-il actif ?
        boolean proxyAccessEnabled = wsClientConfiguration.getBoolean(PROXY_ENABLE_PROPERTY, Boolean.FALSE);

        // Initialisation des param�tres de l'acc�s par proxy
        if (proxyAccessEnabled) {
            // Initialisation du proxy
            proxy = initProxy(wsClientConfiguration);

            // Initialisation de l'authentification du proxy
            proxyAuthentication = initProxyAuth(wsClientConfiguration);
        } else {
            proxy = null;
            proxyAuthentication = null;
        }

        // Le mode bouchon est-il actif ?
        mockModeEnabled = wsClientConfiguration.getBoolean(MOCK_MODE_PROPERTY, Boolean.FALSE);

        // Contr�le d'abonnement
        checkAboScheme = wsClientConfiguration.getString(CHECKABO_SCHEME_PROPERTY);
        checkAboHostname = wsClientConfiguration.getString(CHECKABO_HOSTNAME_PROPERTY);
        checkAboPort = wsClientConfiguration.getInt(CHECKABO_PORT_PROPERTY);
        checkAboContext = wsClientConfiguration.getString(CHECKABO_CONTEXT_PROPERTY);
        checkAboUrl = wsClientConfiguration.getString(CHECKABO_URL_PROPERTY);
    }

    /**
     * Retourne l'instance singleton.
     * 
     * @return instance du ConfLoader.
     */
    public static WebServiceClientConfigurationManager getInstance() {
        return instance;
    }

    /**
     * Getter proxy
     * 
     * @return the proxy
     */
    public ProxyBean getProxy() {
        return proxy;
    }

    /**
     * Getter proxyAuthentication
     * 
     * @return the proxyAuthentication
     */
    public UsernamePasswordCredentials getProxyAuthentication() {
        return proxyAuthentication;
    }

    /**
     * Getter mockModeEnabled
     * 
     * @return the mockModeEnabled
     */
    public boolean isMockModeEnabled() {
        return mockModeEnabled;
    }

    /**
     * Getter checkAboScheme
     * 
     * @return the checkAboScheme
     */
    public String getCheckAboScheme() {
        return checkAboScheme;
    }

    /**
     * Getter checkAboHostname
     * 
     * @return the checkAboHostname
     */
    public String getCheckAboHostname() {
        return checkAboHostname;
    }

    /**
     * Getter checkAboPort
     * 
     * @return the checkAboPort
     */
    public int getCheckAboPort() {
        return checkAboPort;
    }

    /**
     * Getter checkAboContext
     * 
     * @return the checkAboContext
     */
    public String getCheckAboContext() {
        return checkAboContext;
    }

    /**
     * Getter checkAboUrl
     * 
     * @return the checkAboUrl
     */
    public String getCheckAboUrl() {
        return checkAboUrl;
    }

    /**
     * Initialisation du proxy.
     * 
     * @param wsClientConfiguration configuration
     * @return objet {@link ProxyBean}
     */
    private ProxyBean initProxy(Configuration wsClientConfiguration) {
        ProxyBean proxyConf = new ProxyBean();

        proxyConf.setHostname(wsClientConfiguration.getString(PROXY_HOSTNAME_PROPERTY));
        proxyConf.setPort(wsClientConfiguration.getInt(PROXY_PORT_PROPERTY));

        return proxyConf;
    }

    /**
     * Initialistion de l'authentification du proxy.
     * 
     * @param wsClientConfiguration configuration
     * @return objet {@link UsernamePasswordCredentials}
     */
    private UsernamePasswordCredentials initProxyAuth(Configuration wsClientConfiguration) {
        UsernamePasswordCredentials proxyAuth = null;

        String proxyUsername = wsClientConfiguration.getString(PROXY_USERNAME_PROPERTY, StringUtils.EMPTY);

        if (StringUtils.isNotEmpty(proxyUsername)) {
            String proxyPassword = wsClientConfiguration.getString(PROXY_PASSWORD_PROPERTY);

            proxyAuth = new UsernamePasswordCredentials(proxyUsername, proxyPassword);
        }

        return proxyAuth;
    }
}
