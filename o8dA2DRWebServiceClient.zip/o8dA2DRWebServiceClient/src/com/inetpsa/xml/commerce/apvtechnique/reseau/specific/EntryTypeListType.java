/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: EntryTypeListType.java,v 1.2 2009-04-03 13:19:57 cedric Exp $
 */

package com.inetpsa.xml.commerce.apvtechnique.reseau.specific;

/**
 * Liste des informations sur la documentation
 * 
 * @version $Revision: 1.2 $ $Date: 2009-04-03 13:19:57 $
 */
public class EntryTypeListType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -769881823677430400L;
	/**
     * Field _entryList
     */
    private java.util.List _entryList;


      //----------------/
     //- Constructors -/
    //----------------/

    public EntryTypeListType() 
     {
        super();
        this._entryList = new java.util.ArrayList();
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.EntryTypeListType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vEntry
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry vEntry)
        throws java.lang.IndexOutOfBoundsException
    {
        this._entryList.add(vEntry);
    } //-- void addEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) 

    /**
     * 
     * 
     * @param index
     * @param vEntry
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addEntry(int index, com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry vEntry)
        throws java.lang.IndexOutOfBoundsException
    {
        this._entryList.add(index, vEntry);
    } //-- void addEntry(int, com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) 

    /**
     * Method enumerateEntry
     * 
     * 
     * 
     * @return an Enumeration over all possible elements of this
     * collection
     */
    public java.util.Enumeration enumerateEntry()
    {
        return java.util.Collections.enumeration(this._entryList);
    } //-- java.util.Enumeration enumerateEntry() 

    /**
     * Method getEntry
     * 
     * 
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry
     * at the given index
     */
    public com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry getEntry(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        // check bounds for index
        if (index < 0 || index >= this._entryList.size()) {
            throw new IndexOutOfBoundsException("getEntry: Index value '" + index + "' not in range [0.." + (this._entryList.size() - 1) + "]");
        }
        
        return (com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) _entryList.get(index);
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry getEntry(int) 

    /**
     * Method getEntry
     * 
     * 
     * 
     * @return this collection as an Array
     */
    public com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry[] getEntry()
    {
        int size = this._entryList.size();
        com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry[] array = new com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry[size];
        for (int index = 0; index < size; index++){
            array[index] = (com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) _entryList.get(index);
        }
        
        return array;
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry[] getEntry() 

    /**
     * Method getEntryCount
     * 
     * 
     * 
     * @return the size of this collection
     */
    public int getEntryCount()
    {
        return this._entryList.size();
    } //-- int getEntryCount() 

    /**
     * Method iterateEntry
     * 
     * 
     * 
     * @return an Iterator over all possible elements in this
     * collection
     */
    public java.util.Iterator iterateEntry()
    {
        return this._entryList.iterator();
    } //-- java.util.Iterator iterateEntry() 

    /**
     */
    public void removeAllEntry()
    {
        this._entryList.clear();
    } //-- void removeAllEntry() 

    /**
     * Method removeEntry
     * 
     * 
     * 
     * @param vEntry
     * @return true if the object was removed from the collection.
     */
    public boolean removeEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry vEntry)
    {
        boolean removed = _entryList.remove(vEntry);
        return removed;
    } //-- boolean removeEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) 

    /**
     * Method removeEntryAt
     * 
     * 
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry removeEntryAt(int index)
    {
        Object obj = this._entryList.remove(index);
        return (com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) obj;
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry removeEntryAt(int) 

    /**
     * 
     * 
     * @param index
     * @param vEntry
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setEntry(int index, com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry vEntry)
        throws java.lang.IndexOutOfBoundsException
    {
        // check bounds for index
        if (index < 0 || index >= this._entryList.size()) {
            throw new IndexOutOfBoundsException("setEntry: Index value '" + index + "' not in range [0.." + (this._entryList.size() - 1) + "]");
        }
        
        this._entryList.set(index, vEntry);
    } //-- void setEntry(int, com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) 

    /**
     * 
     * 
     * @param vEntryArray
     */
    public void setEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry[] vEntryArray)
    {
        //-- copy array
        _entryList.clear();
        
        for (int i = 0; i < vEntryArray.length; i++) {
                this._entryList.add(vEntryArray[i]);
        }
    } //-- void setEntry(com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry) 

}
