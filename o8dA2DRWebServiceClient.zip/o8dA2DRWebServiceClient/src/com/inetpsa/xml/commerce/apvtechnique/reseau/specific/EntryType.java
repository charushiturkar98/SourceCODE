/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: EntryType.java,v 1.2 2009-04-03 13:19:57 cedric Exp $
 */

package com.inetpsa.xml.commerce.apvtechnique.reseau.specific;

/**
 * Class EntryType.
 * 
 * @version $Revision: 1.2 $ $Date: 2009-04-03 13:19:57 $
 */
public class EntryType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -4986323403586556635L;

	/**
     * Field _key
     */
    private java.lang.String _key;

    /**
     * Field _value
     */
    private java.lang.String _value;


      //----------------/
     //- Constructors -/
    //----------------/

    public EntryType() 
     {
        super();
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.EntryType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'key'.
     * 
     * @return the value of field 'Key'.
     */
    public java.lang.String getKey()
    {
        return this._key;
    } //-- java.lang.String getKey() 

    /**
     * Returns the value of field 'value'.
     * 
     * @return the value of field 'Value'.
     */
    public java.lang.String getValue()
    {
        return this._value;
    } //-- java.lang.String getValue() 

    /**
     * Sets the value of field 'key'.
     * 
     * @param key the value of field 'key'.
     */
    public void setKey(java.lang.String key)
    {
        this._key = key;
    } //-- void setKey(java.lang.String) 

    /**
     * Sets the value of field 'value'.
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(java.lang.String value)
    {
        this._value = value;
    } //-- void setValue(java.lang.String) 

}
