/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: Entry.java,v 1.2 2009-04-03 13:19:57 cedric Exp $
 */

package com.inetpsa.xml.commerce.apvtechnique.reseau.specific;

/**
 * Class Entry.
 * 
 * @version $Revision: 1.2 $ $Date: 2009-04-03 13:19:57 $
 */
public class Entry extends EntryType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = -7008380793610583671L;

	public Entry() 
     {
        super();
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry()

}
