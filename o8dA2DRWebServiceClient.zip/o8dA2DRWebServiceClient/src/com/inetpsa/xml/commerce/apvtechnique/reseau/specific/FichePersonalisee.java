/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.0.5</a>, using an XML
 * Schema.
 * $Id: FichePersonalisee.java,v 1.2 2009-04-03 13:19:57 cedric Exp $
 */

package com.inetpsa.xml.commerce.apvtechnique.reseau.specific;

/**
 * Class FichePersonalisee.
 * 
 * @version $Revision: 1.2 $ $Date: 2009-04-03 13:19:57 $
 */
public class FichePersonalisee extends EntryTypeListType 
implements java.io.Serializable
{


      //----------------/
     //- Constructors -/
    //----------------/

    /**
	 * 
	 */
	private static final long serialVersionUID = 8828483025617227239L;

	public FichePersonalisee() 
     {
        super();
    } //-- com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee()

}
