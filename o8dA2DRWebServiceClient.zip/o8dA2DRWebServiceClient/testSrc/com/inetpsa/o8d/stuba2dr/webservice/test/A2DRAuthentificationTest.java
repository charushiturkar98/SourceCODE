package com.inetpsa.o8d.stuba2dr.webservice.test;

import java.util.Enumeration;

import junit.framework.TestCase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.stuba2dr.webservice.A2DRAuthentifierStub;
import com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * @author e298062
 */
public class A2DRAuthentificationTest extends TestCase {

    private static final Logger LOGGER = LoggerFactory.getLogger(A2DRAuthentifierStub.class);

    public void testDevAccess() {

        // String id = "AP25759789";
        // String pass = "pmdgdiag";
        String id = "AC82264775";
        String pass = "becker";
        String applicationName = "ROLE.OGD.ACCES";
        FichePersonalisee fiche = null;

        String endPoint = "http://a2dr.dev.inetpsa.com/A2DRAuthentification";
        A2DRAuthentifierStub stub = new A2DRAuthentifierStub(endPoint);
        Utilisateur utilisateur = new Utilisateur();
        utilisateur.setIdentifiant(id);
        utilisateur.setMotDePasse(pass);
        try {
            fiche = stub.authenticate(utilisateur, applicationName);
            assertNotNull(fiche);

            int i = 1;
            for (Enumeration enumemation = fiche.enumerateEntry(); enumemation.hasMoreElements();) {

                Entry entry = (Entry) enumemation.nextElement();
                LOGGER.info("[{}]=>{}:{}", i, entry.getKey(), entry.getValue());
                i++;
            }
        } catch (Exception ex) {
            LOGGER.error("Error during execution", ex);
            fail("Exception during WS call");
        }
    }
}
