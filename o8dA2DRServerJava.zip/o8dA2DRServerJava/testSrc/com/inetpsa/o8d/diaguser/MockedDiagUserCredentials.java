package com.inetpsa.o8d.diaguser;

/**
 * Classe de cr�ation des credentials locaux au serveur. <br/>
 * Utiliser de pr�f�rence la classe {@link DiagUserCredentials}.<br/>
 * En effet, l'ip n'est pas trait�e ici.
 * 
 * @author E331258
 */
public class MockedDiagUserCredentials extends DiagUserCredentials {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -858337511338879352L;

    /**
     * Constructeur.
     * 
     * @param username identifiant de l'utilisateur
     * @param password mot de passe de l'utilisateur
     */
    public MockedDiagUserCredentials(String username, String password) {
        super(username, password, null);
    }
}
