package com.inetpsa.o8d.a2dr.config;

import com.inetpsa.o8d.a2dr.beans.ApplicationRelayType;
import com.inetpsa.o8d.a2dr.beans.AuthenticationBean;
import com.inetpsa.o8d.a2dr.beans.ProxyBean;
import com.inetpsa.o8d.a2dr.beans.RelayAccessConfigurationBean;
import com.inetpsa.o8d.a2dr.security.AesEncDec;
import com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory;
import com.inetpsa.o8d.diaguser.DiagUserException;

import junit.framework.TestCase;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class ServerConfigurationManagerTest extends TestCase {

    public void testConfiguration() {
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        try {
            serverConfigurationManager.init("a2dr_server_configuration_test.xml");
        } catch (DiagUserException e) {
            fail(e.getMessage());
        }

        AuthenticationBean authenticationBean = serverConfigurationManager.getServerAccount();
        assertNotNull(authenticationBean);
        assertEquals(AesEncDec.decrypt("WUmsU/qCnqcAQ7RxoHk9rQ=="), authenticationBean.getLogin());
        assertEquals(AesEncDec.decrypt("a31BwX0VR+JlwpYxr3SHIA=="), authenticationBean.getPassword());

        ProxyBean proxyBean = serverConfigurationManager.getProxy();
        assertNotNull(proxyBean);
        assertEquals("http.internetpsa.inetpsa.com", proxyBean.getHostname());
        assertEquals(80, proxyBean.getPort());

        RelayAccessConfigurationBean relayAccessConfigurationBean = serverConfigurationManager.getRelayAccessConfiguration("serav");
        assertNotNull(relayAccessConfigurationBean);
        assertEquals("serav", relayAccessConfigurationBean.getApplicationName());
        assertEquals("SERAV_APP", relayAccessConfigurationBean.getApplicationId());
        assertEquals(ApplicationRelayType.BASIC_RELAY, relayAccessConfigurationBean.getType());
        assertEquals("http", relayAccessConfigurationBean.getScheme());
        assertEquals("serav2.inetpsa.com", relayAccessConfigurationBean.getHostname());
        assertEquals(80, relayAccessConfigurationBean.getPort());
        assertEquals("SeravII", relayAccessConfigurationBean.getContext());
        assertEquals("http://serav2.inetpsa.com:80/SeravII", relayAccessConfigurationBean.getUrl());
        assertEquals(false, relayAccessConfigurationBean.isUseProxy());

        StrategieFactory strategieFactory = serverConfigurationManager.getStrategieFactory("SERAV_APP");
        assertNotNull(strategieFactory);
        assertEquals("com.inetpsa.o8d.a2dr.strategie.factory.AuthorisationAndAuthentificationOIFactory", strategieFactory.getClass().getName());
    }
}
