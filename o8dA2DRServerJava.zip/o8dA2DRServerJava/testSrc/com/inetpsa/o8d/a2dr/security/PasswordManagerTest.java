package com.inetpsa.o8d.a2dr.security;

import java.security.NoSuchAlgorithmException;

import junit.framework.TestCase;

import org.apache.commons.codec.DecoderException;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class PasswordManagerTest extends TestCase {

    private static final String PLAIN_TEXT_PASSWORD = "mot de passe";
    private static final String WRONG_PASSWORD = "password";
    private static final String SECURED = "31f9056d92610df80de5366e45430898306d5a50d02827ba6975cf67cfd96eecc90c0621ff6f31f97053b9d0d1f7a308ab733e5d0e63d1adfbfc14abe18301158101be6fb7eb006b1f5332affda0ee55";

    public void testGenerateCheck() {
        PasswordManager passwordManager = new PasswordManager();

        String generatedSecuredPasswordHash = null;
        try {
            generatedSecuredPasswordHash = passwordManager.generateStrongPasswordHash(PLAIN_TEXT_PASSWORD);
        } catch (PasswordManagerException e) {
            e.printStackTrace();
            fail("Error during generation");
        }

        boolean matched;
        try {
            matched = passwordManager.validatePassword(WRONG_PASSWORD, generatedSecuredPasswordHash);
            assertFalse("Password shouldn't match", matched);
        } catch (PasswordManagerException e) {
            e.printStackTrace();
            fail("Error during validate");
        }

        try {
            matched = passwordManager.validatePassword(WRONG_PASSWORD, SECURED);
            assertFalse("Password shouldn't match", matched);
        } catch (PasswordManagerException e) {
            e.printStackTrace();
            fail("Error during validate");
        }

        try {
            matched = passwordManager.validatePassword(PLAIN_TEXT_PASSWORD, generatedSecuredPasswordHash);
            assertTrue("Password don't match", matched);
        } catch (PasswordManagerException e) {
            e.printStackTrace();
            fail("Error during validate");
        }

        try {
            matched = passwordManager.validatePassword(PLAIN_TEXT_PASSWORD, SECURED);
            assertTrue("Password don't match", matched);
        } catch (PasswordManagerException e) {
            e.printStackTrace();
            fail("Error during validate");
        }
    }

    public void testSaltAlgorithmError() {
        PasswordManager passwordManager = new PasswordManager();
        passwordManager.setSaltAlgorithm("bidon");

        try {
            passwordManager.generateStrongPasswordHash(PLAIN_TEXT_PASSWORD);
            fail("Should fail");
        } catch (PasswordManagerException e) {
            assertEquals("Error during salt generator init", e.getMessage());
            assertTrue("Invalid exception", e.getCause() instanceof NoSuchAlgorithmException);
        }
    }

    public void testValidateError() {
        PasswordManager passwordManager = new PasswordManager();

        try {
            passwordManager.validatePassword(PLAIN_TEXT_PASSWORD, PLAIN_TEXT_PASSWORD);
            fail("Should fail");
        } catch (PasswordManagerException e) {
            assertEquals("Error during hex decoding", e.getMessage());
            assertTrue("Invalid exception", e.getCause() instanceof DecoderException);
        }
    }
}
