package com.inetpsa.o8d.a2dr.beans;

import java.util.Date;

import junit.framework.TestCase;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class VinA2DRComparatorTest extends TestCase {

    public void testComparator() throws InterruptedException {
        VinA2DRComparator vinA2DRComparator = new VinA2DRComparator();

        VinA2DR vin1 = new VinA2DR();
        vin1.setDateFin(new Date());
        assertEquals(0, vinA2DRComparator.compare(vin1, vin1));

        Thread.sleep(2000);

        VinA2DR vin2 = new VinA2DR();
        vin2.setDateFin(new Date());

        assertEquals(-1, vinA2DRComparator.compare(vin1, vin2));
        assertEquals(1, vinA2DRComparator.compare(vin2, vin1));
    }
}
