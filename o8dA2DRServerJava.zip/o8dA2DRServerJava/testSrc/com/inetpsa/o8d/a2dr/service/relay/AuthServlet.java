/*
 * Creation : 5 mai 2015
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Servlet de test pour validation de l'authentification envoy�e au niveau des relais
 * 
 * @author e365699
 */
public class AuthServlet extends HttpServlet {

    /**
     * Credentials
     */
    private DiagUserCredentials credentials;

    /**
     * {@inheritDoc}
     * 
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        common(req, resp);
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        common(req, resp);
    }

    /**
     * @param request {@link HttpServletRequest}
     * @param response {@link HttpServletResponse}
     * @throws IOException erreur {@link IOException}
     * @throws ServletException erreur {@link ServletException}
     */
    private void common(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        try {
            credentials = DiagUserCredentials.createCredentials(request, null, null); // CAP-26498:DiagLot2- code change for adding extra parameter
        } catch (DiagUserException e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }

        response.setStatus(HttpServletResponse.SC_OK);
    }

    /**
     * Getter credentials
     * 
     * @return the credentials
     */
    public DiagUserCredentials getCredentials() {
        return credentials;
    }

}
