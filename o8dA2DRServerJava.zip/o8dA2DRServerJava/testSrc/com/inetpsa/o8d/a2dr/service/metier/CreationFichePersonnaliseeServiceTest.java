package com.inetpsa.o8d.a2dr.service.metier;

import junit.framework.TestCase;

import org.apache.commons.lang3.StringUtils;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class CreationFichePersonnaliseeServiceTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
    }

    public void testExecuteEmpty() {
        CreationFichePersonnaliseeService creationFichePersonnaliseeService = null;

        try {
            creationFichePersonnaliseeService = (CreationFichePersonnaliseeService) ServiceFactory.getInstance().getService((User) null,
                    CreationFichePersonnaliseeService.SERVICE_NAME);
            creationFichePersonnaliseeService.execute();
            assertNull(creationFichePersonnaliseeService.getOutput(CreationFichePersonnaliseeService.OUT_FICHE_PERSONALISEE));
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (creationFichePersonnaliseeService != null) {
                try {
                    creationFichePersonnaliseeService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteNoUser() {
        CreationFichePersonnaliseeService creationFichePersonnaliseeService = null;

        try {
            creationFichePersonnaliseeService = (CreationFichePersonnaliseeService) ServiceFactory.getInstance().getService((User) null,
                    CreationFichePersonnaliseeService.SERVICE_NAME);
            creationFichePersonnaliseeService.setInput(CreationFichePersonnaliseeService.IN_APPLICATION_ROLE, "O8D");
            creationFichePersonnaliseeService.execute();
            FichePersonalisee fiche = (FichePersonalisee) creationFichePersonnaliseeService
                    .getOutput(CreationFichePersonnaliseeService.OUT_FICHE_PERSONALISEE);
            assertNotNull(fiche);

            Entry[] entries = fiche.getEntry();

            for (Entry entry : entries) {
                assertNotNull(entry.getKey());
                assertNull(entry.getValue());
            }
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (creationFichePersonnaliseeService != null) {
                try {
                    creationFichePersonnaliseeService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecute() {
        UserA2DR userA2DR = new UserA2DR();
        userA2DR.setNom("USER NAME");

        CreationFichePersonnaliseeService creationFichePersonnaliseeService = null;

        try {
            creationFichePersonnaliseeService = (CreationFichePersonnaliseeService) ServiceFactory.getInstance().getService((User) null,
                    CreationFichePersonnaliseeService.SERVICE_NAME);
            creationFichePersonnaliseeService.setInput(CreationFichePersonnaliseeService.IN_APPLICATION_ROLE, "O8D");
            creationFichePersonnaliseeService.setInput(CreationFichePersonnaliseeService.IN_UTILISATEUR, userA2DR);
            creationFichePersonnaliseeService.execute();
            FichePersonalisee fiche = (FichePersonalisee) creationFichePersonnaliseeService
                    .getOutput(CreationFichePersonnaliseeService.OUT_FICHE_PERSONALISEE);
            assertNotNull(fiche);

            Entry[] entries = fiche.getEntry();

            for (Entry entry : entries) {
                assertNotNull(entry.getKey());

                if (entry.getKey().equals("nom")) {
                    assertEquals("USER NAME", entry.getValue());
                } else {
                    assertTrue("Value invalid for key=" + entry.getKey() + " : " + entry.getValue(), StringUtils.isEmpty(entry.getValue()));
                }
            }
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (creationFichePersonnaliseeService != null) {
                try {
                    creationFichePersonnaliseeService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
