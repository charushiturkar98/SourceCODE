package com.inetpsa.o8d.a2dr.service.metier;

import junit.framework.TestCase;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.MockedDiagUserCredentials;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class RamenerDonneeDeBDServiceTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
    }

    public void testExecuteEmpty() {
        RamenerDonneeDeBDService ramenerDonneeDeBDService = null;

        DiagUserCredentials credentials = new MockedDiagUserCredentials("Unknown", null);

        try {
            ramenerDonneeDeBDService = (RamenerDonneeDeBDService) ServiceFactory.getInstance().getService((User) null,
                    RamenerDonneeDeBDService.SERVICE_NAME);
            ramenerDonneeDeBDService.setInput(RamenerDonneeDeBDService.IN_CREDENTIALS, credentials);
            ramenerDonneeDeBDService.execute();

            assertNull(ramenerDonneeDeBDService.getOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE));
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (ramenerDonneeDeBDService != null) {
                try {
                    ramenerDonneeDeBDService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
