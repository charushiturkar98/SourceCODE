/*
 * Creation : 5 mai 2015
 */
package com.inetpsa.o8d.a2dr.service;

import javax.servlet.Servlet;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

/**
 * Mock serveur
 * 
 * @author e365699
 */
public class MockServer implements Runnable {
    /** le serveur */
    private Server server;
    /** Servlet context */
    private ServletContextHandler context;

    /**
     * Constructeur
     * 
     * @param port le port
     */
    public MockServer(int port) {
        server = new Server(port);

        context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        server.setHandler(context);
    }

    /**
     * Ajout d'une servlet au serveur
     * 
     * @param servlet l'objet {@link Servlet}
     * @param path Path de la servlet
     */
    public void addServlet(final Servlet servlet, final String path) {
        context.addServlet(new ServletHolder(servlet), path);
    }


    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        try {
            server.start();
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Arr�t
     */
    public void stopServer() {
        if (server != null) {
            try {
                server.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
