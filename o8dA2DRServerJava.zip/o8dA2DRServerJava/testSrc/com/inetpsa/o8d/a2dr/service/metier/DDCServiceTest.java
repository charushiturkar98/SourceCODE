package com.inetpsa.o8d.a2dr.service.metier;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.service.metier.cards.ApplicationCardFactory;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserFactory;
import com.inetpsa.o8d.diaguser.MockedDiagUserCredentials;

import junit.framework.TestCase;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class DDCServiceTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
        DiagUserFactory.getInstance().init();
        ApplicationCardFactory.getInstance();
    }

    public void testExecuteEmpty() {
        DDCService ddcService = null;

        try {
            ddcService = (DDCService) ServiceFactory.getInstance().getService((User) null, DDCService.SERVICE_NAME);
            ddcService.execute();
            fail("prerequis non fourni");
        } catch (AuthentificationException e) {
            assertEquals("Le connecteur 'DiagUser' non present en session", e.getMessage());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (ddcService != null) {
                try {
                    ddcService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecute() {
        DiagUserCredentials credentials = new MockedDiagUserCredentials("tdc_123456", "PASSWORD");

        AbstractDiagUserConnector diagUserConnector = null;
        /*
         * try { diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(credentials);
         * diagUserConnector.setApplicationId("O8D"); } catch (DiagUserException e) { e.printStackTrace(); fail(e.getMessage()); }
         */

        DDCService ddcService = null;

        /*
         * try { ddcService = (DDCService) ServiceFactory.getInstance().getService((User) null, DDCService.SERVICE_NAME);
         * ddcService.setInput(DDCService.DIAG_USER_INSTANCE, diagUserConnector); ddcService.execute(); Map outMap = (Map)
         * ddcService.getOutput(DDCService.OUT_MAP); String identityCard = (String) outMap.get(DDCService.RESPONSE_FROM_TARGET);
         * assertNotNull(identityCard); assertEquals(
         * "USER_ID=TDC_123456\nUSER_IDENTITY=guest doe\n\nROLE.OGD.ACCES=true\nOUG.GARAGE=true\nSERAV_APP=true\nO7D.ACCES_ADMIN=true\nOAU.AUTEUR=true\nODW.WEBDIAG.PPPRODUCTION=true\n"
         * , identityCard); } catch (AuthentificationException e) { assertEquals("Le connecteur 'DiagUser' non present en session", e.getMessage()); }
         * catch (FwkException e) { e.printStackTrace(); fail(e.getMessage()); } finally { if (ddcService != null) { try { ddcService.close(); } catch
         * (FwkException e) { e.printStackTrace(); } } }
         */
    }
}
