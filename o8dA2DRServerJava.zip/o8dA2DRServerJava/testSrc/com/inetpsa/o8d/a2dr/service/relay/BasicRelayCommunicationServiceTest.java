/*
 * Creation : 5 mai 2015
 */
/**
 * 
 */
package com.inetpsa.o8d.a2dr.service.relay;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.Cookie;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.beans.RelayAccessConfigurationBean;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.service.MockServer;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.MockedDiagUserCredentials;

/**
 * Test du service de relai
 * 
 * @author e365699
 */
public class BasicRelayCommunicationServiceTest {

    private static MockServer mockServer;

    private static CookieServlet cookieServlet = new CookieServlet();
    private static AuthServlet authServlet = new AuthServlet();

    static Object deepCopy(Object object) throws Exception {
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(object);
            oos.flush();
            ByteArrayInputStream inputStream = new ByteArrayInputStream(bos.toByteArray());
            ois = new ObjectInputStream(inputStream);
            return ois.readObject();
        } finally {
            oos.close();
            ois.close();
        }
    }

    static <U> void updateSet(Set<U> to, Collection<U> from) {
        for (U obj : from) {
            to.remove(obj);
            to.add(obj);
        }
    }

    @BeforeClass
    public static void init() throws DiagUserException, InterruptedException {
        ServerConfigurationManager.getInstance().init("a2dr_server_mock_configuration_test.xml");
        cookieServlet = Mockito.spy(cookieServlet);
        authServlet = Mockito.spy(authServlet);

        mockServer = new MockServer(9999);
        mockServer.addServlet(cookieServlet, "/serav/cookie");
        mockServer.addServlet(cookieServlet, "/repps/cookie");
        mockServer.addServlet(authServlet, "/ediag/auth");
        mockServer.addServlet(authServlet, "/serav/auth");

        Thread th = new Thread(mockServer);
        th.start();
        Thread.sleep(2000);
    }

    @AfterClass
    public static void endServer() {
        mockServer.stopServer();
    }

    /**
     * Test transmision authentification
     * 
     * @throws Exception exception
     */
    // @Test
    public void testForwardAuth() throws Exception {
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        final RelayAccessConfigurationBean relayAccessConfigurationEdiag = serverConfigurationManager.getRelayAccessConfiguration("ediag");

        // Appel EDIAG
        BasicRelayCommunicationService businessService = null;
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationEdiag);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, null);

        try {
            businessService.execute();
            fail("No basic auth : should fail");
        } catch (FwkException e) {
            // OK
        }

        // Avec Basic-auth (EDIAG) --> Forward
        final String user = "test";
        final String password = "pass";
        MockedDiagUserCredentials credentials = new MockedDiagUserCredentials(user, password);

        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationEdiag);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, null);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_CREDENTIALS, credentials);
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "auth");

        businessService.execute();

        int status = (int) businessService.getOutput(BasicRelayCommunicationService.STATUS_CODE);
        assertEquals("HTTP code should be equals", 200, status);

        assertThat(authServlet.getCredentials().getUserName()).as("User").isEqualToIgnoringCase(user);
        assertThat(authServlet.getCredentials().getPassword()).as("Password").isEqualToIgnoringCase(password);

        reset(authServlet);

        // Avec Basic-auth (SERAV) --> Technical Account
        final RelayAccessConfigurationBean relayAccessConfigurationSerav = serverConfigurationManager.getRelayAccessConfiguration("serav");
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationSerav);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, null);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_CREDENTIALS, credentials);
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "auth");

        businessService.execute();

        status = (int) businessService.getOutput(BasicRelayCommunicationService.STATUS_CODE);
        assertEquals("HTTP code should be equals", 200, status);

        assertThat(authServlet.getCredentials().getUserName()).as("User").isEqualToIgnoringCase(user);
        reset(authServlet);
    }

    /**
     * Test de la transmission des cookies
     * 
     * @throws Exception exception
     */
    // @Test
    public void testCookie() throws Exception {

        Set<Cookie> cookieA2DR = new HashSet<Cookie>();

        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        final RelayAccessConfigurationBean relayAccessConfigurationRepps = serverConfigurationManager.getRelayAccessConfiguration("repps");
        final RelayAccessConfigurationBean relayAccessConfigurationSerav = serverConfigurationManager.getRelayAccessConfiguration("serav");

        BasicRelayCommunicationService businessService = null;

        // Appel REPPS
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationRepps);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, null);
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "cookie");

        businessService.execute();

        Collection<Cookie> cookieRepps = (Collection<Cookie>) businessService.getOutput(BasicRelayCommunicationService.OUT_COOKIES);
        assertNotNull("cookie list should not be null", cookieRepps);
        assertFalse("cookie list should not be empty", cookieRepps.isEmpty());

        verify(cookieServlet).service(any(HttpServletRequest.class), any(HttpServletResponse.class));

        assertTrue("No cookie should be present in first repps request", cookieServlet.getTransmittedCookie().isEmpty());
        reset(cookieServlet);

        updateSet(cookieA2DR, cookieRepps);

        // Appel REPPS n�2 (v�rification transmission cookie dans la requ�te)
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationRepps);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, deepCopy(cookieA2DR));
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "cookie");

        businessService.execute();

        Collection<Cookie> cookieReppsUpdated = (Collection<Cookie>) businessService.getOutput(BasicRelayCommunicationService.OUT_COOKIES);
        assertEquals("cookie list should be equals", cookieRepps, cookieReppsUpdated);

        verify(cookieServlet).service(any(HttpServletRequest.class), any(HttpServletResponse.class));

        assertFalse("cookie should be present in request", cookieServlet.getTransmittedCookie().isEmpty());
        assertEquals("REPPS cookie list should be same size", cookieRepps.size(), cookieServlet.getTransmittedCookie().size());
        reset(cookieServlet);

        updateSet(cookieA2DR, cookieReppsUpdated);

        // Appel Serav
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationSerav);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, deepCopy(cookieA2DR));
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "cookie");

        businessService.execute();

        // La liste contient les cookies SERAV en plus de ceux de REPPS
        Collection<Cookie> cookieSerav = (Collection<Cookie>) businessService.getOutput(BasicRelayCommunicationService.OUT_COOKIES);
        assertNotNull("cookie list from serav should not be null", cookieSerav);
        assertFalse("cookie list from serav should not be empty", cookieSerav.isEmpty());

        verify(cookieServlet).service(any(HttpServletRequest.class), any(HttpServletResponse.class));

        assertTrue("No cookie should be present in first serav request", cookieServlet.getTransmittedCookie().isEmpty());
        reset(cookieServlet);

        updateSet(cookieA2DR, cookieSerav);

        // Appel SERAV n�2
        businessService = (BasicRelayCommunicationService) ServiceFactory.getInstance().getService((User) null, "basic_relay_communication_service");

        businessService.setInput(AbstractRelayCommunicationService.IN_RELAY_ACCESS_CONFIGURATION, relayAccessConfigurationSerav);
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_BODY, new ByteArrayOutputStream());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_HEADERS, new HashMap<String, String>());
        businessService.setInput(AbstractRelayCommunicationService.IN_REQUEST_COOKIES, deepCopy(cookieA2DR));
        businessService.setInput(AbstractRelayCommunicationService.IN_TARGET_PATH, "cookie");

        businessService.execute();

        Collection<Cookie> cookieSeravUpdated = (Collection<Cookie>) businessService.getOutput(BasicRelayCommunicationService.OUT_COOKIES);
        assertEquals("cookie list should be equals", cookieSerav, cookieSeravUpdated);

        verify(cookieServlet).service(any(HttpServletRequest.class), any(HttpServletResponse.class));

        assertFalse("cookie should be present in request", cookieServlet.getTransmittedCookie().isEmpty());
        assertEquals("SERAV cookie list should be same size", cookieSerav.size(), cookieServlet.getTransmittedCookie().size());
        reset(cookieServlet);

        updateSet(cookieA2DR, cookieSeravUpdated);

        assertEquals("List should be equals", cookieSerav.size() + cookieRepps.size(), cookieA2DR.size());
    }

    /**
     * Test de la d�sactivation d'un relai
     * 
     * @throws Exception exception
     */
    @Test
    public void testActivation() throws Exception {
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        final RelayAccessConfigurationBean relayAccessConfigurationRepps = serverConfigurationManager.getRelayAccessConfiguration("repps");
        final RelayAccessConfigurationBean relayAccessConfigurationDeactivate = serverConfigurationManager
                .getRelayAccessConfiguration("deactivateRelay");

        assertNotNull(relayAccessConfigurationRepps);
        assertNull("This relay should be deactivate", relayAccessConfigurationDeactivate);
    }

}
