package com.inetpsa.o8d.a2dr.service.securite;

import junit.framework.TestCase;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class AuthentificationStrategieServiceTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
    }

    public void testExecute() {
        AuthentificationStrategieService authentificationStrategieService = null;

        try {
            authentificationStrategieService = (AuthentificationStrategieService) ServiceFactory.getInstance().getService((User) null,
                    AuthentificationStrategieService.SERVICE_NAME);
            authentificationStrategieService.execute();
            fail("Should fail");
        } catch (FwkException e) {
            e.printStackTrace();
            assertEquals("Unknown authentication strategy for application id : null", e.getMessage());
        } finally {
            if (authentificationStrategieService != null) {
                try {
                    authentificationStrategieService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteLibreAcces() {
        AuthentificationStrategieService authentificationStrategieService = null;

        try {
            authentificationStrategieService = (AuthentificationStrategieService) ServiceFactory.getInstance().getService((User) null,
                    AuthentificationStrategieService.SERVICE_NAME);
            authentificationStrategieService.setInput(AuthentificationStrategieService.IN_APPLICATIONID, "DEV_LIBRE_ACCES");
            authentificationStrategieService.execute();
            assertNull(authentificationStrategieService.getOutput(AuthentificationStrategieService.DIAG_USER_INSTANCE));
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (authentificationStrategieService != null) {
                try {
                    authentificationStrategieService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
