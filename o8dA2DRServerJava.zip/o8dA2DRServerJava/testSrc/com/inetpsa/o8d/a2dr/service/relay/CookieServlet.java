/*
 * Creation : 5 mai 2015
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.ListUtils;

/**
 * Servlet de test pour validation de la gestion des cookies au niveau des relais
 * 
 * @author e365699
 */
public class CookieServlet extends HttpServlet {
    /** Map des cookies selon le contexte */
    private static Map<String, List<Cookie>> contextCookieAssocations = new HashMap<String, List<Cookie>>();
    /** Cookie par d�faut */
    private static List<Cookie> defaultCookie = Arrays.asList(new Cookie("Hello", "World"));
    /** Liste des cookies re�us */
    private List<Cookie> transmittedCookie;

    static {
        List<Cookie> cookieSerav = new ArrayList<Cookie>();
        cookieSerav.add(new Cookie("JSESSIONID", "11111111111111111111111111111111"));
        cookieSerav.add(new Cookie("Cookie1", "cookie1Serav"));
        contextCookieAssocations.put("/serav", cookieSerav);

        List<Cookie> cookieRepps = new ArrayList<Cookie>();
        cookieRepps.add(new Cookie("JSESSIONID", "22222222222222222222222222222222"));
        cookieRepps.add(new Cookie("Cookie1", "cookie1Repps"));
        contextCookieAssocations.put("/repps", cookieRepps);
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        common(req, resp);
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        common(req, resp);
    }

    /**
     * @param request {@link HttpServletRequest}
     * @param response {@link HttpServletResponse}
     * @throws IOException erreur {@link IOException}
     * @throws ServletException erreur {@link ServletException}
     */
    private void common(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        List<Cookie> cookies = contextCookieAssocations.get(request.getServletPath());
        cookies = ListUtils.defaultIfNull(cookies, defaultCookie);
        // Sauvegarde des cookies re�us (pour v�rification dans TU)
        transmittedCookie = Arrays.asList(request.getCookies());

        for (Cookie cookie : cookies) {
            response.addCookie(cookie);
        }
        response.setStatus(HttpServletResponse.SC_OK);
    }

    public List<Cookie> getTransmittedCookie() {
        return transmittedCookie;
    }

}
