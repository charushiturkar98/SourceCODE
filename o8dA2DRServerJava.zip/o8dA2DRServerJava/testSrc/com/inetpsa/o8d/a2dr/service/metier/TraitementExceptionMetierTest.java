package com.inetpsa.o8d.a2dr.service.metier;

import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.httpclient.HttpStatus;

import com.inetpsa.cxl.transport.ResponseIsNotOkException;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.exception.HostNotFoundException;
import com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * TODO : Description
 * 
 * @author E331258
 */
public class TraitementExceptionMetierTest extends TestCase {

    public void testExecute() {
        TraitementExceptionMetier traitementExceptionMetier = null;

        try {
            traitementExceptionMetier = (TraitementExceptionMetier) ServiceFactory.getInstance().getService((User) null,
                    TraitementExceptionMetier.SERVICE_NAME);
            traitementExceptionMetier.execute();
            assertNull(traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
            assertEquals(0, ((Map) traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER)).size());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (traitementExceptionMetier != null) {
                try {
                    traitementExceptionMetier.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteAuthentificationException() {
        TraitementExceptionMetier traitementExceptionMetier = null;

        try {
            traitementExceptionMetier = (TraitementExceptionMetier) ServiceFactory.getInstance().getService((User) null,
                    TraitementExceptionMetier.SERVICE_NAME);
            traitementExceptionMetier.setInput(TraitementExceptionMetier.IN_EXCEPTION_METIER, new AuthentificationException());
            traitementExceptionMetier.execute();
            assertEquals(HttpStatus.SC_UNAUTHORIZED, traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
            assertEquals(1, ((Map) traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER)).size());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (traitementExceptionMetier != null) {
                try {
                    traitementExceptionMetier.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteDiagUserException() {
        TraitementExceptionMetier traitementExceptionMetier = null;

        try {
            traitementExceptionMetier = (TraitementExceptionMetier) ServiceFactory.getInstance().getService((User) null,
                    TraitementExceptionMetier.SERVICE_NAME);
            traitementExceptionMetier.setInput(TraitementExceptionMetier.IN_EXCEPTION_METIER, new DiagUserException());
            traitementExceptionMetier.execute();
            assertEquals(HttpStatus.SC_GATEWAY_TIMEOUT, traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
            assertEquals(0, ((Map) traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER)).size());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (traitementExceptionMetier != null) {
                try {
                    traitementExceptionMetier.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteHostNotFoundException() {
        TraitementExceptionMetier traitementExceptionMetier = null;

        try {
            traitementExceptionMetier = (TraitementExceptionMetier) ServiceFactory.getInstance().getService((User) null,
                    TraitementExceptionMetier.SERVICE_NAME);
            traitementExceptionMetier.setInput(TraitementExceptionMetier.IN_EXCEPTION_METIER, new HostNotFoundException());
            traitementExceptionMetier.execute();
            assertEquals(HttpStatus.SC_GATEWAY_TIMEOUT, traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
            assertEquals(0, ((Map) traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER)).size());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (traitementExceptionMetier != null) {
                try {
                    traitementExceptionMetier.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void testExecuteResponseIsNotOkException() {
        TraitementExceptionMetier traitementExceptionMetier = null;

        try {
            traitementExceptionMetier = (TraitementExceptionMetier) ServiceFactory.getInstance().getService((User) null,
                    TraitementExceptionMetier.SERVICE_NAME);
            traitementExceptionMetier.setInput(AbstractRelayCommunicationService.STATUS_CODE, 404);
            traitementExceptionMetier.setInput(TraitementExceptionMetier.IN_EXCEPTION_METIER, new ResponseIsNotOkException("test"));
            traitementExceptionMetier.execute();
            assertEquals(404, traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
            assertEquals(0, ((Map) traitementExceptionMetier.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER)).size());
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (traitementExceptionMetier != null) {
                try {
                    traitementExceptionMetier.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
