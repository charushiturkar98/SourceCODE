/*
 * Creation : Jul 12, 2022
 */
package com.inetpsa.o8d.weba2dr.err;

/**
 * The Class ErrCode.
 */
public final class ErrorCode {

    /**
     * Instantiates a new err code.
     */
    ErrorCode() {
        super();
    }

    /** Constants for sending error response to DDC. */
    public static final int ERROR_400_CODE = 400;

    /** The Constant ERROR_400. */
    public static final String ERROR_400_MSG = "BAD REQUEST";

    /** The Constant 401_CODE. */
    public static final int ERROR_401_CODE = 401;

    /** The Constant ERROR_401. */
    public static final String ERROR_401_MSG = "UNAUTHORIZED";

    /** The constant ERROR_404 *. */
    public static final int ERROR_404_CODE = 404;

    /** The constant ERROR_404_MSG *. */
    public static final String ERROR_404_MSG = "NO DATA RECEIVED";

    /** The Constant SUCCESS_500_CODE. */
    public static final int ERROR_500_CODE = 500;

    /** The Constant ERROR_500. */
    public static final String ERROR_500_MSG = "INTERNAL ERROR";

    /** The Constant SUCCESS_HTTP_CODE. */
    public static final int ERROR_200_CODE = 200;

    /** The Constant SUCCESS_403_CODE. */
    public static final String ERROR_200_MSG = "NO DATA RECEIVED";

    /** The Constant ERROR_403_CODE. */
    public static final Integer ERROR_403_CODE = 403;

    /** The Constant ERROR_405_CODE. */
    public static final Integer ERROR_405_CODE = 405;

    /** The Constant ERROR_410_CODE. */
    public static final Integer ERROR_410_CODE = 410;

    /** The Constant ERROR_503_CODE. */
    public static final Integer ERROR_503_CODE = 503;

    /** The Constant ERROR_1_CODE. */
    public static final Integer ERROR_1_CODE = -1;

    /** The Constant ERROR_6_CODE. */
    public static final Integer ERROR_6_CODE = 6;

    /** The Constant ERROR_111_CODE. */
    public static final Integer ERROR_111_CODE = 111;

    /** The Constant ERROR_112_CODE. */
    public static final Integer ERROR_112_CODE = 112;

    /** The Constant ERROR_900_CODE. */
    public static final Integer ERROR_900_CODE = 900;

    /** The Constant ERROR_901_CODE. */
    public static final Integer ERROR_901_CODE = 901;

    /** The Constant ERROR_902_CODE. */
    public static final Integer ERROR_902_CODE = 902;

    /** The Constant ERROR_904_CODE. */
    public static final Integer ERROR_904_CODE = 904;

    /** The Constant ERROR_201_CODE. */
    public static final Integer ERROR_201_CODE = 201;

    /** The Constant ERROR_202_CODE. */
    public static final Integer ERROR_202_CODE = 202;

    /** The Constant ERROR_205_CODE. */
    public static final Integer ERROR_205_CODE = 205;

    /** The Constant ERROR_118_CODE. */
    public static final Integer ERROR_118_CODE = 118;

    /** The Constant ERROR_301_CODE. */
    public static final Integer ERROR_301_CODE = 301;

    /** The Constant ERROR_302_CODE. */
    public static final Integer ERROR_302_CODE = 302;

    /** The Constant ERROR_4001_CODE. */
    public static final Integer ERROR_4001_CODE = 4001;

    /** The Constant ERROR_4004_CODE. */
    public static final Integer ERROR_4004_CODE = 4004;

    /** The Constant ERROR_4005_CODE. */
    public static final Integer ERROR_4005_CODE = 4005;

    /** The Constant ERROR_4006_CODE. */
    public static final Integer ERROR_4006_CODE = 4006;

    /** The Constant ERROR_4010_CODE. */
    public static final Integer ERROR_4010_CODE = 4010;

    /** The Constant ERROR_5000_CODE. */
    public static final Integer ERROR_5000_CODE = 5000;

    /** The Constant ERROR_5999_CODE. */
    public static final Integer ERROR_5999_CODE = 5999;

    /** The Constant ERROR_408_CODE. */
    public static final int ERROR_408_CODE = 408;

    /** The Constant ERROR_504_CODE. */
    public static final int ERROR_504_CODE = 504;

    // POUDG-9437

    /** The Constant ERROR_11_CODE. */
    public static final int ERROR_11_CODE = 11;

    /** The Constant ERROR_20_CODE. */
    public static final int ERROR_20_CODE = 20;

    /** The Constant ERROR_22_CODE. */
    public static final int ERROR_22_CODE = 22;

    /** The Constant ERROR_24_CODE. */
    public static final int ERROR_24_CODE = 24;

    /** The Constant ERROR_26_CODE. */
    public static final int ERROR_26_CODE = 26;

    /** The Constant ERROR_12_CODE. */
    public static final int ERROR_12_CODE = 12;
}
