package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlType;

/**
 * The Class Frame.CAP-25017
 */
@XmlType(propOrder = { "value" })
public class Frame {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
