package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Message is a root class for marshling and unmarshling CAP-25017
 */
@XmlRootElement(name = "message")
@XmlType(propOrder = { "mockmessage", "repairingrequests" })
public class Message {

    private boolean mockmessage;
    private Repairingrequests repairingrequests;

    @XmlElement(name = "mock-message")
    public boolean isMockmessage() {
        return mockmessage;
    }

    public void setMockmessage(boolean mockmessage) {
        this.mockmessage = mockmessage;
    }

    @XmlElement(name = "repairing-requests")
    public Repairingrequests getRepairingrequests() {
        return repairingrequests;
    }

    public void setRepairingrequests(Repairingrequests repairingrequests) {
        this.repairingrequests = repairingrequests;
    }

}