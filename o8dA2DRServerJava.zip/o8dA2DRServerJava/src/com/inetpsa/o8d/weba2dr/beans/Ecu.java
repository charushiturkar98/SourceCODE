package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Ecu.CAP-25017
 */
@XmlType(propOrder = { "codeapp", "frames", "unlockseed", "cyberUin" })
public class Ecu {
    private String codeapp;
    private Frames frames;
    private String unlockseed;

    /** CAP-29146 Adding new parameter-START */
    private String cyberUin;

    @XmlElement(name = "cyber-uin")
    public String getCyberUin() {
        return cyberUin;
    }

    public void setCyberUin(String cyberUin) {
        this.cyberUin = cyberUin;
    }

    /** CAP-29146 Adding new parameter-END */

    @XmlElement(name = "code-app")
    public String getCodeapp() {
        return codeapp;
    }

    public void setCodeapp(String codeapp) {
        this.codeapp = codeapp;
    }

    public Frames getFrames() {
        return frames;
    }

    public void setFrames(Frames frames) {
        this.frames = frames;
    }

    @XmlElement(name = "unlock-seed")
    public String getUnlockseed() {
        return unlockseed;
    }

    public void setUnlockseed(String unlockseed) {
        this.unlockseed = unlockseed;
    }

}
