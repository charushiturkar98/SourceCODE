package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Requests.CAP-25017
 */
@XmlType(propOrder = { "unlockingcontent", "requestreturncode" })
@XmlRootElement(name = "requests")
public class Requests {

    private Requestreturncode requestreturncode;
    private Unlockingcontent unlockingcontent;

    @XmlElement(name = "request-return-code")
    public Requestreturncode getRequestreturncode() {
        return requestreturncode;
    }

    public void setRequestreturncode(Requestreturncode requestreturncode) {
        this.requestreturncode = requestreturncode;
    }

    @XmlElement(name = "unlocking-content")
    public Unlockingcontent getUnlockingcontent() {
        return unlockingcontent;
    }

    public void setUnlockingcontent(Unlockingcontent unlockingcontent) {
        this.unlockingcontent = unlockingcontent;
    }
}
