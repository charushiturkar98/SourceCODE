package com.inetpsa.o8d.weba2dr.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Frames. CAP-25017
 */
@XmlRootElement(name = "frames")
@XmlType(propOrder = { "frame" })
public class Frames {
    private List<Frame> frame;

    public List<Frame> getFrame() {
        return frame;
    }

    public void setFrame(List<Frame> frame) {
        this.frame = frame;
    }

}
