/*
 * Creation : 17 Jun 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.weba2dr.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class UnlockBsrfResponseBean.CAP-25017
 */
@JsonInclude(Include.NON_NULL)
public class UnlockBsrfResponseBean {

    private String returnCode;
    private String indexConfidence;
    private String unlockingValue;
    private String comments;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getIndexConfidence() {
        return indexConfidence;
    }

    public void setIndexConfidence(String indexConfidence) {
        this.indexConfidence = indexConfidence;
    }

    public String getUnlockingValue() {
        return unlockingValue;
    }

    public void setUnlockingValue(String unlockingValue) {
        this.unlockingValue = unlockingValue;
    }

}
