package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Repairingrequests.CAP-25017
 */
@XmlRootElement(name = "repairingrequests")
@XmlType(propOrder = { "parameters", "requests" })
public class Repairingrequests {
    private Parameters parameters;
    private Requests requests;

    @XmlElement(name = "parameters")
    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }

    @XmlElement(name = "requests")
    public Requests getRequests() {
        return requests;
    }

    public void setRequests(Requests requests) {
        this.requests = requests;
    }

}
