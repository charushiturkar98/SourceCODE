/*
 * Creation : 12 Jul 2023
 */
package com.inetpsa.o8d.weba2dr.beans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService;
import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;

/**
 * The Class CorvetDocsoa.
 */
public class CorvetDocsoa {

    /** The Constant logger. */
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(CorvetDocsoa.class);

    /** The list. */
    static List<String> codeList = new ArrayList<>(
            Arrays.asList(RelayConstants.CODE_1, RelayConstants.CODE_2, RelayConstants.CODE_3, RelayConstants.CODE_4, RelayConstants.CODE_5,
                    RelayConstants.CODE_6, RelayConstants.CODE_7, RelayConstants.CODE_8, RelayConstants.CODE_9, RelayConstants.CODE_10,
                    RelayConstants.CODE_11, RelayConstants.CODE_12, RelayConstants.CODE_13, RelayConstants.CODE_14, RelayConstants.CODE_15));

    /** The lcdv index. */
    static List<Integer> lcdvIndexes = new ArrayList<>(Arrays.asList(RelayConstants.LCDV_INDEX_0, RelayConstants.LCDV_INDEX_1,
            RelayConstants.LCDV_INDEX_6, RelayConstants.LCDV_INDEX_9, RelayConstants.LCDV_INDEX_14, RelayConstants.LCDV_INDEX_15));

    /**
     * Adds the lcdv base attributes.
     *
     * @param corvetOutput  the corvet output
     * @param attributCodes the attribut codes
     */
    public void addLcdvBaseAttributes(String corvetOutput, List<String> attributCodes) {
        List<String> lcdvBaseAttributes = new ArrayList<>();
        try {
            if (!corvetOutput.isEmpty()) {
                String lcdvBaseValue = corvetOutput.substring(
                        corvetOutput.indexOf(AbstractRelayCommunicationService.LCDV_BASE) + AbstractRelayCommunicationService.LCDV_BASE.length(),
                        corvetOutput.indexOf(AbstractRelayCommunicationService.LCDV_BASE_END));
                int lcdvBaseIndex = 0;
                String lcdvCode;
                for (int listIndex = 0; listIndex < codeList.size(); listIndex++) {
                    while (lcdvBaseIndex < lcdvBaseValue.length()) {
                        if (lcdvIndexes.contains(lcdvBaseIndex)) {
                            lcdvCode = codeList.get(listIndex) + lcdvBaseValue.charAt(lcdvBaseIndex);
                            lcdvBaseIndex++;
                        } else {
                            lcdvCode = codeList.get(listIndex) + lcdvBaseValue.charAt(lcdvBaseIndex) + lcdvBaseValue.charAt(lcdvBaseIndex + 1);
                            lcdvBaseIndex += 2;
                        }
                        lcdvBaseAttributes.add(lcdvCode);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Exception while parsing the lcdv code list: ", e);
        }
        attributCodes.addAll(lcdvBaseAttributes);
    }

}