package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class Unlockingcontent. CAP-25017
 */
@XmlRootElement(name = "unlocking-content")
public class Unlockingcontent {
    private String unlockingvalue;
    private String id;
    private String text;

    @XmlElement(name = "unlocking-value")
    public String getUnlockingvalue() {
        return unlockingvalue;
    }

    public void setUnlockingvalue(String unlockingvalue) {
        this.unlockingvalue = unlockingvalue;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

}
