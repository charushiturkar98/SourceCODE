package com.inetpsa.o8d.weba2dr.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class Parameters.CAP-25017
 */
@XmlRootElement(name = "parameters")
@XmlType(propOrder = { "vin", "ecu", "casutilisation", "indexconfidence" })
public class Parameters {
    private String vin;
    private Ecu ecu;
    private String casutilisation;
    private String indexconfidence;

    @XmlElement(name = "vin")
    public String getVin() {
        return vin;
    }

    @XmlElement(name = "index-confidence")
    public String getIndexconfidence() {
        return indexconfidence;
    }

    public void setIndexconfidence(String indexconfidence) {
        this.indexconfidence = indexconfidence;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    @XmlElement(name = "ecu")
    public Ecu getEcu() {
        return ecu;
    }

    public void setEcu(Ecu ecu) {
        this.ecu = ecu;
    }

    @XmlElement(name = "cas-utilisation")
    public String getCasutilisation() {
        return casutilisation;
    }

    public void setCasutilisation(String casutilisation) {
        this.casutilisation = casutilisation;
    }

}
