/*
  * Creation : Jul 20, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.hash.Hashing;
import com.google.common.io.BaseEncoding;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;

/**
 * The Class TokenGen.
 */
public class TokenGen {

    /**
     * Instantiates a new token gen.
     */
    TokenGen() {
    }

    /** The server configuration manager. */
    static ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();

    /** The kid. */
    static String kid = StringUtils.EMPTY;

    /** The request body after token generation. */
    private static JSONObject requestBodyAfterTokenGeneration;

    /** The config bean ADA. */
    static ADAServiceConfig configBeanADA;
    // Without this static block, you will get a parsing error when parsing the private key and
    // It wont recognize the key as PKCS#8 format
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    /**
     * Gets the request body after token generation.
     *
     * @return the request body after token generation
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static ByteArrayOutputStream getRequestBodyAfterTokenGeneration() throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] requestBodyArray = requestBodyAfterTokenGeneration.toString().getBytes();
        out.write(requestBodyArray);
        return out;
    }

    /**
     * Creates the request body and add exp nbf iat.
     *
     * @param popTokenPayload the pop token payload
     * @param service the service
     * @throws JsonProcessingException the json processing exception
     * @throws JSONException the JSON exception
     */
    private static void createRequestBodyAndAddExpNbfIat(PopTokenPayload popTokenPayload, String service)
            throws JsonProcessingException, JSONException {
        String json = StringUtils.EMPTY;

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        if (service.equals(RelayConstants.ADA_CERTIFICATE)) {
            json = ow.writeValueAsString(popTokenPayload.getRequestBodyForAdaCall());
        }
        if (service.equals(RelayConstants.ADA_CHALLENGE)) {
            json = ow.writeValueAsString(popTokenPayload.getRequestBodyForSignChallenageCall());
        }
        if (service.equals(RelayConstants.ADA_TRACK_RESPONSE)) {
            json = ow.writeValueAsString(popTokenPayload.getRequestBodyForTrakResponseCall());
        }
        // Cap-28735 x250 lot2 witexedi
        if (service.equals(RelayConstants.TBM_HU)) {
            json = ow.writeValueAsString(popTokenPayload.getRequestBodyForTbmhuCall());

        }
        requestBodyAfterTokenGeneration = new JSONObject(json);
        requestBodyAfterTokenGeneration.put(RelayConstants.EXP, popTokenPayload.getExp());
        requestBodyAfterTokenGeneration.put(RelayConstants.IAT, popTokenPayload.getIat());
        // Cap-28735 x250 lot2 witexedi
        if (service.equals(RelayConstants.TBM_HU)) {
            requestBodyAfterTokenGeneration.put(RelayConstants.MARKET, RelayConstants.THE_1000);
            requestBodyAfterTokenGeneration.put(RelayConstants.SERVICE, RelayConstants.ECU_REPLACEMENT);
        } else {
            requestBodyAfterTokenGeneration.put(RelayConstants.NBF, popTokenPayload.getNbf());
        }
        if (service.equals(RelayConstants.ADA_CERTIFICATE)) {
            requestBodyAfterTokenGeneration.put(RelayConstants.MARKET, StringUtils.EMPTY);
        }
    }

    /**
     * Gets the pop token.
     *
     * @param service the service
     * @return the pop token
     * @throws JSONException the JSON exception
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws InvalidKeyException the invalid key exception
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeySpecException the invalid key spec exception
     * @throws SignatureException the signature exception
     * @throws ConfigurationException the configuration exception
     * @throws UnrecoverableKeyException the unrecoverable key exception
     * @throws CertificateException the certificate exception
     * @throws KeyStoreException the key store exception
     */
    public static String getPopToken(String service) throws JSONException, IOException, InvalidKeyException, NoSuchAlgorithmException,
            InvalidKeySpecException, SignatureException, ConfigurationException, UnrecoverableKeyException, CertificateException, KeyStoreException {

        readConfigFromFileForADA(service);

        // creating the creation and expiration time.
        long iat = System.currentTimeMillis() / RelayConstants.TOKEN_DIVIDER; // creation time
        long exp = iat + RelayConstants.TOKEN_EXPIRATION; // expiration time

        // The complete payload
        PopTokenPayload popTokenPayload = new PopTokenPayload();
        popTokenPayload.setExp(exp);
        popTokenPayload.setIat(iat);

        // Cap-28735 x250 lot2 witexedi
        if (!service.equals(RelayConstants.TBM_HU)) {
            popTokenPayload.setNbf(iat);
        }

        // To update the request body with the token informations
        createRequestBodyAndAddExpNbfIat(popTokenPayload, service);
        popTokenPayload.setDigest(hmacSha256(requestBodyAfterTokenGeneration));

        // The header Json
        JSONObject header = new JSONObject();
        header.put(RelayConstants.ALG, RelayConstants.RS256); // HS256 or RS256
        header.put(RelayConstants.TYP, RelayConstants.JWT);
        header.put(RelayConstants.KID, configBeanADA.getKid());

        // Reading data from the private key to sing the popToken
        InputStream is = TokenGen.class.getClassLoader().getResourceAsStream(configBeanADA.getPrivateKeyName());
        String privateKey = jksFileLoader(configBeanADA.getPrivateKeyPwd(), configBeanADA.getPrivateKeyAlias(), is);

        // mapping the popTokenPayload to create a json from it
        JSONObject thePayloadJson = new JSONObject();
        if (service.equals(RelayConstants.TBM_HU)) {
            thePayloadJson = requestBodyAfterTokenGeneration;
        } else {
            thePayloadJson.put(RelayConstants.EXP, popTokenPayload.getExp());
            thePayloadJson.put(RelayConstants.IAT, popTokenPayload.getIat());
            thePayloadJson.put(RelayConstants.NBF, popTokenPayload.getNbf());
            thePayloadJson.put(RelayConstants.DIGEST, popTokenPayload.getDigest());
        }

        return jwtTokenGenerator(header, thePayloadJson, privateKey, RelayConstants.RS256);
    }

    /**
     * Read config from file for ADA.
     *
     * @param service the service
     * @return the ADA service config
     * @throws ConfigurationException the configuration exception
     */
    public static ADAServiceConfig readConfigFromFileForADA(String service) throws ConfigurationException {
        // Loading the configuration file
        AbstractFileConfiguration config = new PropertiesConfiguration();
        config.setDelimiterParsingDisabled(true);
        config.load(Thread.currentThread().getContextClassLoader().getResource(RelayConstants.ADA_CONFIG_FILE));
        configBeanADA = new ADAServiceConfig();
        configBeanADA.setPrivateKeyName(config.getString(RelayConstants.ADA_PRIVATE_KEY));
        configBeanADA.setPrivateKeyPwd(config.getString(RelayConstants.JKS_LOCAL_PASS));
        if (service.equals(RelayConstants.TBM_HU)) {
            configBeanADA.setKid(config.getString(RelayConstants.TBMHU_KID_VALUE));
            configBeanADA.setPrivateKeyAlias(config.getString(RelayConstants.TBMHU_LOCAL_ALAIS));
            configBeanADA.setTbmhuPw(config.getString(RelayConstants.DSS_TBMHU_PASSWORD));
            configBeanADA.setTbmhuUn(config.getString(RelayConstants.DSS_TBMHU_USERNAME));
        } else {
            configBeanADA.setKid(config.getString(RelayConstants.ADA_KID_VALUE));
            configBeanADA.setPrivateKeyAlias(config.getString(RelayConstants.JKS_LOCAL_ALAIS));
            configBeanADA.setForcedCipherSuit(config.getString(RelayConstants.ADA_FORCED_CIPHER_SUITE));
        }
        return configBeanADA;
    }

    /**
     * Rsa sha 256.
     *
     * @param tokenData the token data
     * @param privateKey the private key
     * @return the string
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeyException the invalid key exception
     * @throws InvalidKeySpecException the invalid key spec exception
     * @throws SignatureException the signature exception
     */
    private static String rsaSha256(String tokenData, String privateKey)
            throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, SignatureException {
        privateKey = privateKey.replace("-----BEGIN RSA PRIVATE KEY-----", StringUtils.EMPTY)
                .replace("-----END RSA PRIVATE KEY-----", StringUtils.EMPTY).replace("\n", StringUtils.EMPTY).replace("\r", StringUtils.EMPTY);
        byte[] b1 = RelayConstants.base64.decode(privateKey);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
        KeyFactory kf = KeyFactory.getInstance(RelayConstants.RSA);
        // signing the message
        Signature privateSignature = Signature.getInstance(RelayConstants.SHA256WITHRSA);
        privateSignature.initSign(kf.generatePrivate(spec));

        privateSignature.update(tokenData.getBytes(StandardCharsets.UTF_8));
        byte[] signature = privateSignature.sign();

        return RelayConstants.base64.encodeAsString(signature);
    }

    /**
     * Un pad.
     *
     * @param signature the signature
     * @return the string
     */
    private static String unPad(String signature) {
        return signature.replaceAll("\\=", StringUtils.EMPTY).replaceAll("\\+", "-").replaceAll("\\/", "_");
    }

    /**
     * Jwt token generator.
     *
     * @param header the header
     * @param payload the payload
     * @param privateKey the private key
     * @param algo the algo
     * @return the string
     * @throws InvalidKeyException the invalid key exception
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeySpecException the invalid key spec exception
     * @throws SignatureException the signature exception
     */
    private static String jwtTokenGenerator(JSONObject header, JSONObject payload, String privateKey, String algo)
            throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
        // Creating the signature according to the algo
        String signature = StringUtils.EMPTY;
        if (algo.equals(RelayConstants.HS256)) {
            signature = hmacSha256(base64UrlEncode(header) + "." + base64UrlEncode(payload), privateKey);
        }
        if (algo.equals(RelayConstants.RS256)) {
            signature = unPad(rsaSha256(base64UrlEncode(header) + "." + base64UrlEncode(payload), privateKey));
        }
        // here we are hashing and encrypting the pop token
        return base64UrlEncode(header) + "." + base64UrlEncode(payload) + "." + signature;

    }

    /**
     * Hmac sha 256.
     *
     * @param tokenData the token data
     * @param pKey the key
     * @return the string
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeyException the invalid key exception
     */
    private static String hmacSha256(String tokenData, String pKey) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] hash = pKey.getBytes(StandardCharsets.UTF_8);
        Mac sha256Hmac = Mac.getInstance(RelayConstants.HMACSHA256);
        SecretKeySpec secretKey = new SecretKeySpec(hash, RelayConstants.HMACSHA256);
        sha256Hmac.init(secretKey);
        byte[] signedBytes = sha256Hmac.doFinal(tokenData.getBytes(StandardCharsets.UTF_8));
        return unPad(BaseEncoding.base64().encode(signedBytes));

    }

    /**
     * Base 64 url encode.
     *
     * @param tokenObject the token object
     * @return the string
     */
    private static String base64UrlEncode(Object tokenObject) {
        return new String(Base64.encodeBase64(tokenObject.toString().getBytes(), false, true));
    }

    /**
     * Hmac sha 256.
     *
     * @param tokenObject the token object
     * @return the string
     */
    private static String hmacSha256(Object tokenObject) {
        return BaseEncoding.base64().encode(Hashing.sha256().hashString(tokenObject.toString(), StandardCharsets.UTF_8).asBytes());

    }

    /**
     * Jks file loader.
     *
     * @param password the password
     * @param alais the alais
     * @param is the is
     * @return the string
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws CertificateException the certificate exception
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws KeyStoreException the key store exception
     * @throws UnrecoverableKeyException the unrecoverable key exception
     */
    private static String jksFileLoader(String password, String alais, InputStream is)
            throws NoSuchAlgorithmException, CertificateException, IOException, KeyStoreException, UnrecoverableKeyException {
        char[] pw = password.toCharArray();
        KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
        keystore.load(is, pw);
        Key key = keystore.getKey(alais, pw);
        return RelayConstants.base64.encodeAsString(key.getEncoded());

    }
}