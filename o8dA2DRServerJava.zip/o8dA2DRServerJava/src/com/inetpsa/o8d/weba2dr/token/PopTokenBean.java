/*
 * Creation : Jul 20, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class PopTokenBean.
 */
public class PopTokenBean {

    // Only the payload, the header will be hard coded whenever we are creating a new popToken

    /** The pop token payload. */
    PopTokenPayload popTokenPayload;

    /**
     * Instantiates a new pop token bean.
     *
     * @param popTokenPayload the pop token payload
     */
    public PopTokenBean(PopTokenPayload popTokenPayload) {
        super();
        this.popTokenPayload = popTokenPayload;
    }

    /**
     * Instantiates a new pop token bean.
     */
    public PopTokenBean() {

    }

    /**
     * Gets the pop token payload.
     *
     * @return the pop token payload
     */
    public PopTokenPayload getPopTokenPayload() {
        return popTokenPayload;
    }

    /**
     * Sets the pop token payload.
     *
     * @param popTokenPayload the new pop token payload
     */
    public void setPopTokenPayload(PopTokenPayload popTokenPayload) {
        this.popTokenPayload = popTokenPayload;
    }

}
