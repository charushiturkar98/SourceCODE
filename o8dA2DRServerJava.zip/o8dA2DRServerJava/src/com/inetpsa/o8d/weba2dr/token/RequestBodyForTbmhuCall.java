/*
 * Creation : Oct 7, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class RequestBodyForTbmhuCall.
 */
public class RequestBodyForTbmhuCall {

    /** The service. */
    String service;

    /** The market. */
    String market;

    /** The ecu. */
    String ecu;

    /** The vin. */
    String vin;

    /** The serial number. */
    String serialNumber;

    /** The sw component id hw number. */
    String swComponentIdHwNumber;

    /** The sw component id hw version. */
    String swComponentIdHwVersion;

    /** The fw version sw number. */
    String fwVersionSwNumber;

    /** The fw version sw version. */
    String fwVersionSwVersion;

    /** The firmware version. */
    String firmwareVersion;

    /** The modem data imei. */
    String modemDataImei;

    /** The sim identifier iccid. */
    String simIdentifierIccid;

    /** The international mobile subscriber identity imsi. */
    String internationalMobileSubscriberIdentityImsi;

    /** The mobile subscriber isdn msisdn. */
    String mobileSubscriberIsdnMsisdn;

    /** The vci SN. */
    String vciSN;

    /** The year. */
    String year;

    /** The body. */
    String body;

    /** The dealer code. */
    String dealerCode;

    /** The user id. */
    String userId;

    /** The iat. */
    String iat;

    /** The exp. */
    String exp;

    /**
     * Instantiates a new request body for tbmhu call.
     */
    public RequestBodyForTbmhuCall() {
    }

    /**
     * Instantiates a new request body for tbmhu call.
     *
     * @param service the service
     * @param market the market
     * @param ecu the ecu
     * @param vin the vin
     * @param serialNumber the serial number
     * @param swComponentIdHwNumber the sw component id hw number
     * @param swComponentIdHwVersion the sw component id hw version
     * @param fwVersionSwNumber the fw version sw number
     * @param fwVersionSwVersion the fw version sw version
     * @param firmwareVersion the firmware version
     * @param modemDataImei the modem data imei
     * @param simIdentifierIccid the sim identifier iccid
     * @param internationalMobileSubscriberIdentityImsi the international mobile subscriber identity imsi
     * @param mobileSubscriberIsdnMsisdn the mobile subscriber isdn msisdn
     * @param vciSN the vci SN
     * @param year the year
     * @param body the body
     * @param dealerCode the dealer code
     * @param userId the user id
     * @param iat the iat
     * @param exp the exp
     */
    public RequestBodyForTbmhuCall(String service, String market, String ecu, String vin, String serialNumber, String swComponentIdHwNumber,
            String swComponentIdHwVersion, String fwVersionSwNumber, String fwVersionSwVersion, String firmwareVersion, String modemDataImei,
            String simIdentifierIccid, String internationalMobileSubscriberIdentityImsi, String mobileSubscriberIsdnMsisdn, String vciSN, String year,
            String body, String dealerCode, String userId, String iat, String exp) {
        super();
        this.service = service;
        this.market = market;
        this.ecu = ecu;
        this.vin = vin;
        this.serialNumber = serialNumber;
        this.swComponentIdHwNumber = swComponentIdHwNumber;
        this.swComponentIdHwVersion = swComponentIdHwVersion;
        this.fwVersionSwNumber = fwVersionSwNumber;
        this.fwVersionSwVersion = fwVersionSwVersion;
        this.firmwareVersion = firmwareVersion;
        this.modemDataImei = modemDataImei;
        this.simIdentifierIccid = simIdentifierIccid;
        this.internationalMobileSubscriberIdentityImsi = internationalMobileSubscriberIdentityImsi;
        this.mobileSubscriberIsdnMsisdn = mobileSubscriberIsdnMsisdn;
        this.vciSN = vciSN;
        this.year = year;
        this.body = body;
        this.dealerCode = dealerCode;
        this.userId = userId;
        this.iat = iat;
        this.exp = exp;
    }

    /**
     * Gets the service.
     *
     * @return the service
     */
    public String getService() {
        return service;
    }

    /**
     * Sets the service.
     *
     * @param service the new service
     */
    public void setService(String service) {
        this.service = service;
    }

    /**
     * Gets the market.
     *
     * @return the market
     */
    public String getMarket() {
        return market;
    }

    /**
     * Sets the market.
     *
     * @param market the new market
     */
    public void setMarket(String market) {
        this.market = market;
    }

    /**
     * Gets the ecu.
     *
     * @return the ecu
     */
    public String getEcu() {
        return ecu;
    }

    /**
     * Sets the ecu.
     *
     * @param ecu the new ecu
     */
    public void setEcu(String ecu) {
        this.ecu = ecu;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the serial number.
     *
     * @return the serial number
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the serial number.
     *
     * @param serialNumber the new serial number
     */
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * Gets the sw component id hw number.
     *
     * @return the sw component id hw number
     */
    public String getSwComponentIdHwNumber() {
        return swComponentIdHwNumber;
    }

    /**
     * Sets the sw component id hw number.
     *
     * @param swComponentIdHwNumber the new sw component id hw number
     */
    public void setSwComponentIdHwNumber(String swComponentIdHwNumber) {
        this.swComponentIdHwNumber = swComponentIdHwNumber;
    }

    /**
     * Gets the sw component id hw version.
     *
     * @return the sw component id hw version
     */
    public String getSwComponentIdHwVersion() {
        return swComponentIdHwVersion;
    }

    /**
     * Sets the sw component id hw version.
     *
     * @param swComponentIdHwVersion the new sw component id hw version
     */
    public void setSwComponentIdHwVersion(String swComponentIdHwVersion) {
        this.swComponentIdHwVersion = swComponentIdHwVersion;
    }

    /**
     * Gets the fw version sw number.
     *
     * @return the fw version sw number
     */
    public String getFwVersionSwNumber() {
        return fwVersionSwNumber;
    }

    /**
     * Sets the fw version sw number.
     *
     * @param fwVersionSwNumber the new fw version sw number
     */
    public void setFwVersionSwNumber(String fwVersionSwNumber) {
        this.fwVersionSwNumber = fwVersionSwNumber;
    }

    /**
     * Gets the fw version sw version.
     *
     * @return the fw version sw version
     */
    public String getFwVersionSwVersion() {
        return fwVersionSwVersion;
    }

    /**
     * Sets the fw version sw version.
     *
     * @param fwVersionSwVersion the new fw version sw version
     */
    public void setFwVersionSwVersion(String fwVersionSwVersion) {
        this.fwVersionSwVersion = fwVersionSwVersion;
    }

    /**
     * Gets the firmware version.
     *
     * @return the firmware version
     */
    public String getFirmwareVersion() {
        return firmwareVersion;
    }

    /**
     * Sets the firmware version.
     *
     * @param firmwareVersion the new firmware version
     */
    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    /**
     * Gets the modem data imei.
     *
     * @return the modem data imei
     */
    public String getModemDataImei() {
        return modemDataImei;
    }

    /**
     * Sets the modem data imei.
     *
     * @param modemDataImei the new modem data imei
     */
    public void setModemDataImei(String modemDataImei) {
        this.modemDataImei = modemDataImei;
    }

    /**
     * Gets the sim identifier iccid.
     *
     * @return the sim identifier iccid
     */
    public String getSimIdentifierIccid() {
        return simIdentifierIccid;
    }

    /**
     * Sets the sim identifier iccid.
     *
     * @param simIdentifierIccid the new sim identifier iccid
     */
    public void setSimIdentifierIccid(String simIdentifierIccid) {
        this.simIdentifierIccid = simIdentifierIccid;
    }

    /**
     * Gets the international mobile subscriber identity imsi.
     *
     * @return the international mobile subscriber identity imsi
     */
    public String getInternationalMobileSubscriberIdentityImsi() {
        return internationalMobileSubscriberIdentityImsi;
    }

    /**
     * Sets the international mobile subscriber identity imsi.
     *
     * @param internationalMobileSubscriberIdentityImsi the new international mobile subscriber identity imsi
     */
    public void setInternationalMobileSubscriberIdentityImsi(String internationalMobileSubscriberIdentityImsi) {
        this.internationalMobileSubscriberIdentityImsi = internationalMobileSubscriberIdentityImsi;
    }

    /**
     * Gets the mobile subscriber isdn msisdn.
     *
     * @return the mobile subscriber isdn msisdn
     */
    public String getMobileSubscriberIsdnMsisdn() {
        return mobileSubscriberIsdnMsisdn;
    }

    /**
     * Sets the mobile subscriber isdn msisdn.
     *
     * @param mobileSubscriberIsdnMsisdn the new mobile subscriber isdn msisdn
     */
    public void setMobileSubscriberIsdnMsisdn(String mobileSubscriberIsdnMsisdn) {
        this.mobileSubscriberIsdnMsisdn = mobileSubscriberIsdnMsisdn;
    }

    /**
     * Gets the vci SN.
     *
     * @return the vci SN
     */
    public String getVciSN() {
        return vciSN;
    }

    /**
     * Sets the vci SN.
     *
     * @param vciSN the new vci SN
     */
    public void setVciSN(String vciSN) {
        this.vciSN = vciSN;
    }

    /**
     * Gets the year.
     *
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * Sets the year.
     *
     * @param year the new year
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * Gets the body.
     *
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * Sets the body.
     *
     * @param body the new body
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * Gets the dealer code.
     *
     * @return the dealer code
     */
    public String getDealerCode() {
        return dealerCode;
    }

    /**
     * Sets the dealer code.
     *
     * @param dealerCode the new dealer code
     */
    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the iat.
     *
     * @return the iat
     */
    public String getIat() {
        return iat;
    }

    /**
     * Sets the iat.
     *
     * @param iat the new iat
     */
    public void setIat(String iat) {
        this.iat = iat;
    }

    /**
     * Gets the exp.
     *
     * @return the exp
     */
    public String getExp() {
        return exp;
    }

    /**
     * Sets the exp.
     *
     * @param exp the new exp
     */
    public void setExp(String exp) {
        this.exp = exp;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RequestBodyForTbmhuCall [service=" + service + ", market=" + market + ", ecu=" + ecu + ", vin=" + vin + ", serialNumber="
                + serialNumber + ", swComponentIdHwNumber=" + swComponentIdHwNumber + ", swComponentIdHwVersion=" + swComponentIdHwVersion
                + ", fwVersionSwNumber=" + fwVersionSwNumber + ", fwVersionSwVersion=" + fwVersionSwVersion + ", firmwareVersion=" + firmwareVersion
                + ", modemDataImei=" + modemDataImei + ", simIdentifierIccid=" + simIdentifierIccid + ", internationalMobileSubscriberIdentityImsi="
                + internationalMobileSubscriberIdentityImsi + ", mobileSubscriberIsdnMsisdn=" + mobileSubscriberIsdnMsisdn + ", vciSN=" + vciSN
                + ", year=" + year + ", body=" + body + ", dealerCode=" + dealerCode + ", userId=" + userId + ", iat=" + iat + ", exp=" + exp + "]";
    }

}
