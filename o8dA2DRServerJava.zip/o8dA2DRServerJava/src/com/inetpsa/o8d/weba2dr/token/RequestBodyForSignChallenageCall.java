/*
 * Creation : Sep 14, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class RequestBodyForSignChallenageCall.
 */
public class RequestBodyForSignChallenageCall {

    /** The session ID. */
    private String sessionID;

    /** The ecu challenge. */
    private String ecuChallenge;

    /**
     * Instantiates a new request body for sign challenage call.
     */
    public RequestBodyForSignChallenageCall() {

    }

    /**
     * Gets the session ID.
     *
     * @return the session ID
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the session ID.
     *
     * @param sessionID the new session ID
     */
    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    /**
     * Gets the ecu challenge.
     *
     * @return the ecu challenge
     */
    public String getEcuChallenge() {
        return ecuChallenge;
    }

    /**
     * Sets the ecu challenge.
     *
     * @param ecuChallenge the new ecu challenge
     */
    public void setEcuChallenge(String ecuChallenge) {
        this.ecuChallenge = ecuChallenge;
    }

    /**
     * Instantiates a new request body for sign challenage call.
     *
     * @param sessionID    the session ID
     * @param ecuChallenge the ecu challenge
     */
    public RequestBodyForSignChallenageCall(String sessionID, String ecuChallenge) {
        super();
        this.sessionID = sessionID;
        this.ecuChallenge = ecuChallenge;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RequestBodyForSignChallenageCall [sessionID=" + sessionID + ", ecuChallenge=" + ecuChallenge + "]";
    }

}
