/*
 * Creation : Jul 22, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

import com.inetpsa.o8d.a2dr.service.relay.RewriteResponseRelayCommunicationService;

/**
 * The Class PopTokenPayload.
 */
public class PopTokenPayload {

    /** The digest. */
    private String digest;

    /** The iat. */
    private Long iat;

    /** The nbf. */
    private Long nbf;

    /** The exp. */
    private Long exp;

    /** The request body for ada call. */
    private RequestBodyForAdaCall requestBodyForAdaCall;

    /** The request body for sign challenage call. */
    private RequestBodyForSignChallenageCall requestBodyForSignChallenageCall;

    /** The request body for trak response call. */
    private RequestBodyForTrakResponseCall requestBodyForTrakResponseCall;

    /**
     * Instantiates a new pop token payload.
     *
     * @param digest the digest
     * @param iat the iat
     * @param nbf the nbf
     * @param exp the exp
     * @param requestBodyForAdaCall the request body for ada call
     * @param requestBodyForSignChallenageCall the request body for sign challenage call
     * @param requestBodyForTrakResponseCall the request body for trak response call
     */
    public PopTokenPayload(String digest, Long iat, Long nbf, Long exp, RequestBodyForAdaCall requestBodyForAdaCall,
            RequestBodyForSignChallenageCall requestBodyForSignChallenageCall, RequestBodyForTrakResponseCall requestBodyForTrakResponseCall) {
        super();
        this.digest = digest;
        this.iat = iat;
        this.nbf = nbf;
        this.exp = exp;
        this.requestBodyForAdaCall = requestBodyForAdaCall;
        this.requestBodyForSignChallenageCall = requestBodyForSignChallenageCall;
        this.requestBodyForTrakResponseCall = requestBodyForTrakResponseCall;
    }

    /**
     * Instantiates a new pop token payload.
     */
    public PopTokenPayload() {
    }

    /**
     * Gets the digest.
     *
     * @return the digest
     */
    public String getDigest() {
        return digest;
    }

    /**
     * Sets the digest.
     *
     * @param digest the new digest
     */
    public void setDigest(String digest) {
        this.digest = digest;
    }

    /**
     * Gets the iat.
     *
     * @return the iat
     */
    public Long getIat() {
        return iat;
    }

    /**
     * Sets the iat.
     *
     * @param iat the new iat
     */
    public void setIat(Long iat) {
        this.iat = iat;
    }

    /**
     * Gets the nbf.
     *
     * @return the nbf
     */
    public Long getNbf() {
        return nbf;
    }

    /**
     * Sets the nbf.
     *
     * @param nbf the new nbf
     */
    public void setNbf(Long nbf) {
        this.nbf = nbf;
    }

    /**
     * Gets the exp.
     *
     * @return the exp
     */
    public Long getExp() {
        return exp;
    }

    /**
     * Sets the exp.
     *
     * @param exp the new exp
     */
    public void setExp(Long exp) {
        this.exp = exp;
    }

    /**
     * Gets the request body for ada call.
     *
     * @return the request body for ada call
     */
    public RequestBodyForAdaCall getRequestBodyForAdaCall() {
        requestBodyForAdaCall = RewriteResponseRelayCommunicationService.requestBodyForAdaCallFetched;
        return requestBodyForAdaCall;
    }

    /**
     * Gets the request body for sign challenage call.
     *
     * @return the request body for sign challenage call
     */
    public RequestBodyForSignChallenageCall getRequestBodyForSignChallenageCall() {
        requestBodyForSignChallenageCall = RewriteResponseRelayCommunicationService.requestBodyForSignChallenageFetched;
        return requestBodyForSignChallenageCall;
    }

    /**
     * Gets the request body for trak response call.
     *
     * @return the request body for trak response call
     */
    public RequestBodyForTrakResponseCall getRequestBodyForTrakResponseCall() {
        requestBodyForTrakResponseCall = RewriteResponseRelayCommunicationService.requestBodyForTrakResponseCall;
        return requestBodyForTrakResponseCall;
    }

    /**
     * Gets the request body for tbmhu call.
     *
     * @return the request body for tbmhu call
     */
    public RequestBodyForTbmhuCall getRequestBodyForTbmhuCall() {
        return RewriteResponseRelayCommunicationService.requestBodyForTbmhuCall;
    }

    /**
     * Sets the request body for ada call.
     *
     * @param requestBodyForAdaCall the new request body for ada call
     */
    /**
     * @param requestBodyForAdaCall
     */
    public void setRequestBodyForAdaCall(RequestBodyForAdaCall requestBodyForAdaCall) {
        this.requestBodyForAdaCall = requestBodyForAdaCall;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "PopTokenPayload [digest=" + digest + ", iat=" + iat + ", nbf=" + nbf + ", exp=" + exp + ", requestBodyForAdaCall="
                + requestBodyForAdaCall + "]";
    }

}
