/*
 * Creation : Sep 21, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class RequestBodyForTrakResponseCall.
 */
public class RequestBodyForTrakResponseCall {

    /** The session ID. */
    private String sessionID;

    /** The ecu result. */
    private boolean ecuResult;

    /** The ecu response. */
    private String ecuResponse;

    /** The user token. */
    private String userToken;

    /**
     * Gets the user token.
     *
     * @return the user token
     */
    public String getUserToken() {
        return userToken;
    }

    /**
     * Sets the user token.
     *
     * @param userToken the new user token
     */
    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    /**
     * Instantiates a new request body for trak response call.
     *
     * @param sessionID   the session ID
     * @param ecuResult   the ecu result
     * @param ecuResponse the ecu response
     */
    public RequestBodyForTrakResponseCall(String sessionID, boolean ecuResult, String ecuResponse) {
        super();
        this.sessionID = sessionID;
        this.ecuResult = ecuResult;
        this.ecuResponse = ecuResponse;
    }

    /**
     * Instantiates a new request body for trak response call.
     */
    public RequestBodyForTrakResponseCall() {

    }

    /**
     * Gets the session ID.
     *
     * @return the session ID
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the session ID.
     *
     * @param sessionID the new session ID
     */
    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    /**
     * Checks if is ecu result.
     *
     * @return true, if is ecu result
     */
    public boolean isEcuResult() {
        return ecuResult;
    }

    /**
     * Sets the ecu result.
     *
     * @param ecuResult the new ecu result
     */
    public void setEcuResult(boolean ecuResult) {
        this.ecuResult = ecuResult;
    }

    /**
     * Gets the ecu response.
     *
     * @return the ecu response
     */
    public String getEcuResponse() {
        return ecuResponse;
    }

    /**
     * Sets the ecu response.
     *
     * @param ecuResponse the new ecu response
     */
    public void setEcuResponse(String ecuResponse) {
        this.ecuResponse = ecuResponse;
    }

}
