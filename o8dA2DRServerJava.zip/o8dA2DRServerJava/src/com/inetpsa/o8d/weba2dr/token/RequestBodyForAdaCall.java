/*
 * Creation : Jul 15, 2022
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class RequestBodyForAdaCall.
 */
public class RequestBodyForAdaCall {

    /** The vin. */
    private String vin;

    /** The sgw SN. */
    private String sgwSN;

    /** The ecu CANID. */
    private String ecuCANID;

    /** The ecu cert store UUID. */
    private String ecuCertStoreUUID;

    /** The ecu SN. */
    private String ecuSN;

    /** The user ID. */
    private String userid;

    /** The dealer code. */
    private String dealerCode;

    /** The market. */
    private String market;

    /** The ecu policy type. */
    private String ecuPolicyType;

    /** The tool ID. */
    private String externalToolID;

    /** The claimed role. */
    private String claimedRole;

    /** The user token. */
    private String userToken;

    /**
     * Instantiates a new request body for ada call.
     */
    public RequestBodyForAdaCall() {

    }

    /**
     * Instantiates a new request body for ada call.
     *
     * @param vIN              the v IN
     * @param sgwSN            the sgw SN
     * @param ecuCANID         the ecu CANID
     * @param ecuCertStoreUUID the ecu cert store UUID
     * @param ecuSN            the ecu SN
     * @param userid           the user ID
     * @param dealerCode       the dealer code
     * @param market           the market
     * @param ecuPolicyType    the ecu policy type
     * @param externalToolID   the tool ID
     * @param claimedRole      the claimed role
     * @param userToken        the user token
     * @param diagboxMode      the diagbox mode
     */
    public RequestBodyForAdaCall(String vIN, String sgwSN, String ecuCANID, String ecuCertStoreUUID, String ecuSN, String userid, String dealerCode,
            String market, String ecuPolicyType, String externalToolID, String claimedRole, String userToken, String diagboxMode) {
        super();
        vin = vIN;
        this.sgwSN = sgwSN;
        this.ecuCANID = ecuCANID;
        this.ecuCertStoreUUID = ecuCertStoreUUID;
        this.ecuSN = ecuSN;
        this.userid = userid;
        this.dealerCode = dealerCode;
        this.market = market;
        this.ecuPolicyType = ecuPolicyType;
        this.externalToolID = externalToolID;
        this.claimedRole = claimedRole;
        this.userToken = userToken;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVIN() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vIN the new vin
     */
    public void setVIN(String vIN) {
        vin = vIN;
    }

    /**
     * Gets the sgw SN.
     *
     * @return the sgw SN
     */
    public String getSgwSN() {
        return sgwSN;
    }

    /**
     * Sets the sgw SN.
     *
     * @param sgwSN the new sgw SN
     */
    public void setSgwSN(String sgwSN) {
        this.sgwSN = sgwSN;
    }

    /**
     * Gets the ecu CANID.
     *
     * @return the ecu CANID
     */
    public String getEcuCANID() {
        return ecuCANID;
    }

    /**
     * Sets the ecu CANID.
     *
     * @param ecuCANID the new ecu CANID
     */
    public void setEcuCANID(String ecuCANID) {
        this.ecuCANID = ecuCANID;
    }

    /**
     * Gets the ecu cert store UUID.
     *
     * @return the ecu cert store UUID
     */
    public String getEcuCertStoreUUID() {
        return ecuCertStoreUUID;
    }

    /**
     * Sets the ecu cert store UUID.
     *
     * @param ecuCertStoreUUID the new ecu cert store UUID
     */
    public void setEcuCertStoreUUID(String ecuCertStoreUUID) {
        this.ecuCertStoreUUID = ecuCertStoreUUID;
    }

    /**
     * Gets the ecu SN.
     *
     * @return the ecu SN
     */
    public String getEcuSN() {
        return ecuSN;
    }

    /**
     * Sets the ecu SN.
     *
     * @param ecuSN the new ecu SN
     */
    public void setEcuSN(String ecuSN) {
        this.ecuSN = ecuSN;
    }

    /**
     * Gets the user ID.
     *
     * @return the user ID
     */
    public String getUserId() {
        return userid;
    }

    /**
     * Sets the user ID.
     *
     * @param userid the new user ID
     */
    public void setUserId(String userid) {
        this.userid = userid;
    }

    /**
     * Gets the dealer code.
     *
     * @return the dealer code
     */
    public String getDealerCode() {
        return dealerCode;
    }

    /**
     * Sets the dealer code.
     *
     * @param dealerCode the new dealer code
     */
    public void setDealerCode(String dealerCode) {
        this.dealerCode = dealerCode;
    }

    /**
     * Gets the market.
     *
     * @return the market
     */
    public String getMarket() {
        return market;
    }

    /**
     * Sets the market.
     *
     * @param market the new market
     */
    public void setMarket(String market) {
        this.market = market;
    }

    /**
     * Gets the ecu policy type.
     *
     * @return the ecu policy type
     */
    public String getEcuPolicyType() {
        return ecuPolicyType;
    }

    /**
     * Sets the ecu policy type.
     *
     * @param ecuPolicyType the new ecu policy type
     */
    public void setEcuPolicyType(String ecuPolicyType) {
        this.ecuPolicyType = ecuPolicyType;
    }

    /**
     * Gets the tool ID.
     *
     * @return the tool ID
     */
    public String getExternalToolID() {
        return externalToolID;
    }

    /**
     * Sets the tool ID.
     *
     * @param externalToolID the new tool ID
     */
    public void setExternalToolID(String externalToolID) {
        this.externalToolID = externalToolID;
    }

    /**
     * Gets the claimed role.
     *
     * @return the claimed role
     */
    public String getClaimedRole() {
        return claimedRole;
    }

    /**
     * Sets the claimed role.
     *
     * @param claimedRole the new claimed role
     */
    public void setClaimedRole(String claimedRole) {
        this.claimedRole = claimedRole;
    }

    /**
     * Gets the user token.
     *
     * @return the user token
     */
    public String getUserToken() {
        return userToken;
    }

    /**
     * Sets the user token.
     *
     * @param userToken the new user token
     */
    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MessageDDC [VIN=" + vin + ", sgwSN=" + sgwSN + ", ecuCANID=" + ecuCANID + ", ecuCertStoreUUID=" + ecuCertStoreUUID + ", ecuSN="
                + ecuSN + ", userid=" + userid + ", dealerCode=" + dealerCode + ", market=" + market + ", ecuPolicyType=" + ecuPolicyType
                + ", externalToolID=" + externalToolID + ", claimedRole=" + claimedRole + ", userToken=" + userToken + "]";
    }

}
