/*
 * Creation : 14 Sep 2022
 */
/**
 * 
 */
package com.inetpsa.o8d.weba2dr.token;

/**
 * The Class ADAServiceConfig.
 *
 * @author E543118
 */
public class ADAServiceConfig {

    /** The kid. */
    private String kid;

    /** The private key name. */
    private String privateKeyName;

    /** The private key pwd. */
    private String privateKeyPwd;

    /** The private key alias. */
    private String privateKeyAlias;

    /** The proxy url. */
    private String proxyUrl;

    /** The proxy port. */
    private int proxyPort;

    /** The forced cipher suit. */
    private String forcedCipherSuit;

    /** The tbmhu pw. */
    private String tbmhuPw;

    /** The tbmhu un. */
    private String tbmhuUn;

    /**
     * Gets the tbmhu pw.
     *
     * @return the tbmhu pw
     */
    public String getTbmhuPw() {
        return tbmhuPw;
    }

    /**
     * Sets the tbmhu pw.
     *
     * @param tbmhuPw the new tbmhu pw
     */
    public void setTbmhuPw(String tbmhuPw) {
        this.tbmhuPw = tbmhuPw;
    }

    /**
     * Gets the tbmhu un.
     *
     * @return the tbmhu un
     */
    public String getTbmhuUn() {
        return tbmhuUn;
    }

    /**
     * Sets the tbmhu un.
     *
     * @param tbmhuUn the new tbmhu un
     */
    public void setTbmhuUn(String tbmhuUn) {
        this.tbmhuUn = tbmhuUn;
    }

    /**
     * Gets the kid.
     *
     * @return the kid
     */
    public String getKid() {
        return kid;
    }

    /**
     * Sets the kid.
     *
     * @param kid the new kid
     */
    public void setKid(String kid) {
        this.kid = kid;
    }

    /**
     * Gets the private key name.
     *
     * @return the private key name
     */
    public String getPrivateKeyName() {
        return privateKeyName;
    }

    /**
     * Sets the private key name.
     *
     * @param privateKeyName the new private key name
     */
    public void setPrivateKeyName(String privateKeyName) {
        this.privateKeyName = privateKeyName;
    }

    /**
     * Gets the private key pwd.
     *
     * @return the private key pwd
     */
    public String getPrivateKeyPwd() {
        return privateKeyPwd;
    }

    /**
     * Sets the private key pwd.
     *
     * @param privateKeyPwd the new private key pwd
     */
    public void setPrivateKeyPwd(String privateKeyPwd) {
        this.privateKeyPwd = privateKeyPwd;
    }

    /**
     * Gets the private key alias.
     *
     * @return the private key alias
     */
    public String getPrivateKeyAlias() {
        return privateKeyAlias;
    }

    /**
     * Sets the private key alias.
     *
     * @param privateKeyAlias the new private key alias
     */
    public void setPrivateKeyAlias(String privateKeyAlias) {
        this.privateKeyAlias = privateKeyAlias;
    }

    /**
     * Gets the proxy url.
     *
     * @return the proxy url
     */
    public String getProxyUrl() {
        return proxyUrl;
    }

    /**
     * Sets the proxy url.
     *
     * @param proxyUrl the new proxy url
     */
    public void setProxyUrl(String proxyUrl) {
        this.proxyUrl = proxyUrl;
    }

    /**
     * Gets the proxy port.
     *
     * @return the proxy port
     */
    public int getProxyPort() {
        return proxyPort;
    }

    /**
     * Sets the proxy port.
     *
     * @param proxyPort the new proxy port
     */
    public void setProxyPort(int proxyPort) {
        this.proxyPort = proxyPort;
    }

    /**
     * Gets the forced cipher suit.
     *
     * @return the forced cipher suit
     */
    public String getForcedCipherSuit() {
        return forcedCipherSuit;
    }

    /**
     * Sets the forced cipher suit.
     *
     * @param forcedCipherSuit the new forced cipher suit
     */
    public void setForcedCipherSuit(String forcedCipherSuit) {
        this.forcedCipherSuit = forcedCipherSuit;
    }

}
