/*
 * Creation : 27 Jun 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

/**
 * The Class LdapOauthConfig.
 */
public class LdapOauthConfig {

    /* Access Token Url */
    private String accessTokenUrl;

    /* Client ID */
    private String clientId;

    /* Client Secret */
    private String clientSecret;

    /* Scope */
    private String scope;

    /**
     * Getter accessTokenUrl
     * 
     * @return the accessTokenUrl
     */
    public String getAccessTokenUrl() {
        return accessTokenUrl;
    }

    /**
     * Setter accessTokenUrl
     * 
     * @param accessTokenUrl the accessTokenUrl to set
     */
    public void setAccessTokenUrl(String accessTokenUrl) {
        this.accessTokenUrl = accessTokenUrl;
    }

    /**
     * Getter clientId
     * 
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Setter clientId
     * 
     * @param clientId the clientId to set
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Getter clientSecret
     * 
     * @return the clientSecret
     */
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Setter clientSecret
     * 
     * @param clientSecret the clientSecret to set
     */
    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    /**
     * Getter scope
     * 
     * @return the scope
     */
    public String getScope() {
        return scope;
    }

    /**
     * Setter scope
     * 
     * @param scope the scope to set
     */
    public void setScope(String scope) {
        this.scope = scope;
    }

}
