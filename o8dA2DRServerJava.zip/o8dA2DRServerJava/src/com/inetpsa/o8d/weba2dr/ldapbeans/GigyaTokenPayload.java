/*
 * Creation : 30 May 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class GigyaTokenPayload.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GigyaTokenPayload implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 376806800901989930L;

    /** The api key. */
    private String apiKey;

    /** The call ID. */
    private String callID;

    /** The data. */
    private transient Data data;

    /**
     * Instantiates a new gigya token payload.
     */
    public GigyaTokenPayload() {
    }

    /**
     * Instantiates a new gigya token payload.
     *
     * @param apiKey the api key
     * @param callID the call ID
     * @param data the data
     */
    public GigyaTokenPayload(String apiKey, String callID, Data data) {
        super();
        this.apiKey = apiKey;
        this.callID = callID;
        this.data = data;
    }

    /**
     * Gets the api key.
     *
     * @return the api key
     */
    public String getApiKey() {
        return apiKey;
    }

    /**
     * Sets the api key.
     *
     * @param apiKey the new api key
     */
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * Gets the call ID.
     *
     * @return the call ID
     */
    public String getCallID() {
        return callID;
    }

    /**
     * Sets the call ID.
     *
     * @param callID the new call ID
     */
    public void setCallID(String callID) {
        this.callID = callID;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */

    public Data getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(Data data) {
        this.data = data;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "GigyaTokenPayload [apiKey=" + apiKey + ", callID=" + callID + ", data=" + data + "]";
    }

}
