/*
 * Creation : 16 Jun 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

/**
 * The Class GigyaServiceConfig.
 */
public class GigyaServiceConfig {

    /** The url. */
    private String url;

    /** The user key. */
    private String userKey;

    /** The secret. */
    private String secret;

    /** The query. */
    private String query;

    /** The maximum attempts. */
    private int maximumAttempts;

    /** The delay. */
    private int delay;

    /**
     * Gets the url.
     *
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * Sets the url.
     *
     * @param url the new url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Gets the user key.
     *
     * @return the user key
     */
    public String getUserKey() {
        return userKey;
    }

    /**
     * Sets the user key.
     *
     * @param userKey the new user key
     */
    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    /**
     * Gets the secret.
     *
     * @return the secret
     */
    public String getSecret() {
        return secret;
    }

    /**
     * Sets the secret.
     *
     * @param secret the new secret
     */
    public void setSecret(String secret) {
        this.secret = secret;
    }

    /**
     * Gets the query.
     *
     * @return the query
     */
    public String getQuery() {
        return query;
    }

    /**
     * Sets the query.
     *
     * @param query the new query
     */
    public void setQuery(String query) {
        this.query = query;
    }

    /**
     * Getter maximumAttempts
     * 
     * @return the maximumAttempts
     */
    public int getMaximumAttempts() {
        return maximumAttempts;
    }

    /**
     * Setter maximumAttempts
     * 
     * @param maximumAttempts the maximumAttempts to set
     */
    public void setMaximumAttempts(int maximumAttempts) {
        this.maximumAttempts = maximumAttempts;
    }

    /**
     * Getter delay
     * 
     * @return the delay
     */
    public int getDelay() {
        return delay;
    }

    /**
     * Setter delay
     * 
     * @param delay the delay to set
     */
    public void setDelay(int delay) {
        this.delay = delay;
    }

}
