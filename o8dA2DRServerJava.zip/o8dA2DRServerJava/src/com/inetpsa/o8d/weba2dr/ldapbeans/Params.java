/*
 * Creation : 30 May 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class Params.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Params {

    /** The password. */
    private String password;

    /** The new password. */
    private String newPassword;

    /**
     * Instantiates a new params.
     */
    public Params() {
    }

    /**
     * Instantiates a new params.
     *
     * @param password    the password
     * @param newPassword the new password
     */
    public Params(String password, String newPassword) {
        super();
        this.password = password;
        this.newPassword = newPassword;
    }

    /**
     * Gets the password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     *
     * @param password the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the new password.
     *
     * @return the new password
     */
    public String getNewPassword() {
        return newPassword;
    }

    /**
     * Sets the new password.
     *
     * @param newPassword the new new password
     */
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Params [password=" + password + ", newPassword=" + newPassword + "]";
    }

}
