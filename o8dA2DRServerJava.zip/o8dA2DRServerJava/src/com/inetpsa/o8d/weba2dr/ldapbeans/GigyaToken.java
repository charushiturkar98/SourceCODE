/*
 * Creation : 30 May 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

/**
 * The Class GigyaToken.
 */
public class GigyaToken {

    /** The gigya token payload. */
    private GigyaTokenPayload gigyaTokenPayload;

    /**
     * Instantiates a new gigya token.
     *
     * @param gigyaTokenPayload the gigya token payload
     */
    public GigyaToken(GigyaTokenPayload gigyaTokenPayload) {
        super();
        this.gigyaTokenPayload = gigyaTokenPayload;
    }

    /**
     * Instantiates a new gigya token.
     */
    public GigyaToken() {
    }

    /**
     * Gets the gigya token payload.
     *
     * @return the gigya token payload
     */
    public GigyaTokenPayload getGigyaTokenPayload() {
        return gigyaTokenPayload;
    }

    /**
     * Sets the gigya token payload.
     *
     * @param gigyaTokenPayload the new gigya token payload
     */
    public void setGigyaTokenPayload(GigyaTokenPayload gigyaTokenPayload) {
        this.gigyaTokenPayload = gigyaTokenPayload;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "GigyaToken [gigyaTokenPayload=" + gigyaTokenPayload + "]";
    }
}
