/*
 * Creation : 19 Jun 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class Data.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {

    /** The params. */
    private Params params;

    /**
     * Instantiates a new data.
     */
    public Data() {
    }

    /**
     * Instantiates a new data.
     *
     * @param params the params
     */
    public Data(Params params) {
        super();
        this.params = params;
    }

    /**
     * Gets the params.
     *
     * @return the params
     */
    public Params getParams() {
        return params;
    }

    /**
     * Sets the params.
     *
     * @param params the new params
     */
    public void setParams(Params params) {
        this.params = params;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Data [params=" + params + "]";
    }

}
