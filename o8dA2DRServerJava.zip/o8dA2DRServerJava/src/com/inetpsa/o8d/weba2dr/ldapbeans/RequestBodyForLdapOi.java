/*
 * Creation : 31 May 2023
 */
package com.inetpsa.o8d.weba2dr.ldapbeans;

/**
 * The Class RequestBodyForLdapOi.
 */
public class RequestBodyForLdapOi {

    /** The userName2. */
    private String userName2;

    /** The password. */
    private String password;

    /**
     * Instantiates a new request body for registration.
     */
    public RequestBodyForLdapOi() {

    }

    /**
     * Gets the userName2.
     *
     * @return the userName2
     */
    public String getUserName2() {
        return userName2;
    }

    /**
     * Sets the userName2.
     *
     * @param userName2 the new user name
     */
    public void setUserName2(String userName2) {
        this.userName2 = userName2;
    }

    /**
     * Gets the password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     *
     * @param password the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Instantiates a new request body for ldap oi.
     *
     * @param userName2   the userName2
     * @param password    the password
     * @param newPassword the new password
     */
    public RequestBodyForLdapOi(String userName2, String password) {
        super();
        this.userName2 = userName2;
        this.password = password;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RequestBodyForLdapOi [userName2=" + userName2 + ", password=" + password + "]";
    }

}
