package com.inetpsa.o8d.diaguser.impl;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;

import com.inetpsa.o8d.a2dr.beans.DiagboxJetonBean;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.service.AbonnementVINChecker;
import com.inetpsa.o8d.a2dr.service.Authentification;
import com.inetpsa.o8d.diaguser.AbstractOIConnector;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Implementation locale de l'utilisateur OI.
 * 
 * @author e331258
 */
public class LocalAccessOIUser extends RemoteAccessOIUser {

    /**
     * Generated serial version UID
     */
    private static final long serialVersionUID = -871032354080138380L;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.impl.RemoteAccessOIUser#executeAuthentication()
     */
    @Override
    protected void executeAuthentication() throws DiagUserException {
        logger.debug("executeAuthentication()");

        try {
            Authentification authentification = new Authentification();
            // CAP-26498:DiagLot2- Passing server name in parameter
            fiche = authentification.authenticate(getDiagUserCredentials(), applicationId, hostName);

            authenticationDone = true;

            if (fiche != null) {
                validUser = true;
            } else {
                validUser = false;
            }
        } catch (AuthentificationException ex) {
            logger.warn("authentification pour '" + getUserName() + "' a echoue", ex);
            authenticationDone = true;
            validUser = false;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.impl.RemoteAccessOIUser#isAbonnementVinValide()
     */
    @Override
    public boolean isAbonnementVinValide() throws DiagUserException {
        logger.debug("isAbonnementVinValide()");

        // Fonctionnement en mode bouchon
        String radical = getEntry("radicalVin").getValue();

        if (StringUtils.isNotEmpty(radical)) {
            if (this.vin.substring(0, radical.length()).equals(radical)) {
                return true;
            }

            return false;
        }

        // Fonctionnement nominal
        boolean isAuthorized = false;

        AbonnementVINChecker oiAbonnementVINChecker = new AbonnementVINChecker();

        try {
            oiAbonnementVINChecker.checkAbo(this.vin, getDiagUserCredentials());
            DiagboxJetonBean diagboxJeton = oiAbonnementVINChecker.getDiagboxJeton();
            if (diagboxJeton != null) {
                isAuthorized = diagboxJeton.getAutorisation();
            }
        } catch (IOException e) {
            logger.error("Fatal transport error: ", e);
        }

        return isAuthorized;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.impl.RemoteAccessOIUser#buildNewInstance()
     */
    @Override
    public AbstractOIConnector buildNewInstance() {
        return new LocalAccessOIUser();
    }
}
