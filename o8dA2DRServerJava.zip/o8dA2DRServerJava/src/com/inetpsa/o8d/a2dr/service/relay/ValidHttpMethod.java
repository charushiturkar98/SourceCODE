package com.inetpsa.o8d.a2dr.service.relay;

/**
 * M�thodes de requ�tage http g�r�es.
 * 
 * @author E331258
 */
public enum ValidHttpMethod {

    /**
     * M�thode http GET.
     */
    GET,
    /**
     * M�thode http POST.
     */
    POST
}
