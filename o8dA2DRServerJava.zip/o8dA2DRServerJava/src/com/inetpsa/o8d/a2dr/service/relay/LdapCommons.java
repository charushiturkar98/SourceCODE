/*
 * Creation : 30 May 2023
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigya.socialize.GSKeyNotFoundException;
import com.gigya.socialize.GSRequest;
import com.gigya.socialize.GSResponse;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.beans.ProxyBean;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.exception.GigyaTokenInvalidException;
import com.inetpsa.o8d.weba2dr.err.ErrorCode;
import com.inetpsa.o8d.weba2dr.ldapbeans.GigyaServiceConfig;
import com.inetpsa.o8d.weba2dr.ldapbeans.GigyaToken;
import com.inetpsa.o8d.weba2dr.ldapbeans.GigyaTokenPayload;
import com.inetpsa.o8d.weba2dr.ldapbeans.LdapOauthConfig;

/**
 * The Class LdapCommons: POUDG-9437.
 */
public class LdapCommons {

    /**
     * Instantiates a new ldap commons.
     */
    LdapCommons() {
        super();
    }

    /** Logger. */
    protected static final Logger logger = LoggerFactory.getLogger(LdapCommons.class);

    /** The config. */
    protected static AbstractFileConfiguration config = new PropertiesConfiguration();

    /**
     * Decrypt and set gigya token data.
     *
     * @param encodedGigyaToken the encoded gigya token
     * @return the gigya token
     */
    public static GigyaToken decryptAndSetGigyaTokenData(String encodedGigyaToken) {
        GigyaToken gigyaToken = new GigyaToken();
        try {
            String base64EncodedPayloadBody = encodedGigyaToken.split("\\.")[1];
            Base64 base64Url = new Base64(true);
            gigyaToken.setGigyaTokenPayload(
                    new ObjectMapper().readValue(new String(base64Url.decode(base64EncodedPayloadBody)), GigyaTokenPayload.class));
        } catch (IOException jsonException) {
            logger.error(RelayConstants.ERROR_BAD_FORMAT_TOKEN, jsonException);
        } catch (Exception e) {
            logger.error("Something went wrong while decrypting token :", e);
        }
        return gigyaToken;
    }

    /**
     * Extract gigya token.
     *
     * @param gigyaToken the gigya token
     * @return the gigya token
     */
    public static GigyaToken extractGigyaToken(String gigyaToken) {
        return decryptAndSetGigyaTokenData(gigyaToken);
    }

    /**
     * Audit search.
     *
     * @param decryptedGigyaToken the decrypted gigya token
     * @return the string
     * @throws FwkException the fwk exception
     */
    public static String auditSearch(GigyaToken decryptedGigyaToken) throws FwkException {
        RewriteResponseRelayCommunicationService rewriteResponse = new RewriteResponseRelayCommunicationService();
        String uid = null;
        // reading config file and form the requestBody to call audit search api
        GigyaServiceConfig configBeanGigya = new GigyaServiceConfig();
        HttpsURLConnection httpConn = null;
        try {
            String finalRequestForAuditSearch = requestForAuditSearch(decryptedGigyaToken, configBeanGigya);
            for (int attempt = 1; attempt <= configBeanGigya.getMaximumAttempts(); attempt++) {
                try {
                    Thread.sleep(configBeanGigya.getDelay());
                    if (logger.isInfoEnabled())
                        logger.info("Attempt no. {} to get UID from gigya", attempt);
                    httpConn = BatteryInfoUtil.createHttpConnWithProxyAndTLS(configBeanGigya.getUrl(), RelayConstants.GIGYA);
                    httpConn.setRequestMethod(RelayConstants.POST_METHOD);
                    httpConn.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.CONTENT_TYPE_DATA);
                    httpConn.setRequestProperty(RelayConstants.CHARSET, RelayConstants.UTF_8);
                    httpConn.setDoOutput(true);
                    rewriteResponse.requestBodyWriter(httpConn, finalRequestForAuditSearch);
                    httpConn.connect();
                    uid = extractUid(httpConn);
                    if (null != uid)
                        break;
                } catch (InterruptedException e) {
                    logger.error("Thread interrupted while calling GetAuditSearch", e);
                    Thread.currentThread().interrupt();
                } catch (Exception e) {
                    logger.error("Exception while calling GetAuditSearch from URl: ", e);
                } finally {
                    httpConn.disconnect();
                }
            }
        } catch (Exception e) {
            logger.error("Exception while calling GetAuditSearch from URl: ", e);
        }
        if (null == uid)
            logger.warn("Unable to retrieve UID");
        return uid;
    }

    /**
     * Read configuration for audit search.
     *
     * @param decryptedGigyaToken the decrypted gigya token
     * @param configBeanGigya     the config bean gigya
     * @return the string builder
     * @throws UnsupportedEncodingException the unsupported encoding exception
     * @throws ConfigurationException       the configuration exception
     */
    public static String requestForAuditSearch(GigyaToken decryptedGigyaToken, GigyaServiceConfig configBeanGigya)
            throws UnsupportedEncodingException, ConfigurationException {
        // Loading the configuration file

        readConfigFile(decryptedGigyaToken, configBeanGigya);
        StringBuilder sqlQuery = new StringBuilder();
        sqlQuery.append(configBeanGigya.getQuery());
        // Append the CallID fetched from Gigya Token to Query to fetch UID.
        sqlQuery.append("'").append(decryptedGigyaToken.getGigyaTokenPayload().getCallID()).append("'");
        // Build the request body to call Audit Search Service of Gigya.
        HashMap<String, String> params = new HashMap<>();
        params.put("apiKey", decryptedGigyaToken.getGigyaTokenPayload().getApiKey());
        params.put("userKey", configBeanGigya.getUserKey());
        params.put("secret", configBeanGigya.getSecret());
        params.put("query", sqlQuery.toString());

        StringBuilder requestForAuditSearch = new StringBuilder();
        boolean firstElement = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (firstElement)
                firstElement = false;
            else
                requestForAuditSearch.append("&");
            requestForAuditSearch.append(URLEncoder.encode(entry.getKey(), RelayConstants.UTF_8));
            requestForAuditSearch.append("=");
            requestForAuditSearch.append(URLEncoder.encode(entry.getValue(), RelayConstants.UTF_8));
        }
        return requestForAuditSearch.toString();
    }

    /**
     * Read config file.
     *
     * @param decryptedGigyaToken the decrypted gigya token
     * @param configBeanGigya     the config bean gigya
     * @throws ConfigurationException the configuration exception
     */
    private static void readConfigFile(GigyaToken decryptedGigyaToken, GigyaServiceConfig configBeanGigya) throws ConfigurationException {
        AbstractFileConfiguration config = new PropertiesConfiguration();
        config.setDelimiterParsingDisabled(true);
        config.load(Thread.currentThread().getContextClassLoader().getResource(RelayConstants.GIGYA_CONFIG_FILE));
        configBeanGigya.setUrl(config.getString(RelayConstants.GIGYA_AUDIT_SEARCH_URL));
        decryptedGigyaToken.getGigyaTokenPayload().setApiKey(decryptedGigyaToken.getGigyaTokenPayload().getApiKey());
        configBeanGigya.setUserKey(config.getString(RelayConstants.GIGYA_USERKEY));
        configBeanGigya.setSecret(config.getString(RelayConstants.GIGYA_SECRET));
        decryptedGigyaToken.getGigyaTokenPayload().setCallID(decryptedGigyaToken.getGigyaTokenPayload().getCallID());
        configBeanGigya.setQuery(config.getString(RelayConstants.GIGYA_QUERY));
        configBeanGigya.setDelay(config.getInt(RelayConstants.GIGYA_DELAY));
        configBeanGigya.setMaximumAttempts(config.getInt(RelayConstants.GIGYA_MAXIMUM_ATTEMPTS));
    }

    /**
     * Validate gigya token signature.
     *
     * @param encodedToken    the encoded token
     * @param decrpyptedToken the decrpypted token
     * @return true, if successful
     * @throws ConfigurationException     the configuration exception
     * @throws GSKeyNotFoundException     the GS key not found exception
     * @throws GigyaTokenInvalidException the gigya token invalid exception
     * @throws InvalidKeyException        the invalid key exception
     * @throws NoSuchAlgorithmException   the no such algorithm exception
     * @throws InvalidKeySpecException    the invalid key spec exception
     * @throws SignatureException         the signature exception
     */
    public static void validateGigyaTokenSignature(String encodedToken, GigyaToken decrpyptedToken)
            throws ConfigurationException, GSKeyNotFoundException, GigyaTokenInvalidException, InvalidKeyException, NoSuchAlgorithmException,
            InvalidKeySpecException, SignatureException {
        String[] splitString = encodedToken.split("\\.");
        String tokenData = splitString[0] + "." + splitString[1];
        String keySignatureString = splitString[2];
        // fetch the public key to validate signature
        GSResponse response = fetchPublicKey(decrpyptedToken);
        String fetchedPublicKey = response.getData().get(RelayConstants.PUBLIC_KEY).toString();
        keySignatureString = keySignatureString.replace('-', '+'); // 62nd char of encoding
        keySignatureString = keySignatureString.replace('_', '/'); // 63rd char of encoding
        fetchedPublicKey = fetchedPublicKey.replace('-', '+'); // 62nd char of encoding
        fetchedPublicKey = fetchedPublicKey.replace('_', '/'); // 63rd char of encoding

        // Signature verification block
        RSAPublicKeySpec rsaPubKey = new RSAPublicKeySpec(new BigInteger(1, Base64.decodeBase64(fetchedPublicKey.getBytes())),
                new BigInteger(1, Base64.decodeBase64(response.getData().get(RelayConstants.EXP_STRING).toString().getBytes())));
        Signature rsaSig = Signature.getInstance(RelayConstants.SHA256WITHRSA);
        rsaSig.initVerify(KeyFactory.getInstance(RelayConstants.RSA).generatePublic(rsaPubKey));
        rsaSig.update(tokenData.getBytes(StandardCharsets.UTF_8));
        if (rsaSig.verify(Base64.decodeBase64(keySignatureString.getBytes()))) {
            logger.info("Valid Signature!");
        } else {
            logger.error("Invalid Signature");
            throw new GigyaTokenInvalidException(ErrorCode.ERROR_400_CODE, RelayConstants.INVALID_GIGYA_TOKEN);
        }

    }

    /**
     * Fecth public key.
     *
     * @param decrpyptedToken the decrpypted token
     * @return the GS response
     * @throws ConfigurationException     the configuration exception
     * @throws GigyaTokenInvalidException the gigya token invalid exception
     */
    public static GSResponse fetchPublicKey(GigyaToken decrpyptedToken) throws ConfigurationException, GigyaTokenInvalidException {
        GigyaServiceConfig configBeanGigya = new GigyaServiceConfig();
        // read config file to get userkey and secret key
        readConfigFile(decrpyptedToken, configBeanGigya);
        GSResponse response = null;
        // prepare request for fetching public key
        GSRequest request = new GSRequest(decrpyptedToken.getGigyaTokenPayload().getApiKey(), configBeanGigya.getSecret(), RelayConstants.API_METHOD,
                null, false, configBeanGigya.getUserKey());
        final ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        ProxyBean loginProxy = serverConfigurationManager.getProxy();
        Authenticator authenticator = new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                return (new PasswordAuthentication(serverConfigurationManager.getServerAccount().getLogin(),
                        serverConfigurationManager.getServerAccount().getPassword().toCharArray()));
            }
        };
        Authenticator.setDefault(authenticator);
        InetSocketAddress proxyAddress = new InetSocketAddress(loginProxy.getHostname(), loginProxy.getPort());
        Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyAddress);
        request.setProxy(proxy);
        request.setAPIDomain(RelayConstants.API_DOMAIN);
        try {
            response = request.send();
        } catch (Exception e) {
            logger.error("Exception while fetching public key", e);
            throw new GigyaTokenInvalidException(ErrorCode.ERROR_400_CODE, RelayConstants.INVALID_GIGYA_TOKEN);
        }
        logger.debug("Response from api to fetch public key: {} ", response.getData());
        if (response.getErrorCode() == 0) {
            logger.info("Success while fetching public key");
        } else {
            logger.warn("Uh-oh, we got the following error: {} ", response.getLog());
        }
        return response;

    }

    /**
     * Adds the error message for gigya.
     *
     * @param responseCode the response code
     * @return the string
     */
    static String addErrorMessageForGigya(int responseCode) {
        String message;
        switch (responseCode) {
        case HttpURLConnection.HTTP_UNAUTHORIZED:
            message = RelayConstants.UNAUTHORIZED;
            break;
        case HttpURLConnection.HTTP_FORBIDDEN:
            message = RelayConstants.FORBIDDEN_USER;
            break;
        case HttpURLConnection.HTTP_NOT_FOUND:
            message = RelayConstants.TECHNICAL_ERROR;
            break;
        case HttpURLConnection.HTTP_CLIENT_TIMEOUT:
            message = RelayConstants.TIMEOUT;
            break;
        case HttpURLConnection.HTTP_BAD_METHOD:
            message = RelayConstants.METHOD_NOT_ALLOWED;
            break;
        case HttpURLConnection.HTTP_INTERNAL_ERROR:
            message = RelayConstants.INTERNAL_ERROR_LDAPOI;
            break;
        default:
            message = RelayConstants.INTERNAL_SERVER_ERROR;
        }
        return message;
    }

    /**
     * Adds the error code for gigya.
     *
     * @param resultCode the result code
     * @return the integer
     */
    static Integer addErrorCodeForGigya(int resultCode) {
        Integer statusCode = null;
        switch (resultCode) {
        case ErrorCode.ERROR_11_CODE:
        case ErrorCode.ERROR_12_CODE:
        case ErrorCode.ERROR_20_CODE:
        case ErrorCode.ERROR_22_CODE:
        case ErrorCode.ERROR_24_CODE:
            statusCode = HttpURLConnection.HTTP_BAD_REQUEST;
            break;
        case ErrorCode.ERROR_26_CODE:
            statusCode = HttpURLConnection.HTTP_NOT_ACCEPTABLE;
            break;
        default:
            statusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
        }
        logger.warn("Status code to be returned to Gigya :{}", statusCode);
        return statusCode;
    }

    /**
     * Read config file for ldapoi oauth.
     *
     * @return the ldap oauth config
     * @throws ConfigurationException the configuration exception
     */
    public static LdapOauthConfig readConfigFileForLdapOi() throws ConfigurationException {
        AbstractFileConfiguration config = new PropertiesConfiguration();
        config.setDelimiterParsingDisabled(true);
        LdapOauthConfig ldapOauthConfig = new LdapOauthConfig();
        config.load(Thread.currentThread().getContextClassLoader().getResource(RelayConstants.LDAP_OI_OAUTH_CONFIG_FILE));
        ldapOauthConfig.setAccessTokenUrl(config.getString(RelayConstants.LDAP_OI_ACCESS_TOKEN_URL));
        ldapOauthConfig.setClientId(config.getString(RelayConstants.LDAP_OI_CLIENT_ID));
        ldapOauthConfig.setClientSecret(config.getString(RelayConstants.LDAP_OI_CLIENT_SECRET));
        ldapOauthConfig.setScope(config.getString(RelayConstants.LDAP_OI_SCOPE));
        return ldapOauthConfig;

    }

    /**
     * Gets the OAuth token for ldap oi.
     *
     * @return the o auth token for ldap oi
     * @throws ConfigurationException the configuration exception
     */
    public static String getOAuthTokenForLdapOi() throws ConfigurationException {
        LdapOauthConfig ldapOauthConfig = LdapCommons.readConfigFileForLdapOi();
        HttpsURLConnection httpConn = null;
        try {

            OAuthClientRequest request = OAuthClientRequest.tokenLocation(ldapOauthConfig.getAccessTokenUrl())
                    .setGrantType(GrantType.CLIENT_CREDENTIALS).setClientId(ldapOauthConfig.getClientId())
                    .setClientSecret(ldapOauthConfig.getClientSecret()).setScope(ldapOauthConfig.getScope()).buildBodyMessage();
            httpConn = BatteryInfoUtil.createHttpConnWithProxyAndTLS(request.getLocationUri(), AbstractRelayCommunicationService.LDAP_OI);
            BatteryInfoUtil.setRequestBody(request, RelayConstants.POST_METHOD, httpConn);
            if (httpConn != null) {
                httpConn.connect();
                if (HttpURLConnection.HTTP_OK == httpConn.getResponseCode()) {
                    JsonObject fromJson = new Gson().fromJson(BatteryInfoUtil.convertStreamToString(httpConn.getInputStream()), JsonObject.class);
                    if (fromJson.has(RelayConstants.ACCESS_TOKEN)) {
                        JsonElement jsonTokenResponse = fromJson.get(RelayConstants.ACCESS_TOKEN);
                        if (logger.isInfoEnabled())
                            logger.info("OAuth Token retrieved successfully");
                        return jsonTokenResponse.getAsString();
                    } else if (logger.isInfoEnabled())
                        logger.info("Unable to retrieve OAuth Token");

                } else {
                    logger.warn("Response received for Oauth Token: {}", httpConn.getResponseCode());
                }
            }
        } catch (Exception e) {
            logger.error("Exception while getting oauth token :", e);
        } finally {
            if (null != httpConn)
                httpConn.disconnect();
        }
        return null;
    }

    /**
     * Extract UID.
     *
     * @param httpConn the http connection
     * @return the uid
     */
    public static String extractUid(HttpsURLConnection httpConn) {
        String uid = null;
        try {
            // reading config file and form the requestBody to call audit search api
            String auditSearchResponse = BasicRelayCommunicationService.getResponseFromPortfolio(httpConn);
            if (logger.isInfoEnabled())
                logger.info("Response coming from Audit Search: {}", auditSearchResponse);
            if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                JSONObject auditSearchJsonResponse = new JSONObject(auditSearchResponse);
                if (auditSearchJsonResponse.has(RelayConstants.RESULTS)) {
                    JSONArray auditSearchResponseResultsArray = auditSearchJsonResponse.getJSONArray(RelayConstants.RESULTS);
                    for (int i = 0; i < auditSearchResponseResultsArray.length(); i++) {
                        JSONObject res = auditSearchResponseResultsArray.getJSONObject(i);
                        uid = res.getString(RelayConstants.UID);
                        if (logger.isInfoEnabled())
                            logger.info("UID fetched from audit search response: {}", uid);
                    }
                } else {
                    logger.warn("Error response received gigya for audit search : {}", auditSearchResponse);
                }
            } else {
                logger.warn("Response code received from gigya audit search : {} ", httpConn.getResponseCode());
            }
        } catch (Exception e) {
            logger.error("Exception while extracting uid from audit search response: ", e);
        }

        return uid;
    }
}
