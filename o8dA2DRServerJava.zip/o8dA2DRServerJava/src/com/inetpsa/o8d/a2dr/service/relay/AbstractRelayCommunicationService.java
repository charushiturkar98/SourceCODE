package com.inetpsa.o8d.a2dr.service.relay;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;
import org.apache.commons.configuration.AbstractConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.cxl.core.client.ClientParameters;
import com.inetpsa.cxl.core.fault.ServiceException;
import com.inetpsa.cxl.transport.ResponseIsNotOkException;
import com.inetpsa.fdz.ws.lcdv.client.LCDVService;
import com.inetpsa.fdz.ws.lcdv.client.LCDVServiceClient;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.exception.ServiceTechnicalException;
import com.inetpsa.o8d.a2dr.beans.AuthenticationBean;
import com.inetpsa.o8d.a2dr.beans.ProxyBean;
import com.inetpsa.o8d.a2dr.beans.RelayAccessConfigurationBean;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.exception.HostNotFoundException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.UserType;
import com.inetpsa.o8d.weba2dr.err.ErrorCode;
import com.inetpsa.xml.fdzsoa.commerce.apvtechnique.reseau.specific.MarquePSAType;
import com.inetpsa.xml.fdzsoa.iso.CodeLangueISOType;
import com.inetpsa.xml.fdzsoa.iso.CodePaysISOStype;
import com.inetpsa.xml.fdzsoa.lcdv.commerce.apvtechnique.reseau.specific.FdzServiceLCDVRequestType;
import com.inetpsa.xml.fdzsoa.lcdv.commerce.apvtechnique.reseau.specific.FdzServiceLCDVResponseType;
import com.inetpsa.xml.fdzsoa.produitprocess.vehicule.identification.VINType;

/**
 * Classe abstraite pour la gestion de la communication des relais.
 * 
 * @author E331258
 */
public abstract class AbstractRelayCommunicationService extends AbstractA2DRBusinessService {

    /**
     * Base du nom de l'url des relais.
     */
    private static final String A2DR_RELAY_URL_BASENAME = "/relay/";
    /**
     * S�parateur de contexte.
     */
    protected static final String CONTEXT_SEPARATOR = "/";
    /**
     * Relay Cookie path.
     */
    protected static final String RELAY_COOKIE_PATH = "/";

    /**
     * Siparateur du nom de l'application cible et du nom du cookie dans les noms de cookies apr�ls translation (APP_CookieName).
     */
    private static final String COOKIE_APP_NAME_SEPARATOR = "_";

    /** The Constant S03_ACTION. */
    public static final String S03_ACTION = "/S03Action.do";

    /** The Constant S02_OUDACTION. */
    public static final String S02_OUDACTION = "/S02OudAction.do";

    /** The Constant S05_ACTION. */
    public static final String S05_ACTION = "/S05Action.do";

    /** The Constant PREP_ACTION. */
    public static final String PREP_ACTION = "/preparation.do";

    /** The Constant TELE_CHARGE. */
    public static final String TELE_CHARGE = "/Telechargement.do";

    /** The Constant TELE_CODAGE. */
    public static final String TELE_CODAGE = "/Telecodage.do";

    /** The Constant TRANSPORT_USER_NAME. */
    private static final String TRANSPORT_USER_NAME = "TRANSPORT_USER_NAME";

    /** The Constant TRANSPORT_PWD. */
    private static final String TRANSPORT_PWD = "TRANSPORT_PWD";

    /** The Constant EMETTEUR_VAL. */
    private static final String EMETTEUR_VAL = "EMETTEUR_VAL";

    /** CAP-17119 The Constant APIC_PORTFOLIO_APP. */
    public static final String APIC_PORTFOLIO_APP = "APIC_PORTFOLIO_APP";

    /** The Constant SLASH_SEPARATOR- sonar issue fixed. */
    private static final String SLASH_SEPARATOR = "/";

    /** The Constant LISTE_ELECTRONIQUES- sonar issue fixed. */
    private static final String LISTE_ELECTRONIQUES = "LISTE_ELECTRONIQUES";

    /** The Constant ELECTRONIQUE- sonar issue fixed. */
    private static final String ELECTRONIQUE = "ELECTRONIQUE";

    /** The Constant SERAV- sonar issue fixed. */
    private static final String SERAV = "serav";

    /** The Constant SERAV_UL. */
    public static final String SERAV_UL = "serav_ul";

    /** The Constant CORVET- sonar issue fixed. */
    public static final String CORVET = "corvet";

    /** The Constant LCDV_BASE- sonar issue fixed. */
    public static final String LCDV_BASE = "<LCDV_BASE>";

    /** The Constant LCDV_BASE_END. */
    public static final String LCDV_BASE_END = "</LCDV_BASE>";

    /** The Constant MESSAGE- sonar issue fixed. */
    private static final String MESSAGE = "MESSAGE";

    /** The Constant ENTETE- sonar issue fixed. */
    private static final String ENTETE = "ENTETE";

    /** The Constant READ_TIMEOUT. */
    private static final int READ_TIMEOUT = 30000;

    /** The Constant READ_TIMEOUT_EDIAG. */
    private static final int READ_TIMEOUT_EDIAG = 300000;

    /** The Constant SERAV_APP. */
    private static final String SERAV_APP = "SERAV_APP";

    /** The Constant REPPS. */
    private static final String REPPS = "O7D";

    /** The Constant REPPS. */
    private static final String NRV = "NRV";
    /** The Constant REPPS. */
    public static final String ARGOS = "ARGOS";
    /** CAP-29098: The Constant PORTFOLIO_LABEL. */
    public static final String PORTFOLIO_LABEL = "portfolio_label";
    /** CAP-29098: The Constant PORTFOLIO_APP. */
    public static final String PORTFOLIO_APP = "portfolio";

    /**
     * Taille de log max.
     */
    public static final int MAX_LOG_SIZE = 1000;

    // POUDG-8558--Start--
    /** The Constant LISTE_ORGANES. */
    private static final String LISTE_ORGANES = "LISTE_ORGANES";

    /** The Constant ORGANE. */
    private static final String ORGANE = "ORGANE";
    // POUDG-8558--end--
    /** Ent�tes filtr�es-- sonar issue fixed. */
    private static final Set<String> FILTERED_HEADERS = new HashSet<>();

    // CAP-29321 //sonar fix
    /** The Constant authHeader. */
    private static final String AUTH_HEADER = "authorization";
    /** The Constant dssSessionid. */
    private static final String DSSJ_SESSIONID = "dssJsessionId\":\"";

    // sonar fix
    /** The Constant BASIC. */
    public static final String BASIC = "Basic";

    static {
        // sonar fix
        FILTERED_HEADERS.add(AUTH_HEADER);
        FILTERED_HEADERS.add("proxy-authorization");
        FILTERED_HEADERS.add("content-length");
        FILTERED_HEADERS.add("transfer-encoding");
        FILTERED_HEADERS.add("host");

        /*
         * Les headers de transfert de force pour palier le code d'erreur 304 if-modified-since, if-none-match et ETag permettent de ne pas reexecuter
         * la requete si elle n'a pas ete modifiee depuis le dernier acces
         */
        FILTERED_HEADERS.add("if-modified-since");
        FILTERED_HEADERS.add("if-none-match");
        FILTERED_HEADERS.add("etag");

        /** Nouveaux cookies dans une r�ponse */
        FILTERED_HEADERS.add("set-cookie");
        /** Cookies dans une requ�te */
        FILTERED_HEADERS.add("cookie");
    }

    /**
     * Param�tre pour la configuration du relais.
     */
    public static final String IN_RELAY_ACCESS_CONFIGURATION = "IN_RELAY_ACCESS_CONFIGURATION";
    /**
     * Parametre de la requete, le process cible de la requete utilise par le service (un fichier, un script, une servlet, ...) modifiant ainsi l'url
     * cible du relais
     */
    public static final String IN_TARGET_PATH = "IN_TARGET_PATH";
    /**
     * Param�tre pour le contexte applicatif A2DR.
     */
    public static final String IN_A2DR_CONTEXT = "IN_A2DR_CONTEXT";

    /**
     * Represente le contenu de la requete HTTP du client.
     */
    public static final String IN_REQUEST_BODY = "IN_REQUEST_BODY";

    /** Represente les headers HTTP de la requ�te d'entree du client. */
    public static final String IN_REQUEST_HEADERS = "IN_REQUEST_HEADERS";

    /** Represente les donn�es d'identification du client. */
    public static final String IN_REQUEST_CREDENTIALS = "IN_REQUEST_CREDENTIALS";

    /** Repr�sente les cookies de la requ�te d'entr�e du client. */
    public static final String IN_REQUEST_COOKIES = "IN_REQUEST_COOKIES";

    /**
     * Headers de la requete retournee par le service metier A2DR Utilise par le service (OUT_HEADER contient les headers de RESPONSE_FROM_TARGET).
     */
    public static final String OUT_HEADERS = "OUT_HEADERS";

    /** Cookies � ajouter � la r�ponse de la requ�te cliente. */
    public static final String OUT_COOKIES = "OUT_COOKIES";

    /**
     * Exception survenue lors de l'execution du service metier A2DR Sera utilise par le service metier : TraitementExceptionMetier pour generer la
     * requete HTTP vers le client avec le code d'erreur.
     */
    public static final String EXCEPTION_METIER = "EXCEPTION_METIER";

    /**
     * Code HTTP recu lors de l'execution de la requete du client Utilise par le service (STATUS_CODE est le code HTTP de
     * OUT_HEADER/RESPONSE_FROM_TARGET).
     */
    public static final String STATUS_CODE = "STATUS_CODE";

    /**
     * R�ponse HTTP recue de la cible.
     */
    public static final String RESPONSE_FROM_TARGET = "RESPONSE_FROM_TARGET";

    /**
     * Configuration de l'acc�s au relais.
     */
    protected RelayAccessConfigurationBean relayAccessConfiguration;
    /**
     * Url de l'application cible.
     */
    protected String targetApplicationUrl;
    /**
     * Contenu de la requete.
     */
    private ByteArrayOutputStream requestBody;

    /** Input for Request JsessionId Parameter. */
    public static final String IN_REQUEST_JSESSIONID = "IN_REQUEST_JSESSIONID";

    /**
     * CAP-17119- created The Constant for IN_HTTP_METHOD.
     */
    public static final String IN_HTTP_METHOD = "IN_HTTP_METHOD";

    // CAP-23738 - start - added constants

    /** The Constant IN_APPLICATION_NAME. */
    public static final String IN_APPLICATION_NAME = "IN_APPLICATION_NAME";

    /** The Constant ERECA. */
    private static final String ERECA = "eRECA";

    /** The Constant ERECA_URLS_CONFIGURATION_FILE. */
    private static final String ERECA_URLS_CONFIGURATION_FILE = "ereca-urls.properties";

    /** The Constant ERECA_OV_BRAND_URL. */
    private static final String ERECA_OV_BRAND_URL = "ereca.OV.brand.url";

    /** The Constant ERECA_AP_BRAND_URL. */
    private static final String ERECA_AP_BRAND_URL = "ereca.AP.brand.url";

    /** The Constant ERECA_ACDS_BRAND_URL. */
    private static final String ERECA_ACDS_BRAND_URL = "ereca.ACDS.brand.url";

    /** The Constant ERECA_SCHEME. */
    private static final String ERECA_SCHEME = "ereca.scheme";

    /** The Constant ERECA_CONTEXT. */
    private static final String ERECA_CONTEXT = "ereca.context";

    /** The Constant URL_CREATOR. */
    private static final String URL_CREATOR = "://";

    /** The Constant ERECA_RESPONSE_RETURNCODE. */
    private static final String ERECA_RESPONSE_RETURNCODE = "{\"returnCode\":\"";

    /** The Constant ERECA_RESPONSE_ERRORMSG. */
    private static final String ERECA_RESPONSE_ERRORMSG = "\",\"errorMessage\":\"";

    /** The Constant ERECA_RESPONSE_BRAND. */
    private static final String ERECA_RESPONSE_BRAND = "\",\"brand\":\"";

    /** The Constant ERECA_RESPONSE_CAMPAIGNCODE. */
    private static final String ERECA_RESPONSE_CAMPAIGNCODE = "\",\"campaignCodes\":\"";

    /** The Constant ERECA_RESPONSE_EMPTY_CAMPAIGNCODE. */
    private static final String ERECA_RESPONSE_EMPTY_CAMPAIGNCODE = "[]";

    /** The Constant ERECA_END_RESPONSE_SUCCESS. */
    private static final String ERECA_END_RESPONSE_SUCCESS = "\"}";

    /** The Constant ERECA_END_RESPONSE. */
    private static final String ERECA_END_RESPONSE = "\"}";

    /** The Constant ERECA_RESPONSE_CODE_ONE. */
    private static final String ERECA_RESPONSE_CODE_ONE = "1";

    /** The Constant ERECA_RESPONSE_CODE_ZERO. */
    private static final String ERECA_RESPONSE_CODE_ZERO = "0";

    /** The Constant ERECA_RESPONSE_CODE_TWO. */
    private static final String ERECA_RESPONSE_CODE_TWO = "2";

    /** The Constant ERECA_RESPONSE_NR. */
    private static final String ERECA_RESPONSE_NR = "NR";

    /** The Constant ERECA_RESPONSE_UNKNOWN_VIN. */
    private static final String ERECA_RESPONSE_UNKNOWN_VIN = "Unknown VIN";

    /** The Constant ERECA_RESPONSE_UNAUTH. */
    private static final String ERECA_RESPONSE_UNAUTH = "Unauthorized";

    /** The Constant ERECA_RESPONSE_NOT_FOUND. */
    private static final String ERECA_RESPONSE_NOT_FOUND = "Not Found";

    /** The Constant ERECA_RESPONSE_INTERNAL_SERVER_ERROE. */
    private static final String ERECA_RESPONSE_INTERNAL_SERVER_ERROE = "Internal Server Error";

    /** The Constant ERECA_RESPONSE_OTHER_ERROR. */
    private static final String ERECA_RESPONSE_OTHER_ERROR = "Other Error";

    /** The Constant ERECA_MESSAGE. */
    private static final String ERECA_MESSAGE = "message";

    /** The Constant CAMPAIGN. */
    private static final String CAMPAIGN = "codeCampagne";

    /** POUDG-8294 : remotion of space in Campagne codes. */
    private static final String COMA_WITH_SPACE = ", ";

    /** The Constant COMA_WITHOUT_SPACE. */
    private static final String COMA_WITHOUT_SPACE = ",";

    /** The Constant STATUS. */
    private static final String STATUS = "status";

    /** The Constant ACCEPT_LANG. */
    private static final String ACCEPT_LANG = "Accept-Language";

    /** The Constant BRAND_OV. */
    private static final String BRAND_OV = "OV";

    /** The Constant BRAND_AP. */
    private static final String BRAND_AP = "AP";

    /** The Constant BRAND_AC. */
    private static final String BRAND_AC = "AC";

    /** The Constant BRAND_DS. */
    private static final String BRAND_DS = "DS";

    /** The Constant LANG. */
    private static final String LANG = "lang";

    /** The Constant VIN. */
    private static final String VIN = "vin";

    /** The Constant ERECA_PORT. */
    private static final int ERECA_PORT = 80;

    /** The url for OV. */
    private String urlForOV;

    /** The url for AP. */
    private String urlForAP;

    /** The url for ACDS. */
    private String urlForACDS;

    /** The context. */
    private String context;

    /** The ereca scheme. */
    private String erecaScheme;

    // CAP-23738 - end

    /* POUDG-9437 */
    /** The Constant TELE_CHARGE. */
    public static final String LDAP_OI = "ldap_oi";

    /** The conversion utility. */
    /* CAP-25017 - START */
    protected ConversionUtility conversionUtility;
    /* CAP-25017 - END */

    // CAP-28062 start x250 lot
    /** The Constant Service Name. */
    public static final String IN_SERVICE_NAME = "IN_SERVICE_NAME";
    /**
     * CAP-29098 The Constant USER_ID.
     */
    public static final String USER_ID = "userId";

    /** The Constant IN_REQUEST. */
    public static final String IN_REQUEST = "IN_REQUEST";

    /** The token ddc for set track ADA. */
    protected static String tokenDdcForSetTrackADA;
    // CAP-28062 end

    /**
     * Constructeur.
     * 
     * @throws FwkException si une erreur survient
     */
    public AbstractRelayCommunicationService() throws FwkException {
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.fwk.service.BusinessService#doExecute()
     */
    @Override
    protected void doExecute() throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> doExecute");

        resetServiceParameters();

        initServiceParameters();

        // Construction et initialisation du client Http
        HttpClient httpClient = new HttpClient();

        // Initialisation en indiquant notamment si l'on doit passer par un proxy.
        initHttpClient(httpClient);

        // Prise en compte des cookies re�us en entr�e
        filterAndTranslateRequestCookie(httpClient);

        HttpMethod methodRelay = null;
        // CAP-27774: To handle the error/response for Argos
        Map<Integer, String> applicationStatusMap = null;

        String requestDDC = this.getInput(IN_REQUEST_BODY).toString();
        // String tokenBean = ; // CAP-26498: DiagLot2-code to retrieve Token sent by DDC.
        if (logger.isInfoEnabled())
            logger.info("request body coming from DDC >>> {}: ", requestDDC);
        try {
            if (ARGOS.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())
                    || RelayConstants.ADA.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())
                    || RelayConstants.TBM_HU.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                applicationStatusMap = fetchDataForAPICApplications(requestDDC);
                return;
            } else if (APIC_PORTFOLIO_APP.equalsIgnoreCase(relayAccessConfiguration.getApplicationId())) {
                applicationStatusMap = fetchDataForAPICPortfolioApplications(requestDDC);
                return;
            }
            // POUDG-9437: Building request and Response for GIGYA-LDAPOI
            else if (RelayConstants.LDAP_OI.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                String request = buildRequestForRegistration();
                applicationStatusMap = fetchDataForApicLDAPOI(request);
                return;
            }
            // Construction de la requete
            // CAP-29321:DSS Stress test- added new parameter to fetch request, passing tokenBean directly
            methodRelay = buildApplicationRequest(httpClient, applicationStatusMap, (String) this.getInput(RelayConstants.DSS3_TOKEN), requestDDC); // CAP-27774:
                                                                                                                                                    // added
                                                                                                                                                    // httpClient
                                                                                                                                                    // in
            // Execution de la requete
            if (logger.isInfoEnabled())
                logger.info("envoi de la requete vers [{}]", this.relayAccessConfiguration.getApplicationName());

            int statusCode = httpClient.executeMethod(methodRelay);
            if (logger.isInfoEnabled())
                logger.info("reception du code HTTP retour de [{}] : {}", this.relayAccessConfiguration.getApplicationName(), statusCode);

            // Cap-23738 : Extract code to method to solve sonar issue.
            // CAP-29321:DSS Stress test- added new parameter to fetch request
            logErrorResponse(methodRelay, statusCode, requestDDC);

            // Construction de la reponse au client d'A2DR
            setOutput(STATUS_CODE, Integer.valueOf(statusCode));
            // CAP-29321: DSS stress test - adding parameter for fetching request
            this.buildResponse(methodRelay, applicationStatusMap, requestDDC);
            // R�cup�ration des nouveaux cookies
            translateResponseCookie(httpClient);
        }
        // Start CAP-23738 : To provide error response in JSON format for GetCampaignCode web service
        catch (HttpException e) {
            // CAP-29321
            if (!ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))) {
                setOutput(EXCEPTION_METIER, new HostNotFoundException("HttpException dans le service de relais", e));
            } else {
                createResponseForTimeout(methodRelay, ErrorCode.ERROR_504_CODE);
            }
            logger.error("HttpException dans le service de relais", e);
        } catch (SocketTimeoutException e) {
            String msg = "";
            if (!ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))) {
                msg = "Connection builded but could not recieve response on time: Socket timeout-> l'URL: [" + this.targetApplicationUrl + "]";
                setOutput(EXCEPTION_METIER, new SocketTimeoutException(msg));
            } else {
                msg = "Connection builded but could not recieve response on time: Socket timeout-> l'URL: -- ERECA --";
                createResponseForTimeout(methodRelay, ErrorCode.ERROR_408_CODE);
            }
            if (logger.isInfoEnabled())
                logger.info(msg, e);
            logger.error(msg, e.getMessage());
        } catch (IOException e) {
            String msg = "";
            if (!ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))) {
                msg = "Impossible de se connecter vers l'URL: [" + this.targetApplicationUrl + "]";
                setOutput(EXCEPTION_METIER, new HostNotFoundException(msg, e));
            } else {
                msg = "Impossible de se connecter vers l'URL: -- ERECA --";
                createResponseForTimeout(methodRelay, ErrorCode.ERROR_504_CODE);
            }
            logger.error(msg, e);
        }
        // End CAP-23738
        finally {
            if (methodRelay != null) {
                methodRelay.releaseConnection();
            }
        }
    }

    /**
     * Fetch data for APIC applications.
     *
     * @param requestDDC the request DDC
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public Map<Integer, String> fetchDataForAPICApplications(String requestDDC) throws IOException {
        return null;
    }

    /**
     * Fetch data for Portfolio APIC applications.
     *
     * @param requestDDC the request DDC
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public Map<Integer, String> fetchDataForAPICPortfolioApplications(String requestDDC) throws IOException {
        return null;
    }

    /**
     * CAP-28062: Extract and set response.
     *
     * @param httpConnArgos the http conn argos
     * @param responseHeaders the response headers
     * @param requestDDC the request DDC
     * @param response the response
     * @param statusCodeArgos the status code argos
     * @throws FwkException the fwk exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void extractAndSetResponse(HttpsURLConnection httpConnArgos, Map<String, String> responseHeaders, String requestDDC, String response,
            int statusCodeArgos) throws FwkException, IOException {
        extractResponseHeader(httpConnArgos, responseHeaders);
        setOutput(STATUS_CODE, Integer.valueOf(statusCodeArgos));
        setOutput(OUT_HEADERS, responseHeaders);
        if (responseHeaders.size() > 0) {
            setOutputInResponse(responseHeaders, response);
        } else {
            byte[] responseByte = response.getBytes(StandardCharsets.UTF_8); // Sonar issue fixed
            ByteArrayOutputStream responseByteArray = new ByteArrayOutputStream();
            responseByteArray.write(responseByte);
            setOutput(RESPONSE_FROM_TARGET, responseByteArray);
            // CAP-29321
            responseByteArray.close();
        }
    }

    /**
     * Fetch response header from argos.This code will be removed once the JDK is upgraded to 1.8
     * 
     * @param httpConnArgos httpConnection
     * @param responseHeaders header from Argos
     */
    protected void extractResponseHeader(HttpsURLConnection httpConnArgos, Map<String, String> responseHeaders) {
        if (null != httpConnArgos) {
            Map<String, List<String>> responseHeaderMap = httpConnArgos.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : responseHeaderMap.entrySet()) {
                if (null != entry.getValue()) {
                    for (String value : entry.getValue()) {
                        String name = StringUtils.EMPTY;
                        if (null != entry.getKey())
                            name = StringUtils.lowerCase(entry.getKey());
                        if (!FILTERED_HEADERS.contains(name)) {
                            responseHeaders.put(entry.getKey(), value);
                        }
                    }
                }
            }
        }
    }

    /**
     * Handle argos response.
     *
     * @param methodRelay the method relay
     * @param tokenResponseMap the token response map
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void handleArgosResponse(HttpMethod methodRelay, Map<Integer, String> tokenResponseMap) throws IOException {
    }

    /**
     * CAP-23738 : To log error response.
     *
     * @param methodRelay the method relay
     * @param statusCode the status code
     * @param inputRequestBody the input request body
     * @throws FwkException the fwk exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void logErrorResponse(HttpMethod methodRelay, int statusCode, String inputRequestBody) throws FwkException, IOException {
        // Traitement code retour
        if (statusCode != HttpStatus.SC_OK) {
            String msg = "[" + this.relayAccessConfiguration.getApplicationName() + "] a  renvoye un code http d'erreur [" + statusCode
                    + "] lors de l'execution du relais vers [" + this.targetApplicationUrl + "]";
            if (logger.isWarnEnabled())
                logger.warn(msg);
            // corrected the response body which is printed in the logs in case of error
            ByteArrayOutputStream response = new ByteArrayOutputStream();
            byte[] bytes = methodRelay.getResponseBody();
            response.write(bytes);
            if (logger.isWarnEnabled()) {
                logger.warn("Request: [{}]", inputRequestBody);
                // CAP-29321 check if response if formatted properly
                // sonar fix
                logger.warn("Response: [{}]", response);
            }
            // CAP-29321 Closing Streams
            response.close();

            // CAP-27774:added condition for argos NOK scenario
            if (!((ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME)))
                    || (ARGOS.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))))
                    || (PORTFOLIO_LABEL.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME)))) {
                setOutput(EXCEPTION_METIER, new ResponseIsNotOkException(msg));
            }
        }
    }

    /**
     * CAP-23738 : Create response for request timeout.
     *
     * @param methodRelay the method relay
     * @param httpCode the http code
     */
    private void createResponseForTimeout(HttpMethod methodRelay, int httpCode) {
        try {
            setOutput(STATUS_CODE, Integer.valueOf(httpCode));
            Header[] headers = methodRelay.getResponseHeaders();
            Map<String, String> responseHeaders = new HashMap<>();
            filterHeader(headers, responseHeaders);
            setOutput(OUT_HEADERS, responseHeaders);
            // CAP-29321
            setOutputInResponse(responseHeaders,
                    ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_TWO + ERECA_RESPONSE_ERRORMSG + ERECA_RESPONSE_OTHER_ERROR + ERECA_END_RESPONSE);
        } catch (Exception e1) {
            logger.error("SocketTimeoutException catch : ", e1); // Sonar issue fixed
        }
    }

    /**
     * Permet de reinitialiser les parametres du service a leurs valeurs par defaut.
     */
    private void resetServiceParameters() {
        if (logger.isInfoEnabled())
            logger.info(">> resetServiceParameters");

        relayAccessConfiguration = null;
        requestBody = null;
        targetApplicationUrl = StringUtils.EMPTY;

        if (logger.isInfoEnabled())
            logger.info("<< resetServiceParameters");
    }

    /**
     * Permet d'initialiser en fonction des parametres recus les parametres specifiques du service de dialogue la cible du relais, le nom de
     * l'application, l'identifiant de l'application, l'utilisation du proxy PSA.
     *
     * @throws FwkException si une erreur survient
     */
    private void initServiceParameters() throws FwkException {

        relayAccessConfiguration = (RelayAccessConfigurationBean) this.getInput(IN_RELAY_ACCESS_CONFIGURATION);
        StringBuilder buffer = buildTargetApplicationUrl();

        String inTargetPath = this.getInputParameterValue(IN_TARGET_PATH);

        if (StringUtils.isEmpty(inTargetPath)) {

            // CAP-25454: sonar issue fixed
            // CAP-29321 directly checking condition instead of storing
            if (buffer.indexOf(CORVET) == 0) {
                buffer.append(CONTEXT_SEPARATOR);
            }
        } else {
            if (StringUtils.length(inTargetPath) <= MAX_LOG_SIZE) {
                if (logger.isInfoEnabled()) {
                    logger.info(">> Ajout d'une cible pour l'url [{}]", inTargetPath);
                }
            } else {
                if (logger.isInfoEnabled()) {
                    logger.info(">> Ajout d'une cible pour l'url : TOO LONG TO LOG");
                }
            }

            // sonar issue fixed
            // Si le path commence d�j� par le contexte, on le supprime
            inTargetPath = StringUtils.removeStart(inTargetPath, SLASH_SEPARATOR + relayAccessConfiguration.getContext());

            int separatorIndex = StringUtils.indexOf(inTargetPath, CONTEXT_SEPARATOR);

            // POUDG-9062 - for CORVET CONTEXT_SEPARATOR shouldn't be appended, CAP-29098: for PORTFOLIO_LABEL CONTEXT_SEPARATOR shouldn't be appended
            if (separatorIndex == 0 || CORVET.equals(relayAccessConfiguration.getApplicationName())
                    || PORTFOLIO_LABEL.equals(relayAccessConfiguration.getApplicationName())) {
                buffer.append(inTargetPath);
            } else {
                buffer.append(CONTEXT_SEPARATOR).append(inTargetPath);
            }
        }

        // Initialisation des parametres specifiques du service
        targetApplicationUrl = buffer.toString();
        buffer.setLength(0); // CAP-29321 Resetting StringBuilder to null
        // sonar issue fixed
        if (logger.isInfoEnabled())
            logger.info("target Url >>> [{}] ", targetApplicationUrl);

        if (StringUtils.length(targetApplicationUrl) <= MAX_LOG_SIZE) {
            if (logger.isInfoEnabled())
                logger.info("initServiceParameters : utilisation de l'url cible [{}], proxy [{}]", targetApplicationUrl,
                        relayAccessConfiguration.isUseProxy());
        } else {
            if (logger.isInfoEnabled()) {
                logger.info("initServiceParameters : utilisation de l'url cible TOO LONG TO LOG, proxy [{}]", relayAccessConfiguration.isUseProxy());
                logger.info("Check  [{}], proxy [{}]", targetApplicationUrl, relayAccessConfiguration.isUseProxy());
            }
        }

        if (logger.isInfoEnabled())
            logger.info("<< initServiceParameters");
    }

    /**
     * Initialisation de la valeur de l'url de l'application cible.
     *
     * @return url
     * @throws FwkException the fwk exception
     */
    private StringBuilder buildTargetApplicationUrl() throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> buildTargetApplicationUrl");

        // Recuperation des parametres de configuration du relais
        StringBuilder buffer = new StringBuilder();

        // CAP-17119 DAAS evolution & CAP-25017_UnlockingBSRF evolution, for APIC no port should be there in the URL & POUDG-9062 & POUDG-9437
        if (relayAccessConfiguration.getApplicationId().equals(APIC_PORTFOLIO_APP) || relayAccessConfiguration.getApplicationName().equals(SERAV_UL)
                || relayAccessConfiguration.getApplicationName().equals(CORVET) || relayAccessConfiguration.getApplicationName().equals(LDAP_OI)) {

            buffer.append(relayAccessConfiguration.getScheme()).append("://").append(relayAccessConfiguration.getHostname());

        } else {
            buffer.append(relayAccessConfiguration.getScheme()).append("://").append(relayAccessConfiguration.getHostname()).append(":")
                    .append(relayAccessConfiguration.getPort());
        }
        if (StringUtils.isNotEmpty(relayAccessConfiguration.getContext())) {
            // une cible metier specifique est rensignee
            if (logger.isInfoEnabled())
                logger.info("Context applicatif : [{}]", relayAccessConfiguration.getContext());

            buffer.append("/").append(relayAccessConfiguration.getContext());
        }
        // sonar issue
        if (StringUtils.isNotEmpty(relayAccessConfiguration.getUrl()) && logger.isInfoEnabled()) {
            logger.info("AAR URL : [{}]", relayAccessConfiguration.getUrl());
        }
        // sonar issue
        if (relayAccessConfiguration.getType() != null && logger.isInfoEnabled()) {
            logger.info("AAR Type : [{}]", relayAccessConfiguration.getType());
        }
        // CAP-29098: Appending userId in url for getLabelsInfo service
        if (PORTFOLIO_LABEL.equals(relayAccessConfiguration.getApplicationName())) {
            if (this.getInput(RelayConstants.DSS3_HOSTNAME).toString()
                    .contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))) {
                buffer.append("?").append(USER_ID + "=" + (String) this.getInput(RelayConstants.TOKEN_USERNAME));
            } else {
                buffer.append("?").append(USER_ID + "=" + ((DiagUserCredentials) this.getInput(IN_REQUEST_CREDENTIALS)).getUserName());
            }
        }
        // CAP-29098:END

        if (StringUtils.length(targetApplicationUrl) <= MAX_LOG_SIZE) {
            if (logger.isInfoEnabled())
                logger.info("<< buildTargetApplicationUrl [app={}] / [id={}] avec l'url de base [{}]",
                        this.relayAccessConfiguration.getApplicationName(), relayAccessConfiguration.getApplicationId(), targetApplicationUrl);
        } else {
            if (logger.isInfoEnabled())
                logger.info("<< buildTargetApplicationUrl [app={}] / [id={}] avec l'url de base TOO LONG TO LOG",
                        this.relayAccessConfiguration.getApplicationName(), relayAccessConfiguration.getApplicationId());
        }

        return buffer;
    }

    /**
     * Initialisation de la valeur de l'url du relais.
     * 
     * @return url du relais
     * @throws FwkException si une erreur survient
     */
    protected String buildA2drRelayUrl() throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> buildA2drRelayUrl");

        // CAP-29321 Directly using a2drcontext instead of storing
        StringBuilder buffer = new StringBuilder();
        buffer.append(this.getInputParameterValue(IN_A2DR_CONTEXT)).append(A2DR_RELAY_URL_BASENAME)
                .append(relayAccessConfiguration.getApplicationName());

        String a2drRelayUrl = buffer.toString();
        buffer.setLength(0); // CAP-29321 Resetting StringBuilder to null

        if (StringUtils.length(a2drRelayUrl) <= MAX_LOG_SIZE) {
            if (logger.isInfoEnabled())
                logger.info("<< buildA2drRelayUrl : url relais [{}]", a2drRelayUrl);
        } else {
            if (logger.isInfoEnabled())
                logger.info("<< buildA2drRelayUrl : url relais TOO LONG TO LOG");
        }

        return a2drRelayUrl;
    }

    /**
     * Permet de construire la requete qui sera envoyee vers l'url cible HttpMethod est l'interface generique d'implementation d'une methode HTTP
     * d'apache avec les classes GET/POST comme instance possible en retour.
     *
     * @param httpClient the http client
     * @param argosStatusMap the argos status map
     * @param request the request
     * @param tokenBean the token bean
     * @return la requete a envoyer avec la methode voulue (GetMethod ou PostMethod)
     * @throws FwkException si une erreur survient
     */
    // sonar issue fixed
    // CAP-29321:DSS Stress test- added new parameter to fetch request
    private HttpMethod buildApplicationRequest(HttpClient httpClient, Map<Integer, String> argosStatusMap, String tokenBean, String request)
            throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> buildApplicationRequest");

        HttpMethod methodRequest;

        // Control de l'initialisation des parametres
        if (StringUtils.isEmpty(targetApplicationUrl)) {
            String msg = "Exception d'initialisation du service - cible du relais non identifiee";
            setOutput(EXCEPTION_METIER, new ServiceTechnicalException(msg));

            logger.error(msg);
        }
        // CAP-27774: call to generate Access token via OAuth 2.0
        String accessToken = StringUtils.EMPTY; // CAP-26498.
        if (ARGOS.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
            accessToken = getBatteryInfoAccessToken(request, httpClient, argosStatusMap);
        }
        // CAP-17119 set HTTPMethod from request
        ValidHttpMethod httpMethod = ValidHttpMethod.valueOf(StringUtils.upperCase(this.getInputParameterValue(IN_HTTP_METHOD)));

        switch (httpMethod) {
        case GET:
            methodRequest = new GetMethod(targetApplicationUrl);
            if (logger.isInfoEnabled())
                logger.info("methodRequest GET[{}]", methodRequest);
            break;
        case POST:
            // CAP-29321:DSS Stress Test- passed 'request' parameter
            methodRequest = buildPostMethod(request);
            if (logger.isInfoEnabled())
                logger.info("methodRequest POST[{}]", methodRequest);
            break;
        default:
            throw new FwkException("Not implement http method : " + httpMethod);
        }

        // Transfert des Headers du client
        filterAndCopyHeaders(methodRequest, accessToken, tokenBean); // CAP-26498: code to add Token sent by DDC.

        if (logger.isInfoEnabled())
            logger.info("<< buildApplicationRequest");

        return methodRequest;
    }

    /**
     * CAP-27774: code to call access token from Argos.
     *
     * @param request the request
     * @param client the client
     * @param argosStatusMap the argos status map
     * @return the battery info access token
     */
    public String getBatteryInfoAccessToken(String request, HttpClient client, Map<Integer, String> argosStatusMap) {
        return null;

    }

    /**
     * Filtrage et copie des ent�tes � destination de l'URL cible.
     *
     * @param methodRequest l'objet requ�te � envoyer
     * @param accessToken the access token
     * @param tokenBean the token bean
     * @throws FwkException si une erreur survient
     */
    private void filterAndCopyHeaders(HttpMethod methodRequest, String accessToken, String tokenBean) throws FwkException {

        Map<String, String> requestHeaders = (Map<String, String>) this.getInput(IN_REQUEST_HEADERS);
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();

        for (Map.Entry<String, String> headerEntry : requestHeaders.entrySet()) {
            String lowerCased = StringUtils.lowerCase(headerEntry.getKey());

            if (!FILTERED_HEADERS.contains(lowerCased)) {
                // CAP-25454 Sonar fixes.
                // CAP-29321
                methodRequest.setRequestHeader(headerEntry.getKey(), headerEntry.getValue());
            }

            // CAP-17119 DAAS put basic auth in request for APIC to authenticate it
            addRequestAndAuthHeader(methodRequest, accessToken, tokenBean, serverConfigurationManager, headerEntry, lowerCased);
            // CAP-17119 DAAS added for testing purpose only
            logger.info("Request Header: Basic-Auth to application [{}] ", headerEntry.getKey());

        }

    }

    /**
     * Adds the request and auth header in the request sent to service.
     *
     * @param methodRequest the method request
     * @param accessToken the access token
     * @param tokenBean the token bean
     * @param serverConfigurationManager the server configuration manager
     * @param headerEntry the header entry
     * @param lowerCased the lower cased
     * @throws FwkException the fwk exception
     */
    private void addRequestAndAuthHeader(HttpMethod methodRequest, String accessToken, String tokenBean,
            ServerConfigurationManager serverConfigurationManager, Map.Entry<String, String> headerEntry, String lowerCased) throws FwkException {

        StringBuilder authHeaderValue = new StringBuilder();
        String hostname = ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME);
        // CAP-25454 Appending basic authorization header in diagcloud while calling target applications
        if (relayAccessConfiguration.getApplicationId().equals(APIC_PORTFOLIO_APP)
                && this.getInput(RelayConstants.DSS3_HOSTNAME).toString().contains(hostname) && lowerCased.equals(AUTH_HEADER)) {
            AuthenticationBean portfolio = serverConfigurationManager.getPortfolioAccount();
            authHeaderValue.append(BASIC).append(" ")
                    .append(new String(Base64.encodeBase64(
                            new StringBuilder().append(portfolio.getLogin()).append(":").append(portfolio.getPassword()).toString().getBytes())))
                    .toString();
            methodRequest.setRequestHeader(AUTH_HEADER, authHeaderValue.toString());
        } else if (relayAccessConfiguration.getApplicationName().equals(SERAV_UL)
                && this.getInput(RelayConstants.DSS3_HOSTNAME).toString().contains(hostname) && lowerCased.equals(AUTH_HEADER)) {
            AuthenticationBean seravUl = serverConfigurationManager.getUnlockingBsrfAccount();
            authHeaderValue.append(BASIC).append(" ")
                    .append(new String(Base64.encodeBase64(
                            new StringBuilder().append(seravUl.getLogin()).append(":").append(seravUl.getPassword()).toString().getBytes())))
                    .toString();
            methodRequest.setRequestHeader(AUTH_HEADER, authHeaderValue.toString());
        } else if ((relayAccessConfiguration.getApplicationId().equals(APIC_PORTFOLIO_APP)
                || relayAccessConfiguration.getApplicationName().equals(SERAV_UL) || relayAccessConfiguration.getApplicationName().equals(CORVET))
                && lowerCased.equals(AUTH_HEADER)) {
            methodRequest.setRequestHeader(headerEntry.getKey(), headerEntry.getValue());
        } // END POUDG-9062
        else if (relayAccessConfiguration.getApplicationName().equalsIgnoreCase(ARGOS) && StringUtils.isNotBlank(accessToken)) {
            methodRequest.setRequestHeader(AUTH_HEADER, authHeaderValue.append("Bearer ").append(accessToken).toString());
        } /* START: CAP-26498 : Add condition for Serav RA user */
        else if (relayAccessConfiguration.getApplicationName().equals(SERAV) && null != tokenBean
                && (UserType.LDAP).toString().equals(relayAccessConfiguration.getUserType())) {
            methodRequest.setRequestHeader("userToken ", authHeaderValue.append(tokenBean).toString());
        }
        addRequestAndAuthHeaderForCorvet(AUTH_HEADER, hostname, authHeaderValue, lowerCased, serverConfigurationManager, methodRequest, headerEntry);
        authHeaderValue.setLength(0); // CAP-29321 Resetting StringBuilder to null
    }

    /**
     * Adds the request and auth header for corvet.
     *
     * @param authHeader the auth header
     * @param hostname the hostname
     * @param authHeaderValue the auth header value
     * @param lowerCased the lower cased
     * @param serverConfigurationManager the server configuration manager
     * @param methodRequest the method request
     * @param headerEntry the header entry
     * @throws FwkException the fwk exception
     */
    public void addRequestAndAuthHeaderForCorvet(String authHeader, String hostname, StringBuilder authHeaderValue, String lowerCased,
            ServerConfigurationManager serverConfigurationManager, HttpMethod methodRequest, Entry<String, String> headerEntry) throws FwkException {
    }

    /**
     * Filtrage et translation des cookies re�us dans la requ�te � destination de l'URL cible.
     * 
     * @param httpClient l'objet {@link HttpClient}
     * @throws FwkException si une erreur survient
     */
    private void filterAndTranslateRequestCookie(HttpClient httpClient) throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> filterAndTranslateRequestCookie");

        Collection<Cookie> requestCookies = (Collection<Cookie>) this.getInput(IN_REQUEST_COOKIES);
        // Fix for POUDG-6548
        String dssJsessionId = null;
        requestBody = (ByteArrayOutputStream) this.getInput(IN_REQUEST_BODY);

        // SONAR issue fix
        dssJsessionId = containsDssJsessionId();

        if (CollectionUtils.isEmpty(requestCookies)) {
            if (logger.isInfoEnabled())
                logger.info(">> no cookie in request");
        } else {
            // Fix for POUDG-6548
            if (StringUtils.isNotEmpty(dssJsessionId))
                for (Cookie cookie : requestCookies) {
                    if (cookie.getName().contains("Ediag") && cookie.getName().contains("JSESSIONID")) {
                        // CAP-25454:sonar issue fixed
                        if (logger.isDebugEnabled())
                            logger.debug(">> Setting correct JSession Id received from request in cookies # {}", dssJsessionId);
                        cookie.setValue(dssJsessionId);
                    }
                }

            // Filtrage + translation
            final String prefix = this.relayAccessConfiguration.getApplicationName() + COOKIE_APP_NAME_SEPARATOR;
            Collection<Cookie> filteredCookies = CollectionUtils.select(requestCookies, new Predicate<Cookie>() {

                @Override
                public boolean evaluate(Cookie cookie) {
                    // Filtrage
                    if (StringUtils.startsWith(cookie.getName(), prefix)) {
                        // Translation
                        cookie.setName(StringUtils.substringAfter(cookie.getName(), prefix));
                        // CAP-29321
                        cookie.setDomain(relayAccessConfiguration.getHostname());
                        cookie.setPath(RELAY_COOKIE_PATH);
                        return true;
                    }
                    return false;
                }
            });

            // Ajout des cookies au client HTTP
            httpClient.getState().addCookies(filteredCookies.toArray(new Cookie[filteredCookies.size()]));
        }
        if (logger.isInfoEnabled())
            logger.info("<< filterAndTranslateRequestCookie");
    }

    /**
     * SONAR issue fix- Contains dss jsession id.
     *
     * @return the string
     */
    private String containsDssJsessionId() {
        if (requestBody.toString().contains("dssJsessionId") && logger.isInfoEnabled()) {
            logger.info(">> Taking dssJessionId from Request Body # {}", StringUtils.substringBetween(requestBody.toString(), DSSJ_SESSIONID, "\""));
        }
        return StringUtils.substringBetween(requestBody.toString(), DSSJ_SESSIONID, "\"");
    }

    /**
     * Translation des cookies re�us de l'URL cible � destination du client.
     * 
     * @param httpClient l'objet {@link HttpClient}
     * @throws FwkException si une erreur survient
     */
    private void translateResponseCookie(HttpClient httpClient) throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> translateResponseCookie");
        // sonar issue fixed
        Set<Cookie> outCookies = new HashSet<>();

        final String prefix = this.relayAccessConfiguration.getApplicationName() + COOKIE_APP_NAME_SEPARATOR;
        Cookie[] cookies = httpClient.getState().getCookies();
        // On parcours � partir de la fin pour avoir la bonne valeur si un cookie a �t� modif� (risque de doublon dans le tableau, si le path
        // est
        // diff�rent en raison de notre translation)
        for (int i = cookies.length - 1; i >= 0; i--) {
            final Cookie cookie = cookies[i];
            final Cookie newCookie = new Cookie(/* domain */null, prefix + cookie.getName(), cookie.getValue(), RELAY_COOKIE_PATH,
                    cookie.getExpiryDate(), cookie.getSecure());
            outCookies.add(newCookie);
        }

        setOutput(OUT_COOKIES, outCookies);
        if (logger.isInfoEnabled())
            logger.info("<< translateResponseCookie");
    }

    /**
     * Construction de la requete post.
     *
     * @param inputRequest the input request
     * @return requete post
     */
    // sonar fix
    private HttpMethod buildPostMethod(String inputRequest) {
        HttpMethod methodRequest = new PostMethod(targetApplicationUrl);

        String extractedString = "";
        // sonar issue fixed
        ByteArrayRequestEntity inRequestEntity = null;
        // sonar issue fixed : Refactor this method to reduce its Cognitive Complexity
        if (logger.isInfoEnabled())
            logger.info("Relay of the request to [{}] : {}", this.relayAccessConfiguration.getApplicationName(), inputRequest);

        if (inputRequest.contains("dssJsessionId")) {
            // sonar issue fixed
            // CAP-29321
            if (logger.isInfoEnabled())
                logger.info(">> Removing dssJessionId from Request Body # {}", StringUtils.substringBetween(inputRequest, DSSJ_SESSIONID, "\""));
            inputRequest = StringUtils.remove(inputRequest, StringUtils.substringBetween(inputRequest, DSSJ_SESSIONID, "\""));
            inputRequest = StringUtils.remove(inputRequest, ",\"dssJsessionId\":\"\"");
            // sonar issue fixed
            if (logger.isInfoEnabled())
                logger.info(">> Request body after removing dssJessionId: {}", inputRequest);
        }

        String requestBodyInput = inputRequest.replace("\\", "");
        // docsoa webservice

        if (StringUtils.isNotEmpty(inputRequest) && inputRequest.contains("XML_PARAM=")) {
            extractedString = inputRequest;
            extractedString = extractedString.substring(extractedString.indexOf("XML_PARAM="), extractedString.trim().length() - 2);
            extractedString = extractedString.replace("\\", "");

            inRequestEntity = new ByteArrayRequestEntity(extractedString.getBytes());

        } else if (StringUtils.isNotEmpty(inputRequest)
                && (inputRequest.contains(RelayConstants.REPPS_SERVER) || inputRequest.contains(RelayConstants.REPPS))) {
            // Fix POUDG-6642
            if (inputRequest.contains(RelayConstants.EDIAG_HEADERS)) {
                extractedString = inputRequest.substring(inputRequest.indexOf(RelayConstants.REPPS_XML), inputRequest.lastIndexOf("\"}"));
                extractedString = extractedString.replace("\\", "");
                extractedString = extractedString.replace("}}", "}");
            }
            inRequestEntity = new ByteArrayRequestEntity(extractedString.getBytes());
        } else if (requestBodyInput.contains(RelayConstants.VIN) && requestBodyInput.contains(RelayConstants.LANG)
                && requestBodyInput.contains(RelayConstants.CN) && requestBodyInput.contains(RelayConstants.VEHICLEDATAS)) {
            requestBodyInput = requestBodyInput.replace("\"{", "{");
            requestBodyInput = requestBodyInput.replace("]}\"", "]}");
            JSONObject corvetInput = corvetRequest(requestBodyInput);
            String corvetInputXml = jsonToXml(corvetInput.toString());
            // sonar issue fixed --- start
            if (logger.isInfoEnabled())
                logger.info("Request Message for Corvet : {}", corvetInputXml);
            if (corvetInputXml != null) {
                inRequestEntity = new ByteArrayRequestEntity(corvetInputXml.getBytes());
            } // --- end
        } else if (StringUtils.isNotEmpty(inputRequest) && inputRequest.contains(RelayConstants.EDIAG_XML)) {
            String ediagInput = inputRequest.substring(inputRequest.indexOf(RelayConstants.EDIAG),
                    inputRequest.lastIndexOf(RelayConstants.EDIAG_END));
            ediagInput = ediagInput.concat(RelayConstants.EDIAG_END);

            // Fix for POUDG-6568
            ediagInput = RelayConstants.XML_ENC.concat(ediagInput);
            ediagInput = ediagInput.replaceAll(RelayConstants.EDIAG_ESCAPE, RelayConstants.BLANK);
            // sonar issue fixed
            if (logger.isInfoEnabled())
                logger.info("Request Message before sending to ediag: [{}] ", ediagInput);
            // Sonar Issue fixed- cap 23738
            inRequestEntity = new ByteArrayRequestEntity(ediagInput.getBytes(StandardCharsets.UTF_8));// Fix for POUDG-6568, Sonar issue fixed
            // sonar issue fixed
            // CAP-29321
            if (logger.isInfoEnabled()) {
                logger.info("EDIAG RequestEntity : {}", inRequestEntity.toString());
            }
        } else {
            // for messaging part or any other calls
            inRequestEntity = new ByteArrayRequestEntity(inputRequest.getBytes());
        }
        // CAP-25017 : sonar issue fixed : Refactor this method to reduce its Cognitive Complexity
        inRequestEntity = prepareReqBodyForSeravUl(inputRequest, inRequestEntity);
        // sending request from post method to serav
        ((PostMethod) methodRequest).setRequestEntity(inRequestEntity);
        // sonar issue fixed
        // CAP-29321
        if (logger.isInfoEnabled())
            logger.info("End of Post method >>>>>>>>>>>>>>>>>>>>>>>>>> {}", methodRequest);
        return methodRequest;
    }

    /**
     * // CAP-29321: Code Refactor: Prepare req body for serav ul.
     *
     * @param inputRequest the input request
     * @param inRequestEntity the in request entity
     * @return the byte array request entity
     */
    public ByteArrayRequestEntity prepareReqBodyForSeravUl(String inputRequest, ByteArrayRequestEntity inRequestEntity) {
        return inRequestEntity;
    }

    /**
     * Permet d'initialiser le client http qui sera utilise pour envoyer la requete vers l'url cible met a jour les accreditations neccessaires pour
     * l'acces a la cible (proxy+authentification avec le compte de service).
     *
     * @param requestBody the request body
     * @param marque the marque
     * @param corvetOutput the corvet output
     * @return the string
     */

    private String docSoaSoapRequest(String requestBody, String marque, String corvetOutput) {
        String docSoaResponse = "";
        // sonar issue fixed
        String requestBodyInput = requestBody.replace("\\", "");
        requestBodyInput = requestBodyInput.replace("\"{", "{");
        requestBodyInput = requestBodyInput.replace("]}\"", "]}");

        JSONObject jsonObj = new JSONObject(requestBodyInput);

        String vinNumber = jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_VIN);

        ClientParameters clientParameter = new ClientParameters();
        clientParameter.setTransportUsername(ServerConfigurationManager.getInstance().getVariableValue(TRANSPORT_USER_NAME));
        clientParameter.setTransportPwd(ServerConfigurationManager.getInstance().getVariableValue(TRANSPORT_PWD));
        clientParameter.setMsgUsername(RelayConstants.MESSAGE_USER_NAME);
        clientParameter.setMsgPassword(RelayConstants.MESSAGE_PASSWORD);

        LCDVService lcdvService = null;
        FdzServiceLCDVResponseType fdzServiceLCDVResponse;
        LCDVServiceClient lcdvServiceClient = LCDVServiceClient.getInstance();
        try {

            lcdvService = lcdvServiceClient.getService(clientParameter); // creating request for DocSoa and setting the request data
            FdzServiceLCDVRequestType fdzServiceLCDVRequest = new FdzServiceLCDVRequestType();

            VINType vinType = new VINType();
            // CAP-29321 directly assigning vds,vis,wmi
            vinType.setVDS(vinNumber.substring(RelayConstants.THREE, RelayConstants.NINE));
            vinType.setVIS(vinNumber.substring(RelayConstants.NINE, RelayConstants.SEVENTEEN));
            vinType.setWMI(vinNumber.substring(RelayConstants.ZERO, RelayConstants.THREE));

            // POUDG 6522
            // sonar issue fixed
            // CAP-29321 directly using instead of storing language
            String[] language1 = jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_LANG).split("_");
            if (!StringUtils.isEmpty(jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_CN))) {
                fdzServiceLCDVRequest
                        .setPays(CodePaysISOStype.fromValue(jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_CN)));
                fdzServiceLCDVRequest.setPaysUser(
                        CodePaysISOStype.fromValue(jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_CN)));
            } else {
                // sonar issue fixed
                fdzServiceLCDVRequest.setPays(CodePaysISOStype.fromValue(language1[1]));
                // sonar issue fixed
                fdzServiceLCDVRequest.setPaysUser(CodePaysISOStype.fromValue(language1[1]));
            }

            fdzServiceLCDVRequest.setMode(RelayConstants.DOCSOA_MODE);
            fdzServiceLCDVRequest.setVehCom(true);
            // sonar issue fixed
            fdzServiceLCDVRequest.setLangue(CodeLangueISOType.fromValue(language1[0].toLowerCase()));
            fdzServiceLCDVRequest.setVin(vinType);
            // CAP-23738, CAP-29321
            fdzServiceLCDVRequest.setMarque(getMarqueType(marque));

            // CAP-29321
            if (logger.isInfoEnabled()) {
                logger.info("********************   LCDV Service Request Parameters Start   ********************");

                logger.info("Pays: [{}]", fdzServiceLCDVRequest.getPays());
                logger.info("PaysUser: [{}]", fdzServiceLCDVRequest.getPaysUser());
                logger.info("Mode: [{}]", fdzServiceLCDVRequest.getMode());
                logger.info("VehCom: [{}]", fdzServiceLCDVRequest.isVehCom());
                logger.info("Langue: [{}]", fdzServiceLCDVRequest.getLangue());
                logger.info("VIN: [{}]", vinNumber);
                logger.info("VDS: [{}] VIS:[{}] WMI:[{}]", fdzServiceLCDVRequest.getVin().getVDS(), fdzServiceLCDVRequest.getVin().getVIS(),
                        fdzServiceLCDVRequest.getVin().getWMI());
                logger.info("Marque: [{}]", fdzServiceLCDVRequest.getMarque());

                logger.info("********************   LCDV Service Request Parameters End   ********************");
            }

            fdzServiceLCDVResponse = lcdvService.getLCDV(fdzServiceLCDVRequest);
            if (logger.isInfoEnabled())
                logger.info("fdzServiceLCDVResponse.getLCDV() [{}] ", fdzServiceLCDVResponse.getLCDV().size());

            // POUDG-9055: If not empty then filter out LCDV on the basis of CORVET response
            if (jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.LISTE_ATTRIBUTES)) {

                if (logger.isInfoEnabled())
                    logger.info("Filtering the DOCSOA LCDV values by CORVET LISTE_ATTRIBUTE");
                filterLCDVDataBasisOfCORVETResponse(corvetOutput, fdzServiceLCDVResponse);
            }
            // POUDG-8742: code to check if LCDV from DOCSOA response is empty. If Empty populate the data from CORVET and set in LCDV
            else if (fdzServiceLCDVResponse.getCodeRetour() != 0 && fdzServiceLCDVResponse.getLCDV().isEmpty()) {
                setLCDVDataFromCorvet(corvetOutput, fdzServiceLCDVResponse);
            }
            docSoaResponse = objectToJson(fdzServiceLCDVResponse);
            if (logger.isInfoEnabled())
                logger.info("Response from docSOA: [{}]", docSoaResponse);
        } catch (

        ServiceException e1) {
            logger.error("Error while creating request for DocSoa and setting the request data:", e1);
            logger.error("VIN:[{}]", vinNumber);
        }
        return docSoaResponse;

    }

    /**
     * CAP-23738 : To get vehicle brand.
     *
     * @param marque the marque
     * @return the marque type
     */
    private MarquePSAType getMarqueType(String marque) {
        MarquePSAType marqueType = null;
        if (marque.equalsIgnoreCase(MarqueType.AP.getValue())) {
            marqueType = MarquePSAType.AP;
        } else if (marque.equalsIgnoreCase(MarqueType.AC.getValue()) || StringUtils.isEmpty(marque.trim())) {// Fix for POUDG-6492
            marqueType = MarquePSAType.AC;
        } else if (marque.equalsIgnoreCase(MarqueType.DS.getValue())) {
            marqueType = MarquePSAType.DS;
        } else if (marque.equalsIgnoreCase(MarqueType.AD.getValue())) {// Fix for POUDG-6751
            marqueType = MarquePSAType.AD;
        } else if (marque.equalsIgnoreCase(MarqueType.OV.getValue())) {// Fix for POUDG-7144
            marqueType = MarquePSAType.OV;
        } else if (marque.equalsIgnoreCase(MarqueType.AM.getValue())) {// Fix for POUDG-8742
            marqueType = MarquePSAType.AM;
        }
        return marqueType;
    }

    /**
     * Corvet request.
     *
     * @param inputCorvetRequest the input corvet request
     * @return the JSON object
     */
    private JSONObject corvetRequest(String inputCorvetRequest) {
        JSONObject jsonObj = new JSONObject(inputCorvetRequest);

        JSONObject emetteur = new JSONObject();

        emetteur.append(RelayConstants.EMETTEUR, ServerConfigurationManager.getInstance().getVariableValue(EMETTEUR_VAL));
        // emetteur.append(RelayConstants.EMETTEUR, RelayConstants.EMETTEUR_PVAL); // prod value
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).put(RelayConstants.ENTETE, emetteur);

        JSONObject recherche = new JSONObject();
        String vinNumber = jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.JSON_VIN);

        JSONObject critere = new JSONObject();
        critere.append(RelayConstants.WMI, vinNumber.substring(RelayConstants.ZERO, RelayConstants.THREE));
        critere.append(RelayConstants.VDS, vinNumber.substring(RelayConstants.THREE, RelayConstants.NINE));
        critere.append(RelayConstants.VIS, vinNumber.substring(RelayConstants.NINE, RelayConstants.SEVENTEEN));
        recherche.append(RelayConstants.CRITERE, critere);

        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).put(RelayConstants.RECHERCHE, recherche);

        JSONObject donneesVehicule = new JSONObject();
        // POUDG-8558
        JSONObject listOrgans;
        // cap 9291
        JSONObject listElectronique;
        JSONObject reponse = new JSONObject();

        reponse.append(RelayConstants.DONNEES_VEHICULE, donneesVehicule);
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).put(RelayConstants.REPONSE, reponse);
        donneesVehicule.put(RelayConstants.DONNEE, jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).get(RelayConstants.VEHICLE_DATAS));
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(RelayConstants.VEHICLE_DATAS);

        // sonar issue fixed for create constants--- start
        // cap 9291
        if (jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).has(LISTE_ELECTRONIQUES)) {
            listElectronique = new JSONObject();
            reponse.append(LISTE_ELECTRONIQUES, listElectronique);
            listElectronique.put(ELECTRONIQUE,
                    jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getJSONObject(LISTE_ELECTRONIQUES).get(ELECTRONIQUE));
            jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(ELECTRONIQUE);
            jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(LISTE_ELECTRONIQUES);
        } // --- end
          // POUDG-8558: Added Organe tag in request to CORVET
        if (jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).has(LISTE_ORGANES)) {
            listOrgans = new JSONObject();
            reponse.append(LISTE_ORGANES, listOrgans);
            listOrgans.put(ORGANE, jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getJSONObject(LISTE_ORGANES).get(ORGANE));
            jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(ORGANE);
            jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(LISTE_ORGANES);
        } // POUDG-8558:--- end
          // POUDG-9055: Start - Adding % at the end of DSS LISTE_ATTRIBUTE values
        JSONObject lcdvAttribute = new JSONObject();
        reponse.append(RelayConstants.LCDV_ATTRIBUT, lcdvAttribute);
        if (jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.LISTE_ATTRIBUTES)) {
            try {
                // Fetch the ATTRIBUT parameter from LISTE_ATTRIBUTS of DDC request.
                Object corvetListeAttributeArray = jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).getJSONObject(RelayConstants.LISTE_ATTRIBUTES)
                        .get(RelayConstants.ATTRIBUT);
                addPercentageAtEndToListeAttribut(corvetListeAttributeArray, lcdvAttribute);
            } catch (Exception e) {
                String message = "Exception while fetching attribute values from DDC request";
                logger.error(message, e);
            }
            // POUDG-9055: End
        } else {
            // Code added when there will be no tag of Liste_attribute in DDC request
            getAllLCDVAttributeFromCorvet(lcdvAttribute);
        }
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(RelayConstants.LISTE_ATTRIBUTES);
        // POUDG-8742: --end

        jsonObj.remove(RelayConstants.HEADERS);
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(RelayConstants.JSON_LANG);
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(RelayConstants.JSON_CN);
        jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE).remove(RelayConstants.JSON_VIN);
        JSONObject message = jsonObj.getJSONObject(RelayConstants.JSON_MESSAGE);
        jsonObj.append(RelayConstants.MESSAGE, message);
        jsonObj.remove(RelayConstants.JSON_MESSAGE);

        return jsonObj;

    }

    /**
     * Json to xml.
     *
     * @param content the content
     * @return the string
     */
    private String jsonToXml(String content) {

        JSONObject json;
        String xml = null;
        try {
            json = new JSONObject(content);
            xml = XML.toString(json);
            return xml;
            // sonar issue fixed
        } catch (JSONException e) {
            logger.error("Error while converting Json to XML:", e);
        }
        return xml;
    }

    /**
     * Object to json.
     *
     * @param response the response
     * @return the string
     */
    private String objectToJson(Object response) {
        ObjectMapper mapper;
        String fdzResponseInJson = null;
        try {
            mapper = new ObjectMapper();
            fdzResponseInJson = mapper.writeValueAsString(response);
        } catch (JsonProcessingException e) {
            logger.error("Error while converting Object to Json: ", e);
        }
        return fdzResponseInJson;
    }

    /**
     * Inits the http client.
     *
     * @param client the client
     * @throws FwkException the fwk exception
     */
    private void initHttpClient(HttpClient client) throws FwkException {
        DiagUserCredentials inputCredentials = (DiagUserCredentials) this.getInput(IN_REQUEST_CREDENTIALS);
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        AuthenticationBean serverAccount = serverConfigurationManager.getServerAccount();
        // CAP-25454 :Getting Technical account for SERAV(Diagcloud)
        AuthenticationBean serav = serverConfigurationManager.getSeravAccount();
        // CAP-25454 :Getting Technical account for EDIAG(Diagcloud)
        AuthenticationBean ediag = serverConfigurationManager.getEdiagAccount();
        // CAP-25454 :Getting Technical account for CampaignCode & getInfoVehicule(CORVET)
        AuthenticationBean corvet = serverConfigurationManager.getCorvetAccount();
        // CAP-25454 :Getting Technical account for CampaignCode & getInfoVehicule(CORVET)
        AuthenticationBean argos = serverConfigurationManager.getArgosAccount();
        // CAP-26498 :Getting Technical account for SERAV for RI/OI(Diagcloud Lot2)
        AuthenticationBean seravRi = serverConfigurationManager.getSeravRIAccount(); // Sonar issue fix
        // Removed lines for Sonar Issues
        // mise a jour des parametres "proxy"
        if (relayAccessConfiguration.isUseProxy()) {
            ProxyBean proxy = serverConfigurationManager.getProxy();

            client.getHostConfiguration().setProxy(proxy.getHostname(), proxy.getPort());

            client.getState().setProxyCredentials(new AuthScope(proxy.getHostname(), proxy.getPort(), AuthScope.ANY_HOST),
                    new UsernamePasswordCredentials(serverAccount.getLogin(), serverAccount.getPassword()));
        }
        if (logger.isInfoEnabled())
            logger.info("url passed in initHttpClient [{}]", relayAccessConfiguration.getUrl());
        UsernamePasswordCredentials credentials = null;
        // CAP-29321: START-Initialized param to reduce use of .toString() multiple times
        // sonar issue fixed
        String dss3hostname = this.getInput(RelayConstants.DSS3_HOSTNAME).toString();
        if (!relayAccessConfiguration.isForwardCredentials()
                && (!(dss3hostname.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))))) {
            // credentials = new UsernamePasswordCredentials(serverAccount.getLogin(), serverAccount.getPassword()); POUDG-6493
            // sonar issue fixed
            if (!(relayAccessConfiguration.getApplicationName().equalsIgnoreCase(SERAV))) {
                credentials = new UsernamePasswordCredentials(serverAccount.getLogin(), serverAccount.getPassword());
            } else {
                credentials = new UsernamePasswordCredentials(inputCredentials.getUserName(), inputCredentials.getPassword());
            }

        }
        // CAP-25454: adding condition for Diagcloud related calls
        else if ((dss3hostname.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME)))) {
            // On conserve la basic auth re�ue en entr�e
            credentials = getCredentialsForDiagcloud(serverAccount, serav, ediag, corvet, argos, seravRi); // Sonar issue fix
            // CAP-29321: END
        } else if (inputCredentials != null) {
            // On conserve la basic auth re�ue en entr�e
            credentials = new UsernamePasswordCredentials(inputCredentials.getUserName(), inputCredentials.getPassword());
        } else {
            // Erreur, on veut r�utiliser une basic auth manquante
            // CAP-25454 : condition added for handling diagcloud related calls
            if (!(dss3hostname.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))))
                throw new ServiceTechnicalException("Exception d'initialisation du client HTTP - Missing Basic Auth");
        }

        client.getState().setCredentials(
                new AuthScope(relayAccessConfiguration.getHostname(), relayAccessConfiguration.getPort(), AuthScope.ANY_REALM), credentials);

        // On envoie l'authentification avant que le serveur distant nous la demande
        client.getParams().setAuthenticationPreemptive(true);
        // CAP-17119: add socket timeout= 30sec for all application, CAP-19275: remove it for SERAV, EDIAG5-1546 and EDIAG5-1548: increase it to 5
        // mins for EDIAG ---- start
        // CAP-29321 Replacing class level constant EDIAG_APP
        if (relayAccessConfiguration.getApplicationId().equals(RelayConstants.EDIAG_APP)) {
            client.getParams().setSoTimeout(READ_TIMEOUT_EDIAG);
        } else if ((relayAccessConfiguration.getApplicationName().equals(SERAV_UL) || !relayAccessConfiguration.getApplicationId().equals(SERAV_APP))
                && !relayAccessConfiguration.getApplicationId().equals(RelayConstants.EDIAG_APP)) {
            client.getParams().setSoTimeout(READ_TIMEOUT);
        } // ---- end
    }

    /**
     * Gets the credentials for diagcloud.
     *
     * @param repps the repps
     * @param serav the serav
     * @param ediag the ediag
     * @param corvet the corvet
     * @param argos the argos
     * @param seravRi the serav ri
     * @return the credentials for diagcloud
     */
    // CAP-25454: START
    private UsernamePasswordCredentials getCredentialsForDiagcloud(AuthenticationBean repps, AuthenticationBean serav, AuthenticationBean ediag,
            AuthenticationBean corvet, AuthenticationBean argos, AuthenticationBean seravRi) { // Sonar issue fix
        UsernamePasswordCredentials credentials = null;
        /* START: CAP-26498 :DiagLot2- Add check for Serav RA and RI user */
        if ((relayAccessConfiguration.getApplicationName().equalsIgnoreCase(SERAV))
                && ((UserType.LDAP.toString()).equals(relayAccessConfiguration.getUserType()))) {
            credentials = new UsernamePasswordCredentials(serav.getLogin(), serav.getPassword());
        } else if ((relayAccessConfiguration.getApplicationName().equalsIgnoreCase(SERAV))
                && ((UserType.OI.toString()).equals(relayAccessConfiguration.getUserType()))) {
            credentials = new UsernamePasswordCredentials(seravRi.getLogin(), seravRi.getPassword()); // Sonar issue fix
        } else if (relayAccessConfiguration.getApplicationName().equalsIgnoreCase(ARGOS)) {
            credentials = new UsernamePasswordCredentials(argos.getLogin(), argos.getPassword());
        } else if (relayAccessConfiguration.getApplicationId().equals(RelayConstants.EDIAG_APP)) { // CAP-29321
            credentials = new UsernamePasswordCredentials(ediag.getLogin(), ediag.getPassword());
        } else if (relayAccessConfiguration.getApplicationId().equals(REPPS)) {
            credentials = new UsernamePasswordCredentials(repps.getLogin(), repps.getPassword());
        } else if (relayAccessConfiguration.getApplicationId().equals(NRV)) {// only for corvet
            credentials = new UsernamePasswordCredentials(corvet.getLogin(), corvet.getPassword());
        }
        return credentials;

    }
    // CAP-25454: END

    /**
     * Construction de la requete qui sera retourne au client du relais A2DR, mise a jour les parametres "OUT_HEADERS", "RESPONSE_FROM_TARGET" et
     * "METHOD".
     *
     * @param methodRelay requete a relayer vers le client
     * @param argosStatusMap the map
     * @param requestBody the request body
     * @throws IOException exception pouvant etre levee lors de l'ecriture de la requete
     * @throws FwkException exception pouvant etre levee lors de l'ecriture de la requete
     */
    private void buildResponse(HttpMethod methodRelay, Map<Integer, String> argosStatusMap, String requestBody) throws IOException, FwkException {
        // CAP-29321
        ByteArrayOutputStream responseBody = new ByteArrayOutputStream();

        try {

            // Read the response body.
            Header[] headers = methodRelay.getResponseHeaders();
            // sonar issue fixed
            Map<String, String> responseHeaders = new HashMap<>();

            filterHeader(headers, responseHeaders);

            setOutput(OUT_HEADERS, responseHeaders);

            byte[] bytes = methodRelay.getResponseBody();

            bytes = postTreatments(bytes, responseHeaders);

            responseBody.write(bytes);
            // sonar issue fixed

            // CAP-29321
            String response;
            if (!RelayConstants.EDIAG_APP.equals(relayAccessConfiguration.getApplicationId()))
                response = responseBody.toString();
            else
                response = "Ediag Response";

            if (logger.isInfoEnabled())
                // CAP-29321
                logger.info("Response coming from service >>> {}", response);

            if (StringUtils.isBlank(response) && logger.isWarnEnabled()) {
                // Sonar issue fix
                logger.warn("Response is empty or null: [{}]", relayAccessConfiguration.getApplicationName());
                logger.warn("Request: [{}]", requestBody);
                // CAP-29321
                logger.warn("Response: [{}]", Arrays.toString(methodRelay.getResponseBody()));
            }

            // Start CAP-23738 : send error messages to DDC for Corvet application.
            if (ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME)) && ErrorCode.ERROR_200_CODE != methodRelay.getStatusCode()) {
                setOutput(STATUS_CODE, Integer.valueOf(methodRelay.getStatusCode()));
                // CAP-29321
                setOutputInResponse(responseHeaders, ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_TWO + ERECA_RESPONSE_ERRORMSG
                        + getErrorMessage(methodRelay.getStatusCode()) + ERECA_END_RESPONSE);
                return;
            }
            // End CAP-23738

            // CAP-25017 : this block executed when response from serav service for BSRF unlocking calculator service :-Start
            if (relayAccessConfiguration.getApplicationName().equals(SERAV_UL)) {
                conversionUtility = new ConversionUtility();
                // CAP-29321
                responseBody = conversionUtility.convertXmlToJson(response, methodRelay.getStatusCode()); // EDIAG_Performance Issue fix
            }
            // CAP-25017 : this block executed when response from serav service for BSRF unlocking calculator service : - End
            // CAP-27774: set Response for Argos
            if (ARGOS.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                handleArgosResponse(methodRelay, argosStatusMap);
                int statusCode = RelayConstants.ZERO;
                for (Map.Entry<Integer, String> entry : argosStatusMap.entrySet()) {
                    statusCode = entry.getKey();
                    response = entry.getValue();
                }
                if (statusCode != RelayConstants.ZERO && response != null) {
                    setOutput(STATUS_CODE, Integer.valueOf(statusCode));
                    setOutputInResponse(responseHeaders, response);
                }
                return;
            }

            processDocsoaErecaResponse(responseHeaders, responseBody); // CAP-23738 : created method to solve sonar issue
        } finally {
            // CAP-29321 closing streams
            if (null != responseBody)
                responseBody.close();
        }
    }

    /**
     * Handle portfolio labels info response.
     *
     * @param httpConn the http conn
     * @param argosStatusMap the argos status map
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred
     */
    public void handlePortfolioLabelsInfoResponse(HttpsURLConnection httpConn, Map<Integer, String> argosStatusMap) throws IOException {
    }

    /**
     * CAP-23738 : To set Output in response.
     *
     * @param responseHeaders the response headers
     * @param response the ereca resposne
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws FwkException the fwk exception
     */
    protected void setOutputInResponse(Map<String, String> responseHeaders, String response) throws IOException, FwkException {
        byte[] responseByte = response.getBytes(StandardCharsets.UTF_8); // Sonar issue fixed
        responseByte = postTreatments(responseByte, responseHeaders);
        ByteArrayOutputStream responseByteArray = new ByteArrayOutputStream();
        responseByteArray.write(responseByte);
        setOutput(RESPONSE_FROM_TARGET, responseByteArray);
        // CAP-29321 Closing stream
        responseByteArray.close();
    }

    /**
     * Process docsoa ereca response.
     *
     * @param responseHeaders the response headers
     * @param responseBody the response body
     * @throws FwkException the fwk exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void processDocsoaErecaResponse(Map<String, String> responseHeaders, ByteArrayOutputStream responseBody)
            throws FwkException, IOException {
        String lcdvBaseValue = "";

        // sonar issue fixed
        if (relayAccessConfiguration.getApplicationName().equalsIgnoreCase(CORVET)) {
            String corvetOutput = responseBody.toString();

            if (StringUtils.isNotBlank(corvetOutput)) {// Fix for POUDG-6965

                // sonar issue fixed for create constants--- start
                if (corvetOutput.contains(LCDV_BASE)) {
                    // CAP-29321
                    lcdvBaseValue = corvetOutput.substring(corvetOutput.indexOf(LCDV_BASE) + LCDV_BASE.length(), corvetOutput.indexOf(LCDV_BASE_END));
                }
                // CAP-23738 : If LCDV base attribute is not received from CORVET, for eRECA application returnCode=1
                else if (ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))) {
                    setOutput(STATUS_CODE, Integer.valueOf(HttpStatus.SC_OK));
                    // CAP-29321
                    setOutputInResponse(responseHeaders, ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_ONE + ERECA_RESPONSE_ERRORMSG
                            + ERECA_RESPONSE_UNKNOWN_VIN + ERECA_END_RESPONSE);
                    return;
                }

                if (ERECA.equalsIgnoreCase((String) this.getInput(IN_APPLICATION_NAME))) { // CAP-23738
                    getCampaignCodeFromEreca(responseHeaders, lcdvBaseValue);
                } else {
                    getDocsoaResponse(responseHeaders, lcdvBaseValue, corvetOutput);
                }
            } else {
                logger.warn("Response is empty or null: [{}]", relayAccessConfiguration.getApplicationName());
                setOutput(RESPONSE_FROM_TARGET, responseBody);
            }
        } else

            setOutput(RESPONSE_FROM_TARGET, responseBody);
    }

    /**
     * To get Docsoa response and merge with Corvet response.
     *
     * @param responseHeaders the response headers
     * @param lcdvBaseValue the lcdv base value
     * @param corvetOutput the corvet output
     * @return the docsoa response
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws FwkException the fwk exception
     */
    private void getDocsoaResponse(Map<String, String> responseHeaders, String lcdvBaseValue, String corvetOutput) throws IOException, FwkException {
        String corvetDocsoaResponse;
        String docSoaResponseOutput;
        // Fix for POUDG-6492
        if (StringUtils.isEmpty(lcdvBaseValue.trim()))
            docSoaResponseOutput = docSoaSoapRequest(requestBody.toString(), lcdvBaseValue, corvetOutput);
        else
            docSoaResponseOutput = docSoaSoapRequest(requestBody.toString(), lcdvBaseValue.substring(1, 2), corvetOutput);
        // sonar issue fixed
        // CAP-29321
        if (logger.isInfoEnabled())
            logger.info("lcdvBaseValue : {} docSoaResponseOutput : {}", lcdvBaseValue, docSoaResponseOutput);
        // CAP-29321
        corvetDocsoaResponse = corvetDocSoa(XML.toJSONObject(corvetOutput).toString(), docSoaResponseOutput);
        // sonar issue fixed
        if (logger.isInfoEnabled())
            logger.info("corvetDocsoaResponse : {}", corvetDocsoaResponse);
        if (StringUtils.isBlank(corvetDocsoaResponse))
            // sonar issue fixed
            logger.warn("corvetDocsoaResponse is empty. ");
        setOutputInResponse(responseHeaders, corvetDocsoaResponse);
    }

    /**
     * CAP-23738 : To call ERECA web service and get Campaign codes.
     *
     * @param responseHeaders the response headers
     * @param lcdvBaseValue the lcdv base value
     * @return the campaign code from ereca
     * @throws FwkException the fwk exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void getCampaignCodeFromEreca(Map<String, String> responseHeaders, String lcdvBaseValue) throws FwkException, IOException {
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        AuthenticationBean corvet = serverConfigurationManager.getCorvetAccount();
        initializeErecaConfigurationFile();
        String request = ((ByteArrayOutputStream) this.getInput(IN_REQUEST_BODY)).toString();
        JSONObject jsonObject = new JSONObject(request);
        String language = jsonObject.getJSONObject(ERECA_MESSAGE).getString(LANG);
        String vin = jsonObject.getJSONObject(ERECA_MESSAGE).getString(VIN);
        StringBuilder url = new StringBuilder();
        url.append(erecaScheme).append(URL_CREATOR);
        HttpClient httpClient = new HttpClient();
        HttpMethod methodRequest;
        DiagUserCredentials inputCredentials = (DiagUserCredentials) this.getInput(IN_REQUEST_CREDENTIALS);
        // CAP-25454: fetching input credentials
        UsernamePasswordCredentials credentials = getCredentialsForCampaignCode(corvet, inputCredentials);

        httpClient.getParams().setAuthenticationPreemptive(true);
        httpClient.getParams().setSoTimeout(READ_TIMEOUT);

        MarquePSAType marqueType = null;
        if (lcdvBaseValue.length() > 2) {
            marqueType = getMarqueType(lcdvBaseValue.substring(1, 2));
        }
        String brand = ""; // Solved Sonar Issue
        if (marqueType != null) {
            brand = marqueType.name();
        }
        if (BRAND_OV.equalsIgnoreCase(brand)) {
            url.append(urlForOV);
            httpClient.getState().setCredentials(new AuthScope(urlForOV, ERECA_PORT, AuthScope.ANY_REALM), credentials);
        } else if (BRAND_AP.equalsIgnoreCase(brand)) {
            url.append(urlForAP);
            httpClient.getState().setCredentials(new AuthScope(urlForAP, ERECA_PORT, AuthScope.ANY_REALM), credentials);
        } else if (BRAND_AC.equalsIgnoreCase(brand) || BRAND_DS.equalsIgnoreCase(brand)) {
            url.append(urlForACDS);
            httpClient.getState().setCredentials(new AuthScope(urlForACDS, ERECA_PORT, AuthScope.ANY_REALM), credentials);
        } else {
            setOutput(STATUS_CODE, Integer.valueOf(ErrorCode.ERROR_200_CODE));
            String messageDetails = ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_ZERO + ERECA_RESPONSE_BRAND + brand + ERECA_RESPONSE_CAMPAIGNCODE
                    + ERECA_RESPONSE_EMPTY_CAMPAIGNCODE + ERECA_END_RESPONSE_SUCCESS;
            setOutputInResponse(responseHeaders, messageDetails);
            return;
        }

        url.append(CONTEXT_SEPARATOR).append(context).append(CONTEXT_SEPARATOR).append(vin);
        if (logger.isInfoEnabled())
            logger.info("ERECA URL : [{}]", url);
        methodRequest = new GetMethod(url.toString());
        url.setLength(0); // CAP-29321 Resetting StringBuilder to null
        filterAndCopyHeaders(methodRequest, null, null); // CAP-26498-DiagLot2
        methodRequest.setRequestHeader(ACCEPT_LANG, language);
        if (logger.isInfoEnabled())
            logger.info("Request Header to application [{}] : [{}]", ACCEPT_LANG, language);
        int statusCode = httpClient.executeMethod(methodRequest);

        if (ErrorCode.ERROR_200_CODE != statusCode) {
            setOutput(STATUS_CODE, Integer.valueOf(statusCode));
            String errorResposne = "";
            errorResposne = getErrorMessage(statusCode);
            String erecaResposne = ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_TWO + ERECA_RESPONSE_ERRORMSG + errorResposne + ERECA_END_RESPONSE;
            setOutputInResponse(responseHeaders, erecaResposne);
            return;
        }

        byte[] bytesEreca = methodRequest.getResponseBody();
        String responseForEreca = new String(bytesEreca, StandardCharsets.UTF_8);// Sonar issue fixed

        if (logger.isInfoEnabled())
            logger.info("Response from ERECA : [{}]", responseForEreca);

        String messageDetails = "";
        try {
            JSONArray jsonArray = new JSONArray(responseForEreca);
            Set<String> set = new HashSet<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj1 = jsonArray.getJSONObject(i);
                String codeCampaign = obj1.getString(CAMPAIGN);
                String status = obj1.getString(STATUS);
                if (ERECA_RESPONSE_NR.equalsIgnoreCase(status) && codeCampaign != null) {
                    set.add(codeCampaign);
                }
            }

            /** POUDG-8294 : remotion of space in Campagne codes */
            messageDetails = ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_ZERO + ERECA_RESPONSE_BRAND + brand + ERECA_RESPONSE_CAMPAIGNCODE
                    + set.toString().replace(COMA_WITH_SPACE, COMA_WITHOUT_SPACE) + ERECA_END_RESPONSE_SUCCESS;
        } catch (Exception e) {
            logger.error("Error message while parsing ereca response : ", e);
            messageDetails = ERECA_RESPONSE_RETURNCODE + ERECA_RESPONSE_CODE_TWO + ERECA_RESPONSE_ERRORMSG + ERECA_RESPONSE_OTHER_ERROR
                    + ERECA_END_RESPONSE;
        }
        setOutputInResponse(responseHeaders, messageDetails);
    }

    /**
     * Gets the credentials for campaign code.
     *
     * @param corvet the corvet
     * @param inputCredentials the input credentials
     * @return the credentials for campaign code
     * @throws FwkException the fwk exception
     */
    private UsernamePasswordCredentials getCredentialsForCampaignCode(AuthenticationBean corvet, DiagUserCredentials inputCredentials)
            throws FwkException {
        UsernamePasswordCredentials credentials = null;
        if ((inputCredentials != null) && (!this.getInput(RelayConstants.DSS3_HOSTNAME).toString()
                .contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME)))) {
            credentials = new UsernamePasswordCredentials(inputCredentials.getUserName(), inputCredentials.getPassword());
        }
        // CAP-25454: Adding condition for Diagcloud url of campaignCode
        else if ((this.getInput(RelayConstants.DSS3_HOSTNAME).toString()
                .contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME)))) {
            credentials = new UsernamePasswordCredentials(corvet.getLogin(), corvet.getPassword());
        } else {
            throw new ServiceTechnicalException("Exception d'initialisation du client HTTP - Missing Basic Auth");
        }
        return credentials;
    }

    /**
     * CAP-23738 : To retrieve error message.
     *
     * @param statusCode the status code
     * @return the error message
     */
    private String getErrorMessage(int statusCode) {
        String errorResposne;
        if (ErrorCode.ERROR_404_CODE == statusCode) {
            errorResposne = ERECA_RESPONSE_NOT_FOUND;
        } else if (ErrorCode.ERROR_401_CODE == statusCode) {
            errorResposne = ERECA_RESPONSE_UNAUTH;
        } else if (ErrorCode.ERROR_500_CODE == statusCode) {
            errorResposne = ERECA_RESPONSE_INTERNAL_SERVER_ERROE;
        } else {
            errorResposne = ERECA_RESPONSE_OTHER_ERROR;
        }
        return errorResposne;
    }

    /**
     * To filter headers.
     *
     * @param headers the headers
     * @param responseHeaders the response headers
     */
    protected void filterHeader(Header[] headers, Map<String, String> responseHeaders) {
        for (Header header : headers) {

            String name = StringUtils.lowerCase(header.getName());

            if (!FILTERED_HEADERS.contains(name)) {
                if ((StringUtils.length(header.getName()) <= MAX_LOG_SIZE) && (StringUtils.length(header.getValue()) <= MAX_LOG_SIZE)) {
                    if (logger.isInfoEnabled())
                        logger.info("Response Header to application [{}] : [{}]", header.getName(), header.getValue());
                } else {
                    if (logger.isInfoEnabled())
                        logger.info("Response Header to application TOO LONG TO LOG");
                }

                responseHeaders.put(header.getName(), header.getValue());
            }
        }
    }

    // Start CAP-23738
    /**
     * To initialise ereca-urls.properties file
     */
    private void initializeErecaConfigurationFile() {
        if (logger.isInfoEnabled())
            logger.info("initializeErecaConfigurationFile >> ");
        try {
            AbstractConfiguration erecaConfiguration = new PropertiesConfiguration(
                    Thread.currentThread().getContextClassLoader().getResource(ERECA_URLS_CONFIGURATION_FILE));

            urlForOV = erecaConfiguration.getString(ERECA_OV_BRAND_URL);
            urlForAP = erecaConfiguration.getString(ERECA_AP_BRAND_URL);
            urlForACDS = erecaConfiguration.getString(ERECA_ACDS_BRAND_URL);
            context = erecaConfiguration.getString(ERECA_CONTEXT);
            erecaScheme = erecaConfiguration.getString(ERECA_SCHEME);
        } catch (ConfigurationException e) {
            logger.error("Error while processing the ereca-urls.properties file : ", e);
        }
        if (logger.isInfoEnabled())
            logger.info("initializeErecaConfigurationFile << ");
    }
    // End CAP-23738

    /**
     * Corvet doc soa.
     *
     * @param corvetResponseInput the corvet response input
     * @param docsoaResponseInput the docsoa response input
     * @return the string
     */
    private String corvetDocSoa(String corvetResponseInput, String docsoaResponseInput) {
        String corvetDocsoa = "";
        String corvetResponse = "";
        String docsoaResponse = "";
        try {
            corvetResponse = corvetResponseInput.replace("\\", "");
            docsoaResponse = docsoaResponseInput.replace("\\", "");
            if (docsoaResponse.length() != 0) {
                docsoaResponse = docsoaResponse.substring(1, docsoaResponse.length() - 1);
            }
            if (!corvetResponse.isEmpty() && !docsoaResponse.isEmpty()) {
                JSONObject json = new JSONObject(corvetResponse);
                // sonar issue fixed
                JSONObject messageResponse = json.getJSONObject(MESSAGE);
                // sonar issue fixed
                JSONObject entiteResponse = messageResponse.getJSONObject(ENTETE);
                String entiteDocSoa = entiteResponse.toString().replace(entiteResponse.toString(), entiteResponse.toString() + "," + docsoaResponse);
                corvetDocsoa = messageResponse.toString().replace(entiteResponse.toString(), entiteDocSoa);
                corvetDocsoa = "{\"MESSAGE\":" + corvetDocsoa + "}";
            } else {
                // sonar issue fixed
                if (logger.isInfoEnabled())
                    logger.info("Response from DOCSOA & CORVET is NULL ");
                corvetDocsoa = corvetResponse;
            }

        } catch (Exception e) {
            logger.error("Error while creating DOCSOA & CORVET repsonse:", e);
            // sonar issue fixed
            String msg = "corvetResponse: " + corvetResponse + "docsoaResponse: " + docsoaResponse + "#";
            logger.error(msg);
        }
        return corvetDocsoa;
    }

    /**
     * R�cup�ration de la m�thode http.
     * 
     * @return methode http
     * @throws FwkException si une erreur survient
     */
    protected abstract ValidHttpMethod getHttpMethod() throws FwkException;

    /**
     * R�alisation des post traitements.
     * 
     * @param bytes contenu
     * @param responseHeaders ent�tes
     * @return contenu modifi�
     * @throws IOException si une erreur survient
     * @throws FwkException si une erreur survient
     */
    protected abstract byte[] postTreatments(byte[] bytes, Map<String, String> responseHeaders) throws IOException, FwkException;

    /**
     * POUDG-8742:Method is used to traverse and process the data coming from CORVET and set it in FdzServiceLCDVResponseTypeDSS. Sonar issue
     *
     * @param corvetOutput the corvet output
     * @param fdzServiceLCDVResponse the fdz service LCDV response
     */
    public void setLCDVDataFromCorvet(String corvetOutput, FdzServiceLCDVResponseType fdzServiceLCDVResponse) {

    }

    /**
     * POUDG-9055:Method is used filter LCDV data based on CORVET LISTE_ATTRIBUTES.
     *
     * @param corvetOutput the corvet output
     * @param fdzServiceLCDVResponse the fdz service LCDV response
     */
    public void filterLCDVDataBasisOfCORVETResponse(String corvetOutput, FdzServiceLCDVResponseType fdzServiceLCDVResponse) {

    }

    /**
     * POUDG-9055:Adding % at the end of LISTE_ATTRIBUTES.
     *
     * @param reponse the reponse
     * @param dssListeAttributeArray the ddc liste attribute array
     * @param lcdvAttribute lcdv array with added new attribute
     */
    public void addPercentageAtEndToListeAttribut(Object dssListeAttributeArray, JSONObject lcdvAttribute) {

    }

    /**
     * POUDG-9055: Method is used filter LCDV data based on CORVET LISTE_ATTRIBUTES.
     *
     * @param reponse the reponse
     * @param lcdvAttribute the lcdv attribute
     * @return the all LCDV attribute from corvet
     * @throws JSONException the JSON exception
     */
    public void getAllLCDVAttributeFromCorvet(JSONObject lcdvAttribute) {

    }

    /**
     * Gets the token ddc for set track ADA.
     *
     * @return the token ddc for set track ADA
     */
    public static String getTokenDdcForSetTrackADA() {
        return tokenDdcForSetTrackADA;
    }

    /**
     * Fetch data for apic LDAPOI.
     *
     * @param request the request
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public Map<Integer, String> fetchDataForApicLDAPOI(String request) throws IOException {
        return null;
    }

    /**
     * Builds the request for registration.
     *
     * @return the string
     * @throws FwkException the fwk exception
     */
    public String buildRequestForRegistration() throws FwkException {
        return null;
    }

}
