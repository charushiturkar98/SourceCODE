/*
 * Creation : 15 Jun 2021
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.inetpsa.o8d.weba2dr.beans.Ecu;
import com.inetpsa.o8d.weba2dr.beans.Frame;
import com.inetpsa.o8d.weba2dr.beans.Frames;
import com.inetpsa.o8d.weba2dr.beans.Message;
import com.inetpsa.o8d.weba2dr.beans.Parameters;
import com.inetpsa.o8d.weba2dr.beans.Repairingrequests;
import com.inetpsa.o8d.weba2dr.beans.Requests;
import com.inetpsa.o8d.weba2dr.beans.UnlockBsrfResponseBean;
import com.inetpsa.o8d.weba2dr.beans.Unlockingcontent;

/**
 * Json to xml & xml to jon.
 *
 * @author SC28579
 */
public class ConversionUtility {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConversionUtility.class);

    /**
     * Convert json to xml.
     *
     * @param requestInJson the request in json
     * @return the string
     * @throws JAXBException the JAXB exception
     * @throws IOException
     * @throws JsonProcessingException
     */
    public String convertJsonToXml(String requestInJson) {
        JSONObject json;
        StringWriter requestInXml = null;
        String finalRequestInXml = null;
        ObjectMapper objectMapper = null;
        ObjectNode node = null;
        try {
            objectMapper = new ObjectMapper();
            node = (ObjectNode) objectMapper.readTree(requestInJson);
            node.remove(RelayConstants.REQUEST_HEADERS);
            json = new JSONObject(node.toString());
            json = (JSONObject) json.get(RelayConstants.REQUEST_MESSAGE);
            Message message = new Message();
            JAXBContext contextObj = JAXBContext.newInstance(Message.class);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            String listOfFrameStr = json.getString(RelayConstants.LIST_OF_FRAME).replace(RelayConstants.OPEN, "").replace(RelayConstants.CLOSE, "");
            List<String> listOfFrame = Arrays.asList(listOfFrameStr.split(RelayConstants.COMA));

            Frames frames = new Frames();
            List<Frame> frameList = new ArrayList<>();
            for (int i = 0; i < listOfFrame.size(); i++) {
                Frame frame = new Frame();
                frame.setValue(listOfFrame.get(i));
                frameList.add(frame);
            }
            frames.setFrame(frameList);

            Ecu ecu = new Ecu();
            ecu.setCodeapp(json.getString(RelayConstants.APP_CODE));
            ecu.setFrames(frames);
            ecu.setUnlockseed(json.getString(RelayConstants.SEED));
            /** CAP-29146 Adding new parameter */
            if (json.has(RelayConstants.CYBER_UIN)) {
                ecu.setCyberUin(json.getString(RelayConstants.CYBER_UIN));
            }
            Parameters parameters = new Parameters();
            parameters.setVin(json.getString(RelayConstants.VIN_BSRF));
            parameters.setCasutilisation(json.getString(RelayConstants.CAS_UTILISATION));
            parameters.setEcu(ecu);

            Requests requests = new Requests();
            Unlockingcontent unlockingcontent = new Unlockingcontent();
            requests.setUnlockingcontent(unlockingcontent);

            Repairingrequests repairingrequests = new Repairingrequests();
            repairingrequests.setParameters(parameters);
            repairingrequests.setRequests(requests);

            message.setMockmessage(Boolean.TRUE);
            message.setRepairingrequests(repairingrequests);
            requestInXml = new StringWriter();
            marshallerObj.marshal(message, requestInXml);
            finalRequestInXml = requestInXml.toString();
            LOGGER.info("Converting request from json to xml : {}", finalRequestInXml);
        } catch (JSONException | IOException | JAXBException e) {
            LOGGER.error("Error while converting Json to XML : {0}", e);
        }
        return finalRequestInXml;
    }

    /**
     * Convert xml to json.
     *
     * @param responseBody the response body
     * @param statusCode the status code
     * @return the byte array output stream
     */
    public ByteArrayOutputStream convertXmlToJson(String responseBody, int statusCode) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Message message = new Message();
        UnlockBsrfResponseBean unlockBsrfResponseBean = new UnlockBsrfResponseBean();
        JAXBContext jaxbContext = null;
        Unmarshaller unmarshaller = null;
        ObjectMapper objectMapper = null;
        String responseInjson = null;
        try {
            if (statusCode != RelayConstants.SERAV_UL_SUCCESS_STATUS_CODE) {
                unlockBsrfResponseBean.setComments(RelayConstants.OTHER_ERROR);
            } else {
                jaxbContext = JAXBContext.newInstance(Message.class);
                unmarshaller = jaxbContext.createUnmarshaller();
                message = (Message) unmarshaller.unmarshal(new StringReader(responseBody));

                if ((message.getRepairingrequests().getRequests().getRequestreturncode().getValue()).equals(RelayConstants.SUCCESS_CODE)) {
                    unlockBsrfResponseBean.setReturnCode(message.getRepairingrequests().getRequests().getRequestreturncode().getValue());
                    unlockBsrfResponseBean.setIndexConfidence(String.valueOf(message.getRepairingrequests().getParameters().getIndexconfidence()));
                    unlockBsrfResponseBean.setUnlockingValue(message.getRepairingrequests().getRequests().getUnlockingcontent().getUnlockingvalue());
                } else {
                    unlockBsrfResponseBean.setReturnCode(message.getRepairingrequests().getRequests().getRequestreturncode().getValue());
                    unlockBsrfResponseBean.setComments(message.getRepairingrequests().getRequests().getRequestreturncode().getComment());

                }
            }
            objectMapper = new ObjectMapper();
            responseInjson = objectMapper.writeValueAsString(unlockBsrfResponseBean);
            LOGGER.info("Converting response from xml to json : {}", responseInjson);
            byteArrayOutputStream.write(responseInjson.getBytes());
        } catch (Exception e) {
            LOGGER.error("Error while converting XML to Json : {0}", e);
        }
        return byteArrayOutputStream;
    }

}
