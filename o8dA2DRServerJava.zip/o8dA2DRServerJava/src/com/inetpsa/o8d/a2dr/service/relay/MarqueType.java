/*
 * Creation : 21 juil. 2017
 */
package com.inetpsa.o8d.a2dr.service.relay;

public enum MarqueType {
    AP("P"), AC("C"), DS("S"), AD("D"), OV("G"), AM("M");// Fix for POUDG-6751 // Fix for CAP-11495 // Fix for POUDG-8742

    private final String value;

    private MarqueType(final String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }
}