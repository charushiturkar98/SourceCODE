package com.inetpsa.o8d.a2dr.service.metier;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.persistence.IPersistentContextKey;
import com.inetpsa.fwk.service.persistence.OJBPersistentContext;
import com.inetpsa.o8d.a2dr.beans.DiagboxJetonBean;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.beans.VinA2DR;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.security.PasswordManagerException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.oin.psoasis.client.PsOasisConsommer;
import com.inetpsa.oin.psoasis.client.PsOasisCosumeJeton;
import com.inetpsa.oin.psoasis.client.bean.Item;
import com.inetpsa.oin.psoasis.client.bean.Items;
import com.inetpsa.oin.psoasis.client.constant.UniteDuree;

/**
 * Utilisation des jetons.
 * 
 * @author e358045
 */
public class O8DFC1AuthorisationUsageService extends AbstractA2DRBusinessService {

    /** nombre de jours pour les jetons */
    public static final int NB_JOURS_JETONS = 7;

    /** nom du service */
    public static final String SERVICE_NAME = "O8DFC1_service";
    /** parametres */
    public static final String IN_DIAG_USER_INSTANCE = "IN_DIAG_USER_INSTANCE";
    /** parametre Vin re�u de DiagBox */
    public static final String IN_DIAGBOX_VIN = "IN_DIAGBOX_VIN";
    /** parametre AccordConsommation re�u de DiagBox */
    public static final String IN_DIAGBOX_ACCORD_CONSO = "IN_DIAGBOX_ACCORD_CONSO";
    /**
     * Constante OUT_HEADERS : represente les headers de la requete retournee par le service metier A2DR Utilise par le service : A2DRDialogueService
     * (OUT_HEADER est les headers de RESPONSE_FROM_TARGET) sera utilise via un objet MAP
     */
    public static final String OUT_HEADERS = "OUT_HEADERS";
    /** ensemble des resultat */
    public static final String OUT_BEAN = "OUT_BEAN";

    /** The Constant ADS. */
    public static final String ADS = "ADS";

    /** The Constant AS. */
    public static final String AS = "AS";

    /** The Constant SDS. */
    public static final String SDS = "SDS";

    /** The Constant DS. */
    public static final String DS = "DS";

    /** The Constant ADF. */
    public static final String ADF = "ADF";

    /** The Constant AD. */
    public static final String AD = "AD";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probelem.
     */
    public O8DFC1AuthorisationUsageService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.fwk.service.BusinessService#doExecute()
     */
    protected void doExecute() throws FwkException {
        logger.debug("debut Execution du service");

        IPersistentContextKey key = null;
        AbstractDiagUserConnector diagUser = null;

        try {
            diagUser = (AbstractDiagUserConnector) this.getInput(IN_DIAG_USER_INSTANCE);

            this.setOutput(O8DFC1AuthorisationUsageService.OUT_BEAN, new DiagboxJetonBean());

            Map<String, String> mapHeader = new HashMap<>();
            this.setOutput(OUT_HEADERS, mapHeader);

            if (null == diagUser) {
                throw new AuthentificationException("Le connecteur 'DiagUser' non present en session");
            }

            logger.debug("Recuperation des donnees du service de l'utilisateur [{}]", diagUser.getUserName());

            // ///////////////////////////////////////////////////////////////////
            // ///////////////////////////////////////////////////////////////////
            String vinDiagBox = (String) this.getInput(IN_DIAGBOX_VIN);
            String accordConsommation = (String) this.getInput(IN_DIAGBOX_ACCORD_CONSO);
            if (logger.isInfoEnabled()) {
                logger.info("accordConsommation {}", accordConsommation);
            }

            key = buildPersistentContextKey();
            OJBPersistentContext persistentContext = (OJBPersistentContext) getPersistentContext(key);
            PersistenceBroker broker = null;
            // ///////////////////////////////////////////////////////////////
            // ////////////////////////////////////////////////////////////////

            logger.debug("On rentre dans le try de O8DFC1Authorisation");
            broker = persistentContext.getBroker();
            Criteria criteria = new Criteria();
            criteria.addEqualTo("USER_LOGIN", diagUser.getUserName());

            QueryByCriteria q = new QueryByCriteria(UserA2DR.class, criteria);

            UserA2DR crudUserA2DR = (UserA2DR) broker.getObjectByQuery(q);

            if (checkUser(crudUserA2DR, diagUser.getDiagUserCredentials())) {
                setOutputDatas(accordConsommation, crudUserA2DR, vinDiagBox);
            }
        } catch (PersistenceBrokerException e) {
            if (diagUser != null)
                logger.warn("Erreur lors de la recherche de l'utilisateur '" + diagUser.getUserName() + "' en base a2dr", e);

            throw new FwkException(e);
        } catch (PasswordManagerException e) {
            logger.warn("Erreur lors du controle du mot de passe de l'utilisateur '" + diagUser.getUserName() + "'", e);
            throw new FwkException(e);
        } finally {
            if (key != null) {
                try {
                    closePersistentContext(key);
                } catch (FwkException ex) {
                    logger.warn("Erreur lors de la fermeture de context transactionnel", ex);
                }
            }
        }
    }

    /**
     * Fonction : Prendre en compte la demande d�usage de DiagBox [O8D-FC2]
     * 
     * @param crudUserA2DR objet UserA2DR contenant la fiche d'identit� de l'op�rateur ind�pendant
     * @param vinDiagBox VIN du v�hicule � tester
     * @return Un bean contenant les informations de sortie (nom prenom, nbrdejeton, identification, autorisation,...)
     */
    private DiagboxJetonBean prendreEnCompteDemandeUsageDiagBox(UserA2DR crudUserA2DR, String vinDiagBox) {

        DiagboxJetonBean resultat = new DiagboxJetonBean();
        resultat.setIdentification(true);
        resultat.setNomPrenom(crudUserA2DR.getPrenom() + " " + crudUserA2DR.getNom());
        AbstractDiagUserConnector diagUser = null;

        // Ajout du mode d�grad� le : 19/01/2009
        PsOasisCosumeJeton psOasisCosumeJeton;
        try {
            diagUser = (AbstractDiagUserConnector) this.getInput(IN_DIAG_USER_INSTANCE);
            String marque = diagUser.getDiagUserCredentials().getMarque();
            if (marque == null) {
                if (logger.isInfoEnabled())
                    logger.info("Marque is null {} ", marque);
            } else {

                if ("ADS".equalsIgnoreCase(marque) || "AS".equalsIgnoreCase(marque) || "SDS".equalsIgnoreCase(marque))
                    marque = "DS";
                else if ("ADF".equalsIgnoreCase(marque)) {
                    marque = "AD";
                }
            }
            logger.info("Marque => prendreEnCompteDemandeUsageDiagBox {} ", marque);

            psOasisCosumeJeton = new PsOasisCosumeJeton(crudUserA2DR.getLogin(), marque);

            psOasisCosumeJeton.consumeJeton("A2DR_JETONS", 1, NB_JOURS_JETONS, UniteDuree.JOUR, vinDiagBox);
            Items items = psOasisCosumeJeton.send();
            if (items == null) {
                logger.error("Execution du mode d�grad� d'A2DR (POI indisponible) => prendreEnCompteDemandeUsageDiagBox");
                return this.verifierAutUsageDiagBox(crudUserA2DR, vinDiagBox, marque);
            }

            Iterator itItems = items.iterator();

            logger.debug("Test de consommation");

            Item itemConsume = null;

            if (itItems.hasNext()) {
                itemConsume = (Item) itItems.next();
            }
            if (itemConsume != null && itemConsume.isValid()) {
                logger.debug("Consommation r�alis�e");

                // Si la consommation est r�alis�e, il faut d�cr�menter le nombre de jeton
                resultat.setNbJeton(crudUserA2DR.getNbrJetons() - 1);
                resultat.setConsommationRealisee(true);
                resultat.setAutorisation(true);
            } else {
                logger.debug("diagUser.getMarque() {}", diagUser.getMarque());
                resultat = this.verifierAutUsageDiagBox(crudUserA2DR, vinDiagBox, marque);
            }

        } catch (Exception e) {
            logger.error("ERROR ", e);
        }

        return resultat;
    }

    /**
     * Fonction : V�rifier l�autorisation d�usage de DiagBox [O8D-FC1]
     * 
     * @param crudUserA2DR objet UserA2DR contenant la fiche d'identit� de l'op�rateur ind�pendant
     * @param vinDiagBox VIN du v�hicule � tester
     * @return Un bean contenant les informations de sortie (nom prenom, nbrdejeton, identification, autorisation,...)
     */
    private DiagboxJetonBean verifierAutUsageDiagBox(UserA2DR crudUserA2DR, String vinDiagBox, String marque) {

        DiagboxJetonBean resultat = new DiagboxJetonBean();
        resultat.setIdentification(true);

        logger.debug("Nombre de jetons => {}, chaine : {}", crudUserA2DR.getNbrJetons(), crudUserA2DR.getNbrJetons());

        resultat.setNomPrenom(crudUserA2DR.getPrenom() + " " + crudUserA2DR.getNom());
        resultat.setNbJeton(crudUserA2DR.getNbrJetons());
        resultat.setConsommationRealisee(false);

        boolean condition = false;

        // POUDG-7590 -[DSS]DIAGBOX 9.63 POI Fonctionnement compte avec jeton non conforme (Issue was for DS brand)
        String marqueToPOI = marque;
        if (marqueToPOI == null) {
            logger.info("Marque is null {} ", marqueToPOI);
        } else {
            if (ADS.equalsIgnoreCase(marqueToPOI) || AS.equalsIgnoreCase(marqueToPOI) || SDS.equalsIgnoreCase(marqueToPOI))
                marqueToPOI = DS;
            else if (ADF.equalsIgnoreCase(marqueToPOI)) {
                marqueToPOI = AD;
            }
        }
        logger.info("Marque => verifierAutorisationUsageDiagBox {} ", marqueToPOI);

        PsOasisConsommer psOasisConsommer = new PsOasisConsommer(crudUserA2DR.getLogin(), marqueToPOI);
        try {
            psOasisConsommer.addRef(vinDiagBox, 1);
            Items itemsConsommer = psOasisConsommer.send();

            if (itemsConsommer != null) {
                Iterator iteratorConsommer = itemsConsommer.iterator();

                Item itemConsommer = null;

                if (iteratorConsommer.hasNext()) {
                    itemConsommer = (Item) iteratorConsommer.next();
                    condition = itemConsommer.isValid();
                } else {
                    // V�rification en base si POI n'est pas disponible
                    Iterator iterVin = crudUserA2DR.getListeVin().iterator();
                    VinA2DR valeurDuVin = null;
                    while (iterVin.hasNext()) {
                        valeurDuVin = (VinA2DR) iterVin.next();
                        if (valeurDuVin.getVin().equals(vinDiagBox)) {
                            condition = true;
                        }
                    }
                }
            } else {
                // Mode degrade
                logger.error("Execution du mode d�grad� d'A2DR (POI indisponible) => verifierAutorisationUsageDiagBox");

                Iterator iterVin = crudUserA2DR.getListeVin().iterator();
                VinA2DR valeurDuVin = null;
                while (iterVin.hasNext()) {
                    valeurDuVin = (VinA2DR) iterVin.next();

                    if (valeurDuVin.getVin().equals(vinDiagBox)) {
                        condition = true;
                    }
                }
            }
            resultat.setAutorisation(condition);
        } catch (Exception e) {

            logger.trace("ERROR ", e);
        }

        return resultat;
    }

    /**
     * Appels POI.
     * 
     * @param accordConsommation Accord consommation
     * @param userA2dr utilisateur
     * @param vin identifiant vehicule
     * @throws FwkException si une erreur survient
     */
    private void setOutputDatas(String accordConsommation, UserA2DR userA2dr, String vin) throws FwkException {
        AbstractDiagUserConnector diagUser = null;
        diagUser = (AbstractDiagUserConnector) this.getInput(IN_DIAG_USER_INSTANCE);
        if ("True".equals(accordConsommation)) {
            // Fonction : Prendre en compte la demande d�'usage de DiagBox [O8D-FC2]
            logger.debug("D�but de la fonction => prendreEnCompteDemandeUsageDiagBox (accordConsommation == True)");
            this.setOutput(O8DFC1AuthorisationUsageService.OUT_BEAN, this.prendreEnCompteDemandeUsageDiagBox(userA2dr, vin));
        } else {
            // Fonction : V�rifier l�'autorisation d�'usage de DiagBox [O8D-FC1]
            logger.debug("D�but de la fonction => verifierAutorisationUsageDiagBox (accordConsommation != True)");
            this.setOutput(O8DFC1AuthorisationUsageService.OUT_BEAN,
                    this.verifierAutUsageDiagBox(userA2dr, vin, diagUser.getDiagUserCredentials().getMarque()));
        }
    }
}
