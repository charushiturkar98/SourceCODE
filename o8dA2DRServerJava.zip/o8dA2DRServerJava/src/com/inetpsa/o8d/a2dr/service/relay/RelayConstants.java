/*
 * Creation : 7 juil. 2017
 */
package com.inetpsa.o8d.a2dr.service.relay;

import org.apache.commons.codec.binary.Base64;

/**
 * The Class RelayConstants.
 */
public class RelayConstants {

    /** The Constant REQUEST_BODY_XML. */
    public static final String REQUEST_BODY_XML = "<lang>fr_FR</lang><country>FR</country><vin>VF7KF9HD8DS509305</vin><vehicleDatas>CODE_IDENT_INFO</vehicleDatas><vehicleDatas>CODE_CLIENT</vehicleDatas>"
            + "<vehicleDatas>CODE_FAMILLE</vehicleDatas><vehicleDatas>CODE_CENTRE_PROD</vehicleDatas><vehicleDatas>LCDV_BASE</vehicleDatas><vehicleDatas>DATE_ENTREE_FERRAGE</vehicleDatas>"
            + "<vehicleDatas>DATE_ENTREE_PEINTURE</vehicleDatas><vehicleDatas>DATE_ENTREE_MONTAGE</vehicleDatas><vehicleDatas>DATE_SORTIE_MONTAGE</vehicleDatas><vehicleDatas>DATE_ENTREE_COMMERCIALISATION</vehicleDatas>"
            + "<vehicleDatas>DATE_EXPEDITION</vehicleDatas><vehicleDatas>POINT_DE_DESTINATION</vehicleDatas> <vehicleDatas>DATE_PREVISIONNELLE_ARRIVEE</vehicleDatas><vehicleDatas>DATE_FIN_TRANSPORT</vehicleDatas>"
            + "<vehicleDatas>DATE_DEBUT_GARANTIE</vehicleDatas><vehicleDatas>DATE_LIVRAISON_CLIENT</vehicleDatas> <vehicleDatas>POINT_APV_RESPONSABLE</vehicleDatas><vehicleDatas>MILLESIME_COMMERCIAL</vehicleDatas>"
            + "<vehicleDatas>INFORMATIONS_DIVERSES</vehicleDatas><vehicleDatas>N_AUTORISATION_SORTIE</vehicleDatas> <vehicleDatas>N_APV_PR</vehicleDatas><vehicleDatas>NRE</vehicleDatas>"
            + "<vehicleDatas>POIDS_TOTAL_EN_CHARGE</vehicleDatas><vehicleDatas>POIDS_TOTAL_ROULANT</vehicleDatas><vehicleDatas>POIDS_MAXI_ESSIEU_AVANT</vehicleDatas><vehicleDatas>POIDS_MAXI_ESSIEU_ARRIERE</vehicleDatas>"
            + "<vehicleDatas>NUMERO_ORDRE_FABRICATION</vehicleDatas><vehicleDatas>NUMERO_ORDRE_AFFECTATION</vehicleDatas><vehicleDatas>CODE_PAYS_POINT_DE_DESTINATION</vehicleDatas>  <vehicleDatas>CODE_PAYS_POINT_APV_RESPONSABLE</vehicleDatas>"
            + "<vehicleDatas>DOSSIER_IEA</vehicleDatas><vehicleDatas>DOSSIER_COC</vehicleDatas><vehicleDatas>ANCIEN_VIN</vehicleDatas><vehicleDatas>DATE_SUPPRESSION</vehicleDatas>"
            + "<vehicleDatas>MTAC</vehicleDatas> <vehicleDatas>MTRA</vehicleDatas><vehicleDatas>CMAE_ESSIEU_1</vehicleDatas><vehicleDatas>CMAE_ESSIEU_2</vehicleDatas>"
            + "<vehicleDatas>INDICE_FUMEE</vehicleDatas> <vehicleDatas>CO2_MIXTE</vehicleDatas><vehicleDatas>CONSO_MIXTE</vehicleDatas><vehicleDatas>CO2_URBAIN</vehicleDatas><vehicleDatas>CONSO_URBAIN</vehicleDatas>"
            + "<vehicleDatas>CO2_EXTRAURBAIN</vehicleDatas><vehicleDatas>CONSO_EXTRAURBAIN</vehicleDatas><vehicleDatas>MASSE_COMBI</vehicleDatas><vehicleDatas>MASSE_CHARGEMAX</vehicleDatas>"
            + "<vehicleDatas>TVV</vehicleDatas><vehicleDatas>POIDS_VIDE</vehicleDatas><vehicleDatas>POIDS_TOTAL_CHARGE</vehicleDatas><vehicleDatas>POIDS_TOTAL_ROULANT</vehicleDatas>"
            + "<vehicleDatas>LONGUEUR_VEHICULE</vehicleDatas><vehicleDatas>LARGUEUR_VEHICULE</vehicleDatas>"
            + "<vehicleDatas>SURFACE_VEHICULE</vehicleDatas><vehicleDatas>DIRECTIVE_FUMEE</vehicleDatas>" + "<vehicleDatas>PAYS_FUMEE</vehicleDatas>";
    // Preprod

    /** The Constant TRANSPORT_USER_NAME. */
    public static final String TRANSPORT_USER_NAME = "MWPO7DBR";

    /** The Constant TRANSPORT_PWD. */
    public static final String TRANSPORT_PWD = "f5u7rfvk";

    // Prod
    /*
     * public static final String TRANSPORT_USER_NAME = "MZPO7DBR"; public static final String TRANSPORT_PWD = "u8bzcin2";
     */

    /** The Constant MESSAGE_USER_NAME. */
    public static final String MESSAGE_USER_NAME = "d661360";

    /** The Constant MESSAGE_PASSWORD. */
    public static final String MESSAGE_PASSWORD = "dsinma17";

    // public static final String TRANSPORT_USER_NAME = "MDEDIY00";
    // public static final String TRANSPORT_PWD = "eug43kmk";

    // public static final String MESSAGE_USER_NAME = "D818168";
    /** The Constant ZERO. */
    public static final int ZERO = 0;

    /** The Constant ONE. */
    public static final int ONE = 1; // POUDG-8742

    /** The Constant THREE. */
    public static final int THREE = 3;

    /** The Constant NINE. */
    public static final int NINE = 9;

    /** The Constant SEVENTEEN. */
    public static final int SEVENTEEN = 17;

    /** The Constant BRR_TRANSPORT_USER_NAME. */
    // Preprod
    public static final String BRR_TRANSPORT_USER_NAME = "MWPO7DBR";

    /** The Constant BRR_TRANSPORT_PWD. */
    public static final String BRR_TRANSPORT_PWD = "f5u7rfvk";

    /** The Constant BRR_USER_NAME. */
    public static final String BRR_USER_NAME = "MWPO7DBR";

    /** The Constant BRR_PASSWORD. */
    public static final String BRR_PASSWORD = "f5u7rfvk";

    /** The Constant BRR_CLIENT_URL. */
    public static final String BRR_CLIENT_URL = "http://wssoap.preprod.inetpsa.com/brr/services/AC/GestionPdv";

    // Prod
    /*
     * public static final String BRR_TRANSPORT_USER_NAME = "MZPO7DBR"; public static final String BRR_TRANSPORT_PWD = "u8bzcin2"; public static final
     * String BRR_USER_NAME = "MZPO7DBR"; public static final String BRR_PASSWORD = "u8bzcin2"; // datapower URL public static final String
     * BRR_CLIENT_URL = "http://wssoap.inetpsa.com/brr/services/AC/GestionPdv";
     */
    /** The Constant BRR_MESSAGE_ID. */
    public static final String BRR_MESSAGE_ID = "0";

    /** The Constant DOCSOA_MODE. */
    public static final String DOCSOA_MODE = "MODE_XML";

    /** The Constant VIN. */
    public static final String VIN = "vin";

    /** The Constant LANG. */
    public static final String LANG = "lang";

    /** The Constant CN. */
    public static final String CN = "country";

    /** The Constant JSON_MESSAGE. */
    public static final String JSON_MESSAGE = "message";

    /** The Constant JSON_VIN. */
    public static final String JSON_VIN = "vin";

    /** The Constant JSON_CN. */
    public static final String JSON_CN = "country";

    /** The Constant JSON_LANG. */
    public static final String JSON_LANG = "lang";

    /** The Constant EMETTEUR. */
    public static final String EMETTEUR = "EMETTEUR";

    /** The Constant EMETTEUR_PPVAL. */
    public static final String EMETTEUR_PPVAL = "DDC_PPROD";

    /** The Constant EMETTEUR_PVAL. */
    public static final String EMETTEUR_PVAL = "DDC_PROD";

    /** The Constant ENTETE. */
    public static final String ENTETE = "ENTETE";

    /** The Constant RECHERCHE. */
    public static final String RECHERCHE = "RECHERCHE";

    /** The Constant LCDV_ATTRIBUT. */
    // POUDG-8742 // CAP-26684: LCDV7 --start
    public static final String LCDV_ATTRIBUT = "LISTE_ATTRIBUTES_7";

    /** The Constant ATTRIBUT. */
    public static final String ATTRIBUT = "ATTRIBUT";

    /** The Constant LISTE_ATTRIBUTS. */
    public static final String LISTE_ATTRIBUTS = "<LISTE_ATTRIBUTES_7>";

    /** The Constant LISTE_ATTRIBUTS_END. */
    public static final String LISTE_ATTRIBUTS_END = "</LISTE_ATTRIBUTES_7>";
    // CAP-26684: LCDV7 --end
    /** The Constant ATTRIBUT_TAG. */
    public static final String ATTRIBUT_TAG = "<ATTRIBUT>";

    /** The Constant ATTRIBUT_TAG_END. */
    public static final String ATTRIBUT_TAG_END = "</ATTRIBUT>";

    /** The Constant ATTRIBUT_VALUE. */
    public static final String ATTRIBUT_VALUE = "%";

    // POUDG-9055 Start
    /** The Constant LIBELLE_ATTRIBUT. */
    public static final String LIBELLE_ATTRIBUT = "libelleAttribut";

    /** The Constant CODE. */
    public static final String CODE = "code";

    /** The Constant CODE. */
    public static final String NATURE = "nature";

    /** The Constant libelleValue. */
    public static final String LIBELLE = "libelle";

    /** The Constant LIBELLE_ATTRIBUT_COM. */
    public static final String LIBELLE_ATTRIBUT_COM = "libelleAttributCom";

    /** The Constant LIBELLE_NATURE_CLASSE. */
    public static final String LIBELLE_NATURE_CLASSE = "libelleNatureClasse";

    /** The Constant ERRORMSG. */
    public static final String ERRORMSG = "errorMsg";

    /** The Constant localeTraduction. */
    public static final String LOCALETRADUCTION = "localeTraduction";

    /** The Constant isError. */
    public static final String ISERROR = "isError";

    /** The Constant ATTRIBUTE_PATTERN_. */
    public static final String ATTRIBUTE_PATTERN = "(?=<ATTRIBUT>)|(?<=/ATTRIBUT>)";

    /** The Constant LCDV. */
    public static final String LCDV = "LCDV";

    /** The Constant LISTE_ATTRIBUTES. */
    public static final String LISTE_ATTRIBUTES = "LISTE_ATTRIBUTS";

    /** The Constant FIVE. */
    public static final int FIVE = 5;

    // POUDG-9055 end

    /** The Constant CRITERE. */
    // POUDG-8742--end
    public static final String CRITERE = "CRITERE";

    /** The Constant DONNEES_VEHICULE. */
    public static final String DONNEES_VEHICULE = "DONNEES_VEHICULE";

    /** The Constant DONNEE. */
    public static final String DONNEE = "DONNEE";

    /** The Constant VEHICLE_DATAS. */
    public static final String VEHICLE_DATAS = "vehicleDatas";

    /** The Constant MESSAGE. */
    public static final String MESSAGE = "MESSAGE";

    /** The Constant HEADERS. */
    public static final String HEADERS = "headers";

    /** The Constant WMI. */
    public static final String WMI = "WMI";

    /** The Constant VDS. */
    public static final String VDS = "VDS";

    /** The Constant VIS. */
    public static final String VIS = "VIS";

    /** The Constant REPONSE. */
    public static final String REPONSE = "REPONSE";

    /** The Constant VEHICLEDATAS. */
    public static final String VEHICLEDATAS = "vehicleDatas";

    /** The Constant BRR_CODE. */
    public static final String BRR_CODE = "Code";

    /** The Constant BRR_LABEL. */
    public static final String BRR_LABEL = "Label";

    /** The Constant BRR_STATUS. */
    public static final String BRR_STATUS = "Status";

    /** The Constant BRR_END_OF_VALUES. */
    public static final String BRR_END_OF_VALUES = "} ]";

    /** The Constant BRR_ADD_STATUS. */
    public static final String BRR_ADD_STATUS = "}],";

    /** The Constant EDIAG. */
    public static final String EDIAG = "<EDiagML";

    /** The Constant EDIAG_XML. */
    public static final String EDIAG_XML = "<EDiagML xmlns=";

    /** The Constant EDIAG_HEADERS. */
    public static final String EDIAG_HEADERS = "headers";

    /** The Constant EDIAG_ESCAPE. */
    public static final String EDIAG_ESCAPE = "\\\\";

    /** The Constant BLANK. */
    public static final String BLANK = "";

    /** The Constant EDIAG_LINDEX. */
    public static final String EDIAG_LINDEX = "\"}";

    /** The Constant REPPS_XML. */
    public static final String REPPS_XML = "<SOAP-ENV:Envelope";

    /** The Constant REPPS. */
    public static final String REPPS = "repps";

    /** The Constant REPPS_SERVER. */
    public static final String REPPS_SERVER = "REPPSserver";

    /** The Constant Enrollment_portal_URL. */
    public static final String Enrollment_portal_URL = "Enrollment_portal_URL";

    /** The Constant OLD_DSS_URL. */
    public static final String OLD_DSS_URL = "OLD_DSS_URL";

    /** The Constant XML_ENC. */
    // Fix for POUDG-6568
    public static final String XML_ENC = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";

    /** The Constant XML_START. */
    public static final String XML_START = "<?xml";

    /** The Constant EDIAG_END. */
    // Fix for POUDG-6548
    public static final String EDIAG_END = "</EDiagML>";

    /** The Constant CLIENT_ID. */
    public static final String CLIENT_ID = "CLIENT_ID";

    /** The Constant CLIENT_ID_SERAV_UL. */
    public static final String CLIENT_ID_SERAV_UL = "CLIENT_ID_SERAV_UL";

    /** The Constant VIN_BSRF. */
    /* CAP-25017 - START */
    public static final String VIN_BSRF = "vin";

    /** The Constant APP_CODE. */
    public static final String APP_CODE = "appCode";

    /** The Constant LIST_OF_FRAME. */
    public static final String LIST_OF_FRAME = "listOfFrame";

    /** The Constant SEED. */
    public static final String SEED = "seed";

    /** The Constant CAS_UTILISATION. */
    public static final String CAS_UTILISATION = "casUtilisation";

    /** CAP-29146 The Constant CYBER_UIN. */
    public static final String CYBER_UIN = "cyberUin";

    /** The Constant COMA. */
    public static final String COMA = "\\s*,\\s*";

    /** The Constant OPEN. */
    public static final String OPEN = "[";

    /** The Constant CLOSE. */
    public static final String CLOSE = "]";

    /** The Constant SUCCESS_CODE. */
    public static final String SUCCESS_CODE = "000000";

    /** The Constant OTHER_ERROR. */
    public static final String OTHER_ERROR = "Other Error";

    /** The Constant SERAV_UL_SUCCESS_STATUS_CODE. */
    public static final int SERAV_UL_SUCCESS_STATUS_CODE = 200;

    /** The Constant REQUEST_HEADERS. */
    public static final String REQUEST_HEADERS = "headers";

    /** The Constant REQUEST_MESSAGE. */
    public static final String REQUEST_MESSAGE = "message";
    /* CAP-25017 - END */

    /** The Constant DSS3_HOSTNAME. */
    /* CAP-25454 - START */
    public static final String DSS3_HOSTNAME = "DSS3_HOSTNAME";

    /* CAP-25454 - END */
    // CAP-27774 -Start
    /** The Constant ARGOS_URLS_CONFIGURATION_FILE. */
    public static final String ARGOS_URLS_CONFIGURATION_FILE = "argos-urls.properties";

    /** The Constant ARGOS_AUTH_USERNAME. */
    public static final String ARGOS_AUTH_USERNAME = "argos.auth.username";

    /** The Constant ARGOS_AUTH. */
    public static final String ARGOS_AUTH = "argos.auth.password";

    /** The Constant ARGOS_PROXY_URL. */
    public static final String ARGOS_PROXY_URL = "argos.proxy.url";

    /** The Constant ARGOS_PROXY_PORT. */
    public static final String ARGOS_PROXY_PORT = "argos.proxy.port";

    /** The Constant ARGOS. */
    public static final String ARGOS = "argos";

    /** The Constant BATTERY_SERVICE_CALL. */
    public static final String BATTERY_SERVICE_CALL = "/GetBatteryInformation";

    /** The Constant PDI_TYPE. */
    public static final String PDI_TYPE = "pdiType";

    /** The Constant JOBTYPE. */
    public static final String JOBTYPE = "JobType";

    /** The Constant READ_TIMEOUT. */
    public static final int READ_TIMEOUT = 30000;

    /** The Constant AND_CONTEXT_SEPARATOR. */
    protected static final String AND_CONTEXT_SEPARATOR = "&";

    /** The Constant CONTEXT_SEPARATOR. */
    protected static final String CONTEXT_SEPARATOR = "=";

    /** The Constant DATE_FORMAT. */
    public static final String DATE_FORMAT = "yyyy-MM-dd";

    /** The Constant CLIENT_ID_ARGOS. */
    public static final String CLIENT_ID_ARGOS = "CLIENT_ID_ARGOS";

    /** The Constant GET_METHOD. */
    public static final String GET_METHOD = "GET";

    /** The Constant POST_METHOD. */
    public static final String POST_METHOD = "POST";

    /** The Constant CONTENT_TYPE. */
    public static final String CONTENT_TYPE = "Content-Type";

    /** The Constant ACCEPT_CHARSET. */
    public static final String ACCEPT_CHARSET = "Accept-Charset";

    /** The Constant AUTHORIZATION. */
    public static final String AUTHORIZATION = "Authorization";

    /** The Constant JOBS. */
    public static final String JOBS = "jobs";

    /** The Constant TOTAL_COUNT. */
    public static final String TOTAL_COUNT = "totalCount";

    /** The Constant BEGIN_DATE. */
    public static final String BEGIN_DATE = "beginDate";

    /** The Constant DATA. */
    public static final String DATA = "data";

    /** The Constant IDGRES. */
    public static final String IDGRES = "IDGRES";

    /** The Constant OCV. */
    public static final String OCV = "OCV";

    /** The Constant BKCODE. */
    public static final String BKCODE = "BKCODE";

    /** The Constant BAD_REQUEST. */
    public static final String BAD_REQUEST = "{\"ErrorCode\":\"400\",\"ErrorMessage\":\"BAD REQUEST\"}";

    /** The Constant UNAUTHORIZED. */
    public static final String UNAUTHORIZED = "{\"ErrorCode\":\"401\",\"ErrorMessage\":\"UNAUTHORIZED\"}";

    /** The Constant NO_DATA_RECEIVED. */
    public static final String NO_DATA_RECEIVED = "{\"ErrorCode\":\"404\",\"ErrorMessage\":\"NO DATA RECEIVED\"}";

    /** The Constant INTERNAL_SERVER_ERROR. */
    public static final String INTERNAL_SERVER_ERROR = "{\"ErrorCode\":\"500\",\"ErrorMessage\":\"INTERNAL SERVER ERROR\"}";

    /** The Constant SUCCESS_RESPONSE_NO_DATA. */
    public static final String SUCCESS_RESPONSE_NO_DATA = "{\"ErrorCode\":\"200\",\"ErrorMessage\":\"NO DATA RECEIVED\"}";

    /** The Constant FORBIDDEN_USER. */
    public static final String FORBIDDEN_USER = "{\"ErrorCode\":\"403\",\"ErrorMessage\":\"FORBIDDEN USER\"}";

    /** The Constant RESULT. */
    public static final String RESULT = "result";

    /** The Constant VOLTAGE. */
    public static final String VOLTAGE = "voltage";

    /** The Constant BK_CODE. */
    public static final String BK_CODE = "bkcode";

    /** The Constant FILTER_BEGINDATE. */
    public static final String FILTER_BEGINDATE = "&FilterOnBeginDate=true";

    /** The Constant ACCESS_TOKEN. */
    public static final String ACCESS_TOKEN = "access_token";

    /** The Constant DSS3_TOKEN. */
    public static final String DSS3_TOKEN = "DSS3_TOKEN";

    /** The Constant TARGET_APPLICATION_PARAMETER. */
    public static final String TARGET_APPLICATION_PARAMETER = "TARGET_APPLICATION";

    /** The Constant STRING_TRUE. */
    public static final String STRING_TRUE = "true";

    /** The Constant STRING_FALSE. */
    public static final String STRING_FALSE = "false";

    /** The Constant TLS_VERSION_1_2. */
    public static final String TLS_VERSION_1_2 = "TLSv1.2";

    /** The Constant CONTENT_TYPE_DATA. */
    public static final String CONTENT_TYPE_DATA = "application/x-www-form-urlencoded";
    // CAP-27774 -end

    /** The Constant SGW_SN. */
    // CAP-28062 starts
    public static final String SGW_SN = "sgwSN";

    /** The Constant ECU_CANID. */
    public static final String ECU_CANID = "ecuCANID";

    /** The Constant ECU_CERT_STORE_UUID. */
    public static final String ECU_CERT_STORE_UUID = "ecuCertStoreUUID";

    /** The Constant ECU_SN. */
    public static final String ECU_SN = "ecuSN";

    /** The Constant ECU_POLICY_TYPE. */
    public static final String ECU_POLICY_TYPE = "ecuPolicyType";

    /** The Constant CLAIMED_ROLE. */
    public static final String CLAIMED_ROLE = "claimedRole";

    /** The Constant USER_ID. */
    public static final String USER_ID = "userid";

    /** The Constant DEALER_CODE. */
    public static final String DEALER_CODE = "dealerCode";

    /** The Constant USER_TOKEN. */
    public static final String USER_TOKEN = "usertoken";

    /** The Constant DIAGBOX_MODE. */
    public static final String DIAGBOX_MODE = "diagbox mode";

    /** The Constant TOOL_ID1. */
    public static final String TOOL_ID1 = "0170ed4d-DIAGBOX-1233";

    /** The Constant TOOL_ID2. */
    public static final String TOOL_ID2 = "17f541d8-DIAGCLOUD-41d8";

    /** The Constant ADA_CERTIFICATE. */
    public static final String ADA_CERTIFICATE = "/getADACertificate";

    /** The Constant ADA_CHALLENGE. */
    public static final String ADA_CHALLENGE = "/getSignChallenge";

    /** The Constant ADA_TRACK_RESPONSE. */
    public static final String ADA_TRACK_RESPONSE = "/setADATrackResponse";

    /** The Constant ADA_LEVEL3_CERT. */
    public static final String ADA_LEVEL3_CERT = "getLevel3AuthDiagCert";

    /** The Constant ADA_LEVEL3_CHALLENGE. */
    public static final String ADA_LEVEL3_CHALLENGE = "getLevel3SignedChallenge";

    /** The Constant ADA_LEVEL3_TRACK_RESPONSE. */
    public static final String ADA_LEVEL3_TRACK_RESPONSE = "trackResponse";

    /** The Constant IAT. */
    public static final String IAT = "iat";

    /** The Constant EXP. */
    public static final String EXP = "exp";

    /** The Constant NBF. */
    public static final String NBF = "nbf";

    /** The Constant MARKET. */
    public static final String MARKET = "market";

    /** The Constant SUCCESS. */
    public static final String SUCCESS = "success";

    /** The Constant CERTIFICATE. */
    public static final String CERTIFICATE = "certificate";

    /** The Constant SESSION_ID. */
    public static final String SESSION_ID = "sessionID";

    /** The Constant ERROR_CODE. */
    public static final String ERROR_CODE = "ErrorCode";

    /** The Constant ERROR_DESC. */
    public static final String ERROR_DESC = "ErrorDesc";

    /** The Constant ERROR_MESSAGE. */
    public static final String ERROR_MESSAGE = "ErrorMessage";

    /** The Constant BAD_REQUEST_MESSAGE. */
    public static final String BAD_REQUEST_MESSAGE = "{\"errorCode\":400,\"success\":\"false\",\"errorDesc\":\"bad request, required field is missing or empty or equal to null\"}";

    /** The Constant ENCODING. */
    public static final String ENCODING = "UTF-8";

    /** The Constant SHA256. */
    public static final String SHA256 = "SHA-256";

    /** The Constant KID. */
    public static final String KID = "kid";

    /** The Constant ALG. */
    public static final String ALG = "alg";

    /** The Constant TYP. */
    public static final String TYP = "typ";

    /** The Constant DIGEST. */
    public static final String DIGEST = "digest";

    /** The Constant JWT. */
    public static final String JWT = "jwt";

    /** The Constant RS256. */
    public static final String RS256 = "RS256";

    /** The Constant HS256. */
    public static final String HS256 = "HS256";

    /** The Constant base64. */
    public static final Base64 base64 = new Base64();

    /** The Constant HMACSHA256. */
    public static final String HMACSHA256 = "HmacSHA256";

    /** The Constant RSA. */
    public static final String RSA = "RSA";

    /** The Constant SHA256WITHRSA. */
    public static final String SHA256WITHRSA = "SHA256withRSA";

    /** The Constant ADA_PRIVATE_KEY. */
    public static final String ADA_PRIVATE_KEY = "dss.ada.privatekey.o8d00fpcer";

    /** The Constant ERROR_CODE_TO_LOG. */
    static final String ERROR_CODE_TO_LOG = "Error code received from ADA : ";

    /** The Constant TWO. */
    public static final int TWO = 2; // POUDG-8742

    /** The Constant TOKEN_DIVIDER. */
    public static final long TOKEN_DIVIDER = 1000L;

    /** The Constant TOKEN_EXPIRATION. */
    public static final long TOKEN_EXPIRATION = 3600L;

    /** The Constant USER_DIR. */
    public static final String USER_DIR = "user.dir";

    /** The Constant ADA_KID_VALUE. */
    public static final String ADA_KID_VALUE = "dss.ada.uuid.kid";

    /** The Constant ADA_CONFIG_FILE. */
    public static final String ADA_CONFIG_FILE = "dss_ada_configuration.properties";

    /** The Constant JKS_LOCAL_PASS. */
    public static final String JKS_LOCAL_PASS = "dss.ada.privatekey.password";

    /** The Constant JKS_LOCAL_ALAIS. */
    public static final String JKS_LOCAL_ALAIS = "dss.ada.privatekey.alais";

    /** The Constant ADA_FORCED_CIPHER_SUITE. */
    public static final String ADA_FORCED_CIPHER_SUITE = "dss.ada.forced.cipher.suite.name";

    /** The Constant DOT_ZERO. */
    public static final String DOT_ZERO = ":0";

    /** The Constant APPLICATION_JSON. */
    public static final String APPLICATION_JSON = "application/json";

    /** POUDG-9437: The Constant APPLICATION_X-WWW-FORM-URLENCODED. */
    public static final String APPLICATION_FORMURLENCODED = "application/x-www-form-urlencoded";

    /** The Constant ACCEPT. */
    public static final String ACCEPT = "Accept";

    /** The Constant POP. */
    public static final String POP = "PoP ";

    /** The Constant HTTP_CIPHER_SUITE. */
    public static final String HTTP_CIPHER_SUITE = "https.cipherSuites";

    /** The Constant ADA. */
    public static final String ADA = "ADA";

    /** The Constant ECU_CHALLENAGE. */
    public static final String ECU_CHALLENAGE = "ecuChallenge";

    /** The Constant ECU_RESULT. */
    public static final String ECU_RESULT = "ecuResult";

    /** The Constant ECU_RESPONSE. */
    public static final String ECU_RESPONSE = "ecuResponse";

    /** The Constant ECU_CHALLENGE_RESPONSE. */
    public static final String ECU_CHALLENGE_RESPONSE = "ecuChallengeResponse";
    // CAP-28062 end

    // Poudg 8769 start
    /** The Constant TBM_HU. */
    // vin is alrady defined
    public static final String TBM_HU = "TBM_HU";

    /** The Constant ECU. */
    public static final String ECU = "ecu";

    /** The Constant YEAR_VEHICLE. */
    public static final String YEAR_VEHICLE = "yearVehicle";

    /** The Constant BODY_VEHICLE. */
    public static final String BODY_VEHICLE = "bodyVehicle";

    /** The Constant SERIAL_NUMBER. */
    public static final String SERIAL_NUMBER = "SerialNumber";

    /** The Constant SW_COMPONENT_ID_HW_NUMBER. */
    public static final String SW_COMPONENT_ID_HW_NUMBER = "swComponentIdHwNumber";

    /** The Constant SW_COMPONENT_ID_HW_VERSION. */
    public static final String SW_COMPONENT_ID_HW_VERSION = "swComponentIdHwVersion";

    /** The Constant FW_VERSION_SW_NUMBER. */
    public static final String FW_VERSION_SW_NUMBER = "fwVersionSwNumber";

    /** The Constant FW_VERSION_SW_VERSION. */
    public static final String FW_VERSION_SW_VERSION = "fwVersionSwVersion";

    /** The Constant VCISN. */
    public static final String VCISN = "vciSN";

    /** The Constant MODEM_DATA_LMEI. */
    public static final String MODEM_DATA_LMEI = "modemDatalmei";

    /** The Constant SIM_IDENTIFIER_ICCID. */
    public static final String SIM_IDENTIFIER_ICCID = "simIdentifierIccid";

    /** The Constant INTERNATIONAL_MOBILE_SUBSCRIBER_IDENTITY_IMSI. */
    public static final String INTERNATIONAL_MOBILE_SUBSCRIBER_IDENTITY_IMSI = "internationalMobileSubscriberIdentityImsi";

    /** The Constant MOBILE_SUBSCRIBER_ISDN_MSISDN. */
    public static final String MOBILE_SUBSCRIBER_ISDN_MSISDN = "mobileSubscriberIsdnMsisdn";

    /** The Constant FOTAHW_PART_NUMBER. */
    public static final String FOTAHW_PART_NUMBER = "fotahwPartNumber";

    /** The Constant FOASW_PART_NUMBER. */
    public static final String FOASW_PART_NUMBER = "foaswPartNumber";

    /** The Constant DEALER_C. */
    public static final String DEALER_C = "DealerCode";

    /** The Constant FIRMWARE_VERSION. */
    public static final String FIRMWARE_VERSION = "firmwareVersion";

    /** The Constant USER_I. */
    public static final String USER_I = "Userid";

    /** The Constant SERVICE. */
    public static final String SERVICE = "service";

    /** The Constant TBMHU_PREFIX. */
    public static final String TBMHU_PREFIX = "xPSA-";

    /** The Constant TBMHU_KID_VALUE. */
    public static final String TBMHU_KID_VALUE = "dss.tbmhu.uuid.kid";

    /** The Constant TBMHU_LOCAL_ALAIS. */
    public static final String TBMHU_LOCAL_ALAIS = "dss.tbmhu.privatekey.alais";

    /** The Constant ECU_REPLACEMENT. */
    public static final String ECU_REPLACEMENT = "ecuReplacement";

    /** The Constant THE_1000. */
    public static final String THE_1000 = "1000";

    /** The Constant DSS_TBMHU_PASSWORD. */
    public static final String DSS_TBMHU_PASSWORD = "dss.tbmhu.password";

    /** The Constant DSS_TBMHU_USERNAME. */
    public static final String DSS_TBMHU_USERNAME = "dss.tbmhu.username";

    /** The Constant DSS_TBMHU_PUBLICKEY1. */
    public static final String DSS_TBMHU_PUBLICKEY1 = "dss.tbmhu.publickey1";

    /** The Constant DSS_TBMHU_PUBLICKEY2. */
    public static final String DSS_TBMHU_PUBLICKEY2 = "dss.tbmhu.publickey2";

    /** The Constant DSS_TBMHU_PUBLICKEY3. */
    public static final String DSS_TBMHU_PUBLICKEY3 = "dss.tbmhu.publickey3";

    /** The Constant DSS_TBMHU_PUBLICKEY4. */
    public static final String DSS_TBMHU_PUBLICKEY4 = "dss.tbmhu.publickey4";

    /** The Constant BASIC. */
    public static final String BASIC = "Basic ";

    /** The Constant NAFTA. */
    public static final String REGION = "EMEA";

    /** The Constant TEXT_PLAIN. */
    public static final String TEXT_PLAIN = "text/plain";

    /** The Constant ASDP. */
    public static final String SERVICE_INVORKER = "DIAGBOX";

    /** The Constant CHARSET. */
    public static final String CHARSET = "charset";

    /** The Constant X_APP_REGION. */
    public static final String X_APP_REGION = "X-App-Region";

    /** The Constant X_APP_SOURCE. */
    public static final String X_APP_SOURCE = "X-App-Source";

    /** The Constant CONTENT_LENGTH. */
    public static final String CONTENT_LENGTH = "Content-Length";

    /** The Constant BAD_REQUEST_MESSAGE_TBMHU. */
    public static final String BAD_REQUEST_MESSAGE_TBMHU = "{\"ErrorCode\":400,\"ErrorDesc\":\"bad request, required field is missing or empty or equal to null\"}";

    /** The Constant RESPONSE. */
    public static final String RESPONSE = "response";

    /** The Constant RESPONSE_CODE. */
    public static final String RESPONSE_CODE = "responseCode";

    /** The Constant CODE_RECEIVED_BEFORE_MAPPING. */
    public static final String CODE_RECEIVED_BEFORE_MAPPING = "codeReceivedBeforeMapping";

    /** The Constant ERROR. */
    public static final String ERROR = "error";

    /** The Constant FAILURE. */
    public static final String FAILURE = "failure";

    /** The Constant FAILURE_REASON_CODE. */
    public static final String FAILURE_REASON_CODE = "failureReasonCode";

    /** The Constant FAILURE_REASON. */
    public static final String FAILURE_REASON = "failureReason";

    /** The Constant DATA_ENCODED. */
    public static final String DATA_ENCODED = "dataEncoded";

    /** The Constant DATA_XML. */
    public static final String DATA_XML = "dataXml";

    /** The Constant DATA_TO_JSON. */
    public static final String DATA_TO_JSON = "dataToJson";

    /** The Constant COMPLET_RES_DECODED. */
    public static final String COMPLET_RES_DECODED = "completResDecoded";

    /** The Constant SET_TRACALBILITY. */
    public static final String SET_TRACALBILITY = "setFCATraceablility";

    /** The Constant SUCCESS_TBMHU. */
    public static final String SUCCESS_TBMHU = "{success : true}";

    /** The Constant ADA_ERROR. */ // CAP-29321
    public static final String ADA_ERROR = "Error while trying to map the response code from ADA";

    /** The Constant REQUEST_FETCH_EXCEPTION. */ // CAP-29321
    public static final String REQUEST_FETCH_EXCEPTION = "Exception while trying to fetch the requestBody";

    /** The Constant EDIAG_APP. */ // CAP-29321
    public static final String EDIAG_APP = "ODG.GARAGE";

    // CAP-29098-start
    /** The Constant LABELS_LIST. */
    public static final String LABELS_LIST = "labels_list";
    /** The Constant UNKNOWN_HEXACODE. */
    public static final String UNKNOWN_HEXACODE = "{\"ErrorCode\":\"404\",\"ErrorMessage\":\"UNKNOWN_HEXACODE\"}";
    /** The Constant FORBIDDEN_ACCESS. */
    public static final String FORBIDDEN_ACCESS = "{\"ErrorCode\":\"403\",\"ErrorMessage\":\"NO RIGHTS\"}";
    /** The Constant LABEL_CODE. */
    public static final String LABEL_CODE = "label_code";
    /** The Constant COMMERCIAL_LABEL. */
    public static final String COMMERCIAL_LABEL = "commercial_label";
    /** The Constant COMMERCIAL_LABEL_DEFAULT. */
    public static final String COMMERCIAL_LABEL_DEFAULT = "commercial_label_default";
    /** The Constant CLIENT_ID_PORTFOLIO_LABEL. */
    public static final String CLIENT_ID_PORTFOLIO_LABEL = "CLIENT_ID_PORTFOLIO_LABEL";
    /** The Constant CLIENT_ID_PORTFOLIO_LABEL_KEY. */
    public static final String CLIENT_ID_PORTFOLIO_LABEL_KEY = "X-IBM-Client-Id";
    /** The Constant TOKEN_USERNAME. */
    public static final String TOKEN_USERNAME = "token_username";
    /** The Constant PORTFOLIO_ERROR. */
    public static final String PORTFOLIO_ERROR = "Error while trying to map the response code from Portfolio";
    // CAP-29098-end

    // DCLOUD-167
    /** The Constant RA. */
    public static final String RA = "RA";
    /** The Constant RA. */
    public static final String MARQUE = "marque";

    // POUDG-9437: start

    /** The Constant GIGYA_DECRYPTED_TOKEN. */
    public static final String GIGYA_DECRYPTED_TOKEN = "GIGYA_DECRYPTED_TOKEN";

    /** The Constant INDEX. */
    public static final int INDEX = 7;
    /** The Constant ERROR_BAD_FORMAT_TOKEN. */
    public static final String ERROR_BAD_FORMAT_TOKEN = "Invalid token: Token format not encoded correctly in Base64";

    /** The Constant GIGYA_CONFIG_FILE. */
    public static final String GIGYA_CONFIG_FILE = "dss_gigya_configuration.properties";

    /** The Constant GIGYA_USERKEY. */
    public static final String GIGYA_USERKEY = "dss.gigya.userKey";
    /** The Constant GIGYA_SECRET. */
    public static final String GIGYA_SECRET = "dss.gigya.secret";
    /** The Constant GIGYA_QUERY. */
    public static final String GIGYA_QUERY = "dss.gigya.query";
    /** The Constant GIGYA_AUDIT_SEARCH_URL. */
    public static final String GIGYA_AUDIT_SEARCH_URL = "dss.gigya.auditsearch.url";
    /** The Constant GIGYA_MAXIMUM_ATTEMPTS. */
    public static final String GIGYA_MAXIMUM_ATTEMPTS = "dss.gigya.maximum.attempts";
    /** The Constant GIGYA_FIRST_ATTEMPT_DELAY. */
    public static final String GIGYA_FIRST_ATTEMPT_DELAY = "dss.gigya.first.attempt.delay";
    /** The Constant GIGYA_QUERY. */
    public static final String GIGYA_DELAY = "dss.gigya.delay";

    /** The Constant REGISTRATION. */
    public static final String REGISTRATION = "/registration";

    /** The Constant RESET_PASSWORD. */
    public static final String RESET_PASSWORD = "/resetpassword";
    /** The Constant UTF_8. */
    public static final String UTF_8 = "UTF-8";
    /** The Constant LDAP_OI. */
    public static final String LDAP_OI = "LDAP_OI";
    /** The Constant JWT_TOKEN. */
    public static final String JWT_TOKEN = "JWT_TOKEN";
    /** The Constant PUBLIC_KEY. */
    public static final String PUBLIC_KEY = "n";
    /** The Constant EXP_STRING. */
    public static final String EXP_STRING = "e";
    /** The Constant API_METHOD. */
    public static final String API_METHOD = "accounts.getJWTPublicKey";
    /** The Constant API_DOMAIN. */
    public static final String API_DOMAIN = "eu1.gigya.com";
    /** The Constant INVALID_GIGYA_TOKEN. */
    public static final String INVALID_GIGYA_TOKEN = "{\"ErrorCode\":\"400\",\"ErrorMessage\":\"Invalid gigya token - Signature verification failed\"}";

    /** The Constant TECHNICAL_ERROR. */
    public static final String TECHNICAL_ERROR = "{\"ErrorCode\":\"404\",\"ErrorMessage\":\"TECHNICAL_ERROR\"}";
    /** The Constant TIMEOUT. */
    public static final String TIMEOUT = "{\"ErrorCode\":\"408\",\"ErrorMessage\":\"TIMEOUT\"}";

    /** The Constant LDAP_OI_OAUTH_CONFIG_FILE. */
    public static final String LDAP_OI_OAUTH_CONFIG_FILE = "dss_ldap_configuration.properties";

    /** The Constant LDAP_ACCESS_TOKEN_URL. */
    public static final String LDAP_OI_ACCESS_TOKEN_URL = "ldapoi.access.token.url";

    /** The Constant LDAP_CLIENT_ID. */
    public static final String LDAP_OI_CLIENT_ID = "ldapoi.client.id";

    /** The Constant LDAP_CLIENT_SECRET. */
    public static final String LDAP_OI_CLIENT_SECRET = "ldapoi.client.secret";

    /** The Constant LDAP_SCOPE. */
    public static final String LDAP_OI_SCOPE = "ldapoi.scope";

    /** The Constant BEARER. */
    public static final String BEARER = "Bearer ";
    /** The Constant CLIENT_ID_LDAP_OI. */
    public static final String CLIENT_ID_LDAP_OI = "CLIENT_ID_LDAP_OI";

    /** The Constant METHOD_NOT_ALLOWED. */
    public static final String METHOD_NOT_ALLOWED = "{\"ErrorCode\":\"405\",\"ErrorMessage\":\"Method Not Allowed\"}";

    /** Constants for error received from ldap oi. */
    public static final String INTERNAL_ERROR_LDAPOI = "{\"ErrorCode\":\"500\",\"ErrorMessage\":\"Something went wrong on ldap oi end\"}";

    /** The Constant RESULTS. */
    public static final String RESULTS = "results";

    /** The Constant UID. */
    public static final String UID = "uid";

    /** The Constant RESULT_CODE. */
    public static final String RESULT_CODE = "resultCode";

    /** The Constant GIGYA. */
    public static final String GIGYA = "gigya";

    /** The Constant JWS. */
    public static final String JWS = "jws";

    /** The Constant FAILED_TOKEN_VALIDATION. */
    public static final String FAILED_TOKEN_VALIDATION = "{\r\n" + "    \"ErrorCode\": \"400\",\r\n"
            + "    \"ErrorMessage\": \"JWT Token not present or invalid.\"\r\n" + "}";

    // POUDG-9437: end

    // POUDG-9486:START
    /** The Constant CODE_1. */
    public static final String CODE_1 = "B0A0";
    /** The Constant CODE_2. */
    public static final String CODE_2 = "B0B0";
    /** The Constant CODE_3. */
    public static final String CODE_3 = "B0C";
    /** The Constant CODE_4. */
    public static final String CODE_4 = "B0D";
    /** The Constant CODE_5. */
    public static final String CODE_5 = "B0E0";
    /** The Constant CODE_6. */
    public static final String CODE_6 = "B0F";
    /** The Constant CODE_7. */
    public static final String CODE_7 = "B0G0";
    /** The Constant CODE_8. */
    public static final String CODE_8 = "B0H";
    /** The Constant CODE_9. */
    public static final String CODE_9 = "B0J";
    /** The Constant CODE_10. */
    public static final String CODE_10 = "B0K0";
    /** The Constant CODE_11. */
    public static final String CODE_11 = "B0L0";
    /** The Constant CODE_12. */
    public static final String CODE_12 = "B0M";
    /** The Constant CODE_13. */
    public static final String CODE_13 = "B0N";
    /** The Constant CODE_14. */
    public static final String CODE_14 = "B0P";
    /** The Constant CODE_15. */
    public static final String CODE_15 = "B0R";

    /** The Constant LCDV_INDEX_0. */
    public static final int LCDV_INDEX_0 = 0;
    /** The Constant LCDV_INDEX_1. */
    public static final int LCDV_INDEX_1 = 1;
    /** The Constant LCDV_INDEX_6. */
    public static final int LCDV_INDEX_6 = 6;
    /** The Constant LCDV_INDEX_9. */
    public static final int LCDV_INDEX_9 = 9;
    /** The Constant LCDV_INDEX_14. */
    public static final int LCDV_INDEX_14 = 14;
    /** The Constant LCDV_INDEX_15. */
    public static final int LCDV_INDEX_15 = 15;

    // POUDG-9486:END
}