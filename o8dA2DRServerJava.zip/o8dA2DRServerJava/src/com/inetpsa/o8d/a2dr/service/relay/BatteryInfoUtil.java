/*
 * Creation : 14 Mar 2022
 */
/**
 * 
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.oltu.oauth2.common.utils.OAuthUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.beans.ProxyBean;
import com.inetpsa.o8d.a2dr.config.BatteryInfoServiceConfig;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.security.AesEncDec;
import com.inetpsa.o8d.a2dr.service.DssCallEnrollmentPortalService;

/**
 * The Class BatteryInfoService.
 */
/**
 * @author E543118
 */
public class BatteryInfoUtil {

    /** The Constant logger. */
    private static final Logger log = LoggerFactory.getLogger(BatteryInfoUtil.class);

    /** The Constant ACCESS_TOKEN_URL. */
    private static final String ACCESS_TOKEN_URL = "argos.access.token.url";

    /** The Constant CLIENT_ID. */
    private static final String CLIENT_ID = "argos.client.id";

    /** The Constant CLIENT_SECRET. */
    private static final String CLIENT_SECRET = "argos.client.secret";

    /** The Constant ARGOS_STAGGING_URL. */
    private static final String ARGOS_STAGGING_URL = "argos.stagging.url";

    /** The Constant ARGOS_TOKEN_USERNAME. */
    private static final String ARGOS_TOKEN_USERNAME = "argos.token.username";

    /** The Constant ARGOS_TOKEN. */
    private static final String ARGOS_TOKEN = "argos.token.password";

    /** The urlfor argos. */
    StringBuilder urlforArgos; // Sonar issue Fix

    /** The info bean. */
    static BatteryInfoServiceConfig infoBean;

    /**
     * Instantiates a new battery info service.
     *
     * @throws FwkException the fwk exception
     */
    BatteryInfoUtil() throws FwkException {
        super();
    }

    /**
     * Process argos response.
     *
     * @param tokenResponseMap the token response map
     * @param methodRelay      the method relay
     */
    public static void processArgosResponse(Map<Integer, String> tokenResponseMap, HttpMethod methodRelay) {
        String finalResponse = StringUtils.EMPTY;
        try {
            String argosResponse = methodRelay.getResponseBodyAsString();
            JsonObject fromJson = new Gson().fromJson(argosResponse, JsonObject.class);
            // CAP-29321:DSS Stress Test - removed unnecessary .toString()
            String totalCount = (fromJson.get(RelayConstants.TOTAL_COUNT)).toString();
            if (null != totalCount && StringUtils.isNotBlank(totalCount) && (Integer.parseInt(totalCount) > RelayConstants.ZERO)) {
                finalResponse = BatteryInfoUtil.getFilteredOutputResposne(fromJson.toString());
                log.info("Success Response received from Argos: {}", finalResponse);
                tokenResponseMap.put(methodRelay.getStatusCode(), finalResponse);
            } else {
                log.info("No Response received from Argos: {}", fromJson);
                tokenResponseMap.put(methodRelay.getStatusCode(), BatteryInfoUtil.addErrorMessage(methodRelay.getStatusCode()));
            }
        } catch (IOException e) {
            log.error("Exception while fetching data from Argos: ", e);
            tokenResponseMap.put(methodRelay.getStatusCode(), BatteryInfoUtil.addErrorMessage(methodRelay.getStatusCode()));
        }
    }

    /**
     * Prepare url for argos.
     *
     * @param vin     the vin
     * @param pdiType the pdi type
     * @return the string builder
     */
    public static StringBuilder prepareUrlForArgos(String vin, String pdiType) {
        StringBuilder url = new StringBuilder();
        url.append(infoBean.getStaggingUrl());
        SimpleDateFormat formatter = new SimpleDateFormat(RelayConstants.DATE_FORMAT);
        Date date = new Date();
        url.append(RelayConstants.JOBTYPE).append(RelayConstants.CONTEXT_SEPARATOR).append(pdiType).append(RelayConstants.AND_CONTEXT_SEPARATOR)
                .append(RelayConstants.VIN).append(RelayConstants.CONTEXT_SEPARATOR).append(vin).append(RelayConstants.AND_CONTEXT_SEPARATOR)
                .append(RelayConstants.BEGIN_DATE).append(RelayConstants.CONTEXT_SEPARATOR).append((formatter.format(date)))
                .append(RelayConstants.FILTER_BEGINDATE);
        log.info("URL for Argos: {}", url);
        return url;
    }

    /**
     * Read config from file.
     *
     * @return the battery info service config
     */
    public static BatteryInfoServiceConfig readConfigFromFile() {
        try {
            if (null == infoBean) {
                infoBean = new BatteryInfoServiceConfig();
                AbstractFileConfiguration config = new PropertiesConfiguration();
                config.setDelimiterParsingDisabled(true);
                config.load(Thread.currentThread().getContextClassLoader().getResource(RelayConstants.ARGOS_URLS_CONFIGURATION_FILE));
                infoBean.setUserName(config.getString(ARGOS_TOKEN_USERNAME));
                infoBean.setPassword(config.getString(ARGOS_TOKEN));
                infoBean.setAccessTokenURL(config.getString(ACCESS_TOKEN_URL));
                infoBean.setClientId(config.getString(CLIENT_ID));
                infoBean.setClientSecret(config.getString(CLIENT_SECRET));
                infoBean.setStaggingUrl(config.getString(ARGOS_STAGGING_URL));
            }
        } catch (ConfigurationException e) {
            log.error("Error while processing the argos-urls.properties file : ", e);
        }
        return infoBean;
    }

    /**
     * Gets the filtered output resposne.
     *
     * @param response the response
     * @return the filtered output resposne
     */
    public static String getFilteredOutputResposne(String response) {
        JSONObject jResponse = new JSONObject(response);
        List<JSONObject> list = new ArrayList<>();
        JSONObject filterdOutput = new JSONObject();
        if (jResponse.has(RelayConstants.JOBS)) {
            JSONArray jArray = jResponse.getJSONArray(RelayConstants.JOBS);
            for (int i = 0; i < jArray.length(); i++) {
                list.add(jArray.getJSONObject(i));
            }

            if (!list.isEmpty()) {
                compareBeginDate(list);
                JSONObject lastJob = list.get(0);
                log.info("Lastest Response received from Argos: {}", lastJob.get("id"));
                JSONObject data = (JSONObject) lastJob.get((RelayConstants.DATA));

                if (!data.has(RelayConstants.IDGRES) || data.getString(RelayConstants.IDGRES).isEmpty()) {
                    setJsonValue(filterdOutput, RelayConstants.RESULT, StringUtils.SPACE);
                } else {
                    setJsonValue(filterdOutput, RelayConstants.RESULT, data.getString(RelayConstants.IDGRES));
                }
                if (!data.has(RelayConstants.OCV) || data.getString(RelayConstants.OCV).isEmpty()) {
                    setJsonValue(filterdOutput, RelayConstants.VOLTAGE, StringUtils.SPACE);
                } else {
                    setJsonValue(filterdOutput, RelayConstants.VOLTAGE, data.getString(RelayConstants.OCV));
                }
                if (!data.has(RelayConstants.BKCODE) || data.getString(RelayConstants.BKCODE).isEmpty()) {
                    setJsonValue(filterdOutput, RelayConstants.BK_CODE, StringUtils.SPACE);
                } else {
                    setJsonValue(filterdOutput, RelayConstants.BK_CODE, data.getString(RelayConstants.BKCODE));
                }
            }
        }
        return filterdOutput.toString();

    }

    /**
     * Sets the json value.
     *
     * @param obj   the obj
     * @param key   the key
     * @param value the value
     */
    private static void setJsonValue(JSONObject obj, String key, String value) {
        obj.put(key, value);
    }

    /**
     * Compare begin date.
     *
     * @param list the list
     */
    protected static void compareBeginDate(List<JSONObject> list) {
        Collections.sort(list, new Comparator<Object>() {
            SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

            @Override
            public int compare(Object obj1, Object obj2) {
                Date str1 = new Date();
                Date str2 = new Date();
                JSONObject jObj1 = (JSONObject) obj1;
                JSONObject jObj2 = (JSONObject) obj2;
                try {
                    str1 = dateParser.parse((String) jObj1.get(RelayConstants.BEGIN_DATE));
                    str2 = dateParser.parse((String) jObj2.get(RelayConstants.BEGIN_DATE));
                } catch (Exception e) {
                    log.error("Exception while comparing the jobs in json: ", e);
                }
                return str2.compareTo(str1);
            }

        });
    }

    /**
     * Adds the error message.
     *
     * @param responseStatus the response status
     * @return the string
     */
    public static String addErrorMessage(int responseStatus) {

        String message;
        switch (responseStatus) {
        case HttpURLConnection.HTTP_OK:
            message = RelayConstants.SUCCESS_RESPONSE_NO_DATA;
            break;
        case HttpURLConnection.HTTP_BAD_REQUEST:
            message = RelayConstants.BAD_REQUEST;
            break;
        case HttpURLConnection.HTTP_UNAUTHORIZED:
        case HttpURLConnection.HTTP_FORBIDDEN:
            message = RelayConstants.UNAUTHORIZED;
            break;
        case HttpURLConnection.HTTP_NOT_FOUND:
            message = RelayConstants.NO_DATA_RECEIVED;
            break;
        default:
            message = RelayConstants.INTERNAL_SERVER_ERROR;
        }
        return message;
    }

    /**
     * Generate access token.
     *
     * @param requestMethod the request method
     * @param client        the client
     * @return the o auth JSON access token response
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static int generateAccessToken(PostMethod requestMethod, HttpClient client) throws IOException {
        StringBuilder authHeaderValue = new StringBuilder();

        try {
            requestMethod.setRequestHeader(RelayConstants.AUTHORIZATION, extractTokenAuthorization(authHeaderValue));
            requestMethod.addRequestHeader(RelayConstants.CONTENT_TYPE, RelayConstants.CONTENT_TYPE_DATA);// Sonar issue Fix
            requestMethod.addParameter("grant_type", "password");
            requestMethod.addParameter("username", AesEncDec.decrypt(infoBean.getUserName()));
            requestMethod.addParameter("password", AesEncDec.decrypt(infoBean.getPassword()));
            // CAP-29321 Directly return responsecode
            return client.executeMethod(requestMethod);
        } catch (UnsupportedEncodingException e) {
            // CAP-29321
            log.error("Exception while generating the Token from URl: ", e);
        } finally {
            authHeaderValue.setLength(0); // CAP-29321 Resetting StringBuilder to null
        }
        return HttpURLConnection.HTTP_UNAUTHORIZED;
    }

    /**
     * Extract token authorization.
     *
     * @param authHeaderValue the auth header value
     * @return the string
     */
    private static String extractTokenAuthorization(StringBuilder authHeaderValue) {
        String auth = infoBean.getClientId() + ":" + infoBean.getClientSecret();
        return authHeaderValue.append("Basic ").append(Base64.encodeBase64String(auth.getBytes())).toString();
    }

    /**
     * Generate access token. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
     * 
     * @param argosStatusMap the argos status map
     * @return the https URL connection
     */
    public HttpsURLConnection generateAccessToken(Map<Integer, String> argosStatusMap) {
        HttpsURLConnection httpConn = null;
        try {
            httpConn = createHttpConnWithProxyAndTLS(infoBean.getAccessTokenURL(), AbstractRelayCommunicationService.ARGOS);
            OAuthClientRequest request = OAuthClientRequest.tokenLocation(infoBean.getAccessTokenURL()).setGrantType(GrantType.PASSWORD)
                    .setClientId(infoBean.getClientId()).setClientSecret(infoBean.getClientSecret())
                    .setUsername(AesEncDec.decrypt(infoBean.getUserName())).setPassword(AesEncDec.decrypt(infoBean.getPassword())).buildBodyMessage();
            setRequestBody(request, RelayConstants.POST_METHOD, httpConn);
            if (httpConn != null) {
                httpConn.connect();
                log.info("Response received from Argos for Token: {}", httpConn.getResponseCode());// Sonar issue Fix
            }

        } catch (IOException | OAuthSystemException e) {
            // CAP-29321
            log.error("Exception while generating the Token from URl: ", e);
        }
        return httpConn;
    }

    /**
     * Sets the request body. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
     * 
     * @param request           the request
     * @param requestMethod     the request method
     * @param httpURLConnection the http URL connection
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void setRequestBody(OAuthClientRequest request, String requestMethod, HttpURLConnection httpURLConnection) throws IOException {
        String requestBody = request.getBody();
        if (OAuthUtils.isEmpty(requestBody)) {
            return;
        }

        if (OAuth.HttpMethod.POST.equals(requestMethod) || OAuth.HttpMethod.PUT.equals(requestMethod)) {
            httpURLConnection.setDoOutput(true);
            OutputStream ost = httpURLConnection.getOutputStream();
            PrintWriter pw = new PrintWriter(ost);
            pw.print(requestBody);
            pw.flush();
            pw.close();
            ost.close();
        }
    }

    /**
     * Creates the http conn with proxy and TLS. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is
     * upgraded to 1.8
     *
     * @param argosUrl              the argos url
     * @param targetApplicationName the target application name
     * @return the https URL connection
     * @throws IOException Signals that an I/O exception has occurred.
     */

    public static HttpsURLConnection createHttpConnWithProxyAndTLS(String argosUrl, String targetApplicationName) throws IOException {
        HttpsURLConnection httpConn = null;
        try {
            final ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
            ProxyBean loginProxy = serverConfigurationManager.getProxy();
            Authenticator authenticator = new Authenticator() {
                @Override
                public PasswordAuthentication getPasswordAuthentication() {
                    return (new PasswordAuthentication(serverConfigurationManager.getServerAccount().getLogin(),
                            serverConfigurationManager.getServerAccount().getPassword().toCharArray()));
                }
            };
            Authenticator.setDefault(authenticator);
            URL url = new URL(argosUrl);
            InetSocketAddress proxyAddress = new InetSocketAddress(loginProxy.getHostname(), loginProxy.getPort());
            Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyAddress);
            // POUDG-9437
            if (AbstractRelayCommunicationService.LDAP_OI.equals(targetApplicationName)) {
                DssCallEnrollmentPortalService.trustAllHosts();
            }
            httpConn = (HttpsURLConnection) url.openConnection(proxy);
            if (!AbstractRelayCommunicationService.LDAP_OI.equals(targetApplicationName)) {
                SSLContext sslContext = SSLContexts.custom().useProtocol(RelayConstants.TLS_VERSION_1_2).build();
                httpConn.setSSLSocketFactory(sslContext.getSocketFactory());
            }
            httpConn.setReadTimeout(RelayConstants.READ_TIMEOUT); // Sonar issue Fix
            httpConn.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.CONTENT_TYPE_DATA);
        } catch (KeyManagementException | NoSuchAlgorithmException e) {
            // CAP-29321
            log.error("Exception while getting Argos token.", e);
        }
        return httpConn;
    }

    /**
     * Gets the battery info access token. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded
     * to 1.8
     * 
     * @param request        the request
     * @param argosStatusMap the argos status map
     * @return the battery info access token
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public HttpsURLConnection getBatteryInfoAccessToken(String request, Map<Integer, String> argosStatusMap) throws IOException {
        int tokenResponseCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
        String pdiType = null;
        String vin = null;
        HttpsURLConnection httpConn = null;

        try {
            readConfigFromFile();
            JSONObject jsonObject = new JSONObject(request);
            if (!jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.PDI_TYPE)
                    || !jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.VIN)) {
                tokenResponseCode = HttpURLConnection.HTTP_BAD_REQUEST;
            }
            if (tokenResponseCode != HttpURLConnection.HTTP_BAD_REQUEST) {
                pdiType = jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.PDI_TYPE);
                vin = jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.VIN);
                if (StringUtils.isBlank(vin) || vin.length() < RelayConstants.SEVENTEEN || StringUtils.isBlank(pdiType)) {
                    tokenResponseCode = HttpURLConnection.HTTP_BAD_REQUEST;
                }
                if (tokenResponseCode != HttpURLConnection.HTTP_BAD_REQUEST) {
                    httpConn = extractTokenAndCallToArgos(argosStatusMap, pdiType, vin); // Sonar issue fix
                }
                if (argosStatusMap.isEmpty())
                    argosStatusMap.put(tokenResponseCode, addErrorMessage(tokenResponseCode));
            }
        } catch (Exception e) {
            log.error("Exception while Calling Argos for Access Token: ", e);
            argosStatusMap.put(HttpURLConnection.HTTP_INTERNAL_ERROR, addErrorMessage(HttpURLConnection.HTTP_INTERNAL_ERROR));
        }
        return httpConn;
    }

    /**
     * CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
     *
     * @param argosStatusMap argosStatusMap
     * @param pdiType        pditype
     * @param vin            vin
     * @return HttpURLConnection
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private HttpsURLConnection extractTokenAndCallToArgos(Map<Integer, String> argosStatusMap, String pdiType, String vin) throws IOException {
        String token;
        HttpsURLConnection httpConn;
        urlforArgos = prepareUrlForArgos(vin, pdiType);
        httpConn = generateAccessToken(argosStatusMap);
        if (null != httpConn && httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            token = extractResponseToken(httpConn);
            if (StringUtils.isNotBlank(token)) {
                httpConn = createAndCallArgosurl(token, argosStatusMap);
                if (null != httpConn && httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    processArgosResponse(argosStatusMap, httpConn);
                }
            }
        }
        if (argosStatusMap.isEmpty() && null != httpConn)
            argosStatusMap.put(httpConn.getResponseCode(), addErrorMessage(httpConn.getResponseCode()));
        return httpConn;
    }

    /**
     * Creates the and call argosurl. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to
     * 1.8
     * 
     * @param token          the token
     * @param argosStatusMap the argos status map
     * @return the https URL connection
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public HttpsURLConnection createAndCallArgosurl(String token, Map<Integer, String> argosStatusMap) throws IOException {
        HttpsURLConnection httpConn = null;
        try {
            httpConn = createHttpConnWithProxyAndTLS(urlforArgos.toString(), AbstractRelayCommunicationService.ARGOS);
            if (httpConn != null) {
                httpConn.setReadTimeout(RelayConstants.READ_TIMEOUT);
                httpConn.setRequestMethod(RelayConstants.GET_METHOD);
                httpConn.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.CONTENT_TYPE_DATA);// Sonar issue Fix
                httpConn.setRequestProperty(RelayConstants.AUTHORIZATION, RelayConstants.BEARER + token);
                httpConn.connect();
                log.info("Response received from Argos: {}", httpConn.getResponseCode());// Sonar issue Fix
                argosStatusMap.put(httpConn.getResponseCode(), addErrorMessage(httpConn.getResponseCode()));
            }
        } catch (UnsupportedEncodingException e) {
            // CAP-29321
            log.error("Exception while calling Argos from URl: ", e);
        }
        return httpConn;
    }

    /**
     * Extract response token. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
     * 
     * @param httpConn the http conn
     * @return the string
     */
    public static String extractResponseToken(HttpURLConnection httpConn) {
        String tokenResponse = StringUtils.EMPTY;
        try {
            String response = convertStreamToString(httpConn.getInputStream());
            JsonObject fromJson = new Gson().fromJson(response, JsonObject.class);
            if (fromJson.has(RelayConstants.ACCESS_TOKEN)) {
                JsonElement jsonTokenResponse = fromJson.get(RelayConstants.ACCESS_TOKEN);
                tokenResponse = jsonTokenResponse.getAsString();
            }
        } catch (IOException e) {
            log.error("Exception while extracting Access Token: ", e);
        }
        return tokenResponse;

    }

    /**
     * Convert stream to string.. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
     * 
     * @param is the is
     * @return the string
     */
    public static String convertStreamToString(InputStream is) {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            // CAP-29321
            log.error("Exception while converting Response Json To String.", e);
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                // CAP-29321
                log.error("Exception while closing the Input stream coming in response.", e);
            }
        }
        return sb.toString();
    }

    /**
     * Process argos response. CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8s
     * 
     * @param tokenResponseMap the token response map
     * @param httpConn         the http conn
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void processArgosResponse(Map<Integer, String> tokenResponseMap, HttpURLConnection httpConn) throws IOException {
        String finalResponse = StringUtils.EMPTY;
        try {
            String argosResponse = convertStreamToString(httpConn.getInputStream());
            JsonObject fromJson = new Gson().fromJson(argosResponse, JsonObject.class);
            JsonElement totalCount = fromJson.get(RelayConstants.TOTAL_COUNT);
            if (null != totalCount && StringUtils.isNotBlank(totalCount.toString())
                    && (Integer.parseInt(totalCount.toString()) > RelayConstants.ZERO)) {
                finalResponse = getFilteredOutputResposne(fromJson.toString());
                log.info("Success Response received from Argos: {}", finalResponse);
                tokenResponseMap.put(httpConn.getResponseCode(), finalResponse);
            } else {
                log.info("No Response received from Argos: {}", fromJson);
                tokenResponseMap.put(httpConn.getResponseCode(), BatteryInfoUtil.addErrorMessage(httpConn.getResponseCode()));
            }
        } catch (IOException e) {
            log.error("Exception while fetching data from Argos: ", e);
            tokenResponseMap.put(httpConn.getResponseCode(), BatteryInfoUtil.addErrorMessage(httpConn.getResponseCode()));
        }
    }
}
