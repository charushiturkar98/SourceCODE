package com.inetpsa.o8d.a2dr.service.metier;

import java.util.HashMap;
import java.util.Map;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * La classe DDCService assure le service de recuperation de la carte d'identite de l'utilisateur identifie. Utilise le composant DiagUser present en
 * session lors de l'action d'authentification.
 * 
 * @author e300260
 */
public class DDCService extends AbstractA2DRBusinessService {

    /** nom du service */
    public static final String SERVICE_NAME = "ddc_service";

    /** instance utilis� du DiagUser */
    public static final String DIAG_USER_INSTANCE = "DIAG_USER_INSTANCE";

    /**
     * Constante OUT_HEADERS : represente les headers de la requete retournee par le service metier A2DR Utilise par le service : A2DRDialogueService
     * (OUT_HEADER est les headers de RESPONSE_FROM_TARGET) sera utilise via un objet MAP
     */
    public static final String OUT_HEADERS = "OUT_HEADERS";

    /**
     * Constante OUT_MAP : represente un objet MAP qui contiendra les resultats du service metier A2DR OUT_HEADER, EXCEPTION_METIER, METHOD,
     * STATUS_CODE, RESPONSE_FROM_TARGET
     */
    public static final String OUT_MAP = "OUT_MAP";

    /**
     * Constante RESPONSE_FROM_TARGET : represente la requete HTTP recu de la cible apres le relai Utilise par le service : A2DRDialogueService
     */
    public static final String RESPONSE_FROM_TARGET = "RESPONSE_FROM_TARGET";

    /**
     * Constante EXCEPTION_METIER : represente l'exception survenue lors de l'execution du service metier A2DR Sera utilise par le service metier :
     * TraitementExceptionMetier pour generer la requete HTTP vers le client avec le code d'erreur
     */
    public static final String EXCEPTION_METIER = "EXCEPTION_METIER";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme.
     */
    public DDCService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.fwk.service.BusinessService#doExecute()
     */
    protected void doExecute() throws FwkException {
        logger.debug(">>doExecute debut Execution du service");

        try {
            AbstractDiagUserConnector diagUser = (AbstractDiagUserConnector) this.getInput(DIAG_USER_INSTANCE);
            Map<String, Object> result = new HashMap<String, Object>();
            this.setOutput(OUT_MAP, result);

            Map<String, String> mapHeader = new HashMap<String, String>();
            result.put(OUT_HEADERS, mapHeader);

            if (null == diagUser) {
                throw new AuthentificationException("Le connecteur 'DiagUser' non present en session");
            }

            logger.info("DDCService=>doExecute : Recuperation des donnees du service de l'utilisateur [{}]", diagUser.getUserName());

            String identityCard = diagUser.getIdentityCardAsString();
            result.put(RESPONSE_FROM_TARGET, identityCard);
            mapHeader.put("Content-Length", Integer.toString(identityCard.length()));
        } catch (DiagUserException e) {
            logger.error("DDCService=>doExecute : Exception/probleme sur le service 'DDCService'", e);

            throw new AuthentificationException(e);
        }

        logger.debug("<<doExecute fin Execution du service");
    }
}
