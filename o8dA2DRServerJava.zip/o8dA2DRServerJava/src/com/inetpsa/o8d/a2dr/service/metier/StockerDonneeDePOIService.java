package com.inetpsa.o8d.a2dr.service.metier;

import java.text.ParseException;
import java.util.Collection;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.apache.ojb.broker.util.ObjectModification;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.persistence.IPersistentContextKey;
import com.inetpsa.fwk.service.persistence.OJBPersistentContext;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.beans.VinA2DR;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;

/**
 * Cette classe fait partie de l'ensemble cr�e par le projet o8d suite aux impacts �5.
 * 
 * @author e358045
 */
public class StockerDonneeDePOIService extends AbstractA2DRBusinessService {

    /** nom du service */
    public static final String SERVICE_NAME = "stocker_donnee_de_poi";

    /** utilisateur qui c'est authenfier et qu'on veut rendre persistant */
    public static final String IN_UTILISATEUR = "IN_UTILISATEUR";

    /** parametre de retour de l'authentification */
    public static final String IN_FLAG_NOT_AUTHENTICATED = "IN_FLAG_NOT_AUTHENTICATED";
    /**
     * Message d'erreur lors de l'impossibilit� d'abandonner une transaction.
     */
    private static final String ABORT_ERROR_MSG = "la transaction n'a pas pu �tre annul�e";
    /**
     * CAP-26498: The Constant SERVER_NAME. Initialize hostName for differentiating call for diagbox and diagcloud lot2
     */
    public static final String HOST_NAME = "HOST_NAME";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme.
     */
    public StockerDonneeDePOIService() throws FwkException {
        super();
    }

    /**
     * Traitement metier.
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        logger.debug(">> debut Execution du service StockerDonneeDePOIService");

        OJBPersistentContext persistentContext = null;
        IPersistentContextKey key = null;
        PersistenceBroker broker = null;
        String hostName = (String) this.getInput(HOST_NAME);
        try {
            key = buildPersistentContextKey();

            String flagNotAuthenticated = this.getInputParameterValue(IN_FLAG_NOT_AUTHENTICATED);

            UserA2DR utilisateurA2DR = (UserA2DR) this.getInput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE);

            persistentContext = (OJBPersistentContext) getPersistentContext(key);

            broker = persistentContext.getBroker();

            // 1 - si on a le flag => login ou password faux => on le cherche dans la base local, si on le trouve on le supprime
            if (flagNotAuthenticated != null) {

                supprimerUserA2DRSiExiste(utilisateurA2DR, broker, key);
            } else {
                // L'utilisateur est ok
                Criteria criteria = new Criteria();
                criteria.addEqualTo(UserA2DR.USER_LOGIN_FIELD, utilisateurA2DR.getLogin());

                QueryByCriteria condition = new QueryByCriteria(UserA2DR.class, criteria);

                UserA2DR crudUserA2DR = (UserA2DR) broker.getObjectByQuery(condition);

                /*
                 * Explication : si 'crudUserA2DR' != null : L'op�rateur ind�pendant existe dans la base de donn�e local par cons�quent, on met � jour
                 * les references et on les enregistre dans la base de donn�e. si 'crudUtilisateur' == null : L'op�rateur ind�pendant n'existe pas
                 * dans la base de donn�e local par cons�quent, on enregistre l'ensemble des caract�ristiques de l'OI dans notre base local. C'est �
                 * dire l'objet UserA2DR et tous les objets VinA2DR associ�s.
                 */

                UserA2DR crudUserA2DRUpdatedOrInsert = null;
                if (crudUserA2DR != null) {

                    // si on trouve la personne, on l'update
                    updateUserA2DR(crudUserA2DR, utilisateurA2DR, broker, key, hostName);

                    crudUserA2DRUpdatedOrInsert = crudUserA2DR;
                } else {
                    // si on ne le trouve pas, on l'insert

                    crudUserA2DRUpdatedOrInsert = insertUserA2DR(utilisateurA2DR, broker, key, hostName);
                }

                this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, crudUserA2DRUpdatedOrInsert);
            }
        } catch (FwkException e) {
            logger.error("Fwk exception", e);

            if (broker != null) {
                try {
                    if (broker.isInTransaction()) {
                        abortTransaction(key);
                    }
                } catch (FwkException fwk) {
                    logger.error(ABORT_ERROR_MSG, fwk);
                }
            }
        } finally {
            if (persistentContext != null && key != null) {
                try {
                    closePersistentContext(key);
                } catch (FwkException fwk) {
                    logger.error("erreur lors de la fermeture du PersistentContext", fwk);
                }
            }
        }
        logger.debug("<< fin Execution du service StockerDonneeAOIService");
    }

    /**
     * Mise a jour de l'objet UserInformation au niveau de la base.
     * 
     * @param utilisateur utilisateur actuel.
     * @param userA2DRDePOI utilisateur recuprere depuis AOI.
     * @param broker broker OJB.
     * @param key key OJB.
     * @throws FwkException si une erreur survient
     * @throws ParseException si une erreur survient
     */
    private void updateUserA2DR(UserA2DR utilisateur, UserA2DR userA2DRDePOI, PersistenceBroker broker, IPersistentContextKey key, String hostName)
            throws FwkException {

        beginTransaction(key);
        logger.debug("debut insertion des donnees provenant de POI");

        Criteria criteriaIdUser = new Criteria();
        criteriaIdUser.addEqualTo("idUserA2DR", Integer.valueOf(utilisateur.getId()));

        QueryByCriteria qUtilisateurCrite = new QueryByCriteria(VinA2DR.class, criteriaIdUser);
        broker.clearCache();

        logger.debug("suppression de tous les abonnements VinA2DR'{}'", utilisateur.getLogin());
        broker.deleteByQuery(qUtilisateurCrite);

        copyUserDatas(userA2DRDePOI, utilisateur, hostName);

        broker.store(utilisateur, ObjectModification.UPDATE);

        commitTransaction(key);
    }

    /**
     * Insertion d'un utilisateur au niveau de la base
     * 
     * @param utilisateur utilisateur recupere depuis AOI.
     * @param broker broker OJB.
     * @param key key OJB.
     * @return utilisateur utilisateur mis � jour.
     * @throws FwkException si une erreur survient
     * @throws ParseException si une erreur survient
     */
    private UserA2DR insertUserA2DR(UserA2DR utilisateur, PersistenceBroker broker, IPersistentContextKey key, String hostName) throws FwkException {
        beginTransaction(key);
        UserA2DR creationUtilisateurA2DR = new UserA2DR();
        creationUtilisateurA2DR.setLogin(utilisateur.getLogin());
        // CAP-26498:Lot2- no password required
        if (!(hostName.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME)))) {
            creationUtilisateurA2DR.setMotDePasse(utilisateur.getMotDePasse());
        }
        logger.debug("userId={}", creationUtilisateurA2DR.getId());

        broker.store(creationUtilisateurA2DR, ObjectModification.INSERT);

        Criteria criteria = new Criteria();
        criteria.addEqualTo(UserA2DR.USER_LOGIN_FIELD, utilisateur.getLogin());

        QueryByCriteria condition = new QueryByCriteria(UserA2DR.class, criteria);

        UserA2DR crudUserA2DR = (UserA2DR) broker.getObjectByQuery(condition);

        copyUserDatas(utilisateur, crudUserA2DR, hostName);

        broker.store(crudUserA2DR, ObjectModification.UPDATE);

        commitTransaction(key);

        return crudUserA2DR;
    }

    /**
     * Supprime un utilisateur (Op�rateur ind�pendant) s'il existe dans la base de donn�e local alors qu'il n'existe pas sur POI. (exemple :
     * suppression d'un compte sur POI)
     * 
     * @param utilisateurASupprimer objet repr�sentant l'op�rateur ind�pendant � supprimer
     * @param broker broker OJB.
     * @param key key OJB.
     * @throws FwkException si une erreur survient
     */
    private void supprimerUserA2DRSiExiste(UserA2DR utilisateurASupprimer, PersistenceBroker broker, IPersistentContextKey key) throws FwkException {

        Criteria criteria = new Criteria();
        criteria.addEqualTo("login", utilisateurASupprimer.getLogin());

        QueryByCriteria queryUserToDelete = new QueryByCriteria(UserA2DR.class, criteria);

        int nbUtilisateur = broker.getCount(queryUserToDelete);

        // existe chez dans la base A2DR
        if (nbUtilisateur > 0) {
            logger.warn("> debut suppression du user'{}' car il n'existe pas chez POI , mais existe dans la base local d'A2DR =>"
                    + " suppression du compte chez A2DR de l'op�rateur ind�pendant pas authentifier", utilisateurASupprimer.getLogin());
            beginTransaction(key);
            broker.clearCache();

            // cascade delete sur VinA2DR
            broker.deleteByQuery(queryUserToDelete);
            commitTransaction(key);

            logger.warn("< fin suppression du user'{}'", utilisateurASupprimer.getLogin());

            this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, null);
        }
    }

    /**
     * Cette fonction permet d'affecter un objet source provenant de la base de donn�e local l'ensemble des valeurs que contient l'objet dest cr�e �
     * partir des objets provenant de POI.
     * 
     * @param source cr�� � partir des objets provenants de POI
     * @param dest cr�� � partir de la base locale
     * @throws ParseException si une erreur survient
     */
    private void copyUserDatas(UserA2DR source, UserA2DR dest, String hostName) { // Sonar issue fix
        logger.debug("Copy des donn�es");

        dest.setAdrFacture(source.getAdrFacture());
        dest.setCodeLangueISO(source.getCodeLangueISO());
        dest.setCodePaysISO(source.getCodePaysISO());
        dest.setCodePostal(source.getCodePostal());
        dest.setDateFinMax(source.getDateFinMax());
        dest.setEmail(source.getEmail());
        dest.setIsValidate(source.getIsValidate());
        dest.setLogin(source.getLogin());
        // CAP-26498:Lot2- no password required
        if (!(hostName.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME)))) {
            dest.setMotDePasse(source.getMotDePasse());
        }
        dest.setNbrJetons(source.getNbrJetons());
        dest.setNom(source.getNom());
        dest.setPrenom(source.getPrenom());
        dest.setVille(source.getVille());

        Collection<VinA2DR> listeVin = dest.getListeVin();
        listeVin.clear();

        for (VinA2DR vinA2DR : source.getListeVin()) {
            vinA2DR.setIdUserA2DR(dest.getId());
            vinA2DR.setUserA2DR(dest);
            listeVin.add(vinA2DR);
        }
    }
}
