package com.inetpsa.o8d.a2dr.service;

import org.apache.commons.lang.StringUtils;
import org.apache.ojb.broker.PBKey;
import org.apache.ojb.broker.metadata.ConnectionRepository;
import org.apache.ojb.broker.metadata.MetadataManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.BusinessService;
import com.inetpsa.fwk.service.persistence.IPersistentContextKey;
import com.inetpsa.fwk.service.persistence.OJBPersistentContextKey;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.security.PasswordManager;
import com.inetpsa.o8d.a2dr.security.PasswordManagerException;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * La Classe abstraite A2DRAbstractBuissService est la classe m�re des service metier A2DR. Cette classe derive de la classe
 * com.inetpsa.fwk.service.BusinessService
 * 
 * @author Hichame ELKHALFI - E298062
 */
public abstract class AbstractA2DRBusinessService extends BusinessService {

    /** Log de la classe */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Gestionnaire de mot de passe.
     */
    protected static final PasswordManager PASSWORD_MANAGER = new PasswordManager();

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme.
     */
    public AbstractA2DRBusinessService() throws FwkException {
        super();
    }

    /**
     * M�thode doInit() M�thode appel�e � l'initialisation du service
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doInit() throws FwkException {
    }

    /**
     * M�thode doClose() M�thode appel�e � la fermeture du service
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doClose() throws FwkException {
    }

    /**
     * Construction de la cl�.
     * 
     * @return cl�
     */
    protected IPersistentContextKey buildPersistentContextKey() {
        final String jcdAlias = ServerConfigurationManager.getInstance().getJcdAlias();

        return new OJBPersistentContextKey(jcdAlias, getServiceAccount(jcdAlias));
    }

    /**
     * Renvoie le login et le mot de passe pour acceder � la base de donn�es A2DR. Cette m�thode renvoie les identifiants pr�d�finis pour la connexion
     * � la base de donn�e de l'application A2DR dans le fichier de configuration OJB
     * 
     * @param alias String : alias JDC
     * @return tableau contenant le login et le mot de passe pour acceder � la base de donn�es.
     */
    protected String[] getServiceAccount(String alias) {
        String[] account = new String[2];
        ConnectionRepository conRep = MetadataManager.getInstance().connectionRepository();
        PBKey key = conRep.getStandardPBKeyForJcdAlias(alias);
        account[0] = key.getUser();
        account[1] = key.getPassword();

        return account;
    }

    /**
     * Contr�le de l'utilisateur.
     * 
     * @param userA2dr            objet utilisateur
     * @param diagUserCredentials informations d'authentification
     * @return vrai si le mot de passe est valide, faux sinon
     * @throws PasswordManagerException si une erreur de validateur de mot de passe survient
     */
    protected boolean checkUser(UserA2DR userA2dr, DiagUserCredentials diagUserCredentials) throws PasswordManagerException {
        boolean validUser = false;
        /* START: CAP-26498 :DiagLot2 check user without password for diagcloud */
        if (null != userA2dr) {
            if (StringUtils.isNotBlank(diagUserCredentials.getPassword())) {
                validUser = PASSWORD_MANAGER.validatePassword(diagUserCredentials.getPassword(), userA2dr.getMotDePasse());
            }
            /* Removing isValidate check for Diagcloud */
            else {
                validUser = Boolean.TRUE;
            }
            if (validUser) {
                logger.info("On a trouve l'operateur '{}' en base ", diagUserCredentials.getUserName());
            } else {
                logger.warn(
                        "On a trouve l'operateur '{}' en base mais le mot de passe fourni ne correspond pas (le mode degrad� est donc indisponible pour cet utilisateur)",
                        diagUserCredentials.getUserName());
            }
        } else {
            logger.warn("L'utilisateur '{}' n'existe pas en base ", diagUserCredentials.getUserName());
        }
        /* END: CAP-26498 :DiagLot2 check user without password for diagcloud */
        return validUser;
    }
}
