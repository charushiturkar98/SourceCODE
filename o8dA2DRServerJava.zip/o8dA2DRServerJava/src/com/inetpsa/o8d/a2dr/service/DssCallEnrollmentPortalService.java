/*
 * Creation : 1 mars 2018
 */
package com.inetpsa.o8d.a2dr.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.SSLContexts;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.exception.HostNotFoundException;
import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;

/**
 * The Class DssCallEnrollmentPortalService.
 */
public class DssCallEnrollmentPortalService extends AbstractA2DRBusinessService {

    /** nom du service. */
    public static final String SERVICE_NAME = "DssCallEnrollmentPortalService";

    /** The Constant VAR_PROPERTY_BEAN. */
    public static final String VAR_PROPERTY_BEAN = "VAR_PROPERTY_BEAN";

    /** The Constant IN_REQUEST_HEADERS. */
    public static final String IN_REQUEST_HEADERS = "IN_REQUEST_HEADERS";

    /** The Constant IN_DIAG_SR_NO. */
    public static final String IN_DIAG_SR_NO = "IN_DIAG_SR_NO";

    /**
     * Constante OUT_HEADERS : represente les headers de la requete retournee par le service metier A2DR Utilise par le service : A2DRDialogueService
     * (OUT_HEADER est les headers de RESPONSE_FROM_TARGET) sera utilise via un objet MAP.
     */
    public static final String OUT_HEADERS = "OUT_HEADERS";

    /**
     * Constante OUT_MAP : represente un objet MAP qui contiendra les resultats du service metier A2DR OUT_HEADER, EXCEPTION_METIER, METHOD,
     * STATUS_CODE, RESPONSE_FROM_TARGET.
     */
    public static final String OUT_MAP = "OUT_MAP";

    /** Constante RESPONSE_FROM_TARGET : represente la requete HTTP recu de la cible apres le relai Utilise par le service : A2DRDialogueService. */
    public static final String RESPONSE_FROM_TARGET = "RESPONSE_FROM_TARGET";

    /**
     * Constante EXCEPTION_METIER : represente l'exception survenue lors de l'execution du service metier A2DR Sera utilise par le service metier :
     * TraitementExceptionMetier pour generer la requete HTTP vers le client avec le code d'erreur.
     */
    public static final String EXCEPTION_METIER = "EXCEPTION_METIER";

    /** The Constant SERIAL_NUM. */
    public static final String SERIAL_NUM = "systemSerialNb";

    /** The Constant HEADERS. */
    public static final String HEADERS = "headers";

    /** The Constant Stts_Code. */
    public static final String Stts_Code = "Stts_Code";

    /** The Constant DSS_STATUS_RESPO. */
    public static final String DSS_STATUS_RESPO = "dss_status";

    /**
     * Instantiates a new dss call enrollment portal service.
     *
     * @throws FwkException the fwk exception
     */
    public DssCallEnrollmentPortalService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.fwk.service.BusinessService#doExecute()
     */
    @Override
    protected void doExecute() throws FwkException {

        logger.info(">>doExecute debut Execution du service in DssCallEnrollment");
        String url = "";
        HttpURLConnection connection = null;

        try {
            String enrolmentUrl = (String) this.getInput(VAR_PROPERTY_BEAN);
            Map<String, Object> result = new HashMap<String, Object>();
            Map<String, String> headerValueMap = (Map<String, String>) this.getInput(IN_REQUEST_HEADERS);
            String srNumDDC = (String) this.getInput(IN_DIAG_SR_NO);

            logger.debug("Enrollment URL received with serial_num as var | Serial Num DDC  : " + enrolmentUrl + " | " + srNumDDC);

            // get enrollment portal URL
            url = getURL(enrolmentUrl, srNumDDC);

            logger.debug("Final URL for calling Enrollment portal : " + url);

            // perform HTTPGetRequest
            connection = sendPut(url);

            // get Status
            int httpStatusCode = connection.getResponseCode();

            logger.debug(">>> HttpStatus returned from Enrollment portal is : " + httpStatusCode);

            if (httpStatusCode == HttpStatus.SC_OK) {
                String resJsonString = convertStreamToString(connection.getInputStream());

                logger.debug("Response String received from Enrollment portal : " + resJsonString);

                JSONObject jsonObj = new JSONObject(resJsonString);
                String getAuthStts = getAuthStts(jsonObj);
                result.put(DSS_STATUS_RESPO, getAuthStts);
            }

            result.put(Stts_Code, httpStatusCode);

            this.setOutput(OUT_MAP, result);

            logger.debug("<<http status>> : " + httpStatusCode + " and message is  : " + connection.getResponseMessage());

        } catch (JsonParseException p) {
            String msg = "Exception in parsin json";
            setOutput(EXCEPTION_METIER, new HostNotFoundException(msg, p));
            logger.error(msg, p);
        } catch (IOException e) {
            String msg = "Impossible to connect to the URL: [" + url + "]";
            setOutput(EXCEPTION_METIER, new HostNotFoundException(msg, e));
            logger.error(msg, e);
        } finally {

            if (null != connection) {
                connection.disconnect();
            }
        }

        logger.debug("<<doExecute fin Execution du service");

    }

    /**
     * Send put.
     *
     * @param url the url
     * @return the http URL connection
     * @throws IOException Signals that an I/O exception has occurred.
     */

    private HttpURLConnection sendPut(String url) throws IOException {

        HttpURLConnection con = null;

        try {

            String login = ServerConfigurationManager.getInstance().getVariableValue("ENROLL_USER");
            String passWord = ServerConfigurationManager.getInstance().getVariableValue("ENROLL_PSWD");
            // TLS version issue fixed
            SSLContext sslContext = SSLContexts.custom().useProtocol("TLSv1.2").build();

            URL obj = new URL(url);

            // trustAllHosts(); //This block to be used when SSL certificate validation needs to be disabled

            con = (HttpURLConnection) obj.openConnection();

            ((HttpsURLConnection) con).setSSLSocketFactory(sslContext.getSocketFactory());

            // CAP-29321
            con.setRequestProperty("Accept-Charset", RelayConstants.ENCODING);

            con.setRequestMethod("PUT");

            con.setRequestProperty("Accept", "application/json");

            con.setRequestProperty("Content-Type", "application/json");

            con.setRequestProperty("Authorization", buildAuth(login, passWord));

            con.connect();

        } catch (IOException | KeyManagementException | NoSuchAlgorithmException e) {

            throw new IOException(e);

        }

        logger.debug(">>>Returning from sendPut method block >>>>>");

        return con;

    }

    /**
     * Trust all hosts.
     */
    public static void trustAllHosts() {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new java.security.cert.X509Certificate[] {};
            }

            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }
        } };

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLSv1.2");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the auth stts.
     *
     * @param json the json
     * @return the auth stts
     */
    private String getAuthStts(JSONObject json) {

        String stts = "";
        if (null != json) {
            stts = (String) json.get(DSS_STATUS_RESPO);

        }
        return stts;
    }

    /**
     * Gets the url.
     *
     * @param url  the url
     * @param srNo the sr no
     * @return the url
     */
    private String getURL(String url, String srNo) {

        String finalURl = "";
        if (StringUtils.isNotEmpty(url)) {
            finalURl = url.replace("serial_num", srNo);
        }

        return finalURl;
    }

    /**
     * Convert stream to string.
     *
     * @param is the is
     * @return the string
     */
    private static String convertStreamToString(InputStream is) {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    /**
     * Builds the auth.
     *
     * @param userId   the user id
     * @param password the password
     * @return the string
     */
    private String buildAuth(String userId, String password) {
        return new StringBuilder().append("Basic").append(" ")
                .append(new String(Base64.encodeBase64(new StringBuilder().append(userId).append(":").append(password).toString().getBytes())))
                .toString();
    }
}
