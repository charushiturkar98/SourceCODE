package com.inetpsa.o8d.a2dr.service.relay;

import static java.lang.Math.max;
import static java.math.BigInteger.ZERO;
import static java.nio.charset.StandardCharsets.US_ASCII;
import static java.util.Arrays.copyOf;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.configuration.AbstractFileConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.exception.ServiceTechnicalException;
import com.inetpsa.o8d.a2dr.beans.AuthenticationBean;
import com.inetpsa.o8d.a2dr.beans.RelayAccessConfigurationBean;
import com.inetpsa.o8d.a2dr.config.BatteryInfoServiceConfig;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.weba2dr.beans.CorvetDocsoa;
import com.inetpsa.o8d.weba2dr.err.ErrorCode;
import com.inetpsa.o8d.weba2dr.ldapbeans.GigyaToken;
import com.inetpsa.o8d.weba2dr.ldapbeans.RequestBodyForLdapOi;
import com.inetpsa.o8d.weba2dr.token.ADAServiceConfig;
import com.inetpsa.o8d.weba2dr.token.RequestBodyForAdaCall;
import com.inetpsa.o8d.weba2dr.token.RequestBodyForSignChallenageCall;
import com.inetpsa.o8d.weba2dr.token.RequestBodyForTbmhuCall;
import com.inetpsa.o8d.weba2dr.token.RequestBodyForTrakResponseCall;
import com.inetpsa.o8d.weba2dr.token.TokenGen;
import com.inetpsa.xml.fdzsoa.lcdv.commerce.apvtechnique.reseau.specific.FdzServiceLCDVResponseType;
import com.inetpsa.xml.fdzsoa.lcdv.commerce.apvtechnique.reseau.specific.LCDV;
import com.inetpsa.xml.fdzsoa.lcdv.commerce.apvtechnique.reseau.specific.Libelle;

/**
 * Relais permettant une r��criture des urls contenant dans la r�ponse.
 * 
 * @author E331258
 */

public class RewriteResponseRelayCommunicationService extends AbstractRelayCommunicationService {

    /**
     * Chaine de d�but des param�tres d'une url.
     */
    private static final String TARGET_PATH_URL_PARAMETER = "?dssaction=";

    /**
     * Regex pour la recherche des �l�ments � remplacer (avant recherche principale).
     */
    private static final String BEFORE_SEARCH_TO_REPLACE_REGEX = "href=\"javascript:";
    /**
     * Regex pour la recherche des �l�ments � remplacer (apr�s recherche principale).
     */
    private static final String AFTER_SEARCH_TO_REPLACE_REGEX = "hrefA2DRJS=\"javascript:";

    /**
     * Regex pour l'�l�ment � mettre en remplacement (avant recherche principale).
     */
    private static final String BEFORE_SEARCH_TO_REPLACE_REGEX_REPLACEMENT = AFTER_SEARCH_TO_REPLACE_REGEX;
    /**
     * Regex pour l'�l�ment � mettre en remplacement (apr�s recherche principale).
     */
    private static final String AFTER_SEARCH_TO_REPLACE_REGEX_REPLACEMENT = BEFORE_SEARCH_TO_REPLACE_REGEX;

    /**
     * Pattern pour la recherche des �l�ments � remplacer (avant recherche principale).
     */
    private static final Pattern BEFORE_SEARCH_TO_REPLACE_PATTERN = Pattern.compile(BEFORE_SEARCH_TO_REPLACE_REGEX, Pattern.CASE_INSENSITIVE);
    /**
     * Pattern pour la recherche des �l�ments � remplacer (apr�s recherche principale).
     */
    private static final Pattern AFTER_SEARCH_TO_REPLACE_PATTERN = Pattern.compile(AFTER_SEARCH_TO_REPLACE_REGEX, Pattern.CASE_INSENSITIVE);

    /**
     * Regex pour la recherche des emplacements d'insertion.
     */
    private static final String SEARCH_REGEX = "src=\"|href=\"|background=\"|import url[(]|: url[(]";
    /**
     * Pattern pour la recherche des emplacements d'insertion.
     */
    private static final Pattern SEARCH_PATTERN = Pattern.compile(SEARCH_REGEX, Pattern.CASE_INSENSITIVE);

    /** Methode d'envoi de la requete du client vers la cible ("GET" ou "POST") Utilise par le service. */
    public static final String IN_HTTP_METHOD = "IN_HTTP_METHOD";

    /** The Constant mandatoryFieldsToCallGetLevel3. */
    static final List<String> mandatoryFieldsToCallADACert = new ArrayList<>(Arrays.asList(RelayConstants.VIN.toUpperCase(), RelayConstants.SGW_SN,
            RelayConstants.ECU_CANID, RelayConstants.ECU_CERT_STORE_UUID, RelayConstants.ECU_SN, RelayConstants.USER_ID,
            RelayConstants.ECU_POLICY_TYPE, RelayConstants.DIAGBOX_MODE, RelayConstants.USER_TOKEN));

    /** The Constant mandatoryFieldsToCallSignChallenage. */
    static final List<String> mandatoryFieldsToCallSignChallenage = new ArrayList<>(
            Arrays.asList(RelayConstants.ECU_CHALLENAGE, RelayConstants.SESSION_ID));

    /** The Constant mandatoryFieldsToCallTrakResponse. */
    static final List<String> mandatoryFieldsToCallTrakResponse = new ArrayList<>(
            Arrays.asList(RelayConstants.ECU_RESPONSE, RelayConstants.ECU_RESULT, RelayConstants.SESSION_ID));
    /** The un authorized codes. */
    static List<Integer> unAuthorizedCodes = new ArrayList<>(
            Arrays.asList(ErrorCode.ERROR_403_CODE, ErrorCode.ERROR_405_CODE, ErrorCode.ERROR_410_CODE, ErrorCode.ERROR_401_CODE));

    /** The internal error codes. */
    static List<Integer> internalErrorCodes = new ArrayList<>(Arrays.asList(ErrorCode.ERROR_503_CODE, ErrorCode.ERROR_500_CODE));

    /** The bad request error codes. */
    static List<Integer> badRequestErrorCodes = new ArrayList<>(Arrays.asList(ErrorCode.ERROR_400_CODE, ErrorCode.ERROR_1_CODE,
            ErrorCode.ERROR_111_CODE, ErrorCode.ERROR_112_CODE, ErrorCode.ERROR_118_CODE, ErrorCode.ERROR_201_CODE, ErrorCode.ERROR_202_CODE,
            ErrorCode.ERROR_205_CODE, ErrorCode.ERROR_301_CODE, ErrorCode.ERROR_302_CODE, ErrorCode.ERROR_900_CODE, ErrorCode.ERROR_901_CODE,
            ErrorCode.ERROR_902_CODE, ErrorCode.ERROR_904_CODE));

    /** The request body for ada call fetched. */
    public static final RequestBodyForAdaCall requestBodyForAdaCallFetched = new RequestBodyForAdaCall();

    /** The request body for sign challenage fetched. */
    public static final RequestBodyForSignChallenageCall requestBodyForSignChallenageFetched = new RequestBodyForSignChallenageCall();

    /** The request body for track response call. */
    public static final RequestBodyForTrakResponseCall requestBodyForTrakResponseCall = new RequestBodyForTrakResponseCall();

    /** The Constant mandatoryFieldsToCallTBMHU. */
    // poudg 8769
    static final List<String> mandatoryFieldsToCallTBMHU = new ArrayList<>(Arrays.asList(RelayConstants.VIN, RelayConstants.ECU,
            RelayConstants.YEAR_VEHICLE, RelayConstants.BODY_VEHICLE, RelayConstants.SERIAL_NUMBER, RelayConstants.VCISN));

    /** The Constant notMandatoryFieldsToCallTBMHU. */
    static final List<String> notMandatoryFieldsToCallTBMHU = new ArrayList<>(
            Arrays.asList(RelayConstants.SW_COMPONENT_ID_HW_NUMBER, RelayConstants.SW_COMPONENT_ID_HW_VERSION, RelayConstants.FW_VERSION_SW_NUMBER,
                    RelayConstants.FW_VERSION_SW_VERSION, RelayConstants.MODEM_DATA_LMEI, RelayConstants.SIM_IDENTIFIER_ICCID,
                    RelayConstants.INTERNATIONAL_MOBILE_SUBSCRIBER_IDENTITY_IMSI, RelayConstants.MOBILE_SUBSCRIBER_ISDN_MSISDN,
                    RelayConstants.FOTAHW_PART_NUMBER, RelayConstants.FOASW_PART_NUMBER, RelayConstants.DEALER_C, RelayConstants.USER_I));

    /** The request body for tbmhu call. */
    public static final RequestBodyForTbmhuCall requestBodyForTbmhuCall = new RequestBodyForTbmhuCall();

    /** The request body for trak response call. */
    public static final String INVALID_REQUEST = "<<< Request body coming from DDC is not valid >>> ";

    /** The request body for ldap call fetched. */
    public static final RequestBodyForLdapOi requestBodyForLdapOi = new RequestBodyForLdapOi();

    /** The Constant corvetDocsoaForErrorResponse. */
    // POUDG-9486
    public static final CorvetDocsoa corvetDocsoaForErrorResponse = new CorvetDocsoa();

    /**
     * Constructeur.
     * 
     * @throws FwkException si une erreur survient
     */
    public RewriteResponseRelayCommunicationService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#getHttpMethod()
     */
    @Override
    protected ValidHttpMethod getHttpMethod() throws FwkException {
        // Recuperation du parametre pour construire la requete avec la methode adequate
        String methodStr = this.getInputParameterValue(IN_HTTP_METHOD);

        try {
            return ValidHttpMethod.valueOf(StringUtils.upperCase(methodStr));
        } catch (IllegalArgumentException e) {
            String msg = "Exception de configuration de methode d'envoi du service - [" + methodStr + "] non autorisee";
            setOutput(EXCEPTION_METIER, new ServiceTechnicalException(msg));

            logger.error(msg, e);

            throw e;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#postTreatments(byte[], java.util.Map)
     */
    @Override
    protected byte[] postTreatments(byte[] bytes, Map<String, String> responseHeaders) throws IOException, FwkException {
        String contentType = responseHeaders.get("Content-Type");

        if (logger.isInfoEnabled())
            logger.info("Retour d'un content-type=[{}]", contentType);

        // si le flux relay� est du texte, on doit modifier les chemin des ressources
        if (StringUtils.indexOf(contentType, "text") != -1) {
            return modifyPathReferences(bytes, responseHeaders);
        }

        return bytes;
    }

    /**
     * Permet de remplacer dans le flux de page html, le chemin relatif des ressources externes.
     * 
     * @param bytes           contenu de la page a relayer
     * @param responseHeaders objet map qui regroupe les headers de la reponse (le remplacement modifie le header "Content-Length")
     * @return contenu modifi�
     * @throws FwkException si une erreur survient
     */
    private byte[] modifyPathReferences(byte[] bytes, Map<String, String> responseHeaders) throws FwkException {
        if (logger.isInfoEnabled())
            logger.info(">> modifyPathReferences");

        // On construit le chemin a remplacer
        String a2drPath = new StringBuilder().append(buildA2drRelayUrl()).append(TARGET_PATH_URL_PARAMETER).toString();

        if ((StringUtils.length(targetApplicationUrl) <= MAX_LOG_SIZE) && (StringUtils.length(a2drPath) <= MAX_LOG_SIZE)) {
            if (logger.isInfoEnabled())
                logger.info("modification des references de [{}] vers [{}]", targetApplicationUrl, a2drPath);
        } else {
            if (logger.isInfoEnabled())
                logger.info("modification des references TOO LONG TO LOG");
        }

        String strContent = new String(bytes);

        int reponseLength = strContent.length();

        if (logger.isInfoEnabled())
            logger.info("Avant remplacement, la reponse a une taille de [{}]", reponseLength);

        // href=, pour les liens - attention pour les appels vers le javascript
        // recopie temporaire des liens vers js
        strContent = BEFORE_SEARCH_TO_REPLACE_PATTERN.matcher(strContent).replaceAll(BEFORE_SEARCH_TO_REPLACE_REGEX_REPLACEMENT);

        Matcher m = SEARCH_PATTERN.matcher(strContent);

        int startIndex = 0;

        StringBuilder sb = new StringBuilder();

        while (m.find()) {
            String groupStr = m.group();

            if (StringUtils.length(groupStr) <= MAX_LOG_SIZE) {
                if (logger.isInfoEnabled())
                    logger.info("From {} to {} : found {} ({})", startIndex, m.start(), groupStr, m.end());
            } else {
                if (logger.isInfoEnabled())
                    logger.info("From {} to {} : found TOO LONG TO LOG ({})", startIndex, m.start(), m.end());
            }

            sb.append(StringUtils.substring(strContent, startIndex, m.start())).append(groupStr).append(a2drPath);
            startIndex = m.end();
        }

        sb.append(StringUtils.substring(strContent, startIndex));

        strContent = sb.toString();
        sb.setLength(0); // CAP-29321 Resetting StringBuilder to null
        // recopie des liens temporaires vers js
        strContent = AFTER_SEARCH_TO_REPLACE_PATTERN.matcher(strContent).replaceAll(AFTER_SEARCH_TO_REPLACE_REGEX_REPLACEMENT);

        byte[] b = strContent.getBytes();

        // mise a jour du content-length du flux
        responseHeaders.put("Content-Length", String.valueOf(b.length));

        if (logger.isInfoEnabled())
            logger.info("<< modifyPathReferences");

        return b;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#getBatteryInfoAccessToken(java.lang.String,
     *      org.apache.commons.httpclient.HttpClient, java.util.Map)
     */
    @Override
    public String getBatteryInfoAccessToken(String request, HttpClient client, Map<Integer, String> argosStatusMap) {
        int tokenResponseCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
        String token = StringUtils.EMPTY;
        String pdiType = null;
        String vin = null;

        try {
            BatteryInfoServiceConfig infoBean = BatteryInfoUtil.readConfigFromFile();
            JSONObject jsonObject = new JSONObject(request);
            if (!jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.PDI_TYPE)
                    || !jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).has(RelayConstants.VIN)) {

                argosStatusMap.put(HttpURLConnection.HTTP_BAD_REQUEST, BatteryInfoUtil.addErrorMessage(HttpURLConnection.HTTP_BAD_REQUEST));
                return token;
            }
            pdiType = jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.PDI_TYPE);
            vin = jsonObject.getJSONObject(RelayConstants.JSON_MESSAGE).getString(RelayConstants.VIN);
            if (StringUtils.isBlank(vin) || vin.length() < RelayConstants.SEVENTEEN || StringUtils.isBlank(pdiType)) {
                tokenResponseCode = HttpURLConnection.HTTP_BAD_REQUEST;
            }
            if (tokenResponseCode != HttpURLConnection.HTTP_BAD_REQUEST) {
                PostMethod requestMethod = new PostMethod(infoBean.getAccessTokenURL());
                tokenResponseCode = BatteryInfoUtil.generateAccessToken(requestMethod, client);
                if (tokenResponseCode == HttpURLConnection.HTTP_OK) {
                    // CAP-29321 directly using url instead of storing
                    targetApplicationUrl = BatteryInfoUtil.prepareUrlForArgos(vin, pdiType).toString();
                    token = extractResponseToken(requestMethod);
                    if (StringUtils.isNotBlank(token)) {
                        return token;
                    }
                }
            }
            argosStatusMap.put(tokenResponseCode, BatteryInfoUtil.addErrorMessage(tokenResponseCode));
        } catch (Exception e) {
            logger.error("Exception while Calling Argos for Access Token: ", e);
            argosStatusMap.put(HttpURLConnection.HTTP_INTERNAL_ERROR, BatteryInfoUtil.addErrorMessage(HttpURLConnection.HTTP_INTERNAL_ERROR));
        }
        return token;
    }

    /**
     * Extract response token.
     *
     * @param requestMethod the request method
     * @return the string
     */
    private String extractResponseToken(PostMethod requestMethod) {
        String response;
        String tokenResponse = StringUtils.EMPTY;
        try {
            response = requestMethod.getResponseBodyAsString();
            JsonObject fromJson = new Gson().fromJson(response, JsonObject.class);
            if (fromJson.has(RelayConstants.ACCESS_TOKEN)) {
                JsonElement jsonTokenResponse = fromJson.get(RelayConstants.ACCESS_TOKEN);
                tokenResponse = jsonTokenResponse.getAsString();
            }
        } catch (IOException e) {
            logger.error("Exception while extracting Access Token: ", e);
        }
        return tokenResponse;

    }

    /**
     * Handle argos response.
     *
     * @param methodRelay      the method relay
     * @param tokenResponseMap the token response map
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public void handleArgosResponse(HttpMethod methodRelay, Map<Integer, String> tokenResponseMap) throws IOException {
        if (ARGOS.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
            if (methodRelay.getStatusCode() == HttpURLConnection.HTTP_OK) {
                BatteryInfoUtil.processArgosResponse(tokenResponseMap, methodRelay);
            } else {
                if (tokenResponseMap.isEmpty())
                    tokenResponseMap.put(methodRelay.getStatusCode(), BatteryInfoUtil.addErrorMessage(methodRelay.getStatusCode()));
            }
        }
    }

    /**
     * POUDG-8742:Method is used to traverse and process the data coming from CORVET and set it in FdzServiceLCDVResponseTypeDSS. Sonar issue
     *
     * @param corvetOutput           the corvet output
     * @param fdzServiceLCDVResponse the fdz service LCDV response
     */
    @Override
    public void setLCDVDataFromCorvet(String corvetOutput, FdzServiceLCDVResponseType fdzServiceLCDVResponse) {
        List<LCDV> listeLCDVBean = new ArrayList<>();
        List<String> attributCodes = getListeAttributeFromCorvet(corvetOutput);
        // POUDG-9486:START
        corvetDocsoaForErrorResponse.addLcdvBaseAttributes(corvetOutput, attributCodes);
        if (logger.isInfoEnabled())
            logger.info("Added LCDV attributes along with List attributes");
        if (!attributCodes.isEmpty()) {
            setLcdvDataForErrorResponse(listeLCDVBean, attributCodes);
            fdzServiceLCDVResponse.getLCDV().addAll(listeLCDVBean);
        }
    }

    /**
     * Method is used get Attributes from CORVET Liste_Attribute_7.
     *
     * @param corvetOutput the CORVET Liste_Attribute
     * @return the liste attribute from corvet
     */
    public List<String> getListeAttributeFromCorvet(String corvetOutput) {
        List<String> attributCodes = new ArrayList<>();

        if (!corvetOutput.isEmpty() && corvetOutput.contains(RelayConstants.LISTE_ATTRIBUTS)) {
            String listAtrributeLcdv = extractDataFromXML(corvetOutput, RelayConstants.LISTE_ATTRIBUTS, RelayConstants.LISTE_ATTRIBUTS_END);
            String[] listAttribut = listAtrributeLcdv.split(RelayConstants.ATTRIBUTE_PATTERN);
            for (int i = 1; i < listAttribut.length; i++) { // Starting index with 1 as index 0 is always blank
                attributCodes.add(extractDataFromXML(listAttribut[i], RelayConstants.ATTRIBUT_TAG, RelayConstants.ATTRIBUT_TAG_END));
            }
        }
        if (logger.isDebugEnabled())
            logger.debug("Response received from Corvet for Attribute: {} ", attributCodes);

        return attributCodes;
    }

    /**
     * POUDG-9055:Method is used to filter LCDV data based on CORVET response.
     *
     * @param corvetOutput           the corvet output
     * @param fdzServiceLCDVResponse the fdz service LCDV response
     */

    @Override
    public void filterLCDVDataBasisOfCORVETResponse(String corvetOutput, FdzServiceLCDVResponseType fdzServiceLCDVResponse) {
        if (fdzServiceLCDVResponse.getCodeRetour() != 0) {
            setLCDVDataFromCorvet(corvetOutput, fdzServiceLCDVResponse);
            return;
        }
        FdzServiceLCDVResponseType fdzServiceLCDVResponseTypeData = fdzServiceLCDVResponse;
        JSONObject lcdvObject = new JSONObject(fdzServiceLCDVResponseTypeData);
        JSONArray lcdvDataArray = lcdvObject.getJSONArray(RelayConstants.LCDV);
        List<String> attributCodes = getListeAttributeFromCorvet(corvetOutput);
        // Sending LCDV empty if no data received from CORVET. Below method is clearing LCDV data from DOCSOA response
        if (attributCodes.isEmpty()) {
            fdzServiceLCDVResponse.getLCDV().clear();
            if (logger.isDebugEnabled())
                logger.debug("LCDV atttributes of DOCSOA is set to empty as Response from CORVET is empty.");
        } else {
            List<String> attributCodesWith5Char = new ArrayList<>();
            for (int i = 0; i < attributCodes.size(); i++) { // Starting index with 1 as index 0 is always blank
                attributCodesWith5Char.add(attributCodes.get(i).substring(RelayConstants.ZERO, RelayConstants.FIVE));
            }
            JSONArray sortedJsonArray = new JSONArray();
            List<LCDV> lcdvAttribute = new ArrayList<>();
            // Sorting the lcdvData Array
            sortLCDVData(lcdvDataArray, sortedJsonArray);
            if (!attributCodesWith5Char.isEmpty()) {
                setLcdvDataFromDocSoa(sortedJsonArray, attributCodesWith5Char, lcdvAttribute);
                fdzServiceLCDVResponse.getLCDV().clear();
                fdzServiceLCDVResponse.getLCDV().addAll(lcdvAttribute);
                if (logger.isInfoEnabled())
                    logger.info("Filteration is successfully complete on LCDV atttributes of DOCSOA.");
            }
        }

    }

    /**
     * POUDG-9055: Method is used filter LCDV data based on CORVET LISTE_ATTRIBUTES.
     *
     * @param lcdvAttribute the lcdv attribute
     * @return the all LCDV attribute from corvet
     * @throws JSONException the JSON exception
     */
    @Override
    public void getAllLCDVAttributeFromCorvet(JSONObject lcdvAttribute) {
        lcdvAttribute.append(RelayConstants.ATTRIBUT, RelayConstants.ATTRIBUT_VALUE);
        if (logger.isDebugEnabled())
            logger.debug("Attributes received from DDC are empty. Hence Data sent to Corvet is: {} ", lcdvAttribute);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#addPercentageAtEndToListeAttribut(org.json.JSONObject,
     *      org.json.JSONArray, org.json.JSONObject)
     */
    @Override
    public void addPercentageAtEndToListeAttribut(Object corvetListeAttributeList, JSONObject lcdvAttribute) {
        List<String> attributes = new ArrayList<>();
        // Code for Attribute element parameter to check if not null, empty
        ArrayList<String> checkListeAttribute = new ArrayList<>(Arrays.asList(null, StringUtils.EMPTY, "null"));
        // Code for Attribute element values to check if not null, empty, space and ?
        ArrayList<String> checkAttribute = new ArrayList<>(Arrays.asList(StringUtils.EMPTY, null, "?", StringUtils.SPACE));

        if (!checkListeAttribute.contains(corvetListeAttributeList)) {
            JSONArray corvetListeAttributes = (JSONArray) corvetListeAttributeList;
            for (Object corvetListeAttributeData : corvetListeAttributes) {
                String corvetListeAttribute = corvetListeAttributeData.toString();
                if (!checkAttribute.contains(corvetListeAttribute)) {
                    attributes.add(corvetListeAttribute.concat(RelayConstants.ATTRIBUT_VALUE));
                }
            }
            if (attributes.isEmpty()) {
                getAllLCDVAttributeFromCorvet(lcdvAttribute);
            } else {
                lcdvAttribute.put(RelayConstants.ATTRIBUT, attributes);
                if (logger.isDebugEnabled())
                    logger.debug("Attributes received from DDC. Added percentage at the end and sent to corvet are: {} ", attributes);
            }
        } else {
            getAllLCDVAttributeFromCorvet(lcdvAttribute);
        }
    }

    /**
     * Sort LCDV data.
     *
     * @param lcdvDataArray   the lcdv data array
     * @param sortedJsonArray the sorted json array
     * @return the JSON array
     */
    // POUDG-9055: Sort the LCDV data of DOCSOA
    public JSONArray sortLCDVData(JSONArray lcdvDataArray, JSONArray sortedJsonArray) {
        List<JSONObject> list = new ArrayList<>();

        for (int i = 0; i < lcdvDataArray.length(); i++) {
            list.add(lcdvDataArray.getJSONObject(i));
        }
        Collections.sort(list, new Comparator<JSONObject>() {

            @Override
            public int compare(JSONObject a, JSONObject b) {
                String codeValue1 = "";
                String codeValue2 = "";

                try {
                    codeValue1 = (String) a.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE);
                    codeValue2 = (String) b.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE);
                } catch (JSONException e) {
                    String msg = "Exception while sorting values";
                    logger.error(msg, e);

                }
                return codeValue1.compareTo(codeValue2);
            }

        });
        for (int i = 0; i < lcdvDataArray.length(); i++) {
            sortedJsonArray.put(list.get(i));
        }

        if (logger.isInfoEnabled())
            logger.info("Sorting is complete for LCDV values of DOCSOA");

        return sortedJsonArray;

    }

    /**
     * POUDG-8742:Method is used to process the List_Attribute data from CORVET and setting in LCDV data.
     *
     * @param listeLCDVBean the liste LCDV bean
     * @param attr          the attr
     */
    private static void setLcdvDataForErrorResponse(List<LCDV> listeLCDVBean, List<String> attr) {
        if (!attr.isEmpty()) {
            for (String lcdvString : attr) {
                LCDV lcdv = new LCDV();
                Libelle libelle = new Libelle();
                Libelle libelleNatureClasse = new Libelle();
                libelle.setCode(lcdvString);
                libelle.setLibelle(StringUtils.SPACE);
                lcdv.setLibelleAttribut(libelle);
                lcdv.setLibelleAttributCom(libelle);
                // CAP-26684: LCDV7
                String code = lcdvString.substring(RelayConstants.ZERO, RelayConstants.THREE);
                libelleNatureClasse.setCode(code);
                libelleNatureClasse.setLibelle(StringUtils.SPACE);
                lcdv.setLibelleNatureClasse(libelleNatureClasse);
                lcdv.setClasse(code); // CAP-26684: LCDV7
                lcdv.setNature(StringUtils.SPACE);
                listeLCDVBean.add(lcdv);
            }
        }
    }

    /**
     * Sets the lcdv data from doc soa.
     *
     * @param lcdvArray        the lcdv array
     * @param ddcLCDVAttribute the ddc LCDV attribute
     * @param lcdvAttribute    the lcdv attribute
     */
    // POUDG-9055: Set the LCDV data from DOCSOA based on searching
    private void setLcdvDataFromDocSoa(JSONArray lcdvArray, List<String> ddcLCDVAttribute, List<LCDV> lcdvAttribute) {
        for (int i = 0; i < ddcLCDVAttribute.size(); i++) {

            String key = ddcLCDVAttribute.get(i);
            int firstIndex = 0;
            int lastIndex = lcdvArray.length() - 1;

            while (key.compareTo(
                    lcdvArray.getJSONObject(firstIndex).getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE).toString()) >= 0
                    && key.compareTo(lcdvArray.getJSONObject(lastIndex).getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE)
                            .toString()) <= 0) {
                int interpolateIndex = firstIndex + interpolate(
                        lcdvArray.getJSONObject(firstIndex).getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE).toString(),
                        lcdvArray.getJSONObject(lastIndex).getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE).toString(), key,
                        lastIndex - firstIndex);
                int cmp = key.compareTo(
                        lcdvArray.getJSONObject(interpolateIndex).getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE).toString());
                if (cmp < 0)
                    lastIndex = interpolateIndex - 1;
                else if (cmp > 0)
                    firstIndex = interpolateIndex + 1;
                else {
                    setValuesInLCDVObject(lcdvArray.getJSONObject(interpolateIndex), lcdvAttribute);
                    break;

                }
            }

        }

    }

    /**
     * Interpolate.
     *
     * @param firstIndexCode the first index code
     * @param lastIndexCode  the last index code
     * @param key            the key
     * @param id             the id
     * @return the int
     */
    private static int interpolate(String firstIndexCode, String lastIndexCode, String key, int id) {
        int maxLen = max(max(lastIndexCode.length(), firstIndexCode.length()), key.length());
        int result = 0;
        BigInteger lastIndexData = new BigInteger(1, copyOf(lastIndexCode.getBytes(US_ASCII), maxLen));
        BigInteger firstIndexData = new BigInteger(1, copyOf(firstIndexCode.getBytes(US_ASCII), maxLen));
        BigInteger keyData = new BigInteger(1, copyOf(key.getBytes(US_ASCII), maxLen));
        BigInteger d = BigInteger.valueOf(id);
        BigInteger indexDiff = lastIndexData.subtract(firstIndexData);
        if (!ZERO.equals(indexDiff)) {
            result = (int) d.multiply(keyData.subtract(firstIndexData)).divide(indexDiff).longValue();
        }
        return result;
    }

    /**
     * Sets the values in LCDV object.
     *
     * @param jsonObject    the json object
     * @param lcdvAttribute the lcdv attribute
     */
    // POUDG-9055: Set filtered values into lcdvAttribute
    private static void setValuesInLCDVObject(JSONObject jsonObject, List<LCDV> lcdvAttribute) {
        LCDV lcdv = new LCDV();
        Libelle libelleNatureClasse = new Libelle();
        Libelle libelleAttribut = new Libelle();
        Libelle libelleAttributCom = new Libelle();
        String natureValue = jsonObject.get(RelayConstants.NATURE).toString();
        String codeData = jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.CODE).toString();
        String libelleValueForAttribut = jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.LIBELLE).toString();
        String libelleValueForAttributCom = jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).get(RelayConstants.LIBELLE).toString();
        String libelleValueForNatureClasse = jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).get(RelayConstants.LIBELLE).toString();

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).has(RelayConstants.LOCALETRADUCTION))
            libelleAttribut
                    .setLocaleTraduction(jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.LOCALETRADUCTION).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).has(RelayConstants.LOCALETRADUCTION))
            libelleAttributCom.setLocaleTraduction(
                    jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).get(RelayConstants.LOCALETRADUCTION).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).has(RelayConstants.LOCALETRADUCTION))
            libelleNatureClasse.setLocaleTraduction(
                    jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).get(RelayConstants.LOCALETRADUCTION).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).has(RelayConstants.ERRORMSG))
            libelleAttribut.setErrorMsg(jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.ERRORMSG).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).has(RelayConstants.ERRORMSG))
            libelleAttributCom.setErrorMsg(jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).get(RelayConstants.ERRORMSG).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).has(RelayConstants.ERRORMSG))
            libelleNatureClasse.setErrorMsg(jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).get(RelayConstants.ERRORMSG).toString());

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).has(RelayConstants.ISERROR))
            libelleAttribut.setIsError((boolean) jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT).get(RelayConstants.ISERROR));

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).has(RelayConstants.ISERROR))
            libelleAttributCom.setIsError((boolean) jsonObject.getJSONObject(RelayConstants.LIBELLE_ATTRIBUT_COM).get(RelayConstants.ISERROR));

        if (jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).has(RelayConstants.ISERROR))
            libelleNatureClasse.setIsError((boolean) jsonObject.getJSONObject(RelayConstants.LIBELLE_NATURE_CLASSE).get(RelayConstants.ISERROR));

        // Set values for libelleAttribut
        libelleAttribut.setCode(codeData);
        libelleAttribut.setLibelle(libelleValueForAttribut);

        // Set values for libelleAttributCom
        libelleAttributCom.setCode(codeData);
        libelleAttributCom.setLibelle(libelleValueForAttributCom);

        // Set values for libelleNatureClasse
        String code = codeData.substring(RelayConstants.ZERO, RelayConstants.THREE);
        libelleNatureClasse.setCode(code);
        libelleNatureClasse.setLibelle(libelleValueForNatureClasse);

        // set data in lcdv
        lcdv.setLibelleAttribut(libelleAttribut);
        lcdv.setLibelleAttributCom(libelleAttributCom);
        lcdv.setLibelleNatureClasse(libelleNatureClasse);
        lcdv.setClasse(code.substring(RelayConstants.ONE, RelayConstants.THREE));
        lcdv.setNature(natureValue);
        lcdvAttribute.add(lcdv);

    }

    /**
     * POUDG-8742:Method is used to fetch the data from tags in xml format String.
     *
     * @param xml      the xml
     * @param startTag the start tag
     * @param endTag   the end tag
     * @return the string
     */
    private static String extractDataFromXML(String xml, String startTag, String endTag) {

        return xml.substring(xml.indexOf(startTag) + startTag.length(), xml.indexOf(endTag));
    }

    // Cap-28062 start

    /**
     * Validate request body. This method will validate a json file and check if it's values are empty or null.
     *
     * @param requestBody      the request body
     * @param noneRequiredKeys the none required keys
     * @return true, if successful
     */
    public boolean validateRequestBody(JSONObject requestBody, List<String> noneRequiredKeys) {
        JSONArray keys = requestBody.names();
        // list of the values that can invalidate the request body
        ArrayList<String> invalidators = new ArrayList<>(Arrays.asList(StringUtils.EMPTY, "null", null));

        for (int i = 0; i < keys.length(); i++) {
            String key = keys.getString(i);
            String theKeyValue = (requestBody.get(key)).toString().trim();

            if (!(noneRequiredKeys.contains(key)) && invalidators.contains(theKeyValue)) { // the key is required and it's value is in invalidators
                return false;
            }

        }
        return true;
    }

    /**
     * This method will fetch and verify the request from DDC.
     *
     * @param data            the data
     * @param serviceName     the service name
     * @param getLevel3ADAMap the get level 3 ADA map
     * @return the byte array output stream
     */
    public boolean checkRequestFromDDC(String data, String serviceName, Map<Integer, String> getLevel3ADAMap) {
        boolean check = Boolean.FALSE;
        try {

            JSONObject res = new JSONObject(data).getJSONObject(RelayConstants.MESSAGE.toLowerCase());
            if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.ADA_CERTIFICATE)) {
                check = verifyMandatoryFieldDDCReqForADACert(res, getLevel3ADAMap);
            } else if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.ADA_CHALLENGE)) {
                check = verifyMandatoryFieldDDCReqForSignChallenge(res, getLevel3ADAMap);
            } else if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.ADA_TRACK_RESPONSE)) {
                check = verifyMandatoryFieldDDCReqForTrakResponse(res, getLevel3ADAMap);
            } else if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.TBM_HU)) {
                check = verifyMandatoryFieldDDCReqForTBMHU(res, getLevel3ADAMap);
            }
        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception while trying to fetch the requestBody from DDC.", e);
            getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                    BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
            return check;
        }
        return check;
    }

    /**
     * Verify mandatory field DDC req for sign challenge.
     *
     * @param requestBody     the request body
     * @param getLevel3ADAMap the get level 3 ADA map
     * @return true, if successful
     */
    public boolean verifyMandatoryFieldDDCReqForSignChallenge(JSONObject requestBody, Map<Integer, String> getLevel3ADAMap) {
        try {

            boolean mandatoryFieldsCheck = checkIfMandatoryKeyExists(requestBody, mandatoryFieldsToCallSignChallenage);
            boolean requestBodyCheck = validateRequestBody(requestBody, new ArrayList<>(Arrays.asList(StringUtils.EMPTY)));
            if (!mandatoryFieldsCheck || !requestBodyCheck) {
                getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                        BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
                if (logger.isInfoEnabled())
                    logger.info(INVALID_REQUEST);
                return false;
            }
            // take the values here
            requestBodyForSignChallenageFetched.setEcuChallenge(requestBody.getString(RelayConstants.ECU_CHALLENAGE));
            requestBodyForSignChallenageFetched.setSessionID(requestBody.getString(RelayConstants.SESSION_ID));
            return true;
        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception while trying to fetch the request ", e);
            getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                    BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
            return false;
        }
    }

    /**
     * Verify mandatory field DDC req for ADA cert service.
     *
     * @param res             the res
     * @param getLevel3ADAMap the get level 3 ADA map
     * @return true, if successful
     * @throws JSONException the JSON exception
     */
    private boolean verifyMandatoryFieldDDCReqForADACert(JSONObject res, Map<Integer, String> getLevel3ADAMap) {
        String toolID = null;
        // to check if all mandatory fields are exist
        boolean mandatoryFieldsCheck = checkIfMandatoryKeyExists(res, mandatoryFieldsToCallADACert);
        // to check if there is no null or empty string values in the request body, except for the given values
        boolean requestBodyCheck = validateRequestBody(res, new ArrayList<>(Arrays.asList(RelayConstants.DEALER_CODE, RelayConstants.CLAIMED_ROLE)));
        if (!mandatoryFieldsCheck || !requestBodyCheck) {
            getLevel3ADAMap.put(HttpURLConnection.HTTP_BAD_REQUEST, BatteryInfoUtil.addErrorMessage(HttpURLConnection.HTTP_BAD_REQUEST));
            if (logger.isInfoEnabled())
                logger.info(INVALID_REQUEST);
            return false;
        }
        requestBodyForAdaCallFetched.setVIN(res.getString(RelayConstants.VIN.toUpperCase()));
        requestBodyForAdaCallFetched.setSgwSN(res.getString(RelayConstants.SGW_SN));
        requestBodyForAdaCallFetched.setEcuCANID(res.getString(RelayConstants.ECU_CANID));
        requestBodyForAdaCallFetched.setEcuPolicyType(res.getString(RelayConstants.ECU_POLICY_TYPE));
        requestBodyForAdaCallFetched.setEcuCertStoreUUID(res.getString(RelayConstants.ECU_CERT_STORE_UUID));
        requestBodyForAdaCallFetched.setClaimedRole(res.getString(RelayConstants.CLAIMED_ROLE));
        requestBodyForAdaCallFetched.setEcuSN(res.getString(RelayConstants.ECU_SN));
        requestBodyForAdaCallFetched.setDealerCode(res.getString(RelayConstants.DEALER_CODE));
        requestBodyForAdaCallFetched.setUserId(res.getString(RelayConstants.USER_ID));
        requestBodyForAdaCallFetched.setUserToken(res.getString(RelayConstants.USER_TOKEN));
        if (res.getString(RelayConstants.DIAGBOX_MODE).equals(RelayConstants.ONE + StringUtils.EMPTY))
            toolID = RelayConstants.TOOL_ID1;
        if (res.getString(RelayConstants.DIAGBOX_MODE).equals(RelayConstants.TWO + StringUtils.EMPTY))
            toolID = RelayConstants.TOOL_ID2;
        requestBodyForAdaCallFetched.setExternalToolID(toolID);
        return true;
    }

    /**
     * Handling Response from ada service to send to DDC.
     *
     * @param responseFromAda the response from ada
     * @param targetApp       the target app
     * @return the byte array output stream
     */
    public ByteArrayOutputStream responseFromAdaHandler(String responseFromAda, String targetApp) {
        JSONObject res = new JSONObject();
        JSONObject resToSend = new JSONObject();

        try {
            res = new JSONObject(responseFromAda);
            if (responseFromAda.contains(RelayConstants.SUCCESS) && res.getBoolean(RelayConstants.SUCCESS)) {
                setSuccessResponse(targetApp, res, resToSend);
            } else {
                // If error response is received from ADA, then the error code are mapped and changed before being sent to DDC
                setErrorResponse(res, resToSend);
            }
        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception From ADA for the request: ", e);
            resToSend.put("response from ADA", responseFromAda);
        }
        // Preparing the response body to DDC
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] array = resToSend.toString().getBytes();
            out.write(array);
        } catch (IOException e) {
            // CAP-29321
            logger.error("Error found when handling response", e);

        }
        return out;
    }

    /**
     * Sets the error response.
     *
     * @param res       response of Ada
     * @param resToSend response to send DDC
     */
    private void setErrorResponse(JSONObject res, JSONObject resToSend) {
        Integer errorCode;
        errorCode = res.getInt(RelayConstants.ERROR_CODE);
        if (unAuthorizedCodes.contains(errorCode)) {
            errorCode = ErrorCode.ERROR_401_CODE;
            resToSend.put(RelayConstants.ERROR_CODE, errorCode);
            resToSend.put(RelayConstants.ERROR_MESSAGE, ErrorCode.ERROR_401_MSG);
            String msg = RelayConstants.ERROR_CODE_TO_LOG;
            logger.error(msg, errorCode);

        } else if (ErrorCode.ERROR_404_CODE == errorCode) {
            errorCode = ErrorCode.ERROR_404_CODE;
            resToSend.put(RelayConstants.ERROR_CODE, errorCode);
            resToSend.put(RelayConstants.ERROR_MESSAGE, ErrorCode.ERROR_404_MSG);
            String msg = RelayConstants.ERROR_CODE_TO_LOG;
            logger.error(msg, errorCode);

        } else if (badRequestErrorCodes.contains(errorCode)) {
            errorCode = ErrorCode.ERROR_400_CODE;
            resToSend.put(RelayConstants.ERROR_CODE, errorCode);
            resToSend.put(RelayConstants.ERROR_MESSAGE, ErrorCode.ERROR_400_MSG);
            String msg = RelayConstants.ERROR_CODE_TO_LOG;
            logger.error(msg, errorCode);

        } else {
            // In case of unknown error code we send default error code
            errorCode = ErrorCode.ERROR_500_CODE;
            resToSend.put(RelayConstants.ERROR_CODE, errorCode);
            resToSend.put(RelayConstants.ERROR_MESSAGE, ErrorCode.ERROR_500_MSG);
            String msg = RelayConstants.ERROR_CODE_TO_LOG;
            logger.error(msg, errorCode);
        }
    }

    /**
     * Sets the success response.
     *
     * @param targetApp application name
     * @param res       response from ADA
     * @param resToSend response to send to DDC
     */
    private void setSuccessResponse(String targetApp, JSONObject res, JSONObject resToSend) {
        if (targetApp.equals(RelayConstants.ADA_CERTIFICATE)) {
            resToSend.put(RelayConstants.CERTIFICATE, res.getString(RelayConstants.CERTIFICATE));
            resToSend.put(RelayConstants.SESSION_ID, res.getString(RelayConstants.SESSION_ID));
            resToSend.put(RelayConstants.SUCCESS, res.get(RelayConstants.SUCCESS));
        }
        if (targetApp.equals(RelayConstants.ADA_CHALLENGE)) {
            resToSend.put(RelayConstants.ECU_CHALLENGE_RESPONSE, res.getString(RelayConstants.ECU_CHALLENGE_RESPONSE));
            resToSend.put(RelayConstants.SUCCESS, res.get(RelayConstants.SUCCESS));
        }
        if (targetApp.equals(RelayConstants.ADA_TRACK_RESPONSE)) {
            resToSend.put(RelayConstants.SUCCESS, res.get(RelayConstants.SUCCESS));

        }
    }

    /**
     * Check if mandatory key exists.
     *
     * @param json            the json
     * @param mandatoryFields the mandatory fields
     * @return true, if successful
     */
    public boolean checkIfMandatoryKeyExists(JSONObject json, List<String> mandatoryFields) {
        for (String field : mandatoryFields) {
            if (!json.has(field)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Gets the the status code and map it to the correct code.
     *
     * @param httpConnectionGetLevel3ADA the http connection get level 3 ADA
     * @return the the status code
     */
    public int fetchStatusCode(HttpsURLConnection httpConnectionGetLevel3ADA) {
        int statusCode = HttpURLConnection.HTTP_BAD_REQUEST;
        if (httpConnectionGetLevel3ADA != null) {
            try {
                statusCode = httpConnectionGetLevel3ADA.getResponseCode();
                if (unAuthorizedCodes.contains(statusCode)) {
                    statusCode = HttpURLConnection.HTTP_UNAUTHORIZED;
                } else if (internalErrorCodes.contains(statusCode)) {
                    statusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
                }

            } catch (IOException e) {
                logger.error(RelayConstants.ADA_ERROR, e);
            }
        }
        return statusCode;
    }

    /**
     * Fetch response from ADA.
     *
     * @param httpConnectionGetLevel3ADA the http connection get level 3 ADA
     * @return the response from ADA
     */
    public String getSuccessResponseFrom(HttpsURLConnection httpConnectionGetLevel3ADA) {
        StringBuilder res = new StringBuilder();
        try {
            BufferedReader responseMsg = new BufferedReader(new InputStreamReader(httpConnectionGetLevel3ADA.getInputStream()));
            String inputLine;
            while ((inputLine = responseMsg.readLine()) != null) {
                res.append(inputLine);
            }
            responseMsg.close();
        } catch (IOException e) {
            logger.error(RelayConstants.ADA_ERROR, e);
        }
        return res.toString();

    }

    /**
     * Fetch response from ADA.
     *
     * @param httpConnectionGetLevel3ADA the http connection get level 3 ADA
     * @return the response from ADA
     */
    public String getErrorResponseADA(HttpsURLConnection httpConnectionGetLevel3ADA) {
        StringBuilder res = new StringBuilder();
        try {
            BufferedReader responseMsg = new BufferedReader(new InputStreamReader(httpConnectionGetLevel3ADA.getErrorStream()));
            String inputLine;
            while ((inputLine = responseMsg.readLine()) != null) {
                res.append(inputLine);
            }
            responseMsg.close();
        } catch (IOException e) {
            logger.error(RelayConstants.ADA_ERROR, e);
        }
        return res.toString();

    }

    /**
     * Request body writer, write the requestbody in a httpsurlconnection.
     *
     * @param httpConn the http conn
     * @param request  the request
     */
    public void requestBodyWriter(HttpsURLConnection httpConn, String request) {
        OutputStream os = null;
        try {
            os = httpConn.getOutputStream();
            byte[] input = request.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);

        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception while writting request body for the Service.", e);
        } finally {
            try {
                if (null != os)
                    os.close();
            } catch (IOException e) {
                logger.error("Exception while closing output stream.", e);
            }
        }
    }

    /**
     * Gets the the pop token, and return an empty string if there is an exception.
     *
     * @param service the service
     * @return the the pop token
     */
    public String getThePopToken(String service) {
        try {
            return TokenGen.getPopToken(service);

        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception while trying to generate the token: ", e);
        }
        return StringUtils.EMPTY;
    }

    /**
     * Call get level 3 auth diag cert ADA.
     *
     * @param request                  the request
     * @param token                    the token
     * @param getLevel3ADAMap          the get level 3 ADA map
     * @param serviceName              the service name
     * @param relayAccessConfiguration the relay access configuration
     * @return the https URL connection
     * @throws FwkException the fwk exception
     * @throws IOException  Signals that an I/O exception has occurred.
     */
    protected HttpsURLConnection callGetLevel3AuthDiagCertADA(String request, String token, Map<Integer, String> getLevel3ADAMap, String serviceName,
            RelayAccessConfigurationBean relayAccessConfiguration) throws FwkException, IOException {
        RewriteResponseRelayCommunicationService rewriteResponse = new RewriteResponseRelayCommunicationService();
        HttpsURLConnection httpConn = null;
        try {
            String url = prepareUrlForGetLevel3ADA(serviceName, relayAccessConfiguration);
            ADAServiceConfig config = TokenGen.readConfigFromFileForADA(url);
            System.setProperty(RelayConstants.HTTP_CIPHER_SUITE, config.getForcedCipherSuit());
            httpConn = BatteryInfoUtil.createHttpConnWithProxyAndTLS(url, relayAccessConfiguration.getApplicationName());
            httpConn.setReadTimeout(RelayConstants.READ_TIMEOUT);
            httpConn.setRequestMethod(RelayConstants.POST_METHOD);
            httpConn.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.APPLICATION_JSON);
            httpConn.setRequestProperty(RelayConstants.ACCEPT, RelayConstants.APPLICATION_JSON);
            httpConn.setRequestProperty(RelayConstants.AUTHORIZATION, RelayConstants.POP + token);
            httpConn.setDoOutput(true);
            rewriteResponse.requestBodyWriter(httpConn, request);
            httpConn.connect();
            getLevel3ADAMap.put(httpConn.getResponseCode(), BatteryInfoUtil.addErrorMessage(httpConn.getResponseCode()));
        } catch (Exception e) {
            // CAP-29321
            logger.error("Exception while calling GetLevel3AuthDiagCet from URl: ", e);
        }
        return httpConn;
    }

    /**
     * Prepare url for get level 3 ADA.
     *
     * @param serviceName              the service name
     * @param relayAccessConfiguration the relay access configuration
     * @return the string
     */
    private String prepareUrlForGetLevel3ADA(String serviceName, RelayAccessConfigurationBean relayAccessConfiguration) {
        String url = StringUtils.EMPTY;
        if (null != relayAccessConfiguration && null != relayAccessConfiguration.getUrl()) {
            url = relayAccessConfiguration.getUrl();
            url = url.replace(RelayConstants.DOT_ZERO, StringUtils.EMPTY);
        }
        if (RelayConstants.ADA_CERTIFICATE.equalsIgnoreCase(serviceName)) {
            url = url + RelayConstants.ADA_LEVEL3_CERT;
        } else if (RelayConstants.ADA_CHALLENGE.equalsIgnoreCase(serviceName)) {
            url = url + RelayConstants.ADA_LEVEL3_CHALLENGE;
        } else if (RelayConstants.ADA_TRACK_RESPONSE.equalsIgnoreCase(serviceName)) {
            url = url + RelayConstants.ADA_LEVEL3_TRACK_RESPONSE;
        }
        if (logger.isInfoEnabled())
            logger.info("ADA Url created for service {} is: {}", serviceName, url);
        return url;
    }

    /**
     * Adds the headers and status code.
     *
     * @param httpConnectionGetLevel3ADA the http connection get level 3 ADA
     * @param responseHeaders            the response headers
     * @throws FwkException the fwk exception
     */
    protected void addHeadersAndStatusCode(HttpsURLConnection httpConnectionGetLevel3ADA, Map<String, String> responseHeaders) throws FwkException {
        RewriteResponseRelayCommunicationService rewriteResponse = new RewriteResponseRelayCommunicationService();
        if (httpConnectionGetLevel3ADA != null) {
            extractResponseHeader(httpConnectionGetLevel3ADA, responseHeaders);
            setOutput(STATUS_CODE, rewriteResponse.fetchStatusCode(httpConnectionGetLevel3ADA));
            setOutput(OUT_HEADERS, responseHeaders);
        }
    }

    /**
     * Verify mandatory field DDC req for trak response.
     *
     * @param requestBody     the request body
     * @param getLevel3ADAMap the get level 3 ADA map
     * @return true, if successful
     */
    public boolean verifyMandatoryFieldDDCReqForTrakResponse(JSONObject requestBody, Map<Integer, String> getLevel3ADAMap) {
        try {

            boolean mandatoryFieldsCheck = checkIfMandatoryKeyExists(requestBody, mandatoryFieldsToCallTrakResponse);
            boolean requestBodyCheck = validateRequestBody(requestBody, new ArrayList<>(Arrays.asList(StringUtils.EMPTY)));
            if (!mandatoryFieldsCheck || !requestBodyCheck) {
                getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                        BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
                if (logger.isInfoEnabled())
                    logger.info(INVALID_REQUEST);
                return false;
            }
            // take the values here
            requestBodyForTrakResponseCall.setSessionID(requestBody.getString(RelayConstants.SESSION_ID));
            requestBodyForTrakResponseCall.setEcuResponse(requestBody.getString(RelayConstants.ECU_RESPONSE));
            requestBodyForTrakResponseCall.setEcuResult(requestBody.getBoolean(RelayConstants.ECU_RESULT));
            requestBodyForTrakResponseCall.setUserToken(AbstractRelayCommunicationService.getTokenDdcForSetTrackADA());
            return true;
        } catch (Exception e) {
            getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                    BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
            // CAP-29321
            logger.error(RelayConstants.REQUEST_FETCH_EXCEPTION, e);
            return false;
        }
    }
    // CAP-28062 end

    /**
     * Verify mandatory field DDC req for TBMHU.
     *
     * @param requestBody     the request body
     * @param getLevel3ADAMap the get level 3 ADA map
     * @return true, if successful
     */
    // poudg 8769
    public boolean verifyMandatoryFieldDDCReqForTBMHU(JSONObject requestBody, Map<Integer, String> getLevel3ADAMap) {
        try {
            boolean mandatoryFieldsCheck = checkIfMandatoryKeyExists(requestBody, mandatoryFieldsToCallTBMHU);
            boolean requestBodyCheck = validateRequestBody(requestBody, notMandatoryFieldsToCallTBMHU);
            if (!mandatoryFieldsCheck || !requestBodyCheck) {
                getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                        BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
                return false;
            }
            // take the values here

            requestBodyForTbmhuCall.setFirmwareVersion(
                    requestBody.optString(RelayConstants.FW_VERSION_SW_NUMBER) + requestBody.optString(RelayConstants.FW_VERSION_SW_VERSION));
            requestBodyForTbmhuCall.setEcu(requestBody.getString(RelayConstants.ECU));
            requestBodyForTbmhuCall.setVin(requestBody.getString(RelayConstants.VIN));
            requestBodyForTbmhuCall.setSerialNumber(requestBody.getString(RelayConstants.SERIAL_NUMBER));
            requestBodyForTbmhuCall.setSwComponentIdHwNumber(requestBody.optString(RelayConstants.SW_COMPONENT_ID_HW_NUMBER));
            requestBodyForTbmhuCall.setSwComponentIdHwVersion(requestBody.optString(RelayConstants.SW_COMPONENT_ID_HW_VERSION));
            requestBodyForTbmhuCall.setFwVersionSwNumber(requestBody.optString(RelayConstants.FW_VERSION_SW_NUMBER));
            requestBodyForTbmhuCall.setFwVersionSwVersion(requestBody.optString(RelayConstants.FW_VERSION_SW_VERSION));
            requestBodyForTbmhuCall.setModemDataImei(requestBody.optString(RelayConstants.MODEM_DATA_LMEI));
            requestBodyForTbmhuCall.setSimIdentifierIccid(requestBody.optString(RelayConstants.SIM_IDENTIFIER_ICCID));
            requestBodyForTbmhuCall.setInternationalMobileSubscriberIdentityImsi(
                    requestBody.optString(RelayConstants.INTERNATIONAL_MOBILE_SUBSCRIBER_IDENTITY_IMSI));
            requestBodyForTbmhuCall.setMobileSubscriberIsdnMsisdn(requestBody.get(RelayConstants.MOBILE_SUBSCRIBER_ISDN_MSISDN).toString());
            requestBodyForTbmhuCall.setYear(requestBody.getString(RelayConstants.YEAR_VEHICLE));
            requestBodyForTbmhuCall.setBody(requestBody.getString(RelayConstants.BODY_VEHICLE));
            requestBodyForTbmhuCall.setVciSN(RelayConstants.TBMHU_PREFIX + requestBody.getString(RelayConstants.VCISN));
            requestBodyForTbmhuCall.setUserId(RelayConstants.TBMHU_PREFIX + requestBody.optString(RelayConstants.USER_I));
            requestBodyForTbmhuCall.setDealerCode(RelayConstants.TBMHU_PREFIX + requestBody.optString(RelayConstants.DEALER_C));
            return true;
        } catch (Exception e) {
            // CAP-29321
            logger.error(RelayConstants.REQUEST_FETCH_EXCEPTION, e);
            getLevel3ADAMap.put(java.net.HttpURLConnection.HTTP_BAD_REQUEST,
                    BatteryInfoUtil.addErrorMessage(java.net.HttpURLConnection.HTTP_BAD_REQUEST));
            return false;
        }
    }

    /**
     * Gets the response from TBMHU.
     *
     * @param encodedResponse the encoded response
     * @return the response from TBMHU
     */
    public Map<String, Object> getResponseFromTBMHU(String encodedResponse) {
        try {
            String[] splitString = encodedResponse.split("\\.");
            String base64DecodedBody = base64Decoder(splitString[1]);
            JSONObject data = new JSONObject(base64DecodedBody);
            return responseAndResponseCodeMapper(base64Decoder(data.getString(RelayConstants.DATA)), data.getString(RelayConstants.DATA),
                    base64Decoder(splitString[0]) + "\n" + base64DecodedBody);
        } catch (Exception e) {
            // CAP-29321
            logger.error("Error found while decodeding the response received from TBMHU witexedi", e);
        }
        return new HashMap<>();
    }

    /**
     * Base 64 decoder.
     *
     * @param stringToDecode the string to decode
     * @return the string
     */
    public String base64Decoder(String stringToDecode) {
        Base64 base64Url = new Base64(true);
        return new String(base64Url.decode(stringToDecode), StandardCharsets.UTF_8);
    }

    /**
     * Xml to json.
     *
     * @param toConvert the to convert
     * @return the JSON object
     */
    public JSONObject xmlToJson(String toConvert) {
        return XML.toJSONObject(toConvert);
    }

    /**
     * Response and response code mapper.
     *
     * @param xmlResponse       the xml response
     * @param dataEncoded       the data encoded
     * @param completResDecoded the complet res decoded
     * @return the map
     */
    public Map<String, Object> responseAndResponseCodeMapper(String xmlResponse, String dataEncoded, String completResDecoded) {
        try {
            Map<String, Object> responseAndResponseCode = new HashMap<>();
            JSONObject xmlResToJson = xmlToJson(xmlResponse).getJSONObject(RelayConstants.RESULT);
            JSONObject errorCodeAndDescription = new JSONObject();
            if (xmlResToJson.has(RelayConstants.SUCCESS)) {
                if (!xmlResToJson.getBoolean(RelayConstants.SUCCESS)) {
                    // sending a bad request with 400
                    errorCodeAndDescription.put(RelayConstants.ERROR_CODE, ErrorCode.ERROR_400_CODE);
                    errorCodeAndDescription.put(RelayConstants.ERROR_DESC, xmlResToJson.getString(RelayConstants.ERROR));
                    responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(errorCodeAndDescription));
                    responseAndResponseCode.put(RelayConstants.RESPONSE_CODE, ErrorCode.ERROR_400_CODE);
                    responseAndResponseCode.put(RelayConstants.CODE_RECEIVED_BEFORE_MAPPING, "{No error code received in responseBody}");
                }
                // could it be equal to true ?
            } else if (xmlResToJson.has(RelayConstants.REQUEST_MESSAGE)) {
                String message = xmlResToJson.getString(RelayConstants.REQUEST_MESSAGE);
                if (message.equalsIgnoreCase(RelayConstants.SUCCESS)) {
                    // sending a good res with 200
                    responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(new JSONObject(RelayConstants.SUCCESS_TBMHU)));
                    responseAndResponseCode.put(RelayConstants.RESPONSE_CODE, ErrorCode.ERROR_200_CODE);
                } else if (message.equalsIgnoreCase(RelayConstants.FAILURE)) {
                    // sending a bad res with mapped code
                    errorCodeAndDescription = new JSONObject();
                    Integer errorCode = tbmhuErrorCodeMapper(xmlResToJson.getInt(RelayConstants.FAILURE_REASON_CODE));
                    errorCodeAndDescription.put(RelayConstants.ERROR_CODE, errorCode);
                    errorCodeAndDescription.put(RelayConstants.ERROR_DESC, xmlResToJson.getString(RelayConstants.FAILURE_REASON));
                    responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(errorCodeAndDescription));
                    responseAndResponseCode.put(RelayConstants.RESPONSE_CODE, errorCode);
                    responseAndResponseCode.put(RelayConstants.CODE_RECEIVED_BEFORE_MAPPING, xmlResToJson.getInt(RelayConstants.FAILURE_REASON_CODE));
                }
            } else {
                // This should not be reached based on the requirements, but if it's the case, then it's a bad response format
                responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(new JSONObject("Bad response format received from Witexedi.")));
                responseAndResponseCode.put(RelayConstants.RESPONSE_CODE, ErrorCode.ERROR_400_CODE);
            }
            responseAndResponseCode.put(RelayConstants.DATA_ENCODED, dataEncoded);
            responseAndResponseCode.put(RelayConstants.DATA_XML, xmlResponse);
            responseAndResponseCode.put(RelayConstants.DATA_TO_JSON, xmlResToJson);
            responseAndResponseCode.put(RelayConstants.COMPLET_RES_DECODED, completResDecoded);
            // Are they gonna send us 500, 400, 401 or not ?
            return responseAndResponseCode;
        } catch (Exception e) {
            // CAP-29321
            logger.error("Error found while mapping response and response code TBMHU witexedi", e);
        }
        return new HashMap<>();
    }

    /**
     * Tbmhu error code mapper.
     *
     * @param errorCode the error code
     * @return the integer
     */
    private Integer tbmhuErrorCodeMapper(int errorCode) {
        Integer errorMessage = ErrorCode.ERROR_400_CODE;
        if (errorCode == ErrorCode.ERROR_4001_CODE || errorCode == ErrorCode.ERROR_4005_CODE) {
            errorMessage = ErrorCode.ERROR_400_CODE;
        } else if (errorCode == ErrorCode.ERROR_4004_CODE || errorCode == ErrorCode.ERROR_4006_CODE || errorCode == ErrorCode.ERROR_4010_CODE) {
            errorMessage = ErrorCode.ERROR_404_CODE;
        } else if (errorCode >= ErrorCode.ERROR_5000_CODE && errorCode <= ErrorCode.ERROR_5999_CODE) {
            errorMessage = ErrorCode.ERROR_500_CODE;
        }
        return errorMessage;
    }

    /**
     * To output stream.
     *
     * @param value the value
     * @return the byte array output stream
     */
    public ByteArrayOutputStream toOutputStream(Object value) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] array = value.toString().getBytes();
            out.write(array);
        } catch (IOException e) {
            // CAP-29321
            logger.error("Error found while converting object to ByteOutputStream", e);
        }
        return out;
    }

    /**
     * Call TBMHU.
     *
     * @param requestBody              the request body
     * @param relayAccessConfiguration the relay access configuration
     * @return the https URL connection
     */
    public HttpsURLConnection callTBMHU(String requestBody, RelayAccessConfigurationBean relayAccessConfiguration) {
        HttpsURLConnection conn = null;
        String url = relayAccessConfiguration.getUrl();
        try {
            if (null != url) {
                ADAServiceConfig config = TokenGen.readConfigFromFileForADA(RelayConstants.TBM_HU);
                url = url.substring(0, url.length() - RelayConstants.THREE);
                conn = BatteryInfoUtil.createHttpConnWithProxyAndTLS(url, relayAccessConfiguration.getApplicationName());
                String userpass = config.getTbmhuUn() + ":" + config.getTbmhuPw();
                String basicAuth = RelayConstants.BASIC + new String(Base64.encodeBase64(userpass.getBytes()));
                conn.setRequestProperty(RelayConstants.AUTHORIZATION, basicAuth);
                conn.setDoOutput(true);
                conn.setRequestProperty(RelayConstants.CHARSET, StringUtils.EMPTY + StandardCharsets.UTF_8);
                conn.setRequestMethod(RelayConstants.POST_METHOD);
                conn.setRequestProperty(RelayConstants.CONTENT_LENGTH, StringUtils.EMPTY + requestBody.getBytes().length);
                conn.setRequestProperty(RelayConstants.X_APP_REGION, RelayConstants.REGION);
                conn.setRequestProperty(RelayConstants.X_APP_SOURCE, RelayConstants.SERVICE_INVORKER);
                conn.setRequestProperty(RelayConstants.ACCEPT, RelayConstants.TEXT_PLAIN);
                requestBodyWriter(conn, requestBody);
                conn.connect();
                return conn;
            }
        } catch (Exception e) {
            // CAP-29321
            logger.error("Error found while calling TBMHU witexedi", e);
        }
        return conn;
    }

    /**
     * Verify tbmhu signature.
     *
     * @param token the token
     * @return true, if successful
     */
    public boolean verifyTbmhuSignature(String token) {
        try {
            String[] splitString = token.split("\\.");
            String payload = splitString[0] + "." + splitString[1];
            String signature = splitString[2];
            // loading config file
            AbstractFileConfiguration config = new PropertiesConfiguration();
            config.setDelimiterParsingDisabled(true);
            config.load(Thread.currentThread().getContextClassLoader().getResource(RelayConstants.ADA_CONFIG_FILE));

            // Checking preprod and first 2 keys for prod
            if (verifySignature(payload, signature, config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY1))
                    || verifySignature(payload, signature, config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY2))) {
                return true;
            }
            // It comes here only when it's prod and the 2 keys are not the correct one, or when the preprod public keys are not correct.
            if ((!config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY3).endsWith(StringUtils.EMPTY)
                    && !config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY4).endsWith(StringUtils.EMPTY))
                    && (verifySignature(payload, signature, config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY3))
                            || verifySignature(payload, signature, config.getString(RelayConstants.DSS_TBMHU_PUBLICKEY4)))) {

                return true;
            }
        } catch (Exception e) {
            // CAP-29321
            logger.error("Error found while trying to verify the signatrue of the token comming from TBMHU witexedi", e);
        }
        return false;
    }

    /**
     * Verify signature.
     *
     * @param payload   the payload
     * @param signature the signature
     * @param pubK      the pub K
     * @return true, if successful
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeyException      the invalid key exception
     * @throws InvalidKeySpecException  the invalid key spec exception
     * @throws IOException              Signals that an I/O exception has occurred.
     * @throws SignatureException       the signature exception
     */
    private boolean verifySignature(String payload, String signature, String pubK)
            throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, IOException, SignatureException {
        Signature sig = Signature.getInstance(RelayConstants.SHA256WITHRSA);
        sig.initVerify(keyGen(pubK));
        sig.update(payload.getBytes());
        return sig.verify(Base64.decodeBase64(signature));
    }

    /**
     * Key gen.
     *
     * @param publicK the public K
     * @return the public key
     * @throws NoSuchAlgorithmException the no such algorithm exception
     * @throws InvalidKeySpecException  the invalid key spec exception
     * @throws IOException              Signals that an I/O exception has occurred.
     */
    private PublicKey keyGen(String publicK) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        InputStream inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(publicK);
        String pubKeyPEM = IOUtils.toString(inStream, StandardCharsets.UTF_8.name()).replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "").replace("\n", StringUtils.EMPTY).replace("\r", StringUtils.EMPTY);
        byte[] encodedPublicKey = Base64.decodeBase64(pubKeyPEM);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(encodedPublicKey);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#fetchDataForAPICApplications(java.lang.String)
     */
    @Override
    public Map<Integer, String> fetchDataForAPICApplications(String requestDDC) {
        HttpsURLConnection httpConnArgos;
        Map<Integer, String> applStatusMap = new HashMap<>();
        Map<String, String> responseHeaders = new HashMap<>();
        try {
            if (ARGOS.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                // CAP-27774: call to generate Access token via OAuth 2.0. Below code will be removed once the JDK is upgraded to 1.8
                BatteryInfoUtil info = new BatteryInfoUtil();
                String response = StringUtils.EMPTY; // Sonar issue Fix
                int statusCodeArgos = HttpURLConnection.HTTP_BAD_REQUEST;
                httpConnArgos = info.getBatteryInfoAccessToken(requestDDC, applStatusMap);
                for (Map.Entry<Integer, String> entry : applStatusMap.entrySet()) {
                    statusCodeArgos = entry.getKey();
                    response = entry.getValue();
                }
                extractAndSetResponse(httpConnArgos, responseHeaders, requestDDC, response, statusCodeArgos);
                // CAP-27774: call to generate Access token via OAuth 2.0. Above code will be removed once the JDK is upgraded to 1.8
            }
            // CAP-28062 to check if the target is ada_certificate, then we modify the body accordingly

            if (RelayConstants.ADA.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                String serviceName = (String) this.getInput(IN_SERVICE_NAME);
                if (logger.isInfoEnabled())
                    logger.info("ADA Service called: {}", serviceName);
                HttpsURLConnection httpConnectionGetLevel3ADA = null;
                int statusCode = HttpURLConnection.HTTP_BAD_REQUEST;
                String response = StringUtils.EMPTY;
                tokenDdcForSetTrackADA = (String) this.getInput(RelayConstants.DSS3_TOKEN);
                if (StringUtils.isNotBlank(requestDDC) && checkRequestFromDDC(requestDDC, serviceName, applStatusMap)) {
                    // if the request from DDC is OK, we call ADA
                    String popToken = getThePopToken(serviceName);
                    if (logger.isInfoEnabled())
                        logger.info("<<< PoP token generated: {}", popToken);
                    String requestDdcFetched = new String(TokenGen.getRequestBodyAfterTokenGeneration().toByteArray(), StandardCharsets.UTF_8);
                    httpConnectionGetLevel3ADA = callGetLevel3AuthDiagCertADA(requestDdcFetched, popToken, applStatusMap, serviceName,
                            relayAccessConfiguration);
                    response = extractResponseFromADA(applStatusMap, httpConnectionGetLevel3ADA);
                    if (logger.isInfoEnabled())
                        logger.info("<<< Response coming from AdA: {}", response);
                }
                for (Map.Entry<Integer, String> entry : applStatusMap.entrySet()) {
                    statusCode = entry.getKey();
                    response = entry.getValue();
                }
                response = responseFromAdaHandler(response, serviceName).toString();
                if (logger.isInfoEnabled())
                    logger.info("<<< Response Sent to DDC: {}", response);
                extractAndSetResponse(httpConnectionGetLevel3ADA, responseHeaders, requestDDC, response, statusCode);
            }
            // Cap 28062 end
            // Begin Cap-28735 x250 lot2 Witexedi
            if (RelayConstants.TBM_HU.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                String serviceName = RelayConstants.TBM_HU;
                if (logger.isInfoEnabled())
                    logger.info("TBMHU witexedi Service called: {}", RelayConstants.SET_TRACALBILITY);
                Map<String, Object> responseAndResponseCode = new HashMap<>();
                responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(RelayConstants.BAD_REQUEST));
                responseAndResponseCode.put(RelayConstants.RESPONSE_CODE, java.net.HttpURLConnection.HTTP_BAD_REQUEST);
                if (StringUtils.isNotBlank(requestDDC) && checkRequestFromDDC(requestDDC, serviceName, applStatusMap)) {
                    extractResponseFromWitexedi(responseHeaders, serviceName, responseAndResponseCode);
                } else {
                    responseAndResponseCode.put(RelayConstants.RESPONSE, toOutputStream(RelayConstants.BAD_REQUEST_MESSAGE_TBMHU));
                    sendResFromTbmhuToDDC(responseHeaders, responseAndResponseCode);
                }
            }
        } catch (IOException | FwkException e) {
            // CAP-29321
            logger.error("Error while processing response from [{}]  application. ", relayAccessConfiguration.getApplicationName(), e);
        }
        return applStatusMap;
    }

    /**
     * Extract response from ADA.
     *
     * @param applStatusMap              the appl status map
     * @param httpConnectionGetLevel3ADA the http connection get level 3 ADA
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private String extractResponseFromADA(Map<Integer, String> applStatusMap, HttpsURLConnection httpConnectionGetLevel3ADA) throws IOException {
        String response;
        if (java.net.HttpURLConnection.HTTP_OK == httpConnectionGetLevel3ADA.getResponseCode()) {
            response = getSuccessResponseFrom(httpConnectionGetLevel3ADA);
            applStatusMap.clear();
            applStatusMap.put(httpConnectionGetLevel3ADA.getResponseCode(), response);
        } else {
            response = getErrorResponseADA(httpConnectionGetLevel3ADA);
        }
        return response;
    }

    /**
     * Extract response from witexedi.
     *
     * @param responseHeaders         the response headers
     * @param serviceName             the service name
     * @param responseAndResponseCode the response and response code
     * @throws IOException  Signals that an I/O exception has occurred.
     * @throws FwkException the fwk exception
     */
    private void extractResponseFromWitexedi(Map<String, String> responseHeaders, String serviceName, Map<String, Object> responseAndResponseCode)
            throws IOException, FwkException {
        String encodedRes;
        String popToken = getThePopToken(serviceName);
        String requestBodyAfterTokenGeneration = new String(TokenGen.getRequestBodyAfterTokenGeneration().toByteArray(), StandardCharsets.UTF_8);
        if (logger.isInfoEnabled())
            logger.info("<<< RequestBody after PoP token generation: {}", popToken);
        HttpsURLConnection httpsConnectionTbmhu = callTBMHU(popToken, relayAccessConfiguration);
        encodedRes = getSuccessResponseFrom(httpsConnectionTbmhu);
        if (logger.isInfoEnabled())
            logger.info("<<< Response coming from TBMHU encoded: {}", encodedRes);
        if (StringUtils.isNotBlank(encodedRes) && verifyTbmhuSignature(encodedRes)) {
            if (logger.isInfoEnabled())
                logger.info("<<< Signatrue verification done successfully for response comming from TBMHU witexedi.");
            responseAndResponseCode = getResponseFromTBMHU(encodedRes);
            setResAndHeadersForTbmhu(httpsConnectionTbmhu, responseHeaders, responseAndResponseCode, encodedRes, requestBodyAfterTokenGeneration,
                    popToken);
        } else {
            if (logger.isInfoEnabled())
                logger.info("<<< Signatrue verification for response comming from TBMHU witexedi failed.");
            sendResFromTbmhuToDDC(responseHeaders, responseAndResponseCode);
        }
    }

    /**
     * Sets the res and headers for tbmhu.
     *
     * @param httpConn           the http conn
     * @param responseHeaders    the response headers
     * @param responseAndResCode the response and res code
     * @param encodedRes         the encoded res
     * @param requestBody        the request body
     * @param popToken           the pop token
     */
    private void setResAndHeadersForTbmhu(HttpsURLConnection httpConn, Map<String, String> responseHeaders, Map<String, Object> responseAndResCode,
            String encodedRes, String requestBody, String popToken) {
        try {

            if (httpConn != null) {
                Integer responseCodeMapped = (Integer) responseAndResCode.get(RelayConstants.RESPONSE_CODE);
                String preMsg = "[" + this.relayAccessConfiguration.getApplicationName() + "] a  renvoye un code http [" + responseCodeMapped
                        + "]  lors de l'execution du relais vers  [" + this.targetApplicationUrl + "]";
                extractResponseHeader(httpConn, responseHeaders);
                String msg = StringUtils.EMPTY;
                if (httpConn.getResponseCode() == HttpStatus.SC_OK && responseCodeMapped != HttpStatus.SC_OK
                        || httpConn.getResponseCode() != HttpStatus.SC_OK && responseCodeMapped != HttpStatus.SC_OK) {

                    msg = preMsg + " [ le code recu de la connexion est : " + httpConn.getResponseCode()
                            + "] \n  [ Et le code d'erreur recu dans le responseBody est : " + responseAndResCode.get("codeReceivedBeforeMapping")
                            + " ]" + " [Et le code d'erruer recu dans le responseBody mais mappe est pour l'envoyer a DDC:  "
                            + responseAndResCode.get("responseCode") + " ]";
                } else if (httpConn.getResponseCode() == HttpStatus.SC_OK && responseCodeMapped == HttpStatus.SC_OK) {
                    msg = preMsg;
                }
                if (logger.isInfoEnabled()) {
                    logger.info(msg);
                    logger.info("RequestBody after token generation: {}", requestBody);
                    logger.info("Request popToken: {}", popToken);
                    logger.info("Response encoded: {}", encodedRes);
                    logger.info("Response decoded to base 64 : {}", responseAndResCode.get(RelayConstants.COMPLET_RES_DECODED));
                    logger.info("Response data encoded : {}", responseAndResCode.get(RelayConstants.DATA_ENCODED));
                    logger.info("Response data decoded : {}", responseAndResCode.get(RelayConstants.DATA_XML));
                    logger.info("Response data from XML to Json: {}", responseAndResCode.get(RelayConstants.DATA_TO_JSON));
                }

            }
            sendResFromTbmhuToDDC(responseHeaders, responseAndResCode);

        } catch (Exception e) {
            // CAP-29321
            logger.error("Error found while processing response from TBMHU witexedi", e);
        }

    }

    /**
     * Send res from tbmhu to DDC.
     *
     * @param responseHeaders    the response headers
     * @param responseAndResCode the response and res code
     * @throws FwkException the fwk exception
     */
    private void sendResFromTbmhuToDDC(Map<String, String> responseHeaders, Map<String, Object> responseAndResCode) throws FwkException {
        setOutput(OUT_HEADERS, responseHeaders);
        setOutput(STATUS_CODE, responseAndResCode.get("responseCode"));
        setOutput(RESPONSE_FROM_TARGET, responseAndResCode.get("response"));
    }

    /**
     * Adds the request and auth header for corvet.
     *
     * @param authHeader                 the auth header
     * @param hostname                   the hostname
     * @param authHeaderValue            the auth header value
     * @param lowerCased                 the lower cased
     * @param serverConfigurationManager the server configuration manager
     * @param methodRequest              the method request
     * @param headerEntry                the header entry
     * @throws FwkException the fwk exception
     */
    @Override
    public void addRequestAndAuthHeaderForCorvet(String authHeader, String hostname, StringBuilder authHeaderValue, String lowerCased,
            ServerConfigurationManager serverConfigurationManager, HttpMethod methodRequest, Entry<String, String> headerEntry) throws FwkException {
        // START : POUDG-9062 Adding authHeader for CORVET APIC URL for diagbox & diagcloud
        if (relayAccessConfiguration.getApplicationName().equals(AbstractRelayCommunicationService.CORVET)
                && this.getInput(RelayConstants.DSS3_HOSTNAME).toString().contains(hostname) && lowerCased.equals(authHeader)) {
            AuthenticationBean corvet = serverConfigurationManager.getCorvetAccount();
            authHeaderValue.append(BASIC).append(" ")
                    .append(new String(Base64.encodeBase64(
                            new StringBuilder().append(corvet.getLogin()).append(":").append(corvet.getPassword()).toString().getBytes())))
                    .toString();
            methodRequest.setRequestHeader(authHeader, authHeaderValue.toString());
        } /* POUDG-9062 Adding content-type for CORVET APIC URL */
        else if (relayAccessConfiguration.getApplicationName().equals(CORVET) && lowerCased.equalsIgnoreCase(RelayConstants.CONTENT_TYPE)) {
            methodRequest.setRequestHeader(headerEntry.getKey(), "application/xml");
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @throws FwkException
     * @see com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService#buildRequestForRegistration()
     */
    @Override
    public String buildRequestForRegistration() throws FwkException {
        String requestBody = StringUtils.EMPTY;
        String serviceName = (String) this.getInput(IN_SERVICE_NAME);

        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            GigyaToken decryptedGigyaToken = (GigyaToken) this.getInput(RelayConstants.GIGYA_DECRYPTED_TOKEN);
            String uId = LdapCommons.auditSearch(decryptedGigyaToken);
            requestBodyForLdapOi.setUserName2(uId);
            if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.REGISTRATION)) {
                requestBodyForLdapOi.setPassword(decryptedGigyaToken.getGigyaTokenPayload().getData().getParams().getPassword());
                requestBody = ow.writeValueAsString(requestBodyForLdapOi);
            } else if (StringUtils.isNotBlank(serviceName) && serviceName.equalsIgnoreCase(RelayConstants.RESET_PASSWORD)) {
                requestBodyForLdapOi.setPassword(decryptedGigyaToken.getGigyaTokenPayload().getData().getParams().getNewPassword());
                requestBody = ow.writeValueAsString(requestBodyForLdapOi);
            }
            if (logger.isInfoEnabled())
                logger.info("Request Body for {} : {}", serviceName, requestBody);
        } catch (Exception e) {
            logger.error("Exception while building the request body: ", e);
        }
        return requestBody;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#fetchDataForApicLDAPOI(java.lang.String)
     */
    @Override
    public Map<Integer, String> fetchDataForApicLDAPOI(String request) throws IOException {
        HttpsURLConnection httpConn = null;
        String response = StringUtils.EMPTY;
        Map<Integer, String> statusMap = new HashMap<>();
        Map<String, String> responseHeaders = new HashMap<>();
        try {
            httpConn = buildConnectionForLdapOI(request);
            BasicRelayCommunicationService.extractResponseFromPortfolio(statusMap, httpConn, relayAccessConfiguration.getApplicationName());
            int statusCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
            for (Map.Entry<Integer, String> entry : statusMap.entrySet()) {
                statusCode = entry.getKey();
                response = entry.getValue();
            }
            if ((response != null) && (StringUtils.isNotBlank(response))) {
                extractAndSetResponse(httpConn, responseHeaders, request, response, statusCode);
            }

        } catch (Exception e) {
            logger.error("Error while processing response from {} application.", relayAccessConfiguration.getApplicationName(), e);
        } finally {
            if (null != httpConn)
                httpConn.disconnect();
        }
        return statusMap;
    }

    /**
     * Builds the connection for ldap OI.
     *
     * @param request the request
     * @return the https URL connection
     */
    private HttpsURLConnection buildConnectionForLdapOI(String request) {
        HttpsURLConnection httpConnection = null;
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        try {
            httpConnection = BatteryInfoUtil.createHttpConnWithProxyAndTLS(targetApplicationUrl, relayAccessConfiguration.getApplicationName());
            ValidHttpMethod httpMethod = ValidHttpMethod.valueOf(StringUtils.upperCase(this.getInputParameterValue(IN_HTTP_METHOD)));
            httpConnection.setRequestProperty(RelayConstants.AUTHORIZATION, RelayConstants.BEARER + LdapCommons.getOAuthTokenForLdapOi());
            httpConnection.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.APPLICATION_JSON);
            httpConnection.setRequestProperty(RelayConstants.ACCEPT, RelayConstants.APPLICATION_JSON);
            httpConnection.setRequestProperty(RelayConstants.CLIENT_ID_PORTFOLIO_LABEL_KEY,
                    serverConfigurationManager.getVariableValue(RelayConstants.CLIENT_ID_LDAP_OI));
            if (RelayConstants.POST_METHOD.equals(httpMethod.toString())) {
                httpConnection.setDoOutput(true);
                requestBodyWriter(httpConnection, request);
            }
            httpConnection.connect();
        } catch (Exception e) {
            logger.error("Exception while calling LDAPOI via URl: ", e);
        }
        return httpConnection;
    }

}
