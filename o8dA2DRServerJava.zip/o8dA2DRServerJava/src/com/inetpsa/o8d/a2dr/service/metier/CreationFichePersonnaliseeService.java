package com.inetpsa.o8d.a2dr.service.metier;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.MethodUtils;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.a2dr.service.metier.cards.ApplicationCardFactory;
import com.inetpsa.o8d.a2dr.service.metier.cards.UserData;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * Service de cr�ation de la fiche personnalis�e.
 * 
 * @author e358045
 */
public class CreationFichePersonnaliseeService extends AbstractA2DRBusinessService {

    /** nom du service */
    public static final String SERVICE_NAME = "creation_fiche_personalisee";

    /** utilisateur qui s'est authentifier */
    public static final String IN_UTILISATEUR = "IN_UTILISATEUR";

    /** role de l'application appelante */
    public static final String IN_APPLICATION_ROLE = "IN_APPLICATION_ROLE";

    /** fiche personalisee */
    public static final String OUT_FICHE_PERSONALISEE = "OUT_FICHE_PERSONALISEE";
    /**
     * Pr�fixe message d'erreur.
     */
    private static final String ERROR_MSG_PREFIX = "CreationFichePersonnaliseeService Exception => name:";
    /**
     * Suffixe message d'erreur.
     */
    private static final String ERROR_MSG_SUFFIX = ", method:";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme.
     */
    public CreationFichePersonnaliseeService() throws FwkException {
        super();
    }

    /**
     * Traitement metier
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        String applicationRole = (String) this.getInput(IN_APPLICATION_ROLE);
        if (applicationRole == null || applicationRole.length() == 0) {
            logger.error("CreationFichePersonnaliseeService : l'attribut 'role' est vide !!!");
            this.setOutput(OUT_FICHE_PERSONALISEE, null);
            return;
        }

        logger.info("CreationFichePersonnaliseeService - applicationRole:'{}'", applicationRole);

        List<UserData> userDatas = ApplicationCardFactory.getInstance().getMappedCard(applicationRole);

        if ((userDatas == null) || userDatas.isEmpty()) {
            logger.error("CreationFichePersonnaliseeService : il n'y a pas de fiche pour l'applicationRole:'{}'", applicationRole);
            this.setOutput(OUT_FICHE_PERSONALISEE, null);
            return;
        }

        UserA2DR utilisateurA2DR = (UserA2DR) this.getInput(IN_UTILISATEUR);

        FichePersonalisee fichePerso = new FichePersonalisee();

        for (UserData userData : userDatas) {
            String name = userData.getName();
            String method = userData.getMethod();

            String value = null;

            if (method != null) {
                try {
                    value = call(utilisateurA2DR, method);
                } catch (NoSuchMethodException e) {
                    String errorMsg = ERROR_MSG_PREFIX + e + ERROR_MSG_SUFFIX + method;
                    logger.error(errorMsg, e);
                    throw new FwkException(errorMsg, e);
                } catch (IllegalAccessException e) {
                    String errorMsg = ERROR_MSG_PREFIX + e + ERROR_MSG_SUFFIX + method;
                    logger.error(errorMsg, e);
                    throw new FwkException(errorMsg, e);
                } catch (InvocationTargetException e) {
                    String errorMsg = ERROR_MSG_PREFIX + e + ERROR_MSG_SUFFIX + method;
                    logger.error(errorMsg, e);
                    throw new FwkException(errorMsg, e);
                }
            }

            Entry entry = new Entry();
            entry.setKey(name);
            entry.setValue(value);
            fichePerso.addEntry(entry);

            logger.info("Entry.key:'{}', Entry.value:'{}'", name, value);
        }
        this.setOutput(OUT_FICHE_PERSONALISEE, fichePerso);
    }

    /**
     * Permet d'effectuer un appel de m�thode dynamique sur un objet.
     * 
     * @param userA2DR l'objet sur lequel on d�sire effectuer une invocation dynamique de m�thode
     * @param _method le nom de la m�thode
     * @return le r�sultat de l'appel
     * @throws InvocationTargetException si une erreur survient
     * @throws IllegalAccessException si une erreur survient
     * @throws NoSuchMethodException si une erreur survient
     */
    private String call(UserA2DR userA2DR, String _method) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        logger.debug(">call on method={}", _method);

        // Appel de la m�thode avec un objet null
        if (userA2DR == null) {
            return null;
        }

        Object resultValue = MethodUtils.invokeExactMethod(userA2DR, _method);

        String returnStr;

        if (resultValue == null) {
            Method meth = MethodUtils.getMatchingAccessibleMethod(UserA2DR.class, _method);

            if (meth.getReturnType() == Number.class) {
                returnStr = "0";
            } else {
                // valable quand on a affaire avec un type String
                returnStr = StringUtils.EMPTY;
            }
        } else {
            returnStr = resultValue.toString();
        }

        return returnStr;
    }
}
