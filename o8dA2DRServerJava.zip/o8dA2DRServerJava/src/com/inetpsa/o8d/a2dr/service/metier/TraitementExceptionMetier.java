package com.inetpsa.o8d.a2dr.service.metier;

import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpStatus;

import com.inetpsa.cxl.transport.ResponseIsNotOkException;
import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.exception.AutorisationException;
import com.inetpsa.o8d.a2dr.exception.HostNotFoundException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Classe service metier qui de traiter les exception metiers.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class TraitementExceptionMetier extends AbstractA2DRBusinessService {

    /** nom du service */
    public static final String SERVICE_NAME = "traitement_exception_metier";

    /** exception metier */
    public static final String IN_EXCEPTION_METIER = "IN_EXCEPTION_METIER";

    /** code HTTP en sortie */
    public static final String OUT_HTTP_CODE = "OUT_HTTP_CODE";

    /** map des headers HTTP en sortie */
    public static final String OUT_MAP_HEADER = "OUT_MAP_HEADER";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme.
     */
    public TraitementExceptionMetier() throws FwkException {
        super();
    }

    /**
     * Traitement metier.
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        logger.debug(">> doExecute");

        Object myBusinessException = this.getInput(IN_EXCEPTION_METIER);

        Map headers = new HashMap();
        this.setOutput(OUT_MAP_HEADER, headers);

        if (myBusinessException == null) {
            logger.debug("> pas de BusinessException, on continuer le traitement");
            logger.debug("<< traitement des erreur metier du service");
            return;
        }

        logger.info("> RetourClientService => myBusinessException:{}", myBusinessException.getClass().getName());

        if (myBusinessException instanceof AuthentificationException) {
            logger.debug("> RetourClientService : AuthentificationException");

            headers.put("WWW-Authenticate", "Basic realm=\"Authentification NRE SI-DIAG\"");
            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_UNAUTHORIZED);
        } else if (myBusinessException instanceof AutorisationException) {
            logger.debug("> RetourClientService : AutorizationException");

            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_FORBIDDEN);
        } else if (myBusinessException instanceof DiagUserException) {
            logger.debug("> RetourClientService : DiagUserException");

            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_GATEWAY_TIMEOUT);
        } else if (myBusinessException instanceof HostNotFoundException) {
            logger.debug("> RetourClientService : HostNotFoundException");

            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_GATEWAY_TIMEOUT);
        } else if (myBusinessException instanceof BusinessException) {
            logger.debug("> RetourClientService : BusinessException");

            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_GATEWAY_TIMEOUT);
        } else if (myBusinessException instanceof ResponseIsNotOkException) {
            logger.debug("> RetourClientService : ResponseIsNotOkException");

            this.setOutput(OUT_HTTP_CODE, this.getInput(AbstractRelayCommunicationService.STATUS_CODE));
        } else if (myBusinessException instanceof SocketTimeoutException) {
            logger.debug("> RetourClientService : SocketTimeoutException");

            this.setOutput(OUT_HTTP_CODE, HttpStatus.SC_REQUEST_TIMEOUT);
        }

        return;
    }
}
