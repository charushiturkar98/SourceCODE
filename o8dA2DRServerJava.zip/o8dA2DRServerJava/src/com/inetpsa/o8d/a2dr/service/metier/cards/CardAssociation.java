package com.inetpsa.o8d.a2dr.service.metier.cards;

/**
 * Objet XML pour les associations de fiches.
 * 
 * @author E331258
 */
public class CardAssociation {

    /**
     * Application.
     */
    private String application;
    /**
     * Fiche.
     */
    private String card;

    /**
     * Getter application
     * 
     * @return the application
     */
    public String getApplication() {
        return application;
    }

    /**
     * Setter application
     * 
     * @param application the application to set
     */
    public void setApplication(String application) {
        this.application = application;
    }

    /**
     * Getter card
     * 
     * @return the card
     */
    public String getCard() {
        return card;
    }

    /**
     * Setter card
     * 
     * @param card the card to set
     */
    public void setCard(String card) {
        this.card = card;
    }
}
