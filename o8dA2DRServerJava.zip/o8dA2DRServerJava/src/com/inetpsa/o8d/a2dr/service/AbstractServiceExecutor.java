package com.inetpsa.o8d.a2dr.service;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.BusinessService;
import com.inetpsa.fwk.service.ServiceFactory;

/**
 * Permet de lancer un service.
 * 
 * @author E331258
 */
public abstract class AbstractServiceExecutor {

    /**
     * M�thode principale d'ex�cution d'un service appel�e dans l'action.
     * 
     * @param serviceName Objet serviceName.
     * @param callback Objet IServiceCallback.
     * @return Objet retourn� par le service.
     * @throws FwkException Exception technique du framework.
     */
    public final Object executeService(String serviceName, IServiceCallback callback) throws FwkException {
        BusinessService service = null;
        try {
            User user = null;

            service = ServiceFactory.getInstance().getService(user, serviceName);

            if (callback != null) {
                callback.doOnServiceInput(service);
            }

            service.execute();

            if (callback != null) {
                Object obj = callback.doOnServiceOutput(service);

                return obj;
            }

            return null;
        } finally {
            service.close();
        }
    }

    /**
     * Interface � impl�menter par la classe Action, permettant le passage de param�tres (d'entr�e et de sortie) au service.
     */
    public interface IServiceCallback {
        /**
         * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
         * 
         * @param service Objet BusinessService du service appel� par l'action.
         * @throws FwkException Exception technique du framework.
         */
        void doOnServiceInput(BusinessService service) throws FwkException;

        /**
         * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
         * 
         * @param service Objet BusinessService du service appel� par l'action.
         * @return Param�tre de sortie du service.
         * @throws FwkException Exception technique du framework.
         */
        Object doOnServiceOutput(BusinessService service) throws FwkException;
    }
}
