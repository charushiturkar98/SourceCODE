package com.inetpsa.o8d.a2dr.service.securite;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.exception.ServiceTechnicalException;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * Classe metier qui s'occupe de gerer et d'executer les strategie d'authentification. Cette classe va chercher en base de donn�e les strat�gies �
 * suivre.
 * 
 * @author Hichame ELKHALFI - E298062.
 */
public class AuthentificationStrategieService extends AbstractA2DRBusinessService {

    /**
     * Nom de l'application d'authentification
     */
    public static final String A2DR_APPLICATION_ID = "a2drAuthentification";

    /** nom du service */
    public static final String SERVICE_NAME = "authentificaton_strategie";

    /** parametres credentials */
    public static final String IN_CREDENTIALS = "IN_CREDENTIALS";
    /** parametres 'IN_APPLICATION_ID' */
    public static final String IN_APPLICATIONID = "IN_APPLICATIONID";

    /** exception metier */
    public static final String OUT_EXCEPTION_METIER = "OUT_EXCEPTION_METIER";

    /** valeur 'true' */
    public static final Boolean TRUE = Boolean.TRUE;

    /** instance utilis� du DiagUser */
    public static final String DIAG_USER_INSTANCE = "DIAG_USER_INSTANCE";

    /** service d'autorisation */
    public static final String SERVICE_AUTHORISATION = "SERVICE_AUTHORISATION";
    // CAP-26498:DiagLot2-start
    public static final String REQUEST_HOSTNAME = "REQUEST_HOSTNAME";
    // CAP-26498:end

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probelem.
     */
    public AuthentificationStrategieService() throws FwkException {
        super();
    }

    /**
     * Traitement metier.
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        logger.debug("debut Execution du service AuthentificationStrategieService");

        try {
            DiagUserCredentials credentials = (DiagUserCredentials) this.getInput(IN_CREDENTIALS);
            String applicationID = (String) this.getInput(IN_APPLICATIONID);
            // CAP-26498:DiagLot2-start
            String host = (String) this.getInput(REQUEST_HOSTNAME);
            // CAP-26498:end

            StrategieFactory strategyFactory = ServerConfigurationManager.getInstance().getStrategieFactory(applicationID);

            if (strategyFactory == null) {
                logger.warn("strategyFactory = null pour l'application:'{}', veuillez v�rifier l'existance de ce mapping dans la configuration",
                        applicationID);
                throw new ServiceTechnicalException("Unknown authentication strategy for application id : " + applicationID);
            } else {
                logger.debug("Fabrique de strategie que l'on va utiliser:{}", strategyFactory.getClass().getName());

                AbstractStrategie strategie = strategyFactory.createStrategie();

                logger.debug("debut execution de la stategie");
                // CAP-26498:DiagLot2-Adding request in params
                strategie.executeStrategy(credentials, applicationID, host);

                this.setOutput(DIAG_USER_INSTANCE, strategie.getDiagUserConnector());

                logger.debug("fin execution de la stategie");
            }
        } catch (AuthentificationException e) {
            logger.error("Exception metier 'AutorisationException':{} ", e.getMessage());
            this.setOutput(OUT_EXCEPTION_METIER, e);
        } catch (BusinessException be) {
            logger.error("Exception metier '" + be.getClass().getName() + "'", be.getMessage());
            this.setOutput(OUT_EXCEPTION_METIER, be);
        }
        logger.debug("fin Execution du service 'AuthentificationStrategieService'");
    }
}
