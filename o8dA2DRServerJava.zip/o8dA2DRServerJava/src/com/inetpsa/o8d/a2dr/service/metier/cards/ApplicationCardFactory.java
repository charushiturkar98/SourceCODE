package com.inetpsa.o8d.a2dr.service.metier.cards;

import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.DiagUserRuntimeException;

/**
 * Classe utlise par castor pour parse le fichier mapping-fiche.xml. Cette classe parse de fichier 'MAPPING_FILE'.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public final class ApplicationCardFactory {

    /** Log de la classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationCardFactory.class);

    /** nom physique du fichier de configuration */
    private static final String CARDS_FILE = "application_cards.xml";

    /** instance singleton */
    private static final ApplicationCardFactory INSTANCE = new ApplicationCardFactory();

    /** collection des fiches <cle>=nom de l'application, <valeur>liste de donn�es de l'application */
    private Map<String, List<UserData>> applicationUserDatas;

    /**
     * Constructeur de la factory.
     */
    private ApplicationCardFactory() {
        LOGGER.debug(">> init");

        try {
            init();
        } catch (DiagUserException ex) {
            LOGGER.error("Erreur lors du chargement dans le constructeur 'ApplicationCardFactory'", ex);
            throw new DiagUserRuntimeException(ex);
        }

        LOGGER.debug("<< init");
    }

    /**
     * Retourne l'unique instance de la factory
     * 
     * @return instance unique de la factory
     */
    public static ApplicationCardFactory getInstance() {
        return INSTANCE;
    }

    /**
     * Methode ou on parse le fichier de configuration, aussi on construis le pattern des fiches, et on les stocke en memoire.
     * 
     * @throws DiagUserException en cas de probl�me.
     */
    private void init() throws DiagUserException {
        LOGGER.debug(">>init du composant : init()");

        try {
            JAXBContext applicationCardsJaxbContext = JAXBContext.newInstance(ApplicationCards.class);
            Unmarshaller unmarshaller = applicationCardsJaxbContext.createUnmarshaller();

            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(CARDS_FILE);

            if (is == null) {
                throw new DiagUserException("Erreur chargement du fichier " + CARDS_FILE + " : Not found in classpath");
            }

            ApplicationCards applicationCards = (ApplicationCards) unmarshaller.unmarshal(is);

            buildUserDatas(applicationCards);
        } catch (JAXBException e) {
            String errorMsg = "Erreur chargement du fichier '" + CARDS_FILE + "'";
            LOGGER.error(errorMsg, e);
            throw new DiagUserException(errorMsg, e);
        }

        LOGGER.debug("<<init du composant : init()");
    }

    /**
     * Construction des user datas.
     * 
     * @param applicationCards les fiches
     */
    private void buildUserDatas(ApplicationCards applicationCards) {
        applicationUserDatas = new HashMap<String, List<UserData>>();

        for (CardAssociation cardAssociation : applicationCards.getAssociations()) {
            Card card = applicationCards.getCards().get(cardAssociation.getCard());

            applicationUserDatas.put(cardAssociation.getApplication(), card.getDatas());

            LOGGER.info("applicationId={}, datas={}", cardAssociation.getApplication(), CollectionUtils.size(card.getDatas()));
        }
    }

    /**
     * Retourne la liste des fiches non index�.
     * 
     * @param applicationRole role de l'application.
     * @return liste des fiches non index�.
     */
    public List<UserData> getMappedCard(String applicationRole) {
        if (StringUtils.isEmpty(applicationRole)) {
            return Collections.emptyList();
        }

        return applicationUserDatas.get(applicationRole);
    }
}
