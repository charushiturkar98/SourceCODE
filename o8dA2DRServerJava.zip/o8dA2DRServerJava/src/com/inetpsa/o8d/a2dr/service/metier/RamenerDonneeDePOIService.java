package com.inetpsa.o8d.a2dr.service.metier;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.beans.VinA2DR;
import com.inetpsa.o8d.a2dr.beans.VinA2DRComparator;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.a2dr.security.PasswordManagerException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.oin.psoasis.client.PsOasisInfo;
import com.inetpsa.oin.psoasis.client.PsOasisUser;
import com.inetpsa.oin.psoasis.client.bean.Item;
import com.inetpsa.oin.psoasis.client.bean.Items;
import com.inetpsa.oin.psoasis.client.bean.User;
import com.inetpsa.oin.psoasis.client.constant.TypeItem;

/**
 * R�cup�ration des donn�es de POI.
 * 
 * @author e358045
 */
public class RamenerDonneeDePOIService extends AbstractA2DRBusinessService {

    /** nom du serivce */
    public static final String SERVICE_NAME = "ramener_donnee_de_poi";

    /** parametre d'authentification HTTP Basic Auth */
    public static final String IN_CREDENTIALS = "IN_CREDENTIALS";

    /** parametre de retour de l'authentification */
    public static final String OUT_FLAG_NOT_AUTHENTICATED = "OUT_FLAG_NOT_AUTHENTICATED";
    /**
     * Comparateur de VinA2DR.
     */

    public static final String SOURCE_AUTH_URL = "AuthentificationV2";

    public static final String SOURCE_USAGE_URL = "UsageDiagBoxActionV2";

    public static final String LAST_SEP = "/";

    public static final String DOT_SEP = ".";

    private static final Comparator<VinA2DR> VIN_COMPARATOR = new VinA2DRComparator();

    /** The Constant ADS. */
    public static final String ADS = "ADS";

    /** The Constant AS. */
    public static final String AS = "AS";

    /** The Constant SDS. */
    public static final String SDS = "SDS";

    /** The Constant DS. */
    public static final String DS = "DS";

    /** The Constant ADF. */
    public static final String ADF = "ADF";

    /** The Constant AD. */
    public static final String AD = "AD";
    /**
     * CAP-26498: The Constant SERVER_NAME. Initialize hostName for differentiating call for diagbox and diagcloud lot2
     */
    public static final String HOST_NAME = "HOST_NAME";

    /**
     * Constructeur par defaut.
     * 
     * @throws FwkException en cas de probleme
     */
    public RamenerDonneeDePOIService() throws FwkException {
        super();
    }

    /**
     * Traiement metier.
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        if (logger.isDebugEnabled())
            logger.debug(">> doExecute()");

        DiagUserCredentials credentials = (DiagUserCredentials) this.getInput(IN_CREDENTIALS);
        String username = credentials.getUserName();
        String password = credentials.getPassword();
        String marque = credentials.getMarque();
        String hostName = (String) this.getInput(HOST_NAME);
        // sonar issue solved
        if (logger.isInfoEnabled())
            logger.info("Marque from DiagUserCredentials DSS 1 >>> [{}]", marque);
        if (!StringUtils.isBlank(marque) || !StringUtils.isEmpty(marque)) {
            // sonar issue solved -- start
            if (marque.equalsIgnoreCase(ADS) || marque.equalsIgnoreCase(AS) || marque.equalsIgnoreCase(SDS))
                marque = DS;
            else if (marque.equalsIgnoreCase(ADF)) {
                marque = AD;
            } // -- end
        }

        if (logger.isInfoEnabled()) {
            logger.info("Marque from DiagUserCredentials DSS>>> [{}]", marque);
            logger.info("login=[{}]", username);
            logger.info("Connection with POI to retrieve the User object");
        }

        // 08/12/2009 => Permet de r�cup�rer les beans User et beans Items correspondant � op�rateur ind�pendant Le beans Items correspond � un
        // ensemble de bean Item qui corresponde � une jeton ou des abonnements.
        PsOasisUser psOasisUserA2DR;
        User userA2DRPOI;
        try {

            // CAP-26498:DiagLot2 -Code for new POI service for authentication
            if (hostName.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))) {
                psOasisUserA2DR = new PsOasisUser(username, StringUtils.EMPTY, TypeItem.ABONNEMENT, marque);
                userA2DRPOI = psOasisUserA2DR.send();
            } else {
                psOasisUserA2DR = new PsOasisUser(username, password, TypeItem.ABONNEMENT, marque);
                userA2DRPOI = psOasisUserA2DR.send();
            }
            if (userA2DRPOI == null) {
                this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, null);
            } else if (userA2DRPOI.getUserid() != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Nom: {}, Prenom: {}, Adr_facture: {}, UserId: {}, Zip code: {}, Pays: {}, Langue: {}, IsValidate: {}",
                            userA2DRPOI.getNom(), userA2DRPOI.getPrenom(), userA2DRPOI.getAdr_facture(), userA2DRPOI.getUserid(),
                            userA2DRPOI.getZipcode(), userA2DRPOI.getPays(), userA2DRPOI.getLangue(), userA2DRPOI.getIsValidate());

                    logger.debug("Retrieving the POI List of Items");
                }

                PsOasisInfo psItemsPOI;
                psItemsPOI = new PsOasisInfo(username, marque);
                // commented for CAP-6560 PNB changes on 21/08/2017
                // PsOasisInfo psItemsPOI = new PsOasisInfo(username);
                Items itemsPOI = psItemsPOI.send();

                if (logger.isDebugEnabled())
                    logger.debug("Creating the UserA2DR Object from User and POI Beans Received from POIs");

                // R�cup�ration du tableau de Vin par la fonction
                // creerUserA2DR car on ne peut pas envoyer un pointeur de
                // pointeur
                UserA2DR sortieUserA2DR = this.creerUserA2DR(userA2DRPOI, itemsPOI, username, password, hostName);
                this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, sortieUserA2DR);
                if (logger.isInfoEnabled())
                    logger.info("doExecute(): login=[{}] userA2DR=[{}] dateFinMax=[{}]", username, sortieUserA2DR.getNbrJetons(),
                            sortieUserA2DR.getDateFinMax());

            } else {
                if (logger.isInfoEnabled())
                    logger.info("Authentification error");
                this.setOutput(OUT_FLAG_NOT_AUTHENTICATED, StringUtils.EMPTY);
            }

        } catch (PasswordManagerException e) {
            logger.error("Erreur pour PasswordManagerException ", e);
            this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, null);
        } catch (ParseException e) {
            logger.error("Erreur pour ParseException ", e);
            this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, null);
        } catch (Exception e) {
            if (logger.isInfoEnabled())
                logger.info("Error at the time of Calling POI", e);
            logger.error("Error at the time of Calling POI {}", e.getLocalizedMessage());
            if (null != password) {
                logger.error("Error for UserName :{}", username + " and Password is not null");
            } else {
                logger.error("Error for UserName :{}", username + " and Password is null");
            }
        }

        if (logger.isDebugEnabled())
            logger.debug("<< doExecute()");
    }

    /**
     * Sert � calculer le nombre de jetons dont dispose l'op�rateur ind�pendant
     * 
     * @param listeItemsPOI liste items
     * @return nombre de jetons dont dispose l'Op�rateur Ind�pendant
     * @throws ParseException si une erreur survient
     */
    private int calculerNombreJetonRestant(Items listeItemsPOI) throws ParseException {
        /*
         * PsOasisInfo obtenir les jetons non consomm�s (date paiement null si pas pay�s)
         */
        Iterator iteratorInfo = listeItemsPOI.iterator();
        Item itemInfo = null;
        int nbrDeJetons = 0;
        while (iteratorInfo.hasNext()) {
            itemInfo = (Item) iteratorInfo.next();
            if (itemInfo.getDatePaiement() != null && itemInfo.getDateFin() == null && itemInfo.getDateDebut() == null) {
                nbrDeJetons += itemInfo.getQt_restante();
            }
        }
        return nbrDeJetons;
    }

    /**
     * Cette fonction cr�e un ensemble d'objet de type VinA2DR puis le retourne. Cet ensemble d'objet est cr�e � partir d'un ensemble d'objet Item
     * provenant de POI, ainsi que d'un objet UserA2DR afin de lier les objets de type VinA2DR � l'objet UserA2DR.
     * 
     * @param listeItemsPOI items poi
     * @return liste de vins
     * @throws ParseException si une erreur survient
     */
    private List<VinA2DR> retourneListeCompleteVinDePOI(Items listeItemsPOI) throws ParseException {
        // sonar issue fixed
        List<VinA2DR> listeVinA2DR = new ArrayList<>();
        VinA2DR testVinA2DR = null;
        Item oItem = null;

        if (listeItemsPOI != null) {

            Iterator<Item> itListeItem = listeItemsPOI.iterator();

            while (itListeItem.hasNext()) {
                oItem = itListeItem.next();
                testVinA2DR = new VinA2DR();

                if (oItem.getDateFin() != null && oItem.getDateDebut() != null) {

                    testVinA2DR.setDateDebut((Date) oItem.getDateDebut());
                    testVinA2DR.setDateFin((Date) oItem.getDateFin());
                    testVinA2DR.setVin(oItem.getRefi());
                    listeVinA2DR.add(testVinA2DR);
                }
            }
        }

        return listeVinA2DR;
    }

    /**
     * Cette fonction permet de retourner la Date de fin de validit� la plus lointaine parmi une ArrayList d'objet VinA2DR, l'objet VinA2DR impl�mente
     * l'interface Comparable donc la m�thode CompareTo qui est utilis�e par la m�thode statique : "max" de la classe Collections
     * 
     * @param listeVinA2DR Contient un ensemble d'objet de type VinA2DR
     * @return La Date de fin de validit� la plus lointaine parmi une ArrayList
     * @throws ParseException si une erreur survient
     */
    private Date retourneDateMaxFinAbonnementDePOI(List<VinA2DR> listeVinA2DR) throws ParseException {
        /*
         * Au cas o� le nombre d'abonnement VIN actif est null
         */
        logger.debug("Affichage Date Max");
        if (!listeVinA2DR.isEmpty()) {
            VinA2DR vinPrincipalA2DR = Collections.max(listeVinA2DR, VIN_COMPARATOR);
            return vinPrincipalA2DR.getDateFin();
        }
        return new Date();

    }

    /**
     * Cr�ation de l'utilisateur.
     * 
     * @param utilisateurPOI utilisateur POI
     * @param listeItemsPOI liste d'elements de POI
     * @param login le login
     * @param motDePasse le mot de passe
     * @return le user
     * @throws ParseException si une erreur survient
     * @throws PasswordManagerException si une erreur survient
     */
    private UserA2DR creerUserA2DR(final User utilisateurPOI, final Items listeItemsPOI, final String login, final String motDePasse, String hostName)
            throws ParseException, PasswordManagerException {

        final UserA2DR utilisateurA2DR = new UserA2DR();

        // Affectation des attributs d'�tats civils de l'op�rateur ind�pendant
        utilisateurA2DR.setAdrFacture(utilisateurPOI.getAdr_facture());
        utilisateurA2DR.setEmail(utilisateurPOI.getEmail());
        utilisateurA2DR.setIsValidate(utilisateurPOI.getIsValidate());
        utilisateurA2DR.setNom(utilisateurPOI.getNom());
        utilisateurA2DR.setPrenom(utilisateurPOI.getPrenom());
        utilisateurA2DR.setVille(utilisateurPOI.getVille());
        utilisateurA2DR.setCodeLangueISO(utilisateurPOI.getLangue());
        utilisateurA2DR.setCodePaysISO(utilisateurPOI.getPays());
        utilisateurA2DR.setCodePostal(utilisateurPOI.getZipcode());

        if (logger.isDebugEnabled())
            logger.debug("{} {} {}", utilisateurPOI.getLangue(), utilisateurPOI.getPays(), utilisateurPOI.getZipcode());

        utilisateurA2DR.setLogin(login);
        // CAP-26498: not sending password to POI in DiagLot2
        if (!(hostName.contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))))
            utilisateurA2DR.setMotDePasse(PASSWORD_MANAGER.generateStrongPasswordHash(motDePasse));

        // Affectation du nbr de Jetons dont dispose l'op�rateur ind�pendant
        utilisateurA2DR.setNbrJetons(this.calculerNombreJetonRestant(listeItemsPOI));

        // Cr�ation de la liste des abonnements VIN de l'op�rateur ind�pendant
        List<VinA2DR> listeDeVINA2DR = this.retourneListeCompleteVinDePOI(listeItemsPOI);

        // Affection de la liste des abonnements VIN � l'objet op�rateur
        // ind�pendant
        utilisateurA2DR.setListeVin(listeDeVINA2DR);

        // Affection de la date final maximum de l'op�rateur ind�pendant

        utilisateurA2DR.setDateFinMax(this.retourneDateMaxFinAbonnementDePOI(listeDeVINA2DR));

        return utilisateurA2DR;
    }
}
