package com.inetpsa.o8d.a2dr.service.metier.cards;

/**
 * Objet XML pour une donn�e utilisateur
 * 
 * @author e331258
 */
public class UserData {

    /** nom de la donn�e */
    private String name;

    /** m�thode pour r�cup�rer la donn�e */
    private String method;

    /**
     * Getter name
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter name
     * 
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter method
     * 
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * Setter method
     * 
     * @param method the method to set
     */
    public void setMethod(String method) {
        this.method = method;
    }
}
