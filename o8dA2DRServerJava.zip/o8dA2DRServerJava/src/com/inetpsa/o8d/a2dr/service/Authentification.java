package com.inetpsa.o8d.a2dr.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.cxl.message.actionresponse.IStatus;
import com.inetpsa.cxl.message.actionresponse.PsaStatus;
import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.BusinessService;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.service.metier.CreationFichePersonnaliseeService;
import com.inetpsa.o8d.a2dr.service.metier.RamenerDonneeDeBDService;
import com.inetpsa.o8d.a2dr.service.metier.RamenerDonneeDePOIService;
import com.inetpsa.o8d.a2dr.service.metier.StockerDonneeDePOIService;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * Authentification. ==> Migration du code pour supprimer un appel loopback sur le serveur
 * 
 * @author E331258
 */
public class Authentification extends AbstractServiceExecutor {

    /**
     * Gestionnaire de logs.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(Authentification.class);

    /**
     * Statut d'authentification.
     */
    private IStatus authentificationStatus;

    /**
     * Getter authentificationStatus
     *
     * @return the authentificationStatus
     */
    public IStatus getAuthentificationStatus() {
        return authentificationStatus;
    }

    /**
     * Methode qui permet d'authentifier un utilisateur par le biais d'un webservice.
     *
     * @param credentials donn�es d'authentification de l'utilisateur que l'on veut authentifier
     * @param applicationRole nom de l'application qui veut authentifier
     * @param hostName the server name
     * @return FichePersonalisee fiche personnalise qui renseigne divers renseignement : nom, prenom, email, etc... .
     * @throws AuthentificationException si une erreur survient
     */
    public FichePersonalisee authenticate(final DiagUserCredentials credentials, final String applicationRole, String hostName)
            throws AuthentificationException {
        LOGGER.info(">>>> authenticate : operateur {}", credentials.getUserName());

        LOGGER.debug("applicationRole : '{}'", applicationRole);

        long tZero = System.currentTimeMillis();

        Map resultPOI = null;
        String flagNotAuthenticated = null;
        UserA2DR userA2dr = null;

        try {
            // on rapatrie depuis POI et on stocke dans notre base.
            resultPOI = retrieveFromPOI(credentials, hostName);

            flagNotAuthenticated = (String) resultPOI.get(RamenerDonneeDePOIService.OUT_FLAG_NOT_AUTHENTICATED);
            userA2dr = (UserA2DR) resultPOI.get(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE);

            // Ajout de mode d�grad� lors d'un type d'exception non catche.
            // Cas courant
            if (userA2dr != null) {
                userA2dr = storeInDatabase(userA2dr, flagNotAuthenticated, hostName);
            } else {
                // Mode d�grad� ajout du 19/01/2010
                // probleme de communication avec POI, alors on cherche dans notre BD
                LOGGER.info("Utilisation des donnees de BD locale pour generer la Fiche Perso");

                userA2dr = retrieveFromDatabase(credentials);
            }
        } catch (FwkException ex) {
            // probleme de communication avec POI, alors on cherche dans notre BD
            LOGGER.warn("probleme de communication avec POI OU erreur de maj sur la base locale", ex);

            try {
                userA2dr = retrieveFromDatabase(credentials);
            } catch (FwkException e) {
                throw new AuthentificationException("Error during service execution (retrieve database)", e);
            }
        }

        FichePersonalisee fichePerso = null;

        if (userA2dr == null) {
            LOGGER.warn("l'operateur '{}' n'existe ni chez POI ni en base", credentials.getUserName());

            authentificationStatus = PsaStatus.AUTHENTICATION_FAILED;
        } else {
            LOGGER.warn("l'operateur '[{}]' a ete trouve", credentials.getUserName());

            authentificationStatus = PsaStatus.STATUS_OK;

            fichePerso = creationFiche(userA2dr, applicationRole);
        }

        if (LOGGER.isDebugEnabled() && (fichePerso != null)) {
            LOGGER.debug("Authentification - ajoute la fiche perso");
        }

        LOGGER.info("<<<< authenticate - sortie normale - elapsed (ms) : " + (System.currentTimeMillis() - tZero));

        return fichePerso;
    }

    /**
     * R�cup�ration des informations en provenance de POI.
     *
     * @param credentials donn�es d'authentification
     * @param hostName the server name
     * @return r�sultat
     * @throws FwkException si une erreur survient
     */
    private Map retrieveFromPOI(final DiagUserCredentials credentials, final String hostName) throws FwkException {
        LOGGER.debug("execution du service RamenerDonneeDePOIService");

        Map resultPOI = (Map) executeService(RamenerDonneeDePOIService.SERVICE_NAME, new IServiceCallback() {
            /**
             * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @throws FwkException Exception technique du framework.
             */
            public void doOnServiceInput(BusinessService service) throws FwkException {
                service.setInput(RamenerDonneeDePOIService.IN_CREDENTIALS, credentials);
                // CAP-26498: Adding hostName for differentiating call for Diagbox and DiagLot2
                service.setInput(RamenerDonneeDePOIService.HOST_NAME, hostName);
            }

            /**
             * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @return Param�tre de sortie du service.
             * @throws FwkException Exception technique du framework.
             */
            public Object doOnServiceOutput(BusinessService service) throws FwkException {
                Map result = new HashMap();

                result.put(RamenerDonneeDePOIService.OUT_FLAG_NOT_AUTHENTICATED,
                        service.getOutput(RamenerDonneeDePOIService.OUT_FLAG_NOT_AUTHENTICATED));
                result.put(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, service.getOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE));

                return result;
            }
        });

        LOGGER.debug("fin du service RamenerDonneeDePOIService");

        return resultPOI;
    }

    /**
     * Positionnement des informations en base.
     *
     * @param userA2dr l'utilisateur � cr�er/mettre � jour
     * @param flagNotAuthenticated statut d'erreur d'authentification
     * @param hostName the server name
     * @return r�sultat
     * @throws FwkException si une erreur survient
     */
    private UserA2DR storeInDatabase(final UserA2DR userA2dr, final String flagNotAuthenticated, final String hostName) throws FwkException {
        LOGGER.debug("execution du service StockerDonneeDePOIService");

        UserA2DR userA2DROutput = (UserA2DR) executeService(StockerDonneeDePOIService.SERVICE_NAME, new IServiceCallback() {
            /**
             * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @throws FwkException Exception technique du framework.
             */
            public void doOnServiceInput(BusinessService service) throws FwkException {
                service.setInput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, userA2dr);
                service.setInput(StockerDonneeDePOIService.IN_FLAG_NOT_AUTHENTICATED, flagNotAuthenticated);
                // CAP-26498: Adding hostName for differentiating call for Diagbox and DiagLot2
                service.setInput(RamenerDonneeDePOIService.HOST_NAME, hostName);
            }

            /**
             * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @return Param�tre de sortie du service.
             * @throws FwkException Exception technique du framework.
             */
            public Object doOnServiceOutput(BusinessService service) throws FwkException {
                return service.getOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE);
            }
        });

        LOGGER.debug("fin execution du service StockerDonneeDePOIService");

        return userA2DROutput;
    }

    /**
     * R�cup�ration des informations en provenance de la base.
     * 
     * @param credentials donn�es d'authentification
     * @return r�sultat
     * @throws FwkException si une erreur survient
     */
    private UserA2DR retrieveFromDatabase(final DiagUserCredentials credentials) throws FwkException {
        LOGGER.debug("execution du service RamenerDonneeDeBDService");

        UserA2DR userA2DR = (UserA2DR) executeService(RamenerDonneeDeBDService.SERVICE_NAME, new IServiceCallback() {
            /**
             * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @throws FwkException Exception technique du framework.
             */
            public void doOnServiceInput(BusinessService service) throws FwkException {
                service.setInput(RamenerDonneeDeBDService.IN_CREDENTIALS, credentials);
            }

            /**
             * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
             * 
             * @param service Objet BusinessService du service appel� par l'action.
             * @return Param�tre de sortie du service.
             * @throws FwkException Exception technique du framework.
             */
            public Object doOnServiceOutput(BusinessService service) throws FwkException {
                return service.getOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE);
            }
        });

        LOGGER.debug("fin du service RapartierDonneeBDService");

        return userA2DR;
    }

    /**
     * Lancement du service de cr�ation de fiche personnalis�e.
     * 
     * @param userA2dr l'utilisateur � cr�er
     * @param applicationRole application
     * @return la fiche
     * @throws AuthentificationException si une erreur survient
     */
    private FichePersonalisee creationFiche(final UserA2DR userA2dr, final String applicationRole) throws AuthentificationException {
        LOGGER.debug("debut du service CreationFichePersonnaliseeService");

        FichePersonalisee fichePerso = null;

        try {
            fichePerso = (FichePersonalisee) executeService(CreationFichePersonnaliseeService.SERVICE_NAME, new IServiceCallback() {
                /**
                 * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @throws FwkException Exception technique du framework.
                 */
                public void doOnServiceInput(BusinessService service) throws FwkException {
                    service.setInput(CreationFichePersonnaliseeService.IN_UTILISATEUR, userA2dr);
                    service.setInput(CreationFichePersonnaliseeService.IN_APPLICATION_ROLE, applicationRole);
                }

                /**
                 * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @return Param�tre de sortie du service.
                 * @throws FwkException Exception technique du framework.
                 */
                public Object doOnServiceOutput(BusinessService service) throws FwkException {
                    return service.getOutput(CreationFichePersonnaliseeService.OUT_FICHE_PERSONALISEE);
                }
            });
        } catch (FwkException e) {
            throw new AuthentificationException("Error during service execution", e);
        }

        LOGGER.debug("fin du service CreationFichePersonnaliseeService");

        return fichePerso;
    }
}
