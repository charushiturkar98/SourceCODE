package com.inetpsa.o8d.a2dr.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.BusinessService;
import com.inetpsa.o8d.a2dr.beans.DiagboxJetonBean;
import com.inetpsa.o8d.a2dr.service.metier.O8DFC1AuthorisationUsageService;
import com.inetpsa.o8d.a2dr.service.metier.TraitementExceptionMetier;
import com.inetpsa.o8d.a2dr.service.securite.AuthentificationStrategieService;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * Controle de l'abonnement pour un vin. ==> Migration du code pour supprimer un appel loopback sur le serveur
 * 
 * @author E331258
 */
public class AbonnementVINChecker extends AbstractServiceExecutor {

    /**
     * Gestionnaire de logs
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbonnementVINChecker.class);
    /**
     * Taille max du parametre VIN.
     */
    private static final int VIN_PARAM_SIZE = 50;

    /**
     * Jeton diagbox.
     */
    private DiagboxJetonBean diagboxJeton;
    /**
     * Connecteur.
     */
    private AbstractDiagUserConnector diagUser;
    /**
     * Headers suite au traitement des erreurs.
     */
    private Map errorheaders;
    /**
     * Headers.
     */
    private Map<String, String> mapHeader;
    /**
     * Code http suite � l'authentification.
     */
    private Integer httpCodeFromAuthentification;
    /**
     * Accord de consommation.
     */
    private String accordConsommation;

    /**
     * Getter diagUser
     * 
     * @return the diagUser
     */
    public AbstractDiagUserConnector getDiagUser() {
        return diagUser;
    }

    /**
     * Setter diagUser
     * 
     * @param diagUser the diagUser to set
     */
    public void setDiagUser(AbstractDiagUserConnector diagUser) {
        this.diagUser = diagUser;
    }

    /**
     * Getter errorheaders
     * 
     * @return the errorheaders
     */
    public Map getErrorheaders() {
        return errorheaders;
    }

    /**
     * Getter mapHeader
     * 
     * @return the mapHeader
     */
    public Map<String, String> getMapHeader() {
        return mapHeader;
    }

    /**
     * Getter httpCodeFromAuthentification
     * 
     * @return the httpCodeFromAuthentification
     */
    public Integer getHttpCodeFromAuthentification() {
        return httpCodeFromAuthentification;
    }

    /**
     * Setter accordConsommation
     * 
     * @param accordConsommation the accordConsommation to set
     */
    public void setAccordConsommation(String accordConsommation) {
        this.accordConsommation = accordConsommation;
    }

    /**
     * Getter diagboxJeton
     * 
     * @return the diagboxJeton
     */
    public DiagboxJetonBean getDiagboxJeton() {
        return diagboxJeton;
    }

    /**
     * Contr�le de l'abonnement.
     * 
     * @param vin le vin
     * @param diagUserCredentials donn�es d'authentification
     * @throws IOException si une erreur survient
     */
    public void checkAbo(final String vin, final DiagUserCredentials diagUserCredentials) throws IOException {
        if (StringUtils.length(vin) <= VIN_PARAM_SIZE) {
            LOGGER.info(">> Get Jetons pour user {}, vin {}", diagUserCredentials.getUserName(), vin);
        } else {
            LOGGER.info(">> Get Jetons pour user {}, vin TOO LONG TO LOG", diagUserCredentials.getUserName());
        }

        LOGGER.info("applicationID:'{}'", AuthentificationStrategieService.A2DR_APPLICATION_ID);

        // Utilisation de AuthentificationStrategieService afin de choisir en base la strat�gie d'authentification � suivre.

        LOGGER.debug(">> authentification de la cnx");

        Map resultFromAuthentification = executeAuthenticationService(diagUserCredentials);

        /*
         * quand 'httpCode' est null cela veut dire qu'il n'y as pas d'exception metier
         */
        httpCodeFromAuthentification = (Integer) resultFromAuthentification.get(TraitementExceptionMetier.OUT_HTTP_CODE);

        if (httpCodeFromAuthentification != null) {
            errorheaders = (Map) resultFromAuthentification.get(TraitementExceptionMetier.OUT_MAP_HEADER);
            return;
        }

        LOGGER.info("AbonnementVINChecker : d�but de la v�rification d'authorisation et de la consommation pour l'utilisateur : ['{}']",
                diagUserCredentials.getUserName());

        LOGGER.debug("Diaguser object : {}", diagUser);

        Map resultFromO8DFC1AuthorisationUsageService;
        try {
            resultFromO8DFC1AuthorisationUsageService = (Map) executeService(O8DFC1AuthorisationUsageService.SERVICE_NAME, new IServiceCallback() {
                /**
                 * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @throws FwkException Exception technique du framework.
                 */
                public void doOnServiceInput(BusinessService service) throws FwkException {
                    service.setInput(O8DFC1AuthorisationUsageService.IN_DIAG_USER_INSTANCE, diagUser);
                    service.setInput(O8DFC1AuthorisationUsageService.IN_DIAGBOX_VIN, vin);
                    service.setInput(O8DFC1AuthorisationUsageService.IN_DIAGBOX_ACCORD_CONSO, accordConsommation);
                }

                /**
                 * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @return Param�tre de sortie du service.
                 * @throws FwkException Exception technique du framework.
                 */
                public Object doOnServiceOutput(BusinessService service) throws FwkException {
                    Map result = new HashMap();
                    result.put(O8DFC1AuthorisationUsageService.OUT_BEAN, service.getOutput(O8DFC1AuthorisationUsageService.OUT_BEAN));
                    result.put(O8DFC1AuthorisationUsageService.OUT_HEADERS, service.getOutput(O8DFC1AuthorisationUsageService.OUT_HEADERS));
                    return result;
                }
            });
        } catch (FwkException e) {
            throw new IOException("Error during service execution (checkabo)", e);
        }

        LOGGER.info("AbonnementVINChecker : Fin de la v�rification d'authorisation et de la consommation pour l'utilisateur : ['{}']",
                diagUserCredentials.getUserName());

        mapHeader = (Map<String, String>) resultFromO8DFC1AuthorisationUsageService.get(O8DFC1AuthorisationUsageService.OUT_HEADERS);

        diagboxJeton = (DiagboxJetonBean) resultFromO8DFC1AuthorisationUsageService.get(O8DFC1AuthorisationUsageService.OUT_BEAN);

        diagboxJeton.setIdentification(true);

        // CAP-19064: log message from debug to warn
        LOGGER.warn("Reponse complete : {}", diagboxJeton.getReponseComplete());

        LOGGER.info("<< Get Jetons");
    }

    /**
     * Lancement du service d'authentification.
     * 
     * @param diagUserCredentials les donn�es d'authentification
     * @return le r�sultat
     * @throws IOException si une erreur survient
     */
    private Map executeAuthenticationService(final DiagUserCredentials diagUserCredentials) throws IOException {
        final AbonnementVINChecker vinChecker = this;
        // CAP-26498: Fix for Incident- INCI11061140
        final String hostName;
        if (StringUtils.isBlank(diagUserCredentials.getPassword()) && StringUtils.isNotBlank(diagUserCredentials.getTokenUsername())) {
            hostName = "dss3";
        } else {
            hostName = "dss";
        }
        Map resultFromAuthentification;
        try {
            final Exception exceptionMetierAuthentification = (Exception) executeService(AuthentificationStrategieService.SERVICE_NAME,
                    new IServiceCallback() {
                        /**
                         * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
                         * 
                         * @param service Objet BusinessService du service appel� par l'action.
                         * @throws FwkException Exception technique du framework.
                         */
                        public void doOnServiceInput(BusinessService service) throws FwkException {
                            service.setInput(AuthentificationStrategieService.IN_CREDENTIALS, diagUserCredentials);
                            service.setInput(AuthentificationStrategieService.IN_APPLICATIONID, AuthentificationStrategieService.A2DR_APPLICATION_ID);
                            service.setInput(AuthentificationStrategieService.REQUEST_HOSTNAME,
                                    hostName); /* CAP-26498 :DiagLot2- Fix for Incident- INCI11061140 */
                        }

                        /**
                         * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
                         * 
                         * @param service Objet BusinessService du service appel� par l'action.
                         * @return Param�tre de sortie du service.
                         * @throws FwkException Exception technique du framework.
                         */
                        public Object doOnServiceOutput(BusinessService service) throws FwkException {
                            vinChecker
                                    .setDiagUser((AbstractDiagUserConnector) service.getOutput(AuthentificationStrategieService.DIAG_USER_INSTANCE));

                            return service.getOutput(AuthentificationStrategieService.OUT_EXCEPTION_METIER);
                        }
                    });
            LOGGER.debug("<< authentification de la cnx");

            LOGGER.debug(">> traitement des erreur metier du service d'authentification");

            resultFromAuthentification = (Map) executeService(TraitementExceptionMetier.SERVICE_NAME, new IServiceCallback() {
                /**
                 * M�thode permettant � l'action associ�e de passer des param�tres en entr�e au service.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @throws FwkException Exception technique du framework.
                 */
                public void doOnServiceInput(BusinessService service) throws FwkException {
                    service.setInput(TraitementExceptionMetier.IN_EXCEPTION_METIER, exceptionMetierAuthentification);
                }

                /**
                 * M�thode permettant au service de retourner des param�tres de sortie � la classe Action appelante.
                 * 
                 * @param service Objet BusinessService du service appel� par l'action.
                 * @return Param�tre de sortie du service.
                 * @throws FwkException Exception technique du framework.
                 */
                public Object doOnServiceOutput(BusinessService service) throws FwkException {
                    Map result = new HashMap();
                    result.put(TraitementExceptionMetier.OUT_HTTP_CODE, service.getOutput(TraitementExceptionMetier.OUT_HTTP_CODE));
                    result.put(TraitementExceptionMetier.OUT_MAP_HEADER, service.getOutput(TraitementExceptionMetier.OUT_MAP_HEADER));
                    return result;
                }
            });

            LOGGER.debug("<< traitement des erreur metier du service d'authentification");
        } catch (FwkException e) {
            throw new IOException("Error during service execution (auth)", e);
        }

        return resultFromAuthentification;
    }
}
