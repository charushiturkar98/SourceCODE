package com.inetpsa.o8d.a2dr.service.metier.cards;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * Object XML pour une fiche.
 * 
 * @author e331258
 */
public class Card {

    /** liste des donn�es */
    private List<UserData> datas;

    /**
     * Getter datas
     * 
     * @return the datas
     */
    public List<UserData> getDatas() {
        return datas;
    }

    /**
     * Setter datas
     * 
     * @param datas the datas to set
     */
    @XmlElement(name = "data")
    public void setDatas(List<UserData> datas) {
        this.datas = datas;
    }
}
