package com.inetpsa.o8d.a2dr.service.metier;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.persistence.IPersistentContextKey;
import com.inetpsa.fwk.service.persistence.OJBPersistentContext;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.security.PasswordManagerException;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * Service pour r�cup�rer les donn�es en base.
 * 
 * @author e358045
 */
public class RamenerDonneeDeBDService extends AbstractA2DRBusinessService {

    /** nom du service */
    public static final String SERVICE_NAME = "rapatrier_donnee_de_la_bd";

    /** parametre d'authentification HTTP Basic Auth */
    public static final String IN_CREDENTIALS = "IN_CREDENTIALS";

    /**
     * Constructeur de la classe.
     * 
     * @throws FwkException en cas de probleme.
     */
    public RamenerDonneeDeBDService() throws FwkException {
        super();
    }

    /**
     * Traitement metier.
     * 
     * @throws FwkException en cas de probleme.
     */
    protected void doExecute() throws FwkException {
        logger.debug(">> debut Execution du service RamenerDonneeDeBDService");

        DiagUserCredentials credentials = (DiagUserCredentials) this.getInput(IN_CREDENTIALS);
        IPersistentContextKey key = buildPersistentContextKey();
        OJBPersistentContext persistentContext = (OJBPersistentContext) getPersistentContext(key);
        PersistenceBroker broker = null;

        try {
            broker = persistentContext.getBroker();
            Criteria criteria = new Criteria();
            criteria.addEqualTo("USER_LOGIN", credentials.getUserName());

            QueryByCriteria q = new QueryByCriteria(UserA2DR.class, criteria);

            UserA2DR crudUserA2DR = (UserA2DR) broker.getObjectByQuery(q);

            if (checkUser(crudUserA2DR, credentials)) {
                this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, crudUserA2DR);
            } else {
                this.setOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE, null);
            }
        } catch (PasswordManagerException ex) {
            logger.warn("Erreur lors de la recherche de l'utilisateur '" + credentials.getUserName() + "' en base a2dr", ex);
            throw new FwkException(ex);
        } finally {
            try {
                closePersistentContext(key);
            } catch (FwkException ex) {
                logger.warn("Erreur lors de la fermeture de context", ex);
            }
        }

        logger.debug("<< fin Execution du service RamenerDonneeDeBDService");
    }
}
