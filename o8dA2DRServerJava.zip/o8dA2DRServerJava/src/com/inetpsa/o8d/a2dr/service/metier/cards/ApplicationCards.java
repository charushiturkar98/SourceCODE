package com.inetpsa.o8d.a2dr.service.metier.cards;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Objet XML pour les fiches.
 * 
 * @author e331258
 */
@XmlRootElement(name = "application_cards")
public class ApplicationCards {

    /** Definitions de Fiches */
    private Map<String, Card> cards;

    /** Associations de Fiches */
    private List<CardAssociation> associations;

    /**
     * Getter cards
     * 
     * @return the cards
     */
    public Map<String, Card> getCards() {
        return cards;
    }

    /**
     * Setter cards
     * 
     * @param cards the cards to set
     */
    public void setCards(Map<String, Card> cards) {
        this.cards = cards;
    }

    /**
     * Getter associations
     * 
     * @return the associations
     */
    public List<CardAssociation> getAssociations() {
        return associations;
    }

    /**
     * Setter associations
     * 
     * @param associations the associations to set
     */
    @XmlElement(name = "association")
    public void setAssociations(List<CardAssociation> associations) {
        this.associations = associations;
    }
}
