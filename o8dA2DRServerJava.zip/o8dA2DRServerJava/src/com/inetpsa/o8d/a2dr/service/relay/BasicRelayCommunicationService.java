/*
 * 
 */
package com.inetpsa.o8d.a2dr.service.relay;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.o8d.a2dr.beans.AuthenticationBean;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * Relais faisant un post simple et retournant le contenu fourni par la cible sans modification.
 * 
 * @author E331258
 */
public class BasicRelayCommunicationService extends AbstractRelayCommunicationService {

    /** Constants for success code received from ldap oi. */
    public static final String SUCCESS_CODE_LDAPOI = "000";

    /** Logger. */
    protected static final Logger log = LoggerFactory.getLogger(BasicRelayCommunicationService.class);

    /**
     * Constructeur.
     * 
     * @throws FwkException si une erreur survient
     */
    public BasicRelayCommunicationService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#getHttpMethod()
     */
    @Override
    protected ValidHttpMethod getHttpMethod() {
        return ValidHttpMethod.POST;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.service.relay.AbstractRelayCommunicationService#postTreatments(byte[], java.util.Map)
     */
    @Override
    protected byte[] postTreatments(byte[] bytes, Map<String, String> responseHeaders) {
        return bytes;
    }

    /**
     * // CAP-29321: Code Refactor for Prepare req body for serav ul.
     *
     * @param inputRequest    the input request
     * @param inRequestEntity the in request entity
     * @return the byte array request entity
     */
    @Override
    public ByteArrayRequestEntity prepareReqBodyForSeravUl(String inputRequest, ByteArrayRequestEntity inRequestEntity) {
        if (StringUtils.isNotEmpty(inputRequest)
                && relayAccessConfiguration.getApplicationName().equals(AbstractRelayCommunicationService.SERAV_UL)) {
            conversionUtility = new ConversionUtility();
            String requestInXml = null;
            requestInXml = conversionUtility.convertJsonToXml(inputRequest);
            if (null != requestInXml) {
                return new ByteArrayRequestEntity(requestInXml.getBytes());
            } else if (logger.isDebugEnabled())
                logger.debug("Request is either empty or not formed properly");

        }
        return inRequestEntity;
    }

    // CAP-29098: START - handle response for portfolio service getLabelsInfo
    RewriteResponseRelayCommunicationService rewriteResponseRelayCommunicationService = new RewriteResponseRelayCommunicationService();

    /**
     * Handle portfolio labels info response.
     *
     * @param httpConn       the method relay
     * @param argosStatusMap the argos status map
     * @return the map
     * @throws IOException Signals that an I/O exception has occurred
     */
    @Override
    public void handlePortfolioLabelsInfoResponse(HttpsURLConnection httpConn, Map<Integer, String> responseMap) throws IOException {
        String finalResponse;
        JSONObject jsonResponse = new JSONObject(extractResponseFromPortfolio(responseMap, httpConn, relayAccessConfiguration.getApplicationName()));
        List<JSONObject> list = new ArrayList<>();
        JSONObject filterdOutput = new JSONObject();
        if (httpConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            if (logger.isInfoEnabled())
                logger.info("Error response received from Portfolio for getLabelsInfo: {}", jsonResponse);
            responseMap.put(httpConn.getResponseCode(), addErrorMessage(httpConn.getResponseCode()));
        } else {
            if (jsonResponse.has(RelayConstants.LABELS_LIST)) {
                JSONArray jArray = jsonResponse.getJSONArray(RelayConstants.LABELS_LIST);
                for (int i = 0; i < jArray.length(); i++) {
                    list.add(jArray.getJSONObject(i));
                }
                if (!list.isEmpty()) {
                    getSuccessResponseForLabelInfo(jsonResponse, filterdOutput);
                }
                finalResponse = filterdOutput.toString();
                if (logger.isInfoEnabled())
                    logger.info("Success Response received from Portfolio for getLabelsInfo: {}", finalResponse);
                responseMap.clear();
                responseMap.put(httpConn.getResponseCode(), finalResponse);
            }
        }
    }

    /**
     * Adds the error message.
     *
     * @param responseStatusCode the response status code
     * @return the string
     */
    public static String addErrorMessage(int responseStatusCode) {

        String message;
        switch (responseStatusCode) {
        case HttpURLConnection.HTTP_BAD_REQUEST:
            message = RelayConstants.BAD_REQUEST;
            break;
        case HttpURLConnection.HTTP_UNAUTHORIZED:
            message = RelayConstants.UNAUTHORIZED;
            break;
        case HttpURLConnection.HTTP_FORBIDDEN:
            message = RelayConstants.FORBIDDEN_ACCESS;
            break;
        case HttpURLConnection.HTTP_NOT_FOUND:
            message = RelayConstants.UNKNOWN_HEXACODE;
            break;
        default:
            message = RelayConstants.INTERNAL_SERVER_ERROR;
        }
        return message;
    }

    /**
     * Gets the success response for label info.
     *
     * @param jResponse     the j response
     * @param filterdOutput the filterd output
     * @return the success response for label info
     */
    public static void getSuccessResponseForLabelInfo(JSONObject jResponse, JSONObject filterdOutput) {
        String[] strArray = { RelayConstants.LABEL_CODE, RelayConstants.COMMERCIAL_LABEL, RelayConstants.COMMERCIAL_LABEL_DEFAULT };
        JSONArray jsonArray = new JSONArray();
        JSONArray jArray = jResponse.getJSONArray(RelayConstants.LABELS_LIST);
        for (int i = 0; i < jArray.length(); i++) {
            JSONObject jsonObject = new JSONObject();
            JSONObject readResponse = jResponse.getJSONArray(RelayConstants.LABELS_LIST).getJSONObject(i);
            for (String readElement : strArray) {
                if (!readResponse.has(readElement) || readResponse.getString(readElement).isEmpty()) {
                    jsonObject.put(readElement, StringUtils.EMPTY);
                } else
                    jsonObject.put(readElement, readResponse.getString(readElement));
            }
            jsonArray.put(jsonObject);
        }
        filterdOutput.put(RelayConstants.LABELS_LIST, jsonArray);
    }

    @Override
    public Map<Integer, String> fetchDataForAPICPortfolioApplications(String requestDDC) throws IOException {
        HttpsURLConnection httpConn = null;
        String response = StringUtils.EMPTY;
        Map<Integer, String> statusMap = new HashMap<>();
        Map<String, String> responseHeaders = new HashMap<>();

        try {
            httpConn = buildConn(requestDDC);
            if (PORTFOLIO_LABEL.equalsIgnoreCase(relayAccessConfiguration.getApplicationName())) {
                handlePortfolioLabelsInfoResponse(httpConn, statusMap);
            } else if (relayAccessConfiguration.getApplicationId().equals(APIC_PORTFOLIO_APP)
                    && !(PORTFOLIO_LABEL.equals(relayAccessConfiguration.getApplicationName()))) {
                extractResponseFromPortfolio(statusMap, httpConn, relayAccessConfiguration.getApplicationName());
            }
            int statusCode = RelayConstants.SERAV_UL_SUCCESS_STATUS_CODE;
            for (Map.Entry<Integer, String> entry : statusMap.entrySet()) {
                statusCode = entry.getKey();
                response = entry.getValue();
            }
            if ((response != null) && (StringUtils.isNotBlank(response))) {
                extractAndSetResponse(httpConn, responseHeaders, requestDDC, response, statusCode);
            }

        } catch (Exception e) {
            logger.error("Error while processing response from {} application.", relayAccessConfiguration.getApplicationName(), e);
        }
        return statusMap;

    }

    /**
     * Builds the conn.
     *
     * @param requestDDC the request DDC
     * @return the https URL connection
     * @throws FwkException the fwk exception
     */
    private HttpsURLConnection buildConn(String requestDDC) throws FwkException {
        HttpsURLConnection httpConn = null;
        ServerConfigurationManager serverConfigurationManager = ServerConfigurationManager.getInstance();
        AuthenticationBean portfolio = serverConfigurationManager.getPortfolioAccount();
        DiagUserCredentials inputCredentials = (DiagUserCredentials) this.getInput(IN_REQUEST_CREDENTIALS);

        try {
            httpConn = BatteryInfoUtil.createHttpConnWithProxyAndTLS(targetApplicationUrl, relayAccessConfiguration.getApplicationName());
            if (this.getInput(RelayConstants.DSS3_HOSTNAME).toString()
                    .contains(ServerConfigurationManager.getInstance().getVariableValue(RelayConstants.DSS3_HOSTNAME))) {
                httpConn.setRequestProperty(RelayConstants.AUTHORIZATION,
                        RelayConstants.BASIC + new String(Base64.encodeBase64((portfolio.getLogin() + ":" + portfolio.getPassword()).getBytes())));
            } else {
                httpConn.setRequestProperty(RelayConstants.AUTHORIZATION, RelayConstants.BASIC
                        + new String(Base64.encodeBase64((inputCredentials.getUserName() + ":" + inputCredentials.getPassword()).getBytes())));
            }

            ValidHttpMethod httpMethod = ValidHttpMethod.valueOf(StringUtils.upperCase(this.getInputParameterValue(IN_HTTP_METHOD)));
            switch (httpMethod) {
            case GET:
                httpConn.setRequestMethod(RelayConstants.GET_METHOD);
                if (logger.isInfoEnabled())
                    logger.info("httpMethod GET[{}]", httpMethod);
                break;
            case POST:

                httpConn.setRequestMethod(RelayConstants.POST_METHOD);
                httpConn.setRequestProperty(RelayConstants.CONTENT_TYPE, RelayConstants.APPLICATION_JSON);
                httpConn.setRequestProperty(RelayConstants.ACCEPT, RelayConstants.APPLICATION_JSON);
                if (PORTFOLIO_LABEL.equals(relayAccessConfiguration.getApplicationName())) {
                    httpConn.setRequestProperty(RelayConstants.CLIENT_ID_PORTFOLIO_LABEL_KEY,
                            serverConfigurationManager.getVariableValue(RelayConstants.CLIENT_ID_PORTFOLIO_LABEL));
                }
                httpConn.setDoOutput(true);
                rewriteResponseRelayCommunicationService.requestBodyWriter(httpConn, requestDDC);
                if (logger.isInfoEnabled())
                    logger.info("httpMethod POST[{}]", httpMethod);
                break;
            default:
                throw new FwkException("Not implement http method : " + httpMethod);
            }

            httpConn.connect();
            if (logger.isInfoEnabled())
                logger.info("Response code from Portfolio while building connection:{} ", httpConn.getResponseCode());
        } catch (Exception e) {
            String str = "Exception while calling getLabelsInfo service via URl: ";
            logger.error(str, e);
        }
        return httpConn;
    }

    /**
     * Extract response from portfolio.
     *
     * @param applStatusMap   the appl status map
     * @param httpConn        the http connection
     * @param applicationName the application name
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static String extractResponseFromPortfolio(Map<Integer, String> applStatusMap, HttpsURLConnection httpConn, String applicationName)
            throws IOException {
        String response = getResponseFromPortfolio(httpConn);
        int responseCode = httpConn.getResponseCode();
        applStatusMap.clear();
        // POUDG-9437
        if (LDAP_OI.equalsIgnoreCase(applicationName)) {
            if (responseCode != HttpURLConnection.HTTP_OK) {
                log.warn("Error received from LDAP OI:{}", response);
                log.warn("Response code from ldap_oi : {}", responseCode);
                applStatusMap.put(responseCode, LdapCommons.addErrorMessageForGigya(responseCode));
            } else {
                JSONObject jsonResponse = new JSONObject(response);
                if (jsonResponse.get(RelayConstants.RESULT_CODE).toString().equals(SUCCESS_CODE_LDAPOI)) {
                    if (log.isInfoEnabled()) {
                        log.info("LDAP OI successfully performed the requested actions");
                        log.info("Response received from LDAP OI:{}", response);
                    }
                    applStatusMap.put(responseCode, response);
                } else {
                    log.warn("LDAP OI failed to perform the requested actions");
                    log.warn("Status Code received from LDAP OI:{}", responseCode);
                    log.warn("Response received from LDAP OI:{}", response);
                    applStatusMap.put(LdapCommons.addErrorCodeForGigya(Integer.parseInt(jsonResponse.get(RelayConstants.RESULT_CODE).toString())),
                            response);
                }
            }
        } else {
            applStatusMap.put(responseCode, response);
            if (log.isInfoEnabled())
                log.info("Response received from Portfolio:{} ", response);
        }
        return response;
    }

    /**
     * Gets the response from portfolio.
     *
     * @param httpConnectionForPortfolio the http connection for portfolio
     * @return the response from portfolio
     */
    public static String getResponseFromPortfolio(HttpsURLConnection httpConnectionForPortfolio) {
        StringBuilder res = new StringBuilder();
        BufferedReader responseMsg = null;
        try {
            if (java.net.HttpURLConnection.HTTP_OK == httpConnectionForPortfolio.getResponseCode()) {
                responseMsg = new BufferedReader(new InputStreamReader(httpConnectionForPortfolio.getInputStream()));
            } else {
                responseMsg = new BufferedReader(new InputStreamReader(httpConnectionForPortfolio.getErrorStream()));
            }
            String inputLine;
            while ((inputLine = responseMsg.readLine()) != null) {
                res.append(inputLine);
            }

        } catch (IOException e) {
            log.error(RelayConstants.PORTFOLIO_ERROR, e);
        } finally {
            try {
                if (null != responseMsg)
                    responseMsg.close();
            } catch (IOException e) {
                log.error("Exception while closing buffered reader :", e);
            }
        }
        return res.toString();

    }
    // CAP-29098: END - handle response for portfolio service getLabelsInfo
}