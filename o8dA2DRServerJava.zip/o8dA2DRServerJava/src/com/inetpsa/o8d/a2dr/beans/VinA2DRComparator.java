package com.inetpsa.o8d.a2dr.beans;

import java.util.Comparator;

/**
 * Comparateur de vinA2dr / date
 * 
 * @author E331258
 */
public class VinA2DRComparator implements Comparator<VinA2DR> {
    @Override
    public int compare(VinA2DR vin1, VinA2DR vin2) {
        // On implemente la m�thode compareTo afin d'utiliser le Design Patten :
        // patron de methode d�finit pour la methode sort d'Array().
        if (vin1.getDateFin().before(vin2.getDateFin())) {
            return -1;
        } else if (vin1.getDateFin().equals(vin2.getDateFin())) {
            return 0;
        } else {
            return 1;
        }
    }
}
