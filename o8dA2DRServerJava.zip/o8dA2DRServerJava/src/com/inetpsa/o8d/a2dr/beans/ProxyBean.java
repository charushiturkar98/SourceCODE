package com.inetpsa.o8d.a2dr.beans;

/**
 * Bean pour la gestion du proxy.
 * 
 * @author E331258
 */
public class ProxyBean {

    /**
     * Nom d'hote.
     */
    private String hostname;
    /**
     * Port du proxy.
     */
    private int port;

    /**
     * Getter hostname
     * 
     * @return the hostname
     */
    public String getHostname() {
        return hostname;
    }

    /**
     * Setter hostname
     * 
     * @param hostname the hostname to set
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    /**
     * Getter port
     * 
     * @return the port
     */
    public int getPort() {
        return port;
    }

    /**
     * Setter port
     * 
     * @param port the port to set
     */
    public void setPort(int port) {
        this.port = port;
    }
}
