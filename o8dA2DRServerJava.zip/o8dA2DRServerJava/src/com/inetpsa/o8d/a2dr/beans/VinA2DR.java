package com.inetpsa.o8d.a2dr.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe repr�sentant un VIN dans A2DR.
 * 
 * @author e358045
 */
public class VinA2DR implements Serializable {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 8234431207021265818L;

    /**
     * Identifiant v�hicule.
     */
    private String vin;
    /**
     * Date d�but.
     */
    private Date dateDebut;
    /**
     * Date fin.
     */
    private Date dateFin;
    /**
     * Id user.
     */
    private int idUserA2DR;
    /**
     * User.
     */
    private UserA2DR userA2DR;

    /**
     * identifiant
     */
    private int id;

    /**
     * Getter vin
     * 
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Setter vin
     * 
     * @param vin the vin to set
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Getter dateDebut
     * 
     * @return the dateDebut
     */
    public Date getDateDebut() {
        return dateDebut;
    }

    /**
     * Setter dateDebut
     * 
     * @param dateDebut the dateDebut to set
     */
    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    /**
     * Getter dateFin
     * 
     * @return the dateFin
     */
    public Date getDateFin() {
        return dateFin;
    }

    /**
     * Setter dateFin
     * 
     * @param dateFin the dateFin to set
     */
    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    /**
     * Getter idUserA2DR
     * 
     * @return the idUserA2DR
     */
    public int getIdUserA2DR() {
        return idUserA2DR;
    }

    /**
     * Setter idUserA2DR
     * 
     * @param idUserA2DR the idUserA2DR to set
     */
    public void setIdUserA2DR(int idUserA2DR) {
        this.idUserA2DR = idUserA2DR;
    }

    /**
     * Getter userA2DR
     * 
     * @return the userA2DR
     */
    public UserA2DR getUserA2DR() {
        return userA2DR;
    }

    /**
     * Setter userA2DR
     * 
     * @param userA2DR the userA2DR to set
     */
    public void setUserA2DR(UserA2DR userA2DR) {
        this.userA2DR = userA2DR;
    }

    /**
     * Getter id
     * 
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Setter id
     * 
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
