package com.inetpsa.o8d.a2dr.beans;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * Objet repr�sentant un utilisateur.
 * 
 * @author e358045
 */
public class UserA2DR implements Serializable {
    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -6604928711411003939L;
    /**
     * Cl� � utiliser pour les dialogues intra logiciels avec les services.
     */
    public static final String USER_INFORMATION_KEY_FOR_SERVICE = "USER_INFORMATION_KEY_FOR_SERVICE";
    /**
     * Champ pour le login.
     */
    public static final String USER_LOGIN_FIELD = "USER_LOGIN";
    /**
     * Nom.
     */
    private String nom;
    /**
     * Prenom.
     */
    private String prenom;
    /**
     * Email.
     */
    private String email;
    /**
     * Adresse de facturation.
     */
    private String adrFacture;
    /**
     * Ville
     */
    private String ville;
    /**
     * Nombre de jetons.
     */
    private int nbrJetons;
    /**
     * Validit�
     */
    private String isValidate;
    /**
     * Date de fin.
     */
    private Date dateFinMax;
    /**
     * Login.
     */
    private String login;
    /**
     * Mot de passe.
     */
    private String motDePasse;
    /**
     * Code postal.
     */
    private String codePostal;
    /**
     * Code langue ISO.
     */
    private String codeLangueISO;
    /**
     * Code pays ISO.
     */
    private String codePaysISO;

    /**
     * identifiant.
     */
    private int id;
    /**
     * Liste de vins
     */
    private List<VinA2DR> listeVin;

    /**
     * Retourne la date de fin ppd.
     * 
     * @deprecated 25/01/2010 Compatibilite ancienne version de DiagUser pour PPD
     * @return date de fin format�e
     */
    @Deprecated
    public String getDateFinPPDMax() {
        if (this.dateFinMax != null) {
            SimpleDateFormat simpleDateFormatAval = new SimpleDateFormat("dd/MM/yy");

            return simpleDateFormatAval.format(dateFinMax);
        }

        return StringUtils.EMPTY;
    }

    /**
     * Getter nom
     * 
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Setter nom
     * 
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Getter prenom
     * 
     * @return the prenom
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     * Setter prenom
     * 
     * @param prenom the prenom to set
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     * Getter email
     * 
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Setter email
     * 
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Getter adrFacture
     * 
     * @return the adrFacture
     */
    public String getAdrFacture() {
        return adrFacture;
    }

    /**
     * Setter adrFacture
     * 
     * @param adrFacture the adrFacture to set
     */
    public void setAdrFacture(String adrFacture) {
        this.adrFacture = adrFacture;
    }

    /**
     * Getter ville
     * 
     * @return the ville
     */
    public String getVille() {
        return ville;
    }

    /**
     * Setter ville
     * 
     * @param ville the ville to set
     */
    public void setVille(String ville) {
        this.ville = ville;
    }

    /**
     * Getter nbrJetons
     * 
     * @return the nbrJetons
     */
    public int getNbrJetons() {
        return nbrJetons;
    }

    /**
     * Setter nbrJetons
     * 
     * @param nbrJetons the nbrJetons to set
     */
    public void setNbrJetons(int nbrJetons) {
        this.nbrJetons = nbrJetons;
    }

    /**
     * Getter isValidate
     * 
     * @return the isValidate
     */
    public String getIsValidate() {
        return isValidate;
    }

    /**
     * Setter isValidate
     * 
     * @param isValidate the isValidate to set
     */
    public void setIsValidate(String isValidate) {
        this.isValidate = isValidate;
    }

    /**
     * Getter dateFinMax
     * 
     * @return the dateFinMax
     */
    public Date getDateFinMax() {
        return dateFinMax;
    }

    /**
     * Setter dateFinMax
     * 
     * @param dateFinMax the dateFinMax to set
     */
    public void setDateFinMax(Date dateFinMax) {
        this.dateFinMax = dateFinMax;
    }

    /**
     * Getter login
     * 
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * Setter login
     * 
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * Getter motDePasse
     * 
     * @return the motDePasse
     */
    public String getMotDePasse() {
        return motDePasse;
    }

    /**
     * Setter motDePasse
     * 
     * @param motDePasse the motDePasse to set
     */
    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    /**
     * Getter codePostal
     * 
     * @return the codePostal
     */
    public String getCodePostal() {
        return codePostal;
    }

    /**
     * Setter codePostal
     * 
     * @param codePostal the codePostal to set
     */
    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    /**
     * Getter codeLangueISO
     * 
     * @return the codeLangueISO
     */
    public String getCodeLangueISO() {
        return codeLangueISO;
    }

    /**
     * Setter codeLangueISO
     * 
     * @param codeLangueISO the codeLangueISO to set
     */
    public void setCodeLangueISO(String codeLangueISO) {
        this.codeLangueISO = codeLangueISO;
    }

    /**
     * Getter codePaysISO
     * 
     * @return the codePaysISO
     */
    public String getCodePaysISO() {
        return codePaysISO;
    }

    /**
     * Setter codePaysISO
     * 
     * @param codePaysISO the codePaysISO to set
     */
    public void setCodePaysISO(String codePaysISO) {
        this.codePaysISO = codePaysISO;
    }

    /**
     * Getter id
     * 
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Setter id
     * 
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Getter listeVin
     * 
     * @return the listeVin
     */
    public Collection<VinA2DR> getListeVin() {
        return listeVin;
    }

    /**
     * Setter listeVin
     * 
     * @param listeVin the listeVin to set
     */
    public void setListeVin(List<VinA2DR> listeVin) {
        this.listeVin = listeVin;
    }
}
