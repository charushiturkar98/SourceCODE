package com.inetpsa.o8d.a2dr.beans;

import org.apache.commons.lang3.StringUtils;

/**
 * Gestion des jetons.
 * 
 * @author E331258
 */
public class DiagboxJetonBean {

    /**
     * Statut d'identification.
     */
    private boolean identification;
    /**
     * Statut d'autorisation.
     */
    private boolean autorisation;
    /**
     * Nombre de jetons.
     */
    private int nbJeton;
    /**
     * Nom et pr�nom.
     */
    private String nomPrenom;
    /**
     * Statut de consommation.
     */
    private boolean consommationRealisee;

    /**
     * Getter identification
     * 
     * @return the identification
     */
    public boolean getIdentification() {
        return identification;
    }

    /**
     * Setter identification
     * 
     * @param identification the identification to set
     */
    public void setIdentification(boolean identification) {
        this.identification = identification;
    }

    /**
     * Getter autorisation
     * 
     * @return the autorisation
     */
    public boolean getAutorisation() {
        return autorisation;
    }

    /**
     * Setter autorisation
     * 
     * @param autorisation the autorisation to set
     */
    public void setAutorisation(boolean autorisation) {
        this.autorisation = autorisation;
    }

    /**
     * Getter nbJeton
     * 
     * @return the nbJeton
     */
    public int getNbJeton() {
        return nbJeton;
    }

    /**
     * Setter nbJeton
     * 
     * @param nbJeton the nbJeton to set
     */
    public void setNbJeton(int nbJeton) {
        this.nbJeton = nbJeton;
    }

    /**
     * Getter nomPrenom
     * 
     * @return the nomPrenom
     */
    public String getNomPrenom() {
        return nomPrenom;
    }

    /**
     * Setter nomPrenom
     * 
     * @param nomPrenom the nomPrenom to set
     */
    public void setNomPrenom(String nomPrenom) {
        this.nomPrenom = nomPrenom;
    }

    /**
     * Getter consommationRealisee
     * 
     * @return the consommationRealisee
     */
    public boolean getConsommationRealisee() {
        return consommationRealisee;
    }

    /**
     * Setter consommationRealisee
     * 
     * @param consommationRealisee the consommationRealisee to set
     */
    public void setConsommationRealisee(boolean consommationRealisee) {
        this.consommationRealisee = consommationRealisee;
    }

    /**
     * Construction de la reponse complete.
     * 
     * @return reponse complete
     */
    public String getReponseComplete() {
        StringBuilder sb = new StringBuilder();
        sb.append("Identification=").append(StringUtils.capitalize(String.valueOf(identification))).append("\n");
        sb.append("Autorise=").append(StringUtils.capitalize(String.valueOf(autorisation))).append("\n");
        sb.append("NbrDeJeton=").append(nbJeton).append("\n");
        sb.append("NomEtPrenom=").append(nomPrenom).append("\n");
        sb.append("ConsommationRealise=").append(StringUtils.capitalize(String.valueOf(consommationRealisee)));
        return sb.toString();
    }
}
