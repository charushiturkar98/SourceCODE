package com.inetpsa.o8d.a2dr.beans;

/**
 * Diff�rents types de relais.
 * 
 * @author E331258
 */
public enum ApplicationRelayType {

    /**
     * Un relai basique.
     */
    BASIC_RELAY("basic_relay_communication_service"),
    /**
     * Un relai dont le contenu de retour voit ses urls modifi�es pour utiliser elle-m�mes le relai
     */
    REWRITE_RESPONSE_RELAY("rewrite_response_relay_communication_service");

    /**
     * Nom du service de communication pour le type de relais.
     */
    private final String communicationServiceName;

    /**
     * Constructeur.
     * 
     * @param communicationServiceName nom du service de communication
     */
    private ApplicationRelayType(String communicationServiceName) {
        this.communicationServiceName = communicationServiceName;
    }

    /**
     * Getter communicationServiceName.
     *
     * @return the communicationServiceName
     */
    public String getCommunicationServiceName() {
        return communicationServiceName;
    }
}
