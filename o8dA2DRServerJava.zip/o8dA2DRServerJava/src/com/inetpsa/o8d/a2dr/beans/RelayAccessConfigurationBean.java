package com.inetpsa.o8d.a2dr.beans;

/**
 * Configuration d'un acc�s � une application par un relai.
 * 
 * @author E331258
 */
public class RelayAccessConfigurationBean extends ProxyBean {

    /**
     * S�parateur apr�s scheme.
     */
    private static final String URL_SCHEME_SEP = "://";

    /**
     * S�parateur pour le port.
     */
    private static final String URL_PORT_SEPARATOR = ":";

    /**
     * S�parateur dans le chemin.
     */
    private static final String URL_PATH_SEPARATOR = "/";

    /**
     * Nom de l'application.
     */
    private String applicationName;
    /**
     * Type du relai.
     */
    private ApplicationRelayType type;
    /**
     * Identifiant de l'application.
     */
    private String applicationId;
    /**
     * Scheme pour acc�der � l'application.
     */
    private String scheme;
    /**
     * Contexte pour acc�der � l'application.
     */
    private String context;
    /**
     * Proxy n�cessaire pour acc�der � l'application.
     */
    private boolean useProxy;
    /**
     * Cache pour la construction de l'url.
     */
    private String urlCache;

    /**
     * R�utilisation des credentials re�u en entr�e
     */
    private boolean forwardCredentials;

    /**
     * Indicateur d'activation du relai
     */
    private boolean active;

    /* START: CAP-26498 :Diag Lot2 -dssaction changes for UserType */
    /** The user type. */
    private String userType;

    /**
     * Gets the user type.
     *
     * @return the user type
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Sets the user type.
     *
     * @param userType the new user type
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }

    /**
     * Getter applicationName
     * 
     * @return the applicationName
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Setter applicationName
     * 
     * @param applicationName the applicationName to set
     */
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    /**
     * Getter type
     * 
     * @return the type
     */
    public ApplicationRelayType getType() {
        return type;
    }

    /**
     * Setter type
     * 
     * @param type the type to set
     */
    public void setType(ApplicationRelayType type) {
        this.type = type;
    }

    /**
     * Getter applicationId
     * 
     * @return the applicationId
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * Setter applicationId
     * 
     * @param applicationId the applicationId to set
     */
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    /**
     * Getter scheme
     * 
     * @return the scheme
     */
    public String getScheme() {
        return scheme;
    }

    /**
     * Setter scheme
     * 
     * @param scheme the scheme to set
     */
    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    /**
     * Getter context
     * 
     * @return the context
     */
    public String getContext() {
        return context;
    }

    /**
     * Setter context
     * 
     * @param context the context to set
     */
    public void setContext(String context) {
        this.context = context;
    }

    /**
     * Getter useProxy
     * 
     * @return the useProxy
     */
    public boolean isUseProxy() {
        return useProxy;
    }

    /**
     * Setter useProxy
     * 
     * @param useProxy the useProxy to set
     */
    public void setUseProxy(boolean useProxy) {
        this.useProxy = useProxy;
    }

    /**
     * Getter forwardCredentials
     * 
     * @return the forwardCredentials
     */
    public boolean isForwardCredentials() {
        return forwardCredentials;
    }

    /**
     * Setter forwardCredentials
     * 
     * @param forwardCredentials the forwardCredentials to set
     */
    public void setForwardCredentials(boolean forwardCredentials) {
        this.forwardCredentials = forwardCredentials;
    }

    /**
     * Getter active
     * 
     * @return the active
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Setter active
     * 
     * @param active the active to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Retourne l'url construite.
     * 
     * @return l'url
     */
    public String getUrl() {
        if (urlCache == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(scheme).append(URL_SCHEME_SEP).append(getHostname()).append(URL_PORT_SEPARATOR).append(getPort());

            if (context != null) {
                sb.append(URL_PATH_SEPARATOR).append(context);
            }

            urlCache = sb.toString();
            sb.setLength(0); // CAP-29321 Resetting StringBuilder to null
        }

        return urlCache;
    }
}
