package com.inetpsa.o8d.a2dr.beans;

/**
 * Bean pour la gestion des logins/passwords.
 * 
 * @author E331258
 */
public class AuthenticationBean {

    /**
     * Login.
     */
    private String login;
    /**
     * Mot de passe.
     */
    private String password;

    /**
     * Getter login
     * 
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * Setter login
     * 
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * Getter password
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter password
     * 
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
