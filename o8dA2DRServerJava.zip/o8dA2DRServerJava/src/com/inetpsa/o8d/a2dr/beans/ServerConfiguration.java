package com.inetpsa.o8d.a2dr.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Configuration du serveur.
 * 
 * @author E331258
 */
@XmlRootElement(name = "server_configuration")
public class ServerConfiguration {

    /**
     * Alias DB.
     */
    private String jcdAlias;
    /**
     * Compte associ� au serveur.
     */
    private AuthenticationBean serverAccount;
    // CAP-25454:start
    /**
     * Account associated with Serav.
     */
    private AuthenticationBean serav;
    /**
     * Account associated with Portfolio.
     */
    private AuthenticationBean portfolio;
    /**
     * Account associated with Campaign Code/GetInfoVehicule.
     */
    private AuthenticationBean corvet;
    /**
     * Account associated with Unlocking bsrf.
     */
    private AuthenticationBean seravUl;
    /**
     * Account associated with Ediag.
     */
    private AuthenticationBean ediag;

    /**
     * Account associated with Repps.
     */
    private AuthenticationBean repps;

    /**
     * CAP-28375:Account associated with Witexdi.
     */
    private AuthenticationBean witexedi;
    // CAP-26498:start-Lot2
    /**
     * Account associated with Serav for RI/OI.
     */
    private AuthenticationBean seravRi; // Sonar issue fix
    /**
     * Account associated with argos.
     */
    private AuthenticationBean argos;

    /**
     * Getter serav_ri.
     *
     * @return the serav_ri
     */
    public AuthenticationBean getSeravRIAccount() {
        return seravRi; // Sonar issue fix
    }

    /**
     * //Sonar issue fix Setter serav_ri.
     *
     * @param seravRi the new serav RI account
     */
    @XmlElement(name = "serav_ri")
    public void setSeravRIAccount(AuthenticationBean seravRi) {
        this.seravRi = seravRi;
    }

    // CAP-26498:end
    /**
     * Getter serverAccount.
     *
     * @return the serverAccount
     */
    public AuthenticationBean getArgosAccount() {
        return argos;
    }

    /**
     * Setter serverAccount.
     *
     * @param argos the new argos account
     */
    @XmlElement(name = "argos")
    public void setArgosAccount(AuthenticationBean argos) {
        this.argos = argos;
    }

    // CAP-25454:end
    /**
     * Configuration du proxy.
     */
    private ProxyBean proxy;
    /**
     * Configuration des acc�s aux relais.
     */
    private List<RelayAccessConfigurationBean> relayAccessConfigurations = new ArrayList<RelayAccessConfigurationBean>();
    /**
     * Configuration des mappings applicationId/strat�gie.
     */
    private Map<String, String> strategyMappings = new HashMap<>(); // Sonar issue fixed

    /** The variable mapping. */
    private Map<String, String> variableMapping = new HashMap<>(); // Sonar issue fixed

    /**
     * Getter jcdAlias.
     *
     * @return the jcdAlias
     */
    public String getJcdAlias() {
        return jcdAlias;
    }

    /**
     * Setter jcdAlias.
     *
     * @param jcdAlias the jcdAlias to set
     */
    @XmlElement(name = "jcdAlias")
    public void setJcdAlias(String jcdAlias) {
        this.jcdAlias = jcdAlias;
    }

    /**
     * Getter serverAccount.
     *
     * @return the serverAccount
     */
    public AuthenticationBean getServerAccount() {
        return serverAccount;
    }

    /**
     * Setter serverAccount.
     *
     * @param serverAccount the serverAccount to set
     */
    @XmlElement(name = "serverAccount")
    public void setServerAccount(AuthenticationBean serverAccount) {
        this.serverAccount = serverAccount;
    }

    /**
     * Getter proxy.
     *
     * @return the proxy
     */
    public ProxyBean getProxy() {
        return proxy;
    }

    /**
     * Setter proxy.
     *
     * @param proxy the proxy to set
     */
    @XmlElement(name = "proxy")
    public void setProxy(ProxyBean proxy) {
        this.proxy = proxy;
    }

    /**
     * Getter relayAccessConfigurations.
     *
     * @return the relayAccessConfigurations
     */
    public List<RelayAccessConfigurationBean> getRelayAccessConfigurations() {
        return relayAccessConfigurations;
    }

    /**
     * Setter relayAccessConfigurations.
     *
     * @param relayAccessConfigurations the relayAccessConfigurations to set
     */
    @XmlElement(name = "relay")
    public void setRelayAccessConfigurations(List<RelayAccessConfigurationBean> relayAccessConfigurations) {
        this.relayAccessConfigurations = relayAccessConfigurations;
    }

    /**
     * Getter strategyMappings.
     *
     * @return the strategyMappings
     */
    public Map<String, String> getStrategyMappings() {
        return strategyMappings;
    }

    /**
     * Setter strategyMappings.
     *
     * @param strategyMappings the strategyMappings to set
     */
    @XmlElementWrapper(name = "strategy")
    public void setStrategyMappings(Map<String, String> strategyMappings) {
        this.strategyMappings = strategyMappings;
    }

    /**
     * Gets the variable mapping.
     *
     * @return the variable mapping
     */
    public Map<String, String> getVariableMapping() {
        return variableMapping;
    }

    /**
     * Sets the variable mapping.
     *
     * @param variableMapping the variable mapping
     */
    @XmlElementWrapper(name = "variables")
    public void setVariableMapping(Map<String, String> variableMapping) {
        this.variableMapping = variableMapping;
    }

    // CAP-25454:start
    /**
     * Getter serav.
     *
     * @return the serav
     */
    public AuthenticationBean getSeravAccount() {
        return serav;
    }

    /**
     * Setter serav.
     *
     * @param serav the serav to set
     */
    @XmlElement(name = "serav")
    public void setSeravAccount(AuthenticationBean serav) {
        this.serav = serav;
    }

    /**
     * Getter portfolio.
     *
     * @return the portfolio
     */
    public AuthenticationBean getPortfolioAccount() {
        return portfolio;
    }

    /**
     * Setter portfolio.
     *
     * @param portfolio the portfolio to set
     */
    @XmlElement(name = "portfolio")
    public void setPortfolioAccount(AuthenticationBean portfolio) {
        this.portfolio = portfolio;
    }

    /**
     * Getter campaignCode/getInfoVehicule.
     *
     * @return the corvet
     */
    public AuthenticationBean getCorvetAccount() {
        return corvet;
    }

    /**
     * Setter campaignCode/getInfoVehicule.
     *
     * @param corvet the new corvet account
     */
    @XmlElement(name = "corvet")
    public void setCorvetAccount(AuthenticationBean corvet) {
        this.corvet = corvet;
    }

    /**
     * Gets the unlocking bsrf account.
     *
     * @return the unlocking bsrf account
     */
    public AuthenticationBean getUnlockingBsrfAccount() {
        return seravUl;
    }

    /**
     * Setter unlocking bsrf.
     *
     * @param seravUl the new unlocking bsrf account
     */
    @XmlElement(name = "serav_ul")
    public void setUnlockingBsrfAccount(AuthenticationBean seravUl) {
        this.seravUl = seravUl;
    }

    /**
     * Gets the ediag account.
     *
     * @return the ediag account
     */
    public AuthenticationBean getEdiagAccount() {
        return ediag;
    }

    /**
     * Setter ediag.
     *
     * @param ediag the new Ediag account
     */
    @XmlElement(name = "ediag")
    public void setEdiagAccount(AuthenticationBean ediag) {
        this.ediag = ediag;
    }

    /**
     * Gets the repps account.
     *
     * @return the repps account
     */
    public AuthenticationBean getReppsAccount() {
        return repps;
    }

    /**
     * Setter repps.
     *
     * @param repps the new Repps account
     */
    @XmlElement(name = "repps")
    public void setReppsAccount(AuthenticationBean repps) {
        this.repps = repps;
    }

    // CAP-25454:end
    // CAP-28735:x250 lot 2
    public AuthenticationBean getWitexedi() {
        return witexedi;
    }

    @XmlElement(name = "TBM_HU")
    public void setWitexedi(AuthenticationBean witexedi) {
        this.witexedi = witexedi;
    }

}
