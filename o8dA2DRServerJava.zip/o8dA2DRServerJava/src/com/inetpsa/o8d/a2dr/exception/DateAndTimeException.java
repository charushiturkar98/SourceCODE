/*
 * Creation : 20 Mar 2018
 */
package com.inetpsa.o8d.a2dr.exception;

import com.inetpsa.fwk.exception.BusinessException;

public class DateAndTimeException extends BusinessException {

    /**
     * 
     */
    private static final long serialVersionUID = -8878354252873527279L;

    public DateAndTimeException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(String s, String id) {
        super(s, id);
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(String s, Throwable t, String id) {
        super(s, t, id);
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(String s, Throwable t) {
        super(s, t);
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(String s) {
        super(s);
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(Throwable t, String id) {
        super(t, id);
        // TODO Auto-generated constructor stub
    }

    public DateAndTimeException(Throwable t) {
        super(t);
        // TODO Auto-generated constructor stub
    }

}
