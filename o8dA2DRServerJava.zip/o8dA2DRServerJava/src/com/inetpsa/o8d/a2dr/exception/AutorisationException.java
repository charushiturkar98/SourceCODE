package com.inetpsa.o8d.a2dr.exception;

import com.inetpsa.fwk.exception.BusinessException;

/**
 * Exception en cas de probleme d'autorisation.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class AutorisationException extends BusinessException {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -3347338235831083194L;

    /**
     * Constructeur par defaut
     */
    public AutorisationException() {
        super();
    }

    /**
     * Constructeur avec parametre message.
     * 
     * @param message message � envoyer.
     */
    public AutorisationException(String message) {
        super(message);
    }

    /**
     * Constructeur avec parametre et la cause.
     * 
     * @param message message � envoyer
     * @param cause la cause du probl�me
     */
    public AutorisationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructeur avec parametre cause.
     * 
     * @param cause cause du probl�me.
     */
    public AutorisationException(Throwable cause) {
        super(cause);
    }
}
