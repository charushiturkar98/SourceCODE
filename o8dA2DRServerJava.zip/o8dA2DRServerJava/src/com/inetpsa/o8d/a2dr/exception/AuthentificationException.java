package com.inetpsa.o8d.a2dr.exception;

import com.inetpsa.fwk.exception.BusinessException;

/**
 * Exception en cas de probleme d'authentification.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class AuthentificationException extends BusinessException {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -2644775203554620547L;

    /**
     * Constructeur par defaut
     */
    public AuthentificationException() {
        super();
    }

    /**
     * Constructeur avec parametre message.
     * 
     * @param message message � envoyer.
     */
    public AuthentificationException(String message) {
        super(message);
    }

    /**
     * Constructeur avec parametre et la cause.
     * 
     * @param message message � envoyer
     * @param cause la cause du probl�me
     */
    public AuthentificationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructeur avec parametre cause.
     * 
     * @param cause cause du probl�me.
     */
    public AuthentificationException(Throwable cause) {
        super(cause);
    }
}
