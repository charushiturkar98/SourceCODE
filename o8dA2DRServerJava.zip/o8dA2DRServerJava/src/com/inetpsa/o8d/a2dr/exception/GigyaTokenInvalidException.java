/*
 * Creation : 30 May 2023
 */
package com.inetpsa.o8d.a2dr.exception;

/**
 * The Class GigyaTokenInvalidException.
 */
public class GigyaTokenInvalidException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 2445002987549594169L;

    /**
     * Instantiates a new invalid token exception.
     */
    public GigyaTokenInvalidException() {
        super();
    }

    /**
     * Instantiates a new invalid token exception.
     *
     * @param message the message
     */
    public GigyaTokenInvalidException(String message) {
        super(message);
    }

    /** The status code. */
    private int statusCode;

    /** The error. */
    private String errorCode;

    /** The message. */
    private String errorMessage;

    /**
     * Instantiates a new invalid certificate exception.
     *
     * @param statusCode   the status code
     * @param errorMessage the error message
     */
    public GigyaTokenInvalidException(int statusCode, String errorMessage) {
        this.statusCode = statusCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Gets the error.
     *
     * @return the error
     */
    public String getError() {
        return errorCode;
    }

    /**
     * Sets the error.
     *
     * @param error the new error
     */
    public void setError(String error) {
        this.errorCode = error;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Throwable#getMessage()
     */
    @Override
    public String getMessage() {
        return errorMessage;
    }

    /**
     * Sets the message.
     *
     * @param errorMessage the new message
     */
    public void setMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
