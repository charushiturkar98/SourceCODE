package com.inetpsa.o8d.a2dr.exception;

import com.inetpsa.fwk.exception.BusinessException;

/**
 * Exception en cas ou un Host n'est pas joignable.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class HostNotFoundException extends BusinessException {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 673256134809849869L;

    /**
     * Constructeur par defaut
     */
    public HostNotFoundException() {
        super();
    }

    /**
     * Constructeur avec parametre message.
     * 
     * @param message message � envoyer.
     */
    public HostNotFoundException(String message) {
        super(message);
    }

    /**
     * Constructeur avec parametre et la cause.
     * 
     * @param message message � envoyer
     * @param cause la cause du probl�me
     */
    public HostNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructeur avec parametre cause.
     * 
     * @param cause cause du probl�me.
     */
    public HostNotFoundException(Throwable cause) {
        super(cause);
    }
}
