package com.inetpsa.o8d.a2dr.strategie;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.a2dr.exception.AutorisationException;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.AuthenticationStatus;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.DiagUserFactory;

/**
 * Classe faisant partie du Design pattern Decorator. Elle implemente la strategie d'authentification. Authentifie l'utilisateur aupres de DiagUser;
 * utilise pour les utilisateurs Independants ou Agrees
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class Authentifier extends AbstractStrategie {

    /**
     * Constructeur par defaut.
     * 
     * @param strat strategie.
     */
    public Authentifier(AbstractStrategie strat) {
        super(strat);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.AbstractStrategie#execute(com.inetpsa.o8d.diaguser.DiagUserCredentials, java.lang.String)
     */
    @Override
    // CAP-26498:DiagLot2- Passing server name in parameter
    protected void execute(DiagUserCredentials credentials, String applicationId, String hostName) throws BusinessException, DiagUserException {

        String username = credentials.getUserName();
        // checkmarx fixed
        if ((username == null) || (credentials.getPassword() == null)) {
            throw new AuthentificationException("le login ou le password de la BasicAuth est 'null'");
        }

        AbstractDiagUserConnector diagUser = DiagUserFactory.getInstance().getDiagUserConnectorInstance(credentials, hostName);
        if (diagUser == null) {
            throw new AuthentificationException("Le connecteur DiagUser est null");
        }

        try {
            diagUser.setApplicationId(applicationId);
        } catch (DiagUserException ex) {
            throw new AutorisationException(ex);
        }
        setDiagUserConnector(diagUser);

        AuthenticationStatus authenticationStatus;
        try {
            authenticationStatus = diagUser.authenticate();
        } catch (DiagUserException ex) {
            throw new AuthentificationException(ex);
        }

        // controle metier
        if (authenticationStatus == AuthenticationStatus.AUTH_FAILED) {
            throw new AuthentificationException("User '" + username + "' 's authentication failed");
        } else if (authenticationStatus == AuthenticationStatus.LOCKED) {
            throw new AutorisationException("User '" + username + "' has been locked");
        }
    }
}
