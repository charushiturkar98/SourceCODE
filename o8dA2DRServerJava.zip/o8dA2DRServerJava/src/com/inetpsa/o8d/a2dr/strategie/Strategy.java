package com.inetpsa.o8d.a2dr.strategie;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;

/**
 * Interface pour la gestion des strat�gies
 *
 * @author E331258
 */
public interface Strategy {

    /**
     * Ex�cution de la strat�gie.
     *
     * @param credentials objet contenant les elements d'authentification
     * @param applicationId identifiant de l'application
     * @param hostName the server name
     * @throws BusinessException si une erreur survient
     */
    void executeStrategy(DiagUserCredentials credentials, String applicationId, String hostName) throws BusinessException;
}
