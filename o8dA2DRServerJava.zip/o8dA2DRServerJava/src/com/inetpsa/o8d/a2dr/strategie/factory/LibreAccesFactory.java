package com.inetpsa.o8d.a2dr.strategie.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.LibreAcces;

/**
 * Classe LibreAccesFactory derivce de StrategieFactory construit une strategie d'acces permettant l'acces libre a l'application. <br/>
 * ATTENTION : Ce type d'acc�s ne doit pas �tre utilis� en pr�production ou production car il ouvre une porte sur le SI PSA.
 * 
 * @author E298062
 */
public class LibreAccesFactory implements StrategieFactory {

    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LibreAccesFactory.class);

    /** instance singleon */
    private static final LibreAccesFactory INSTANCE = new LibreAccesFactory();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory#createStrategie()
     */
    @Override
    public AbstractStrategie createStrategie() {
        LOGGER.warn("ATTENTION : LibreAccesFactory utilise => a ne faire qu'en environnement de developpement pour des raisons de securite");

        AbstractStrategie strategie = new LibreAcces(null);

        return strategie;
    }

    /**
     * Methode qui renvoie la reference du singleton
     * 
     * @return reference du singleton.
     */
    public static LibreAccesFactory getInstance() {
        return INSTANCE;
    }
}
