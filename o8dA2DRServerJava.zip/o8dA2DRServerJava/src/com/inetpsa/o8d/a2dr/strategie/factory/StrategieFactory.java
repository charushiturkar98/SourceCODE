package com.inetpsa.o8d.a2dr.strategie.factory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;

/**
 * StrategieFactory permet de fabriquer une strategie d'acces.
 * 
 * @author E298062
 */
public interface StrategieFactory {
    /**
     * Cr�ation de la strat�gie
     * 
     * @return {@link AbstractStrategie}
     */
    AbstractStrategie createStrategie();
}
