package com.inetpsa.o8d.a2dr.strategie.factory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.AssimilerOI;
import com.inetpsa.o8d.a2dr.strategie.Authentifier;

/**
 * La classe AuthentifierOIFactory permet de construire une strategie permettant l'acces aux operateurs independants authentifies.
 * 
 * @author e300260
 */
public class AuthentifierOIFactory implements StrategieFactory {

    /** instance singleton */
    private static final AuthentifierOIFactory INSTANCE = new AuthentifierOIFactory();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory#createStrategie()
     */
    @Override
    public AbstractStrategie createStrategie() {
        AbstractStrategie strategie = new Authentifier(null);
        strategie = new AssimilerOI(strategie);
        return strategie;
    }

    /**
     * Methode getInstance.
     * 
     * @return intance de la factory.
     */
    public static AuthentifierOIFactory getInstance() {
        return INSTANCE;
    }
}
