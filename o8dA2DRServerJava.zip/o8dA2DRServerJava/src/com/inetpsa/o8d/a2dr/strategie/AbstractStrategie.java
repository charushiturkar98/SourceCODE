package com.inetpsa.o8d.a2dr.strategie;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Classe abstraite pour la gestion des stat�gies (permet de chainer les strat�gies unitaires).
 * 
 * @author e331258
 */
public abstract class AbstractStrategie implements Strategy {

    /**
     * Connecteur DiagUser.
     */
    private AbstractDiagUserConnector diagUserConnector;

    /**
     * Strategie suivante � chainer.
     */
    private final AbstractStrategie chainedStrategy;

    /**
     * Constructeur.
     * 
     * @param chainedStrategy strategie suivante � chainer
     */
    public AbstractStrategie(AbstractStrategie chainedStrategy) {
        this.chainedStrategy = chainedStrategy;
    }

    /**
     * Setter diagUserConnector
     * 
     * @param diagUserConnector the diagUserConnector to set
     */
    public void setDiagUserConnector(AbstractDiagUserConnector diagUserConnector) {
        this.diagUserConnector = diagUserConnector;
    }

    /**
     * Getter diagUserConnector
     * 
     * @return the diagUserConnector
     */
    public AbstractDiagUserConnector getDiagUserConnector() {
        return diagUserConnector;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.Strategy#executeStrategy(com.inetpsa.o8d.diaguser.DiagUserCredentials, java.lang.String)
     */
    @Override
    // CAP-26498:DiagLot2-Passing server name in parameter
    public void executeStrategy(DiagUserCredentials credentials, String applicationId, String hostName) throws BusinessException {
        try {
            execute(credentials, applicationId, hostName);
        } catch (DiagUserException e) {
            throw new BusinessException("Error during current strategy execution", e);
        }

        if (chainedStrategy != null) {
            // On propage le connecteur
            chainedStrategy.setDiagUserConnector(getDiagUserConnector());
            // CAP-26498:DiagLot2-Passing server name in parameter
            chainedStrategy.executeStrategy(credentials, applicationId, hostName);
        }
    }

    /**
     * Execution de la strat�gie courante.
     * 
     * @param credentials objet {@link DiagUserCredentials}
     * @param applicationId identifiant de l'application
     * @throws BusinessException si une erreur survient
     * @throws DiagUserException si une erreur survient
     */
    protected abstract void execute(DiagUserCredentials credentials, String applicationId, String hostName)
            throws BusinessException, DiagUserException;

}
