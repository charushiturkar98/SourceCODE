package com.inetpsa.o8d.a2dr.strategie.factory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.Authentifier;
import com.inetpsa.o8d.a2dr.strategie.Autoriser;

/**
 * La classe AuthorisationAndAuthentificationFactory construit la strategie permettant l'acces aux utilisateurs authentifies disposant d'une
 * autorisation pour utiliser l'application.
 * 
 * @author E298062
 */
public class AuthorisationAndAuthentificationFactory implements StrategieFactory {
    /** Isntance singleton */
    private static final AuthorisationAndAuthentificationFactory INSTANCE = new AuthorisationAndAuthentificationFactory();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory#createStrategie()
     */
    @Override
    public AbstractStrategie createStrategie() {
        AbstractStrategie strategie = new Autoriser(null);
        strategie = new Authentifier(strategie);
        return strategie;
    }

    /**
     * Methode qui renvoie la reference du singleton
     * 
     * @return reference du singleton.
     */
    public static AuthorisationAndAuthentificationFactory getInstance() {
        return INSTANCE;
    }
}
