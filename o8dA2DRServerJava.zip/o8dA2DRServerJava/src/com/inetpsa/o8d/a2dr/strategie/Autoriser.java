package com.inetpsa.o8d.a2dr.strategie;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.a2dr.exception.AutorisationException;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Classe faisant partie du Design pattern Decorator. Elle implemente la strategie d'autorisation.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class Autoriser extends AbstractStrategie {

    /** Log de la classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(Autoriser.class);

    /**
     * Constructeur reprenant une strategie.
     * 
     * @param strat strategie suivante.
     */
    public Autoriser(AbstractStrategie strat) {
        super(strat);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.AbstractStrategie#execute(com.inetpsa.o8d.diaguser.DiagUserCredentials, java.lang.String)
     */
    @Override
    // CAP-26498:DiagLot2- Passing server name in parameter
    protected void execute(DiagUserCredentials credentials, String applicationId, String hostName) throws BusinessException, DiagUserException {
        try {
            AbstractDiagUserConnector diagUser = getDiagUserConnector();

            if (!diagUser.autorize()) {
                LOGGER.warn("autorisation refusee pour '{}' pour l'application '{}'", diagUser.getUserName(), applicationId);
                throw new AutorisationException(
                        "autorisation refusee pour '" + diagUser.getUserName() + "' pour l'application '" + applicationId + "'");
            }

            LOGGER.info("autorisation acceptee pour '{}' pour l'application '{}'", diagUser.getUserName(), applicationId);
        } catch (DiagUserException ex) {
            throw new DiagUserException(ex);
        }
    }
}
