package com.inetpsa.o8d.a2dr.strategie;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.a2dr.exception.AuthentificationException;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.DiagUserFactory;

/**
 * La classe AssimilerOI est une strategie qui s'applique uniquement aux utilisateurs assimiler Operateur Independant. Repose sur l'implementation
 * d'acces d'un Operateur Independant du diagUser
 * 
 * @author e300260
 */
public class AssimilerOI extends AbstractStrategie {

    /**
     * Constructeur par defaut.
     * 
     * @param strat strategie.
     */
    public AssimilerOI(AbstractStrategie strat) {
        super(strat);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.AbstractStrategie#execute(com.inetpsa.o8d.diaguser.DiagUserCredentials, java.lang.String)
     */
    @Override
    // CAP-26498:DiagLot2-Passing server name in parameter
    protected void execute(DiagUserCredentials credentials, String applicationId, String hostName) throws DiagUserException, BusinessException {
        String username = credentials.getUserName();
     // checkmarx fixed
        if ((username == null) || (credentials.getPassword() == null)) {
            throw new AuthentificationException("le login ou le password de la BasicAuth est 'null'");
        }

        AbstractDiagUserConnector diagUser = DiagUserFactory.getInstance().getDiagUserConnectorInstance(credentials, hostName);
        if (diagUser == null) {
            throw new AuthentificationException("Le connecteur DiagUser est null");
        }
        // une exception est levee lorsque le type d'utilisateur n'est pas un OI
    }
}
