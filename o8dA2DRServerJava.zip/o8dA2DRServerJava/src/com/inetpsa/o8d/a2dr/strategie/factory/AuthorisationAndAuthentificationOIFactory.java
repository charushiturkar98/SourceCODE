package com.inetpsa.o8d.a2dr.strategie.factory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.AssimilerOI;
import com.inetpsa.o8d.a2dr.strategie.Authentifier;
import com.inetpsa.o8d.a2dr.strategie.Autoriser;

/**
 * La classe AuthorisationAndAuthentificationOIFactory construit la strategie permettant l'acces aux operateurs independants authentifies disposant
 * d'une autorisation pour utiliser l'application.
 * 
 * @author e300260
 */
public class AuthorisationAndAuthentificationOIFactory implements StrategieFactory {

    /** instance singleton */
    private static final AuthorisationAndAuthentificationOIFactory INSTANCE = new AuthorisationAndAuthentificationOIFactory();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory#createStrategie()
     */
    @Override
    public AbstractStrategie createStrategie() {
        AbstractStrategie strategie = new Autoriser(null);
        strategie = new Authentifier(strategie);
        strategie = new AssimilerOI(strategie);
        return strategie;
    }

    /**
     * Methode getInstance.
     * 
     * @return intance de la factory.
     */
    public static AuthorisationAndAuthentificationOIFactory getInstance() {
        return INSTANCE;
    }
}
