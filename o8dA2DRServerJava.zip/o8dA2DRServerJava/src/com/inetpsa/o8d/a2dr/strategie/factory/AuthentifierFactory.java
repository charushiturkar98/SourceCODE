package com.inetpsa.o8d.a2dr.strategie.factory;

import com.inetpsa.o8d.a2dr.strategie.AbstractStrategie;
import com.inetpsa.o8d.a2dr.strategie.Authentifier;

/**
 * Classe Factory pour la strategie d'authentification Elle permet l'acces aux utilisateurs authentifies.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class AuthentifierFactory implements StrategieFactory {
    /** instance singleton */
    private static final AuthentifierFactory INSTANCE = new AuthentifierFactory();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory#createStrategie()
     */
    @Override
    public AbstractStrategie createStrategie() {
        AbstractStrategie strategie = new Authentifier(null);

        return strategie;
    }

    /**
     * Methode getInstance.
     * 
     * @return intance de la factory.
     */
    public static AuthentifierFactory getInstance() {
        return INSTANCE;
    }
}
