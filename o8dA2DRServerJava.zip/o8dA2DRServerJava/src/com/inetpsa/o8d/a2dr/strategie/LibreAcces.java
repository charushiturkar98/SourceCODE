package com.inetpsa.o8d.a2dr.strategie;

import com.inetpsa.fwk.exception.BusinessException;
import com.inetpsa.o8d.diaguser.DiagUserCredentials;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Classe faisant partie du Design pattern Decorator. Elle implemente la strategie d'authentification de libre acces.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class LibreAcces extends AbstractStrategie {

    /**
     * Constructeur par defaut.
     * 
     * @param strat strategie anterieur.
     */

    public LibreAcces(AbstractStrategie strat) {
        super(strat);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.a2dr.strategie.AbstractStrategie#execute(com.inetpsa.o8d.diaguser.DiagUserCredentials, java.lang.String)
     */
    @Override
    protected void execute(DiagUserCredentials credentials, String applicationId, String hostName) throws BusinessException, DiagUserException {
        // nothing to do :)
    }
}
