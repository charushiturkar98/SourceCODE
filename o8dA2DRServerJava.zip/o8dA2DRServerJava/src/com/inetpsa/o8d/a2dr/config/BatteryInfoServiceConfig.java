/*
 * Creation : 16 Mar 2022
 */
/**
 * 
 */
package com.inetpsa.o8d.a2dr.config;

/**
 * The Class BatteryInfoBean.
 *
 * @author E543118
 */
public class BatteryInfoServiceConfig {

    /** The access token url. */
    private String accessTokenURL;

    /** The client id. */
    private String clientId;

    /** The client secret. */
    private String clientSecret;

    /** The stagging url. */
    private String staggingUrl;

    /** The user name. */
    private String userName;

    /** The password. */
    private String password;

    /**
     * Getter staggingUrl.
     *
     * @return the staggingUrl
     */
    public String getStaggingUrl() {
        return staggingUrl;
    }

    /**
     * Setter staggingUrl.
     *
     * @param staggingUrl the staggingUrl to set
     */
    public void setStaggingUrl(String staggingUrl) {
        this.staggingUrl = staggingUrl;
    }

    /**
     * Getter accessTokenURL.
     *
     * @return the accessTokenURL
     */
    public String getAccessTokenURL() {
        return accessTokenURL;
    }

    /**
     * Setter accessTokenURL.
     *
     * @param accessTokenURL the accessTokenURL to set
     */
    public void setAccessTokenURL(String accessTokenURL) {
        this.accessTokenURL = accessTokenURL;
    }

    /**
     * Getter clientId.
     *
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Setter clientId.
     *
     * @param clientId the clientId to set
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Getter clientSecret.
     *
     * @return the clientSecret
     */
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Setter clientSecret.
     *
     * @param clientSecret the clientSecret to set
     */
    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    /**
     * Getter userName.
     *
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Setter userName.
     *
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Getter password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter password.
     *
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

}
