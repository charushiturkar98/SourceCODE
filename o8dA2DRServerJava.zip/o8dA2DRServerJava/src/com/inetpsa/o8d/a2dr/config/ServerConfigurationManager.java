package com.inetpsa.o8d.a2dr.config;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang3.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.a2dr.beans.AuthenticationBean;
import com.inetpsa.o8d.a2dr.beans.ProxyBean;
import com.inetpsa.o8d.a2dr.beans.RelayAccessConfigurationBean;
import com.inetpsa.o8d.a2dr.beans.ServerConfiguration;
import com.inetpsa.o8d.a2dr.security.AesEncDec;
import com.inetpsa.o8d.a2dr.strategie.factory.StrategieFactory;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Classe qui gere la configuration du serveur.
 * 
 * @author e331258
 */
public final class ServerConfigurationManager {

    /** log de la classe. */
    private static final Logger LOGGER = LoggerFactory.getLogger(ServerConfigurationManager.class);

    /** instance singleton. */
    private static final ServerConfigurationManager INSTANCE = new ServerConfigurationManager();

    /**
     * Alias DB � utiliser.
     */
    private String jcdAlias;
    /**
     * Compte technique du serveur.
     */
    private AuthenticationBean serverAccount;
    // CAP-25454: START
    /** Serav technical account. */
    private AuthenticationBean serav;

    /** Portfolio technical account. */
    private AuthenticationBean portfolio;

    /** CampaignCode & getInfoVehicule technical account. */
    private AuthenticationBean corvet;

    /** Unlocking Bsrf technical account. */
    private AuthenticationBean seravUl;

    /** Ediag technical account. */
    private AuthenticationBean ediag;

    /** Repps technical account. */
    private AuthenticationBean repps;
    // CAP-25454: END
    /**
     * Account associated with Repps.
     */
    private AuthenticationBean argos;
    // CAP-26498: START-Lot2
    /** Serav technical account for RI/OI. */
    private AuthenticationBean seravRi; // Sonar issue fix
    // CAP-26498: END-
    // CAP-28735: x250-Lot2
    /** Witexedi technical account. */
    private AuthenticationBean witexedi; // Sonar issue fix

    /**
     * Getter witexedi.
     *
     * @return the witexedi
     */
    public AuthenticationBean getWitexediAccount() {
        return witexedi;
    }

    /**
     * Getter ArgosAccount.
     *
     * @return the ArgosAccount
     */
    public AuthenticationBean getArgosAccount() {
        return argos;
    }

    /**
     * Proxy.
     */
    private ProxyBean proxy;
    /**
     * Configuration des acc�s aux relais, index� par nom d'application.
     */
    // sonar issue fix
    private Map<String, RelayAccessConfigurationBean> relayAccessConfigurations = new HashMap<>();

    /** The variable mappings. */
    private Map<String, String> variableMappings;
    /**
     * Configuration des mappings applicationId/fabrique de strat�gie.
     */
    private Map<String, StrategieFactory> strategyMappings;

    /**
     * Retourne l'instance singleton.
     * 
     * @return instance du ConfLoader.
     */
    public static ServerConfigurationManager getInstance() {
        return INSTANCE;
    }

    /**
     * Methode qui charge un fichier properties en memoire.
     * 
     * @param configurationFilename nom du fichier de configuration
     * @throws DiagUserException en cas de probl�me.
     * @throws IOException       IOexception
     */
    public void init(String configurationFilename) throws DiagUserException, IOException {
        ServerConfiguration xmlServerConfiguration;
        InputStream is = null;
        try {
            JAXBContext serverConfigurationJaxbContext = JAXBContext.newInstance(ServerConfiguration.class);
            Unmarshaller unmarshaller = serverConfigurationJaxbContext.createUnmarshaller();

            is = Thread.currentThread().getContextClassLoader().getResourceAsStream(configurationFilename);

            if (is == null) {
                throw new DiagUserException("Erreur chargement du fichier " + configurationFilename + " : Not found in classpath");
            }

            xmlServerConfiguration = (ServerConfiguration) unmarshaller.unmarshal(is);

        } catch (JAXBException e) {
            throw new DiagUserException("Error during configuration", e);
        } finally {
            // CAP-29321 Closing Streams
            if (is != null)
                is.close();
        }

        jcdAlias = xmlServerConfiguration.getJcdAlias();

        serverAccount = xmlServerConfiguration.getServerAccount();
        // CAP-25017 Decoding server account values(only password)
        serverAccount.setLogin(AesEncDec.decrypt(serverAccount.getLogin()));
        serverAccount.setPassword(AesEncDec.decrypt(serverAccount.getPassword()));

        // CAP-25454:start
        serav = xmlServerConfiguration.getSeravAccount();
        // Decoding serav account values(only password)
        serav.setLogin(AesEncDec.decrypt(serav.getLogin()));
        serav.setPassword(AesEncDec.decrypt(serav.getPassword()));

        portfolio = xmlServerConfiguration.getPortfolioAccount();
        // Decoding portfolio account values(only password)
        portfolio.setLogin(AesEncDec.decrypt(portfolio.getLogin()));
        portfolio.setPassword(AesEncDec.decrypt(portfolio.getPassword()));

        corvet = xmlServerConfiguration.getCorvetAccount();
        // Decoding campaignCode & getInfoVehicule account values(only password)
        corvet.setLogin(AesEncDec.decrypt(corvet.getLogin()));
        corvet.setPassword(AesEncDec.decrypt(corvet.getPassword()));

        argos = xmlServerConfiguration.getArgosAccount();
        // Decoding campaignCode & getInfoVehicule account values(only password)
        argos.setLogin(AesEncDec.decrypt(argos.getLogin()));
        argos.setPassword(AesEncDec.decrypt(argos.getPassword()));
        // CAP-28735:x250 lot 2
        witexedi = xmlServerConfiguration.getWitexedi();
        witexedi.setLogin(AesEncDec.decrypt(witexedi.getLogin()));
        witexedi.setPassword(AesEncDec.decrypt(witexedi.getPassword()));

        seravUl = xmlServerConfiguration.getUnlockingBsrfAccount();
        // Decoding UnlockingBsrf account values(only password)
        seravUl.setLogin(AesEncDec.decrypt(seravUl.getLogin()));
        seravUl.setPassword(AesEncDec.decrypt(seravUl.getPassword()));

        ediag = xmlServerConfiguration.getEdiagAccount();
        // Decoding ediag account values(only password)
        ediag.setLogin(AesEncDec.decrypt(ediag.getLogin()));
        ediag.setPassword(AesEncDec.decrypt(ediag.getPassword()));

        repps = xmlServerConfiguration.getReppsAccount();
        // Decoding repps account values(only password)
        repps.setLogin(AesEncDec.decrypt(repps.getLogin()));
        repps.setPassword(AesEncDec.decrypt(repps.getPassword()));
        // CAP-25454:end

        // CAP-26498:start-lot2: //Sonar issue fix
        seravRi = xmlServerConfiguration.getSeravRIAccount();
        // Decoding serav account values(only password)-RI/OI
        seravRi.setLogin(AesEncDec.decrypt(seravRi.getLogin()));
        seravRi.setPassword(AesEncDec.decrypt(seravRi.getPassword()));
        // CAP-26498:end
        proxy = xmlServerConfiguration.getProxy();

        List<RelayAccessConfigurationBean> relais = xmlServerConfiguration.getRelayAccessConfigurations();

        StringBuilder sb = new StringBuilder("Relais disponibles :");

        for (RelayAccessConfigurationBean relay : relais) {
            relayAccessConfigurations.put(relay.getApplicationName(), relay);

            sb.append("\n").append(relay.getApplicationName()).append(" :\n");
            sb.append("\tactive = ").append(relay.isActive()).append("\n");
            sb.append("\ttype = ").append(relay.getType()).append("\n");
            sb.append("\tapplicationId = ").append(relay.getApplicationId()).append("\n");
            sb.append("\tscheme = ").append(relay.getScheme()).append("\n");
            sb.append("\thostname = ").append(relay.getHostname()).append("\n");
            sb.append("\tport = ").append(relay.getPort()).append("\n");
            sb.append("\tuseProxy = ").append(relay.isUseProxy()).append("\n");
            sb.append("\tforwardCredentials = ").append(relay.isForwardCredentials()).append("\n");
        }
        // sonar issue fix
        String sbStr = sb.toString();
        if (LOGGER.isInfoEnabled())
            LOGGER.info("{}", sbStr);
        sb.setLength(0); // CAP-29321 Resetting StringBuilder to null
        Map<String, String> tempMap = xmlServerConfiguration.getStrategyMappings();
        // sonar issue fix
        strategyMappings = new HashMap<>();

        for (Entry<String, String> strategyEntry : tempMap.entrySet()) {
            StrategieFactory strategieFactory = (StrategieFactory) invokeGetInstanceMethod(strategyEntry.getValue());
            strategyMappings.put(strategyEntry.getKey(), strategieFactory);

            LOGGER.info("applicationId strategy mapping added : {}/{}", strategyEntry.getKey(), strategieFactory.getClass().getName());
        }

        Map<String, String> tempVarMap = xmlServerConfiguration.getVariableMapping();
        // sonar issue fix
        variableMappings = new HashMap<>();

        for (Entry<String, String> variableEntry : tempVarMap.entrySet()) {
            variableMappings.put(variableEntry.getKey(), variableEntry.getValue());

            LOGGER.info("Variable key/value pair : {}/{}", variableEntry.getKey(), variableEntry.getValue());
        }
    }

    /**
     * invoque la methode de classe 'getInstance'.
     * 
     * @param className nom de la classe.
     * @return objet de retour qui est en regle generale du m�me type que la classe 'className'
     * @throws DiagUserException en cas de probleme.
     */
    private static Object invokeGetInstanceMethod(String className) throws DiagUserException {
        try {
            return MethodUtils.invokeStaticMethod(Class.forName(className), "getInstance", null);
            // sonar issue fixed : Combined this catch with the one which has the same body
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException e) {
            throw new DiagUserException(e);
        }
    }

    /**
     * Getter jcdAlias.
     *
     * @return the jcdAlias
     */
    public String getJcdAlias() {
        return jcdAlias;
    }

    /**
     * Getter serverAccount.
     *
     * @return the serverAccount
     */
    public AuthenticationBean getServerAccount() {
        return serverAccount;
    }

    // CAP-25454:start
    /**
     * Getter seravAccount.
     *
     * @return the seravAccount
     */
    public AuthenticationBean getSeravAccount() {
        return serav;
    }

    /**
     * Getter portfolioAccount.
     *
     * @return the portfolioAccount
     */
    public AuthenticationBean getPortfolioAccount() {
        return portfolio;
    }

    /**
     * Getter campaignCodeAccount/getInfoVehicule.
     *
     * @return the campaignCodeAccount/getInfoVehicule
     */
    public AuthenticationBean getCorvetAccount() {
        return corvet;
    }

    /**
     * Getter unlockingBsrfAccount.
     *
     * @return the unlockingBsrfAccount
     */
    public AuthenticationBean getUnlockingBsrfAccount() {
        return seravUl;
    }

    /**
     * Getter ediagAccount.
     *
     * @return the ediagAccount
     */
    public AuthenticationBean getEdiagAccount() {
        return ediag;
    }

    /**
     * Getter reppsAccount.
     *
     * @return the reppsAccount
     */
    public AuthenticationBean getReppsAccount() {
        return repps;
    }

    // CAP-25454:end
    // CAP-25454:start
    /**
     * Getter seravAccount.
     *
     * @return the seravAccount
     */
    public AuthenticationBean getSeravRIAccount() {
        return seravRi; // Sonar issue fix
    }

    /**
     * Getter proxy.
     *
     * @return the proxy
     */
    public ProxyBean getProxy() {
        return proxy;
    }

    /**
     * Retourne la configuration du relais pour l'application.
     * 
     * @param applicationName nom de l'application
     * @return configuration du relais
     */
    public RelayAccessConfigurationBean getRelayAccessConfiguration(String applicationName) {
        final RelayAccessConfigurationBean relayAccessConfigurationBean = relayAccessConfigurations.get(applicationName);
        if (relayAccessConfigurationBean != null && relayAccessConfigurationBean.isActive()) {
            return relayAccessConfigurationBean;
        }

        return null;
    }

    /**
     * Retourne la fabrique de strat�gie associ�e � l'identifiant d'application.
     * 
     * @param applicationId l'identifiant d'application
     * @return la fabrique de strat�gie
     */
    public StrategieFactory getStrategieFactory(String applicationId) {
        return strategyMappings.get(applicationId);
    }

    /**
     * Returns the application id variable mapping value.
     *
     * @param applicationId the application id
     * @return application value
     */

    public String getVariableValue(String applicationId) {
        return variableMappings.get(applicationId);
    }

}
