package com.inetpsa.o8d.a2dr.security;

/**
 * Exception lors de l'utilisation du password manager.
 * 
 * @author E331258
 */
public class PasswordManagerException extends Exception {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 1157059118671702572L;

    /**
     * Constructeur.
     * 
     * @param message message de l'exception
     * @param cause cause de l'exception
     */
    public PasswordManagerException(String message, Throwable cause) {
        super(message, cause);
    }
}
