package com.inetpsa.o8d.a2dr.security;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

/**
 * Gestionnaire de mots de passe.
 * 
 * @author E331258s
 */
public class PasswordManager {

    /**
     * Algorithm HMAC.
     */
    private static final String HMAC_ALGORITHM = "HmacSHA512";
    /**
     * Charset UTF-8.
     */
    private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
    /**
     * Masque de calcul.
     */
    private static final int MASK = 0xff;
    /**
     * Nombre d'octets pour l'algorithme de d�rivation.
     */
    private static final int DERIVE_ALGO_BYTES = 4;
    /**
     * Decalages pour chaque position.
     */
    private static final int[] DECALAGES_PAR_POSITION = { 24, 16, 8 };
    /**
     * Nombre de bits par octet.
     */
    private static final int BITS_PER_BYTE = 8;
    /**
     * Taille du sel.
     */
    private static final int SALT_SIZE = 16;
    /**
     * Taille du sel en hexa.
     */
    private static final int HEX_SALT_SIZE = SALT_SIZE * 2;
    /**
     * Milieu du sel en hexa.
     */
    private static final int HEX_SALT_MIDDLE = HEX_SALT_SIZE / 2;
    /**
     * Algorithme de sel par d�faut.
     */
    private static final String DEFAULT_SALT_ALGORITHM = "SHA1PRNG";
    /**
     * Nombre de bits par d�faut pour l'encodage.
     */
    private static final int DEFAULT_ENCODING_BITS_NB = 64 * BITS_PER_BYTE;
    /**
     * Nombre d'it�rations par d�faut.
     */
    private static final int DEFAULT_ITERATIONS_NB = 20000;

    /**
     * Algorithme de sel.
     */
    private String saltAlgorithm = DEFAULT_SALT_ALGORITHM;
    /**
     * Nombre de bits pour l'encodage.
     */
    private int encodingBitsNb = DEFAULT_ENCODING_BITS_NB;
    /**
     * Nombre d'it�rations.
     */
    private int iterationsNb = DEFAULT_ITERATIONS_NB;

    /**
     * Setter saltAlgorithm
     * 
     * @param saltAlgorithm the saltAlgorithm to set
     */
    public void setSaltAlgorithm(String saltAlgorithm) {
        this.saltAlgorithm = saltAlgorithm;
    }

    /**
     * Setter encodingBitsNb
     * 
     * @param encodingBitsNb the encodingBitsNb to set
     */
    public void setEncodingBitsNb(int encodingBitsNb) {
        this.encodingBitsNb = encodingBitsNb;
    }

    /**
     * Setter iterationsNb
     * 
     * @param iterationsNb the iterationsNb to set
     */
    public void setIterationsNb(int iterationsNb) {
        this.iterationsNb = iterationsNb;
    }

    /**
     * G�n�ration du mot de passe encod�.
     * 
     * @param plainTextPassword mot de passe en clair
     * @return mot de passe encod�
     * @throws PasswordManagerException si une erreur survient
     */
    public String generateStrongPasswordHash(String plainTextPassword) throws PasswordManagerException {
        byte[] salt = getSalt();

        byte[] derivedKey = getDerivedKey(plainTextPassword, salt, encodingBitsNb);

        return buildEncodedPasswordString(salt, derivedKey);
    }

    /**
     * Construction de la chaine finale
     * 
     * @param salt       le sel
     * @param derivedKey la cl�
     * @return chaine finale
     */
    private String buildEncodedPasswordString(byte[] salt, byte[] derivedKey) {
        String hexSalt = Hex.encodeHexString(salt);

        StringBuilder passwordHash = new StringBuilder();

        passwordHash.append(StringUtils.substring(hexSalt, HEX_SALT_MIDDLE));
        passwordHash.append(Hex.encodeHexString(derivedKey));
        passwordHash.append(StringUtils.substring(hexSalt, 0, HEX_SALT_MIDDLE));

        return passwordHash.toString();
    }

    /**
     * Validation d'un mot de passe en clair par rapport � un mot de passe encod�.
     * 
     * @param plainTextPassword le mot de passe en clair
     * @param encodedPassword   le mot de passe encod�
     * @return vrai si le mot de passe encod� correspond, faux sinon
     * @throws PasswordManagerException si une erreur survient
     */
    public boolean validatePassword(String plainTextPassword, String encodedPassword) throws PasswordManagerException {

        int saltIndex = encodedPassword.length() - HEX_SALT_MIDDLE;

        StringBuilder hexSaltBuffer = new StringBuilder();
        hexSaltBuffer.append(StringUtils.substring(encodedPassword, saltIndex));
        hexSaltBuffer.append(StringUtils.substring(encodedPassword, 0, HEX_SALT_MIDDLE));
        String hexSalt = hexSaltBuffer.toString();

        byte[] salt;
        byte[] encoded;
        try {
            salt = Hex.decodeHex(hexSalt.toCharArray());
            encoded = Hex.decodeHex(StringUtils.substring(encodedPassword, HEX_SALT_MIDDLE, saltIndex).toCharArray());
        } catch (DecoderException e) {
            throw new PasswordManagerException("Error during hex decoding", e);
        } finally {
            hexSaltBuffer.setLength(0); // CAP-29321 Resetting StringBuilder to null
        }

        byte[] testHash = getDerivedKey(plainTextPassword, salt, encoded.length * BITS_PER_BYTE);

        int diff = encoded.length ^ testHash.length;

        for (int i = 0; i < encoded.length && i < testHash.length; i++) {
            diff |= encoded[i] ^ testHash[i];
        }
        return diff == 0;
    }

    /**
     * G�n�ration d'un sel.
     * 
     * @return le sel
     * @throws PasswordManagerException si une erreur survient
     */
    private byte[] getSalt() throws PasswordManagerException {
        SecureRandom sr;
        try {
            sr = SecureRandom.getInstance(saltAlgorithm);
        } catch (NoSuchAlgorithmException e) {
            throw new PasswordManagerException("Error during salt generator init", e);
        }
        byte[] salt = new byte[SALT_SIZE];
        sr.nextBytes(salt);
        return salt;
    }

    /**
     * Encodage (PBKDF2).
     * 
     * @param str             chaine en clair
     * @param salt            sel
     * @param keyLengthInBits nombre de bits d'encodage
     * @return les octets encod�s
     * @throws PasswordManagerException si une erreur survient
     */
    private byte[] getDerivedKey(String str, byte[] salt, int keyLengthInBits) throws PasswordManagerException {
        byte[] bytes = getUTF8Bytes(str);

        int keyLength = keyLengthInBits / BITS_PER_BYTE;
        byte[] key = new byte[keyLength];

        try {
            Mac prf = Mac.getInstance(HMAC_ALGORITHM);
            SecretKey macKey = new SecretKeySpec(bytes, prf.getAlgorithm());
            prf.init(macKey);

            int hlen = prf.getMacLength();
            int intL = (keyLength + hlen - 1) / hlen; // ceiling
            int intR = keyLength - (intL - 1) * hlen; // residue
            byte[] ui = new byte[hlen];
            byte[] ti = new byte[hlen];
            byte[] ibytes = new byte[DERIVE_ALGO_BYTES];

            for (int i = 1; i <= intL; i++) {
                prf.update(salt);

                int indice = DERIVE_ALGO_BYTES - 1;
                ibytes[indice] = (byte) i;

                while (indice > 0) {
                    indice--;
                    ibytes[indice] = (byte) ((i >> DECALAGES_PAR_POSITION[indice]) & MASK);
                }

                prf.update(ibytes);
                prf.doFinal(ui, 0);

                System.arraycopy(ui, 0, ti, 0, ui.length);

                for (int j = 2; j <= iterationsNb; j++) {
                    prf.update(ui);
                    prf.doFinal(ui, 0);
                    // XOR the intermediate Ui's together.
                    for (int k = 0; k < ui.length; k++) {
                        ti[k] ^= ui[k];
                    }
                }

                if (i == intL) {
                    System.arraycopy(ti, 0, key, (i - 1) * hlen, intR);
                } else {
                    System.arraycopy(ti, 0, key, (i - 1) * hlen, hlen);
                }
            }
        } catch (GeneralSecurityException e) {
            throw new PasswordManagerException("Error deriving PBKDF2 keys", e);
        }

        return key;
    }

    /**
     * Caract�res UTF-8 de la chaine.
     * 
     * @param str chaine
     * @return utf-8
     */
    private static byte[] getUTF8Bytes(String str) {
        CharBuffer cb = CharBuffer.wrap(str);
        ByteBuffer bb = UTF8_CHARSET.encode(cb);
        int len = bb.limit();
        byte[] passwdBytes = new byte[len];
        bb.get(passwdBytes, 0, len);
        return passwdBytes;
    }
}
