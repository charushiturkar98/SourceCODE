/*
 * Creation : 12 Oct 2021
 */
package com.inetpsa.o8d.diagcloud.token.util;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import com.inetpsa.o8d.diagcloud.token.beans.TokenPayloadBean;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.MetaDataRepository;

import junit.framework.TestCase;

/**
 * The Class TokenAuthorisationUtilTest.
 */
public class TokenAuthorisationUtilTest extends TestCase {

    /** The Constant logger. */
    protected final static Log logger = LogFactory.getFactory().getInstance(TokenAuthorisationUtilTest.class);

    /** The application id. */
    public String applicationId = "ODW.WEBDIAG";

    /** The token authorisation uti. */
    TokenAuthorisationUtil tokenAuthorisationUti = new TokenAuthorisationUtil();

    /**
     * Test check token authorisation positive negative.
     *
     * @throws DiagUserException the diag user exception
     */
    @Test
    public void testCheckTokenAuthorisationPositiveNegative() throws DiagUserException {
        String listObject = "SER.APV_PRE_PROD_RESEAU_OV,OUG.GARAGE,SER.APV_RESEAU_OV_PROD";
        MetaDataRepository.getInstance().init();
        try {
            assertTrue(tokenAuthorisationUti.checkTokenAuthorisation(Arrays.asList(StringUtils.split(listObject, ",")), applicationId));
        } catch (TokenInvalidException e) {
            logger.info("Invalid Token:No Roles Matched:" + e);
        }
    }

    /**
     * Test check token authorisation.
     *
     * @throws DiagUserException the diag user exception
     */
    @Test
    public void testCheckTokenAuthorisation() throws DiagUserException {
        String listObject = "SER.APV_PRE_PROD_RESEAU_OV,SER.APV_RESEAU_OV_PROD";
        MetaDataRepository.getInstance().init();
        try {
            assertFalse(tokenAuthorisationUti.checkTokenAuthorisation(Arrays.asList(StringUtils.split(listObject, ",")), applicationId));
        } catch (TokenInvalidException e) {
            logger.info("Invalid Token:No Roles Matched:" + e);
        }
    }

    /**
     * Test convert roles data type.
     *
     * @throws TokenInvalidException the invalid token exception
     */
    @Test
    public void testConvertRolesDataType() throws TokenInvalidException {
        TokenPayloadBean payload = new TokenPayloadBean();
        ArrayList<String> listObject = new ArrayList<>();
        listObject.add("SER.APV_PRE_PROD_RESEAU_OV");
        listObject.add("OUG.GARAGE");
        listObject.add("SER.APV_RESEAU_OV_PROD");
        payload.setRoles(listObject);
        assertNotNull(tokenAuthorisationUti.convertRolesDataType(payload));
    }
}
