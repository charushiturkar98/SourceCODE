/*
 * Creation : 11 Oct 2021
 */
package com.inetpsa.o8d.diagcloud.token.service.impl;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diaguser.DiagUserException;

import junit.framework.TestCase;

/**
 * The Class TokenServiceImplTest.
 */
public class TokenServiceImplTest extends TestCase {

    /** The Constant logger. */
    protected final static Log logger = LogFactory.getFactory().getInstance(TokenServiceImplTest.class);

    /**
     * Test get IDP service data.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Test
    public void test200GetIDPServiceData() throws IOException {

        TokenServiceImpl tokenServiceImpl = new TokenServiceImpl();
        try {
            ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
        } catch (DiagUserException e) {
            logger.info("The Response code received:" + e);
        }
        assertEquals(200, tokenServiceImpl.getIDPServiceData(new StringBuilder()));
    }

}
