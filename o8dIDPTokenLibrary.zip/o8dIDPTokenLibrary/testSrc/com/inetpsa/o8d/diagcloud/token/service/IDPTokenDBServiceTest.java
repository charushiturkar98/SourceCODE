/*
 * Creation : 14 Oct 2021
 */
package com.inetpsa.o8d.diagcloud.token.service;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.security.beans.User;
import com.inetpsa.fwk.service.ServiceFactory;
import com.inetpsa.o8d.a2dr.beans.UserA2DR;
import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diagcloud.token.beans.TokenPojo;
import com.inetpsa.o8d.diagcloud.token.util.TokenConstants;

import junit.framework.TestCase;

public class IDPTokenDBServiceTest extends TestCase {

    @Override
    protected void setUp() throws Exception {
        ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
    }

    public void testExecuteEmpty() {
        TokenIDPDBBusinessService iDPTokenDBService = null;

        TokenPojo token = new TokenPojo();
        token.setDbFetchType(TokenConstants.DB_FETCH_TYPE_RETRIEVE);
        try {
            iDPTokenDBService = (TokenIDPDBBusinessService) ServiceFactory.getInstance().getService((User) null,
                    TokenIDPDBBusinessService.SERVICE_NAME);
            iDPTokenDBService.setInput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE, token);
            iDPTokenDBService.execute();

            assertNull(iDPTokenDBService.getOutput(UserA2DR.USER_INFORMATION_KEY_FOR_SERVICE));
        } catch (FwkException e) {
            e.printStackTrace();
            fail(e.getMessage());
        } finally {
            if (iDPTokenDBService != null) {
                try {
                    iDPTokenDBService.close();
                } catch (FwkException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}