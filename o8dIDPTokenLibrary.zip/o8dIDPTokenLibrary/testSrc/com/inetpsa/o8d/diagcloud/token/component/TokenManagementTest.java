/*
 * Creation : 13 Oct 2021
 */
package com.inetpsa.o8d.diagcloud.token.component;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * The Class TokenManagementTest.
 */
public class TokenManagementTest {

    /** The token. */
    TokenManagement token = new TokenManagement();

    /** The logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /** The Constant encodedToken. */
    public static final String encodedToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjIzOHoifQ.ewogICJzY29wZSI6ICJvcGVuaWQgcHJkOm91ZyIsCiAgImNsaWVudF9pZCI6ICJaWkhCWUpGQkRPSktNSUNJR09QU1BYS09PVE9MSlFQQyIsCiAgInJyZGkiOiAiWENQREcyMSIsCiAgImNvdW50cnkiOiAiREUiLAogICJicmFuZCI6ICJBQyIsCiAgInJvbGVzIjogWwogICAgIlNFUi5BUFZfUFJFX1BST0RfUkVTRUFVX09WIiwKICAgICJPVUcuR0FSQUdFIiwKICAgICJTRVIuQVBWX1JFU0VBVV9PVl9QUk9EIgogIF0sCiAgInVzZXJuYW1lIjogIk0wMDU2MzIwIiwKICAiZXhwIjogMTYzNTc0MTkwMwp9.g_rPY1QJOf6XSsUj5QmXSMrMPG_Ss_zDnW-By3tfkvtIIA09yT2N7mUaC-GZYi-zStGp4HwTDBM-3nM2i6H6cNZ5P6bI2xRlihcC5T5bdvkUK0eK1uhE71D092TbUSrCHiIhN3e2RNR7cPL0qEF3yZ5VlS-vfdp_AyzbyIKmjYklxQgvaRf91xkmgCHjK-1aigDlBpmedzvUZpw9rxULqei2tpRS4zg_utX79PCQ_TaYfhYSsgxdHCraeyl_umX-Pufy7d_vI6r9_Zf6dyAQFoy0A6n3h6jUNrz6cVSjE80i-Zxd-X9ELiWfrzMoR0ob8F86xd2NYWPNxvAdS57KmA";

    /** The Constant actualToken. */
    public static final String actualToken = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjIzOHoifQ.eyJzY29wZSI6Im9wZW5pZCBwcmQ6b3VnIiwiY2xpZW50X2lkIjoiWlpIQllKRkJET0pLTUlDSUdPUFNQWEtPT1RPTEpRUEMiLCJycmRpIjoiWENQREcyMSIsImNvdW50cnkiOiJERSIsImJyYW5kIjoiQUMiLCJyb2xlcyI6Ik9VRy5HQVJBR0UiLCJ1c2VybmFtZSI6Ik0wMDU2MzIwIiwiZXhwIjoxNjMwMzIzNzE0fQ.g_rPY1QJOf6XSsUj5QmXSMrMPG_Ss_zDnW-By3tfkvtIIA09yT2N7mUaC-GZYi-zStGp4HwTDBM-3nM2i6H6cNZ5P6bI2xRlihcC5T5bdvkUK0eK1uhE71D092TbUSrCHiIhN3e2RNR7cPL0qEF3yZ5VlS-vfdp_AyzbyIKmjYklxQgvaRf91xkmgCHjK-1aigDlBpmedzvUZpw9rxULqei2tpRS4zg_utX79PCQ_TaYfhYSsgxdHCraeyl_umX-Pufy7d_vI6r9_Zf6dyAQFoy0A6n3h6jUNrz6cVSjE80i-Zxd-X9ELiWfrzMoR0ob8F86xd2NYWPNxvAdS57KmA";
    /** The application id. */
    public String applicationId = "ODW.WEBDIAG";

    /**
     * Test call and validate IDP service.
     */
    @Test
    public void testCallAndValidateIDPService() {
        try {
            ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
            token.callAndValidateIDPService(encodedToken);
        } catch (TokenInvalidException e) {
            logger.info("Invalid Token:Error while validating the IDP token" + e);
        } catch (DiagUserException e) {
            logger.info("Invalid Token:Error while fecting data from config file" + e);
        }
    }

    /**
     * Test get token info.
     */
    @Test
    public void testGetTokenInfo() {
        try {
            ServerConfigurationManager.getInstance().init("a2dr_server_configuration_test.xml");
            token.getTokenInfo(null, actualToken, applicationId);
        } catch (DiagUserException e) {
            logger.info("Invalid Token:Error while fecting data from config file" + e);
        }
    }

}
