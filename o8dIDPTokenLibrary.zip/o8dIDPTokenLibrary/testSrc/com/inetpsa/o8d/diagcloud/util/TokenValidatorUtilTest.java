/*
 * Creation : 11 Oct 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.diagcloud.util;

import static org.junit.Assert.assertNotEquals;

import com.inetpsa.o8d.diagcloud.token.beans.TokenPayloadBean;

import junit.framework.TestCase;

public class TokenValidatorUtilTest extends TestCase {

    /**
     * Test method for {@link com.inetpsa.o8d.diagcloud.token.util.TokenValidatorUtil#userIdExpToken(com.inetpsa.o8d.diagcloud.token.beans.Token)}.
     */
    public void testUserIdForToken() {
        String expectedUserName = "M0056328";
        TokenPayloadBean payload = new TokenPayloadBean();
        payload.setUsername("M0056328");
        assertEquals(expectedUserName, payload.getUsername());
    }

    public void testExpTimeForToken() {
        long expectedExpTime = 1630322789;
        TokenPayloadBean payload = new TokenPayloadBean();
        payload.setExp(1630322789);

        assertEquals(expectedExpTime, payload.getExp());
    }

    public void testGetCurrentTime() {

        long currentEpochTime = System.currentTimeMillis() / 1000;
        long expectedCurrentTime = 1633953968;
        assertNotEquals(expectedCurrentTime, currentEpochTime);
    }
}
