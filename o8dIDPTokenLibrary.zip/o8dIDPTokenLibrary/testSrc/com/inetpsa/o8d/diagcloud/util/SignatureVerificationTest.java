/*
 * Creation : 13 Oct 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.diagcloud.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;
import org.junit.Test;

import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;
import com.inetpsa.o8d.diagcloud.token.util.SignatureVerificationUtil;

/**
 * The Class SignatureVerificationTest.
 */
public class SignatureVerificationTest {

    /** The Constant expectedEncodedToken. */
    public static final String expectedEncodedToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjRZclEzVGJxOUIyN29TM0V4S2ItaHZpSDI0dyIsInBpLmF0bSI6IjIzOHoifQ.ewogICJzY29wZSI6ICJvcGVuaWQgcHJkOm91ZyIsCiAgImNsaWVudF9pZCI6ICJaWkhCWUpGQkRPSktNSUNJR09QU1BYS09PVE9MSlFQQyIsCiAgInJyZGkiOiAiWENQREcyMSIsCiAgImNvdW50cnkiOiAiREUiLAogICJicmFuZCI6ICJBQyIsCiAgInJvbGVzIjogWwogICAgIlNFUi5BUFZfUFJFX1BST0RfUkVTRUFVX09WIiwKICAgICJPVUcuR0FSQUdFIiwKICAgICJTRVIuQVBWX1JFU0VBVV9PVl9QUk9EIgogIF0sCiAgInVzZXJuYW1lIjogIk0wMDU2MzIwIiwKICAiZXhwIjogMTYzNTc0MTkwMwp9.g_rPY1QJOf6XSsUj5QmXSMrMPG_Ss_zDnW-By3tfkvtIIA09yT2N7mUaC-GZYi-zStGp4HwTDBM-3nM2i6H6cNZ5P6bI2xRlihcC5T5bdvkUK0eK1uhE71D092TbUSrCHiIhN3e2RNR7cPL0qEF3yZ5VlS-vfdp_AyzbyIKmjYklxQgvaRf91xkmgCHjK-1aigDlBpmedzvUZpw9rxULqei2tpRS4zg_utX79PCQ_TaYfhYSsgxdHCraeyl_umX-Pufy7d_vI6r9_Zf6dyAQFoy0A6n3h6jUNrz6cVSjE80i-Zxd-X9ELiWfrzMoR0ob8F86xd2NYWPNxvAdS57KmA";

    /** The Constant logger. */
    protected final static Log logger = LogFactory.getFactory().getInstance(SignatureVerificationTest.class);

    /** The Constant responseIDP. */
    public static final String responseIDP = "{\"keys\":[{\"kty\":\"RSA\",\"kid\":\"4YrQ3Tbq9B27oS3ExKb-hviH24w\",\"use\":\"sig\",\"n\":\"3Cb42aUCeW-aOT2p1OO7S6kvoJ86ZNWaOFul55Xvpv4cQ72IvBbY5oYesUDtnjbC3eE6D-7OOvhFQWHLMYhflLK7ry5XhQy3nE2srMZXGj1Krju3M7XNCFA4ixj_eAyjho3A2Es9K4nxl5Syal5GxGA58ZdH2Ccal211hkbsIt1_E1aPKgEvkO4avtHyvoHPWfO9-dP5IfhIw7IY9slMFDtsfXPpjq_p_CwQUDUBNjH_j7GQqltDYwb8F_ONR5RreB8EXY4Oo2EnxKpSOm700wP85aLWpuHMxRLmRraBK6o-q7EGSGW-UCSWIbuEnZC-5_NdCnemC2_cdXBQSURLew\",\"e\":\"AQAB\",\"x5c\":[\"MIIFozCCBIugAwIBAgIMC4ROssOSOjsV4WXgMA0GCSqGSIb3DQEBCwUAMIGdMQswCQYDVQQGEwJGUjEOMAwGA1UEBxMFUGFyaXMxHDAaBgNVBAoTE1BTQSBQZXVnZW90IENpdHJvZW4xFzAVBgNVBAsTDjAwMDIgMzE5MTg3MzA4MSAwHgYDVQQLExdDZXJ0aWZpY2F0ZSBBdXRob3JpdGllczElMCMGA1UEAxMcUFNBIFBldWdlb3QgQ2l0cm9lbiBQcm9ncmFtczAeFw0yMDAxMjQwOTE1NTVaFw0yMjAxMjMwOTIwNTVaMGMxCzAJBgNVBAYTAkZSMQ4wDAYDVQQHDAVQYXJpczEcMBoGA1UECgwTUFNBIFBldWdlb3QgQ2l0cm9lbjERMA8GA1UECwwIUHJvZ3JhbXMxEzARBgNVBAMMCmlkZmVkX3NhbWwwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDcJvjZpQJ5b5o5PanU47tLqS+gnzpk1Zo4W6Xnle+m/hxDvYi8Ftjmhh6xQO2eNsLd4ToP7s46+EVBYcsxiF+UsruvLleFDLecTaysxlcaPUquO7cztc0IUDiLGP94DKOGjcDYSz0rifGXlLJqXkbEYDnxl0fYJxqXbXWGRuwi3X8TVo8qAS+Q7hq+0fK+gc9Z87350/kh+EjDshj2yUwUO2x9c+mOr+n8LBBQNQE2Mf+PsZCqW0NjBvwX841HlGt4HwRdjg6jYSfEqlI6bvTTA/zlotam4czFEuZGtoErqj6rsQZIZb5QJJYhu4SdkL7n810Kd6YLb9x1cFBJREt7AgMBAAGjggIaMIICFjAdBgNVHQ4EFgQULBsmX+trhyLHI5nxZp9QMRT/ExMwHwYDVR0jBBgwFoAU/MGa354KPQEYek5XAh24WoKsaTUwgckGA1UdIASBwTCBvjCBuwYKKoF6ARfOEAEBBDCBrDBhBggrBgEFBQcCAjBVMBoWE1BTQSBQZXVnZW90IENpdHJvZW4wAwIBBBo3UG9saXRpcXVlIGRlIENlcnRpZmljYXRpb24gUFNBIFBldWdlb3QgQ2l0cm9lbiBQcm9ncmFtczBHBggrBgEFBQcCARY7aHR0cDovL2luZm9jZXJ0LnBzYS1wZXVnZW90LWNpdHJvZW4uY29tL1BDX1BTQV9Qcm9ncmFtcy5wZGYwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwDgYDVR0PAQH/BAQDAgeAMB8GA1UdEQQYMBaBFHN1cHBvcnRpdGFuQG1wc2EuY29tMFkGA1UdHwRSMFAwTqBMoEqGSGh0dHA6Ly9pbmZvY2VydC5wc2EtcGV1Z2VvdC1jaXRyb2VuLmNvbS9QU0FfUGV1Z2VvdF9DaXRyb2VuX1Byb2dyYW1zLmNybDBkBggrBgEFBQcBAQRYMFYwVAYIKwYBBQUHMAKGSGh0dHA6Ly9pbmZvY2VydC5wc2EtcGV1Z2VvdC1jaXRyb2VuLmNvbS9QU0FfUGV1Z2VvdF9DaXRyb2VuX1Byb2dyYW1zLmNydDANBgkqhkiG9w0BAQsFAAOCAQEAsnX5ioQtHu/HgGFnuFm6yQ66jBCtBJEBoGA55BEUMfWgghw8s14C/yIkN9/YM3hA+bVnMuFNN1jrvoco7qabrwnNN/gUYcXkhb/2mOpQg0dtWHhl/4bBWjxvAjxJLisBDT7RLp/+GP7sZ3Fg106qoCVzxYM4j/QxJadCbvbJdQkdb3B1L22JV50BK+dYRR9dEQrQmCnvrBJq3VRJCjqNaB/kryPBnnQGopaXzZNmLHimqi/1CbG59PfKL6VNzKHq2efLPw9e65nUGD9yZD14mcYy1lGc9y6DxVIukuc1MKvEzc9emO3WLpDUTEPa8fY1iv+vjEFqVFoe86Y0T/ZtPg==\",\"MIIFoTCCBImgAwIBAgINAKeC/qxi5m5wrdCzyjANBgkqhkiG9w0BAQsFADCBmzELMAkGA1UEBhMCRlIxDjAMBgNVBAcTBVBhcmlzMRwwGgYDVQQKExNQU0EgUGV1Z2VvdCBDaXRyb2VuMRcwFQYDVQQLEw4wMDAyIDMxOTE4NzMwODEgMB4GA1UECxMXQ2VydGlmaWNhdGUgQXV0aG9yaXRpZXMxIzAhBgNVBAMTGlBTQSBQZXVnZW90IENpdHJvZW4gUmFjaW5lMB4XDTE2MDcyNzEyMzEwN1oXDTI2MDEwMTEyMzEwN1owgZ0xCzAJBgNVBAYTAkZSMQ4wDAYDVQQHEwVQYXJpczEcMBoGA1UEChMTUFNBIFBldWdlb3QgQ2l0cm9lbjEXMBUGA1UECxMOMDAwMiAzMTkxODczMDgxIDAeBgNVBAsTF0NlcnRpZmljYXRlIEF1dGhvcml0aWVzMSUwIwYDVQQDExxQU0EgUGV1Z2VvdCBDaXRyb2VuIFByb2dyYW1zMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz/l5qw++qZat78/RbyG4GCOHrPoo4TQuDAnRnqxmJxzkORu0O17lkhelYmUj8SOsC4akR04G2CukqxxBuGEgWBj5jKZk+tkPM+JPBF4d9uTnSSmGYmiyCbkffVzEWFnAeZIFpZZL3P/oQZXJi4TKt5KKfSF/ede8LvaoACgb0uWPr+f2FycU4sUNVfuJ/25fDEs8euYjDaRUEQp2ji5HIuDJ7N96WMRdwqvtV8bgokJyoFNSf4jpxwmeKkFyrdN9IzqmtnFkipCvVrNZI+4iFx3zDTuGd92gabkrMftkAbfVSiU+oJdWhvCRD+xwrAWVCF0BEgah4Xx/vJw0iRZvPwIDAQABo4IB3jCCAdowEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQU/MGa354KPQEYek5XAh24WoKsaTUwHwYDVR0jBBgwFoAUCp7+V9tkSly7SqQHKsZSpfYd9u8wgbYGA1UdIASBrjCBqzCBqAYKKoF6ARfOEAEBATCBmTBQBggrBgEFBQcCAjBEMBoWE1BTQSBQZXVnZW90IENpdHJvZW4wAwIBARomUG9saXRpcXVlIGRlIENlcnRpZmljYXRpb24gUFNBIFBldWdlb3QwRQYIKwYBBQUHAgEWOWh0dHA6Ly9pbmZvY2VydC5wc2EtcGV1Z2VvdC1jaXRyb2VuLmNvbS9QQ19QU0FfUmFjaW5lLnBkZjAOBgNVHQ8BAf8EBAMCAQYwVwYDVR0fBFAwTjBMoEqgSIZGaHR0cDovL2luZm9jZXJ0LnBzYS1wZXVnZW90LWNpdHJvZW4uY29tL1BTQV9QZXVnZW90X0NpdHJvZW5fUmFjaW5lLmNybDBiBggrBgEFBQcBAQRWMFQwUgYIKwYBBQUHMAKGRmh0dHA6Ly9pbmZvY2VydC5wc2EtcGV1Z2VvdC1jaXRyb2VuLmNvbS9QU0FfUGV1Z2VvdF9DaXRyb2VuX1JhY2luZS5jcnQwDQYJKoZIhvcNAQELBQADggEBAIE2JuhEZ3Edy+2FU4IAybn7OK/HDyGdAXBpVWO/k2xa2uBb7ByK/AEQb2CJR6ETaLE+RkTux/oLTspZXwRcZptBrrJxnIxjreWIfkf4ZqzL7Dt2pfMONeOrw2Zl+F81IZ6+bjcdSq8/Bsg7QVzHLFZi91/u8IpESLKQJsxotmuAM40dr7AbijdVEdRqIgtj07R+vEeUN68Mq5tPCjsyxvllGeyCjykZtGbnQZaKSlVJiXuoOu8oaqtDZ/6i9mrxEVb/c5uhDa81AfecYqRKpyO+KpJ2545hec8Sg0SQ91uYqxgmFwN6ZNrMa8Dsjx+i4wN/zzPsADeuGO4aTJ888os=\",\"MIIE4jCCA8qgAwIBAgINAKeC/qyZMGnJbr997zANBgkqhkiG9w0BAQsFADCBmzELMAkGA1UEBhMCRlIxDjAMBgNVBAcTBVBhcmlzMRwwGgYDVQQKExNQU0EgUGV1Z2VvdCBDaXRyb2VuMRcwFQYDVQQLEw4wMDAyIDMxOTE4NzMwODEgMB4GA1UECxMXQ2VydGlmaWNhdGUgQXV0aG9yaXRpZXMxIzAhBgNVBAMTGlBTQSBQZXVnZW90IENpdHJvZW4gUmFjaW5lMB4XDTE2MDcyNzExNTgzNloXDTI2MDEwMjExNTgzNlowgZsxCzAJBgNVBAYTAkZSMQ4wDAYDVQQHEwVQYXJpczEcMBoGA1UEChMTUFNBIFBldWdlb3QgQ2l0cm9lbjEXMBUGA1UECxMOMDAwMiAzMTkxODczMDgxIDAeBgNVBAsTF0NlcnRpZmljYXRlIEF1dGhvcml0aWVzMSMwIQYDVQQDExpQU0EgUGV1Z2VvdCBDaXRyb2VuIFJhY2luZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJxy+D9uziQ3JmSja3Srd/mERPutw6z0UkUm+xjGa5tuvTUFBVC9ngjuT4hDIU+IcDrT2YZ4kYrIpqUwApG97vem0mede5TXruL+rBbaEEWX2/eYP7atOZMybDqZw7SNNxOxcL56hxPMYfvnbb5UpTiLN30UnhB5zR2nHYCI9E4g3dT+RmWf6Rsq9sEgclZwl4EnaJxKqRGiS4ukwV0TsB+qu1AKMhpN5eZmjdHPSCxllj3Q/hzhloL8o4LKHQEmHonyIS34chktvevBj6SIorhhqUbj4al4ZVPxn5iKMEtf9Qrm0Kzdpxs3SIDkeYqxhnFtBotaa1Hvj1NRnKSCf0sCAwEAAaOCASEwggEdMBIGA1UdEwEB/wQIMAYBAf8CAQIwHQYDVR0OBBYEFAqe/lfbZEpcu0qkByrGUqX2HfbvMB8GA1UdIwQYMBaAFAqe/lfbZEpcu0qkByrGUqX2HfbvMIG2BgNVHSAEga4wgaswgagGCiqBegEXzhABAQEwgZkwRQYIKwYBBQUHAgEWOWh0dHA6Ly9pbmZvY2VydC5wc2EtcGV1Z2VvdC1jaXRyb2VuLmNvbS9QQ19QU0FfUmFjaW5lLnBkZjBQBggrBgEFBQcCAjBEMBoWE1BTQSBQZXVnZW90IENpdHJvZW4wAwIBARomUG9saXRpcXVlIGRlIENlcnRpZmljYXRpb24gUFNBIFBldWdlb3QwDgYDVR0PAQH/BAQDAgEGMA0GCSqGSIb3DQEBCwUAA4IBAQBB2sL1r7RS5jJF5Tl/+P5xyYexqs4+6ro3EfDmxZ+YUvlF0I2JFz359hKEYTpQkWu1meuZhEyviti2gzNyUBRyIRCHkLgaO9gdNNSaLPIBjbOwcqilooB5pcX6ppWQm/PCK8IUV0qG7sCS5i6I1i562UHtzImTJ6R7h6cgOJ5LNAvqYjYoTrBYy1Kyv3ULkBk2EG8pA5lQeSnYMnpBSpgruwlFFeX6+YeciIitrs4EIm4qmxOswxObrO3MifqPo3MDTAe9NgjBNN4lja10NwnUYG2gBMDodX7sZWU9oNZ1CyPsDRxZIyHTgF8K6V71qldHuu7BAQSb4OUufyx5q0y/\"]},{\"kty\":\"EC\",\"kid\":\"Z1WHX7dDyLg44mXHrt4jcSBK8N0\",\"use\":\"sig\",\"x\":\"5k4kFjJztgq9mn56KZ7bQdC0ppt4kxtrHgo0Pr4eAq4\",\"y\":\"IZdt4HXVamys5beru34D70EG0QOWxNYfHPHGIESmDvE\",\"crv\":\"P-256\",\"x5c\":[\"MIIBvDCCAWCgAwIBAgIGAXeLcFWVMAwGCCqGSM49BAMCBQAwYzELMAkGA1UEBhMCRlIxDjAMBgNVBAcTBVBhcmlzMRwwGgYDVQQKExNQU0EgUGV1Z2VvdCBDaXRyb2VuMREwDwYDVQQLEwhQcm9ncmFtczETMBEGA1UEAwwKaWRmZWQyX2VuYzAeFw0yMTAyMTAxMDE1MzBaFw0zMTAyMDgxMDE1MzBaMGMxCzAJBgNVBAYTAkZSMQ4wDAYDVQQHEwVQYXJpczEcMBoGA1UEChMTUFNBIFBldWdlb3QgQ2l0cm9lbjERMA8GA1UECxMIUHJvZ3JhbXMxEzARBgNVBAMMCmlkZmVkMl9lbmMwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAATmTiQWMnO2Cr2afnopnttB0LSmm3iTG2seCjQ+vh4CriGXbeB11WpsrOW3q7t+A+9BBtEDlsTWHxzxxiBEpg7xMAwGCCqGSM49BAMCBQADSAAwRQIhAPGohy5NNaEYlN8QcSb/yurviTGuMphanlchwjIiHIm/AiBnXCG0qNPpKaUS9teQoVyTd+jZ8LqXOp0f9XiJ7L12fA==\"]}]}";

    /** The verification util. */
    SignatureVerificationUtil verificationUtil = new SignatureVerificationUtil();

    /**
     * Test parse token and IDP data.
     */
    @Test
    public void testParseTokenAndIDPData() {
        JsonWebSignature jws = new JsonWebSignature();
        try {
            jws.setCompactSerialization(expectedEncodedToken);
            jws.setAlgorithmConstraints(new AlgorithmConstraints(ConstraintType.PERMIT, AlgorithmIdentifiers.RSA_USING_SHA256));
            verificationUtil.parseToken(responseIDP, jws);
            assertTrue(jws.verifySignature());
        } catch (JoseException e) {
            logger.info("Invalid Token:Error while parsing of token" + e);
        } catch (TokenInvalidException e) {
            logger.info("Invalid Token:Error while calling IDP service" + e);
        }

    }

    /**
     * Test method for {@link com.inetpsa.o8d.diagcloud.token.util.SignatureVerification#decodeAndSetTokenData(java.lang.String)}.
     */
    @Test
    public void testDecodeAndSetTokenData() {

        try {
            assertNotNull(verificationUtil.decodeAndSetTokenData(expectedEncodedToken));
        } catch (TokenInvalidException e) {
            logger.info("Invalid Token:Error while decoding of token" + e);
        }
    }

}
