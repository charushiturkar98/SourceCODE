/*
 * Creation : 13 Aug 2021
 */
package com.inetpsa.o8d.diagcloud.token.util;

import java.io.IOException;

import org.apache.commons.codec.binary.Base64;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.JsonWebKeySet;
import org.jose4j.jwk.VerificationJwkSelector;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.o8d.diagcloud.token.beans.Token;
import com.inetpsa.o8d.diagcloud.token.beans.TokenHeaderBean;
import com.inetpsa.o8d.diagcloud.token.beans.TokenPayloadBean;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;

/**
 * CAP-25454:The Class SignatureVerification.
 */
public class SignatureVerificationUtil {

    /** Logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Parses the token and IDP data also verify and validate signature from token.
     *
     * @param response the response
     * @param jws the jws
     * @return the json web key
     * @throws TokenInvalidException the invalid token exception
     */
    public void parseToken(String response, JsonWebSignature jws) throws TokenInvalidException {
        TokenValidatorUtil userIdExpValidation = new TokenValidatorUtil();
        try {
            JsonWebKeySet json = new JsonWebKeySet(response);

            VerificationJwkSelector selector = new VerificationJwkSelector();
            JsonWebKey jsonKey = selector.select(jws, json.getJsonWebKeys());
            if (null == jsonKey) {
                logger.error(TokenConstants.INVALID_KID_TOKEN);
                throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, userIdExpValidation.getEpochCurrentTime(),
                        TokenConstants.INVALID_KID_TOKEN);
            }
            jws.setKey(jsonKey.getKey());
            logger.info("JWS key:{} ", jws.getKey());
            if (!jws.verifySignature()) {
                logger.error(TokenConstants.INVALID_SIG_WITH_TOKEN);
                throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, userIdExpValidation.getEpochCurrentTime(),
                        TokenConstants.INVALID_SIG_WITH_TOKEN);
            }
            logger.info("JWS Signature is valid : {} ", jws.verifySignature());
        } catch (JoseException exception) {
            // sonar issue fixed
            logger.error("Jose4Exception for Signature validation: ", exception);
            throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, userIdExpValidation.getEpochCurrentTime(),
                    TokenConstants.CUSTOM_EXCEPTION_MSG);
        }
    }

    /**
     * Extract,decode and set token data in TokenBean,TokenHeaderBean and TokenPayloadBean.
     *
     * @param encodedToken the encoded token
     * @return the token
     * @throws TokenInvalidException the invalid token exception
     */
    public Token decodeAndSetTokenData(String encodedToken) throws TokenInvalidException {
        Token token = new Token();
        TokenValidatorUtil userIdExpValidation = new TokenValidatorUtil();
        try {
            String[] splitString = encodedToken.split("\\.");
            String base64EncodedHeader = splitString[0];
            String base64EncodedBody = splitString[1];

            Base64 base64Url = new Base64(true);
            token.setHeader(new ObjectMapper().readValue(new String(base64Url.decode(base64EncodedHeader)), TokenHeaderBean.class));
            token.setPayload(new ObjectMapper().readValue(new String(base64Url.decode(base64EncodedBody)), TokenPayloadBean.class));
        } catch (JsonMappingException jsonException) {
            logger.info(TokenConstants.ERROR_BAD_FORMAT_TOKEN, jsonException);
            throw new TokenInvalidException(TokenConstants.STATUS_400_CODE, TokenConstants.ERROR_400, userIdExpValidation.getEpochCurrentTime(),
                    TokenConstants.ERROR_BAD_FORMAT_TOKEN);
        } catch (IOException exception) {
            logger.info(TokenConstants.ERROR_MSG_INVALID_TOKEN, exception);
            throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, userIdExpValidation.getEpochCurrentTime(),
                    TokenConstants.ERROR_MSG_INVALID_TOKEN);
        }
        return token;
    }
}
