/*
 * Creation : 16 Aug 2021
 */
package com.inetpsa.o8d.diagcloud.token.service;

/**
 * CAP-25454:The Interface ITokenService.
 */
public interface ITokenService {

    /**
     * Gets the IDP service data.
     *
     * @param response the response
     * @return the IDP service data
     */
    int getIDPServiceData(StringBuilder response);

}
