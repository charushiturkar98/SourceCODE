/*
 * Creation : 9 Sep 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.diagcloud.token.util;

/**
 * CAP-25454:The Class TokenConstants.
 * 
 * @author SC28579
 */
public final class TokenConstants {

    /**
     * Instantiates a new token constants.
     */
    private TokenConstants() {
        super();
    }

    /** The Constant INDEX. */
    public static final int INDEX = 7;

    /** The Constant CUSTOM_EXCEPTION_MSG. */
    public static final String CUSTOM_EXCEPTION_MSG = "Error while parsing token : {}";

    /** The Constant INVALID_SIG_WITH_TOKEN. */
    public static final String INVALID_SIG_WITH_TOKEN = "Signature verification failed, Invalid token recieved";

    /** Constants for sending error response to DDC. */
    public static final int STATUS_400_CODE = 400;

    /** The Constant ERROR_400. */
    public static final String ERROR_400 = "Bad request";

    /** The Constant ERROR_MSG_USER_ID. */
    public static final String ERROR_MSG_USER_ID = "Username not found";

    /** The Constant ERROR_MSG_EXP_TIME. */
    public static final String ERROR_MSG_EXP_TIME = "Expiration time not found";

    /** The Constant ERROR_MSG_INVALID_TOKEN. */
    public static final String ERROR_MSG_INVALID_TOKEN = "Invalid token: Token Expired";

    /** The Constant ERROR_MSG_INVALID_TOKEN. */
    public static final String ERROR_MSG_LDAP_INVALID_TOKEN = "Invalid token: User Not Valid";

    /** The Constant EMPTY. */
    public static final String EMPTY = "";

    /** The Constant SUCCESS_HTTP_CODE. */
    public static final int SUCCESS_HTTP_CODE = 200;

    /** The Constant SUCCESS_403_CODE. */
    public static final int STATUS_403_CODE = 403;

    /** The Constant ERROR_403. */
    public static final String ERROR_403 = "No Access";

    /** The Constant ERROR_MSG_403. */
    public static final String ERROR_MSG_403 = "Forbidden Access to the requested resource";

    /** The Constant SUCCESS_500_CODE. */
    public static final int STATUS_500_CODE = 500;

    /** The Constant ERROR_500. */
    public static final String ERROR_500 = "Server error";

    /** The Constant ERROR_MSG_401. */
    public static final String ERROR_MSG_500 = "Internal Server Error";

    /** The Constant SUCCESS_401_CODE. */
    public static final int STATUS_401_CODE = 401;

    /** The Constant ERROR_401. */
    public static final String ERROR_401 = "Unauthorized";

    /** The Constant ERROR_MSG_401. */
    public static final String ERROR_MSG_401 = "Unauthorized user";

    /** The Constant IDP_PORTAL_URL. */
    public static final String IDP_PORTAL_URL = "IDP_PORTAL_URL";

    /** The Constant TLS_VERSION_1_2. */
    public static final String TLS_VERSION_1_2 = "TLSv1.2";

    /** The Constant GET_METHOD. */
    public static final String GET_METHOD = "GET";

    /** The Constant CONTENT_TYPE. */
    public static final String CONTENT_TYPE = "Content-Type";

    /** The Constant ACCEPT_CHARSET. */
    public static final String ACCEPT_CHARSET = "Accept-Charset";

    /** The Constant ACCEPT. */
    public static final String ACCEPT = "Accept";

    /** The Constant INVALID_KID_TOKEN. */
    public static final String INVALID_KID_TOKEN = "Invalid KID parameter for IDP and Token";

    /** The Constant DB_FETCH_TYPE_INSERT. */
    public static final String DB_FETCH_TYPE_INSERT = "INSERT";

    /** The Constant DB_FETCH_TYPE_RETRIEVE. */
    public static final String DB_FETCH_TYPE_RETRIEVE = "RETRIEVE";

    /** The Constant READ_TIMEOUT. */
    public static final int READ_TIMEOUT = 30000;

    /** The Constant READ_TIMEOUT_EDIAG. */
    public static final int READ_CONNECTION_TIMEOUT = 300000;

    /** The Constant ERROR_MSG_INVALID_TOKEN. */
    public static final String ERROR_MSG_AUTHORISATION_FAILED = "Authorisation failed for token";

    /** The Constant ARRAYLIST_ROLE. */
    public static final String ARRAYLIST_ROLE = "java.util.ArrayList";

    /** The Constant STRING_ROLE. */
    public static final String STRING_ROLE = "java.lang.String";

    /** The Constant ERROR_NO_ROLES_AVAILABLE. */
    public static final String ERROR_NO_ROLES_AVAILABLE = "No Roles available in access token";

    /** The Constant ERROR_INVALID_ROLES_DATATYPE. */
    public static final String ERROR_INVALID_ROLES_DATATYPE = "Invalid Datatype for Roles";

    /** The Constant ERROR_BAD_FORMAT_TOKEN. */
    public static final String ERROR_BAD_FORMAT_TOKEN = "Invalid token: Token format not encoded correctly in Base64";

    /** The Constant MILLI_SECS. */
    public static final int MILLI_SECS = 1000;
}
