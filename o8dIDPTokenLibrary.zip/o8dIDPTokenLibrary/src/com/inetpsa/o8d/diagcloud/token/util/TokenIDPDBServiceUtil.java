/*
 * Creation : 17 Sep 2021
 */
package com.inetpsa.o8d.diagcloud.token.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.BusinessService;
import com.inetpsa.o8d.a2dr.service.AbstractServiceExecutor;
import com.inetpsa.o8d.diagcloud.token.beans.Token;
import com.inetpsa.o8d.diagcloud.token.beans.TokenPojo;
import com.inetpsa.o8d.diagcloud.token.service.TokenIDPDBBusinessService;

/**
 * The Class IDPTokenDBServiceImpl CAP-25454
 */
public class TokenIDPDBServiceUtil extends AbstractServiceExecutor {

    /** The logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /** The date format. */
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Insert token info in DataBase.
     *
     * @param token the token
     */
    public void insertTokenInfo(final Token token) {

        final TokenPojo tokenPojo = convertTokenIntoPojo(token);
        tokenPojo.setDbFetchType(TokenConstants.DB_FETCH_TYPE_INSERT);
        try {
            executeService(TokenIDPDBBusinessService.SERVICE_NAME, new IServiceCallback() {

                public void doOnServiceInput(BusinessService service) throws FwkException {
                    service.setInput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE, tokenPojo);
                }

                public Object doOnServiceOutput(BusinessService service) throws FwkException {
                    return service.getOutput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE);
                }
            });
        } catch (FwkException e) {
            // sonar issue fixed
            logger.error("Error while inserting tht token data in DB: ", e);
        }

    }

    /**
     * Retrieve token info from database.
     *
     * @param token the token
     * @return true, if successful
     */
    public boolean retriveTokenInfo(Token token) {

        final TokenPojo tokenPojo = new TokenPojo();
        tokenPojo.setUserName(token.getPayload().getUsername());//sonar issue fix
        tokenPojo.setKid(token.getHeader().getKid());
        tokenPojo.setExpirationTime(token.getPayload().getExp());
        tokenPojo.setDbFetchType(TokenConstants.DB_FETCH_TYPE_RETRIEVE);
        boolean isIdpServiceCallReq = false;
        try {
            tokenPojo.setCreatedDate((dateFormat.parse(dateFormat.format(new Date()))));
            @SuppressWarnings("unchecked")
            List<TokenPojo> tokenDBObjList = (List<TokenPojo>) executeService(TokenIDPDBBusinessService.SERVICE_NAME, new IServiceCallback() {

                public void doOnServiceInput(BusinessService service) throws FwkException {
                    service.setInput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE, tokenPojo);
                }

                public Object doOnServiceOutput(BusinessService service) throws FwkException {
                    return service.getOutput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE);

                }
            });
            if (null == tokenDBObjList || tokenDBObjList.isEmpty()) {
                return true;
            }
            for (TokenPojo tokenPojoObj : tokenDBObjList) {
                if (tokenPojo.getExpirationTime() > tokenPojoObj.getExpirationTime())
                    isIdpServiceCallReq = true;
                else if (tokenPojo.getExpirationTime() == tokenPojoObj.getExpirationTime())
                    isIdpServiceCallReq = false;
            }
        } catch (FwkException e) {
            // sonar issue fixed
            logger.error("exception while fetching token data: ", e);
        } catch (ParseException e) {
            logger.error("exception while parsing the date", e);
        }

        return isIdpServiceCallReq;
    }

    /**
     * Convert token into pojo.
     *
     * @param token the token
     * @return the token pojo
     */
    private TokenPojo convertTokenIntoPojo(Token token) {

        TokenPojo tokenPojo = new TokenPojo();
        if (null != token && !StringUtils.isBlank(token.getHeader().getKid()))
            tokenPojo.setKid((token.getHeader().getKid()));
        if (null != token && !StringUtils.isBlank(token.getPayload().getUsername()))
            tokenPojo.setUserName(token.getPayload().getUsername());//sonar issue fix
        if (null != token && !StringUtils.isBlank(token.getPayload().getClientId()))
            tokenPojo.setClientId(token.getPayload().getClientId());
        if (null != token && !StringUtils.isBlank(token.getPayload().getRrdi()))
            tokenPojo.setRrdi(token.getPayload().getRrdi());
        if (null != token && !StringUtils.isBlank(token.getPayload().getCountry()))
            tokenPojo.setCountry(token.getPayload().getCountry());
        if (null != token && !StringUtils.isBlank(token.getPayload().getBrand()))
            tokenPojo.setBrand(token.getPayload().getBrand());
        if (null != token && token.getPayload().getExp() != 0)
            tokenPojo.setExpirationTime(token.getPayload().getExp());
        return tokenPojo;

    }

}
