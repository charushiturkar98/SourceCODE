package com.inetpsa.o8d.diagcloud.token.beans;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * CAP-25454:The Class TokenResponseBean.
 */
public class TokenResponseBean {

    /**
     * Instantiates a new token response bean.
     *
     * @param statusCode the status code
     * @param error the error
     * @param date the date
     * @param message the message
     * @param isValidToken the is valid token
     */
    public TokenResponseBean(int statusCode, String error, long date, String message, boolean isValidToken) {
        super();
        this.statusCode = statusCode;
        this.error = error;
        this.date = date;
        this.message = message;
        this.isValidToken = isValidToken;
    }

    /** The status code. */
    private int statusCode;

    /** The error. */
    private String error;

    /** The date. */
    private long date;

    /** The message. */
    private String message;

    /** The is valid token. */
    @JsonIgnore
    private boolean isValidToken;

    /**
     * Gets the checks if is valid token.
     *
     * @return the checks if is valid token
     */
    public boolean getIsValidToken() {
        return isValidToken;
    }

    /**
     * Sets the checks if is valid token.
     *
     * @param isValidToken the new checks if is valid token
     */
    public void setIsValidToken(boolean isValidToken) {
        this.isValidToken = isValidToken;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Gets the error.
     *
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * Sets the error.
     *
     * @param error the new error
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * Gets the date.
     *
     * @return the date
     */
    public long getDate() {
        return date;
    }

    /**
     * Sets the date.
     *
     * @param date the new date
     */
    public void setDate(long date) {
        this.date = date;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "TokenBean [statusCode=" + statusCode + ", error=" + error + ", date=" + date + ", message=" + message + "]";
    }

}
