/*
 * Creation : 16 Aug 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.diagcloud.token.component;

import java.util.ArrayList;
import java.util.List;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.a2dr.service.relay.RelayConstants;
import com.inetpsa.o8d.diagcloud.token.beans.Token;
import com.inetpsa.o8d.diagcloud.token.beans.TokenResponseBean;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;
import com.inetpsa.o8d.diagcloud.token.service.ITokenService;
import com.inetpsa.o8d.diagcloud.token.service.impl.TokenServiceImpl;
import com.inetpsa.o8d.diagcloud.token.util.SignatureVerificationUtil;
import com.inetpsa.o8d.diagcloud.token.util.TokenAuthorisationUtil;
import com.inetpsa.o8d.diagcloud.token.util.TokenConstants;
import com.inetpsa.o8d.diagcloud.token.util.TokenIDPDBServiceUtil;
import com.inetpsa.o8d.diagcloud.token.util.TokenValidatorUtil;

/**
 * CAP-25454:The Class TokenManagement.
 */
public class TokenManagement {

    /** Logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * decode the token and check the user and expiration date details from it. code to check weather the tokenID is available in DB, if no it checks
     * the token is valid by calling IDP for valid token.
     *
     * @param tokenBean     the tokenBean
     * @param token         the token
     * @param applicationId the application id
     * @return the TokenResponseBean tokenResponseBean
     */
    public TokenResponseBean getTokenInfo(Token tokenBean, String token, String applicationId) {
        TokenResponseBean tokenResponseBean = null;
        TokenValidatorUtil tokenValidatorUtil = new TokenValidatorUtil();
        TokenIDPDBServiceUtil tokenIDPDBServiceUtil = new TokenIDPDBServiceUtil();
        List<String> listObject = new ArrayList<>();
        TokenAuthorisationUtil authorisation = new TokenAuthorisationUtil();
        boolean isIdpServiceCallReq = false;

        try {

            if (null != tokenBean && null != tokenBean.getPayload()) {
                tokenResponseBean = tokenValidatorUtil.userIdExpToken(tokenBean.getPayload());
                listObject = authorisation.convertRolesDataType(tokenBean.getPayload());
                if (null == listObject || listObject.isEmpty()) {
                    throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401,
                            tokenValidatorUtil.getEpochCurrentTime(), TokenConstants.ERROR_NO_ROLES_AVAILABLE);
                }
                logger.info("Roles:{} for user:{} ", listObject, tokenBean.getPayload().getUsername());// sonar issue fix

                // DCLOUD-167
                if (null != tokenResponseBean && tokenResponseBean.getIsValidToken()
                        && !RelayConstants.RA.equalsIgnoreCase(tokenBean.getPayload().getUserType())) {
                    logger.info("Token Authorisation Not Needed as User is Non-LDAP user!! :{}", tokenBean.getPayload().getUserType());
                } else if (null != tokenResponseBean && tokenResponseBean.getIsValidToken()
                        && !authorisation.checkTokenAuthorisation(listObject, applicationId)) {
                    logger.error("Authorisation failed!! :{}", tokenBean.getPayload().getUsername());// sonar issue fix
                    throw new TokenInvalidException(TokenConstants.STATUS_403_CODE, TokenConstants.ERROR_403,
                            tokenValidatorUtil.getEpochCurrentTime(), TokenConstants.ERROR_MSG_AUTHORISATION_FAILED);
                }
            }
            // Check token data available in database
            if (null != tokenResponseBean && tokenResponseBean.getIsValidToken())
                isIdpServiceCallReq = tokenIDPDBServiceUtil.retriveTokenInfo(tokenBean);
            if (isIdpServiceCallReq) {
                logger.warn("Token data not available in database, calling IDP server to validate the token :{} ", tokenBean.getHeader().getKid());
                callAndValidateIDPService(token);
                tokenIDPDBServiceUtil.insertTokenInfo(tokenBean);
                logger.warn("Token data inserted into database :{} ", tokenBean.getHeader().getKid());
            }
        } catch (TokenInvalidException exception) {
            // sonar issue fixed
            logger.error("Invalid token: ", exception);
            tokenResponseBean = new TokenResponseBean(exception.getStatusCode(), exception.getError(), tokenValidatorUtil.getEpochCurrentTime(),
                    exception.getMessage(), Boolean.FALSE);
        }
        return tokenResponseBean;
    }

    /**
     * code to Call and validate IDP service data in case of no valid token present in database.
     *
     * @param token the decoded token
     * @throws TokenInvalidException the invalid token exception
     */
    public void callAndValidateIDPService(String token) throws TokenInvalidException {
        StringBuilder response = new StringBuilder();
        ITokenService service = new TokenServiceImpl();
        JsonWebSignature jws = new JsonWebSignature();
        TokenValidatorUtil tokenValidatorUtil = new TokenValidatorUtil();
        SignatureVerificationUtil verification = new SignatureVerificationUtil();
        try {
            jws.setCompactSerialization(token);
            jws.setAlgorithmConstraints(new AlgorithmConstraints(ConstraintType.PERMIT, AlgorithmIdentifiers.RSA_USING_SHA256));

            int statusCode = service.getIDPServiceData(response);
            logger.info("Status Code for IDP:{}", statusCode);
            if (0 != statusCode && statusCode == TokenConstants.SUCCESS_HTTP_CODE) {
                verification.parseToken(response.toString(), jws);
            } else {
                logger.error("Invalid Certificate form IDP : statusCode : {} ", statusCode);
                throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, tokenValidatorUtil.getEpochCurrentTime(),
                        TokenConstants.INVALID_SIG_WITH_TOKEN);
            }
            response.setLength(0); // CAP-29321 Resetting StringBuilder to null
        } catch (JoseException exception) {
            // sonar issue fixed
            logger.error("Jose4Exception for token validation: ", exception);
            throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, tokenValidatorUtil.getEpochCurrentTime(),
                    TokenConstants.CUSTOM_EXCEPTION_MSG);
        }
    }
}
