package com.inetpsa.o8d.diagcloud.token.util;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.diagcloud.token.beans.Token;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;

/**
 * The Class TokenUserNamePattern.
 * 
 * @author e614622
 */

public class TokenUserNamePattern {

    /** The logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Checking user pattern.
     *
     * @param connector the connector
     * @param tokenBean the token bean
     * @return true, if successful
     */
    public boolean checkPattern(AbstractDiagUserConnector connector, Token tokenBean) {
        logger.debug("check() >>");
        boolean result = false;
        // sonar issue fix
        if (null != tokenBean.getPayload().getUsername() && !StringUtils.isBlank(tokenBean.getPayload().getUsername())) {
            String login = tokenBean.getPayload().getUsername();
            String pattern = connector.getConnectorDefinition().getPattern();

            logger.debug("Check on id '{}' and pattern '{}'", login, pattern);

            if (Pattern.matches(pattern, login)) {
                result = true;
                logger.debug("The user is of type {}", connector.getUserType());
            } else {
                logger.debug("The user is of type {}", connector.getUserType());
            }
        }
        logger.debug("check() <<");
        return result;
    }

}