/*
 * Creation : 7 Sep 2021
 */
/**
 * 
 */
package com.inetpsa.o8d.diagcloud.token.exception;

/**
 * CAP-25454:The common custom exception class in case of any issues/problem with the retrieved token.
 *
 * @author SC28579
 */
public class TokenInvalidException extends Exception {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -3347338235831083194L;

    /**
     * Instantiates a new invalid token exception.
     */
    public TokenInvalidException() {
        super();
    }

    /**
     * Instantiates a new invalid token exception.
     *
     * @param message the message
     */
    public TokenInvalidException(String message) {
        super(message);
    }

    /**
     * Instantiates a new invalid token exception.
     *
     * @param message the message
     * @param cause the cause
     */
    public TokenInvalidException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Instantiates a new invalid token exception.
     *
     * @param cause the cause
     */
    public TokenInvalidException(Throwable cause) {
        super(cause);
    }

    /** The status code. */
    private int statusCode;

    /** The error. */
    private String error;

    /** The date. */
    private long date;

    /** The message. */
    private String message;

    /**
     * Instantiates a new invalid certificate exception.
     *
     * @param statusCode the status code
     * @param error the error
     * @param date the date
     * @param message the message
     */
    public TokenInvalidException(int statusCode, String error, long date, String message) {
        this.statusCode = statusCode;
        this.error = error;
        this.date = date;
        this.message = message;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Gets the error.
     *
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * Sets the error.
     *
     * @param error the new error
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * Gets the date.
     *
     * @return the date
     */
    public long getDate() {
        return date;
    }

    /**
     * Sets the date.
     *
     * @param date the new date
     */
    public void setDate(long date) {
        this.date = date;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Throwable#getMessage()
     */
    @Override
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

}
