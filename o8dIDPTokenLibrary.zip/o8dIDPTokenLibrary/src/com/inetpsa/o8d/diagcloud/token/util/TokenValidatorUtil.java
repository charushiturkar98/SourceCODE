/*
 * Creation : 13 Sep 2021
 */
package com.inetpsa.o8d.diagcloud.token.util;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.o8d.diagcloud.token.beans.TokenPayloadBean;
import com.inetpsa.o8d.diagcloud.token.beans.TokenResponseBean;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;

/**
 * CAP-25454:The Class UserIdExpValidation.
 */
public class TokenValidatorUtil {

    /** Logger. */
    protected static final Logger logger = LoggerFactory.getLogger(TokenValidatorUtil.class);

    /**
     * CAP-25454: Gets the current time in epoch format.
     *
     * @return the current time
     */
    public long getEpochCurrentTime() {
        return System.currentTimeMillis() / TokenConstants.MILLI_SECS;
    }

    /**
     * CAP-25454: method for extracting userName/expirationTime and validating expiration time.
     *
     * @param tknPayload the tkn payload
     * @return the string of tokenResponseBean in valid scenario
     * @throws TokenInvalidException the invalid token exception
     */
    public TokenResponseBean userIdExpToken(TokenPayloadBean tknPayload) throws TokenInvalidException {
      //sonar issue fix
        if (null != tknPayload.getUsername() && !StringUtils.isBlank(tknPayload.getUsername())) {
            if (tknPayload.getExp() != 0) {
                long expTime = tknPayload.getExp();
                // checking for current time
                long currentEpochTime = getEpochCurrentTime();
                logger.info("Expiration time in Epoch format:{} \n Current time in Epoch format:{} ", currentEpochTime, expTime);
                // validation of expiration time
                if ((expTime) > (currentEpochTime)) {
                    logger.info("Successful validation of token using exp time");
                    return new TokenResponseBean(TokenConstants.SUCCESS_HTTP_CODE, TokenConstants.EMPTY, getEpochCurrentTime(), TokenConstants.EMPTY,
                            Boolean.TRUE);
                }
                throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, getEpochCurrentTime(),
                        TokenConstants.ERROR_MSG_INVALID_TOKEN);
            }
            throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, getEpochCurrentTime(),
                    TokenConstants.ERROR_MSG_EXP_TIME);
        }
        throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, getEpochCurrentTime(),
                TokenConstants.ERROR_MSG_USER_ID);
    }

}
