/*
 * Creation : 30 Sep 2021
 */
package com.inetpsa.o8d.diagcloud.token.util;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.clp.exception.LDAPException;
import com.inetpsa.o8d.diagcloud.token.beans.TokenPayloadBean;
import com.inetpsa.o8d.diagcloud.token.exception.TokenInvalidException;
import com.inetpsa.o8d.diaguser.Autorisation;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.MetaDataRepository;

/**
 * CAP-25454:The Class TokenAuthorisationUtil.
 */
public class TokenAuthorisationUtil {
    /** Logger. */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Compare, Check and validate token and diaguser data for authorisation.
     *
     * @param listObject the list object
     * @param applicationId the application id
     * @return true, if successful
     * @throws TokenInvalidException the invalid token exception
     */
    public boolean checkTokenAuthorisation(List<String> listObject, String applicationId) throws TokenInvalidException {

        TokenValidatorUtil userIdExpValidation = new TokenValidatorUtil();
        try {
            Autorisation autorisation = MetaDataRepository.getInstance().getAutorisation(applicationId);
            if (autorisation.isRoleOrGroupRequired()) {
                logger.debug("Validate Authorisation for the access token.");
                return isRoleOrGroupMember(listObject, autorisation);
            }
        } catch (DiagUserException exception) {
            // sonar issue fixed
            logger.error("Authorisation failed: ", exception);
            throw new TokenInvalidException(TokenConstants.STATUS_403_CODE, TokenConstants.ERROR_403, userIdExpValidation.getEpochCurrentTime(),
                    TokenConstants.ERROR_MSG_AUTHORISATION_FAILED);
        }
        return Boolean.TRUE;
    }

    /**
     * Code to convert roles data type to ArrayList/String to compare with data in config files.
     *
     * @param tokenPayloadBean the token payload bean
     * @return the list
     * @throws TokenInvalidException the invalid token exception
     */
    @SuppressWarnings("unchecked")
    public List<String> convertRolesDataType(TokenPayloadBean tokenPayloadBean) throws TokenInvalidException {
        TokenValidatorUtil userIdExpValidation = new TokenValidatorUtil();
        List<String> listObject;
        if (null != tokenPayloadBean.getRoles() && TokenConstants.ARRAYLIST_ROLE.equalsIgnoreCase(tokenPayloadBean.getRoles().getClass().getName())) {
            listObject = (List<String>) tokenPayloadBean.getRoles();
        } else if (null != tokenPayloadBean.getRoles()
                && TokenConstants.STRING_ROLE.equalsIgnoreCase(tokenPayloadBean.getRoles().getClass().getName())) {
            String value = (String) tokenPayloadBean.getRoles();
            listObject = Arrays.asList(value);
        } else {
            throw new TokenInvalidException(TokenConstants.STATUS_401_CODE, TokenConstants.ERROR_401, userIdExpValidation.getEpochCurrentTime(),
                    TokenConstants.ERROR_NO_ROLES_AVAILABLE);
        }
        return listObject;
    }

    /**
     * Code to compare role/group member with data in Config file.
     *
     * @param tokenRoles the token roles
     * @param autorisation the autorisation
     * @return true, if is role or group member
     * @throws DiagUserException the diag user exception
     */
    protected boolean isRoleOrGroupMember(List<String> tokenRoles, Autorisation autorisation) throws DiagUserException {
        boolean found = false;
        found = isRoleMember(tokenRoles, autorisation.getLdapRoles());
        logger.debug("isRoleMember  : {}", Boolean.valueOf(found));
        if (!found) {
            found = isGroupMember(tokenRoles, autorisation.getLdapGroups());
            logger.debug("isGroupMember : {}", Boolean.valueOf(found));
        }
        return found;
    }

    /**
     * Code to compare role member with data in Config file.
     *
     * @param tokenRoles the token roles
     * @param diagRoleList the diag role list
     * @return true, if is role member
     * @throws DiagUserException the diag user exception
     */
    private boolean isRoleMember(List<String> tokenRoles, List<String> diagRoleList) {
        boolean found = false;

        if (diagRoleList != null && tokenRoles != null) {
            for (int i = 0; (i < diagRoleList.size()) && (!found); i++) {
                String role = diagRoleList.get(i);
                found = searchRole(role, tokenRoles);
            }
        }
        return found;
    }

    /**
     * Code to compare group member with data in Config file.
     *
     * @param tokenGroups from token roles/groups
     * @param diagGroupList the Group from Config file
     * @return true, if is group member
     * @throws DiagUserException the diag user exception
     */
    private boolean isGroupMember(List<String> tokenGroups, List<String> diagGroupList) {
        boolean found = false;

        if (diagGroupList != null && tokenGroups != null) {
            for (int i = 0; (i < diagGroupList.size()) && (!found); i++) {
                String group = diagGroupList.get(i);
                found = searchGroup(group, tokenGroups);
            }
        }
        return found;

    }

    /**
     * Code to compare role member with data in Config file.
     *
     * @param diagrole the roles from Config file
     * @param tokenRoles from token roles/groups
     * @return true, if successful else false
     * @throws LDAPException the LDAP exception
     */
    private boolean searchRole(String diagrole, List<String> tokenRoles) {

        for (String role : tokenRoles) {
            if (StringUtils.equals(role, diagrole)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    /**
     * Code to compare group member with data in Config file.
     *
     * @param diagGroup the Group from Config file
     * @param tokenGroups from token roles/groups
     * @return true, if successful else false
     * @throws LDAPException the LDAP exception
     */
    private boolean searchGroup(String diagGroup, List<String> tokenGroups) {

        for (String group : tokenGroups) {
            if (StringUtils.equals(group, diagGroup)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

}
