
/*
  Creation : 19 Aug 2021
 */
package com.inetpsa.o8d.diagcloud.token.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.conn.ssl.SSLContexts;

import com.inetpsa.o8d.a2dr.config.ServerConfigurationManager;
import com.inetpsa.o8d.diagcloud.token.service.ITokenService;
import com.inetpsa.o8d.diagcloud.token.util.TokenConstants;

/**
 * CAP-25454:The Class TokenServiceImpl.
 */
public class TokenServiceImpl implements ITokenService {

    /** The Constant logger. */
    protected static final Log logger = LogFactory.getFactory().getInstance(TokenServiceImpl.class);

    /**
     * call the IDP URL for token data and validate the response of it{@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diagcloud.token.service.ITokenService#getIDPServiceData(java.lang.StringBuilder)
     */
    public int getIDPServiceData(StringBuilder response) {

        int resCode = HttpURLConnection.HTTP_UNAUTHORIZED;

        try {

            SSLContext sslContext = SSLContexts.custom().useProtocol(TokenConstants.TLS_VERSION_1_2).build();
            String url = ServerConfigurationManager.getInstance().getVariableValue(TokenConstants.IDP_PORTAL_URL);
            URL urlIDP = new URL(url);
            HttpsURLConnection httpConn = (HttpsURLConnection) urlIDP.openConnection();
            httpConn.setSSLSocketFactory(sslContext.getSocketFactory());
            httpConn.setReadTimeout(TokenConstants.READ_TIMEOUT);
            httpConn.setConnectTimeout(TokenConstants.READ_CONNECTION_TIMEOUT);
            httpConn.setRequestMethod(TokenConstants.GET_METHOD);
            httpConn.setRequestProperty(TokenConstants.CONTENT_TYPE, "application/json");
            httpConn.setRequestProperty(TokenConstants.ACCEPT_CHARSET, "UTF-8");
            httpConn.setRequestProperty(TokenConstants.ACCEPT, "application/json");
            resCode = httpConn.getResponseCode();
            logger.info("The Response code received:" + resCode);

            if (resCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                httpConn.getInputStream().close();
                logger.info("GET METHOD Response = \n------------------\n" + response.toString() + "\n------------------------\n");
            }
        } catch (IOException | KeyManagementException | NoSuchAlgorithmException error) {
            // CAP-29321
            logger.error("Error while fetching response from IDP portal.", error);
        }
        return resCode;
    }
}