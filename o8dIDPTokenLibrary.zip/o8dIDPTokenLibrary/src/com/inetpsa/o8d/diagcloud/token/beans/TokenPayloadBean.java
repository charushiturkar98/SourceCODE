package com.inetpsa.o8d.diagcloud.token.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * CAP-25454:The Class TokenPayloadBean.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenPayloadBean implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 376806800901989930L;

    /** The scope. */
    private String scope;

    /** The client id. */
    @JsonProperty("client_id")
    public String clientId;

    /** The rrdi. */
    private String rrdi;

    /** The country. */
    private String country;

    /** The brand. */
    private String brand;

    /** The roles. */
    private transient Object roles;

    /** The username. --sonar issue fix */
    @JsonProperty("username")
    private String username;

    /** The exp. */
    private long exp;

    /** The user type. */
    // START: CAP-26498 :DiagLot2- Add UserType
    @JsonProperty("userType")
    private String userType;

    /**
     * Gets the user type.
     *
     * @return the user type
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Sets the user type.
     *
     * @param userType the new user type
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }

    /**
     * Gets the client id.
     *
     * @return the client id
     */
    @JsonProperty("client_id")
    public String getClientId() {
        return clientId;
    }

    /**
     * Sets the client id.
     *
     * @param clientId the new client id
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Gets the scope.
     *
     * @return the scope
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the scope.
     *
     * @param scope the new scope
     */
    public void setScope(String scope) {
        this.scope = scope;
    }

    /**
     * Gets the rrdi.
     *
     * @return the rrdi
     */
    public String getRrdi() {
        return rrdi;
    }

    /**
     * Sets the rrdi.
     *
     * @param rrdi the new rrdi
     */
    public void setRrdi(String rrdi) {
        this.rrdi = rrdi;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the brand.
     *
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the brand.
     *
     * @param brand the new brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Gets the roles.
     *
     * @return the roles
     */
    public Object getRoles() {
        return roles;
    }

    /**
     * Sets the roles.
     *
     * @param roles the new roles
     */
    public void setRoles(Object roles) {
        this.roles = roles;
    }

    /**
     * Gets the username.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     *
     * @param userName the new user name
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the exp.
     *
     * @return the exp
     */
    public long getExp() {
        return exp;
    }

    /**
     * Sets the exp.
     *
     * @param exp the new exp
     */
    public void setExp(long exp) {
        this.exp = exp;
    }

}
