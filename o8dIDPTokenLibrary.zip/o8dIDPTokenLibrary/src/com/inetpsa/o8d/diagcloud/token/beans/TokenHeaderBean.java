package com.inetpsa.o8d.diagcloud.token.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * CAP-25454:The Class TokenHeaderBean.
 */
public class TokenHeaderBean implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The alg. */
    private String alg;

    /** The pi atm. */
    @JsonProperty("pi.atm")
    public String piAtm;

    /** The kid. */
    private String kid;

    /**
     * Gets the alg.
     *
     * @return the alg
     */
    public String getAlg() {
        return alg;
    }

    /**
     * Sets the alg.
     *
     * @param alg the new alg
     */
    public void setAlg(String alg) {
        this.alg = alg;
    }

    /**
     * Gets the pi atm.
     *
     * @return the pi atm
     */
    public String getPiAtm() {
        return piAtm;
    }

    /**
     * Sets the pi atm.
     *
     * @param pi_atm the new pi atm
     */
    public void setPiAtm(String piAtm) {
        this.piAtm = piAtm;
    }

    /**
     * Gets the kid.
     *
     * @return the kid
     */
    public String getKid() {
        return kid;
    }

    /**
     * Sets the kid.
     *
     * @param kid the new kid
     */
    public void setKid(String kid) {
        this.kid = kid;
    }
}
