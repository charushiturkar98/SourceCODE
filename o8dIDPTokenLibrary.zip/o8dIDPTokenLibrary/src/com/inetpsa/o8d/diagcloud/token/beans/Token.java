package com.inetpsa.o8d.diagcloud.token.beans;

import java.io.Serializable;

/**
 * The Class Token.
 *
 * @author SC28579 CAP-25454
 */
public class Token implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 16832493L;

    /** The header. */
    private TokenHeaderBean header;

    /** The payload. */
    private TokenPayloadBean payload;

    /**
     * Gets the header.
     *
     * @return the header
     */
    public TokenHeaderBean getHeader() {
        return header;
    }

    /**
     * Sets the header.
     *
     * @param header the new header
     */
    public void setHeader(TokenHeaderBean header) {
        this.header = header;
    }

    /**
     * Gets the payload.
     *
     * @return the payload
     */
    public TokenPayloadBean getPayload() {
        return payload;
    }

    /**
     * Sets the payload.
     *
     * @param payload the new payload
     */
    public void setPayload(TokenPayloadBean payload) {
        this.payload = payload;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Token [header=" + header + ", payload=" + payload + "]";
    }

}
