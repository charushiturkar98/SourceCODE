package com.inetpsa.o8d.diagcloud.token.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * CAP-25454 TokenPojo used for DB insert,retrieve and delete.
 *
 * @author SC44980
 */
public class TokenPojo implements Serializable {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -6604928711411013839L;

    /** Key is used to provide input to the service. */

    public static final String TOKEN_INFORMATION_KEY_FOR_SERVICE = "TOKEN_INFORMATION_KEY_FOR_SERVICE";

    /** The id. */
    private int id;

    /** The kid. */
    private String kid;

    /** The user name. */
    private String userName;//sonar issue fix

    /** The client id. */
    private String clientId;

    /** The rrdi. */
    private String rrdi;

    /** The country. */
    private String country;

    /** The brand. */
    private String brand;

    /** The expiration time. */
    private long expirationTime;

    /** The created by. */
    private String createdBy;

    /** The created date. */
    private Date createdDate;

    /** The modified by. */
    private String modifiedBy;

    /** The modified date. */
    private Date modifiedDate;

    /** The db fetch type. */
    private String dbFetchType;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the kid.
     *
     * @return the kid
     */
    public String getKid() {
        return kid;
    }

    /**
     * Sets the kid.
     *
     * @param kid the new kid
     */
    public void setKid(String kid) {
        this.kid = kid;
    }

    /**
     * Gets the user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the user name.
     *
     * @param userName the new user name
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Gets the client id.
     *
     * @return the client id
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Sets the client id.
     *
     * @param clientId the new client id
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Gets the rrdi.
     *
     * @return the rrdi
     */
    public String getRrdi() {
        return rrdi;
    }

    /**
     * Sets the rrdi.
     *
     * @param rrdi the new rrdi
     */
    public void setRrdi(String rrdi) {
        this.rrdi = rrdi;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the brand.
     *
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the brand.
     *
     * @param brand the new brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Gets the expiration time.
     *
     * @return the expiration time
     */
    public long getExpirationTime() {
        return expirationTime;
    }

    /**
     * Sets the expiration time.
     *
     * @param expirationTime the new expiration time
     */
    public void setExpirationTime(long expirationTime) {
        this.expirationTime = expirationTime;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the modified by.
     *
     * @return the modified by
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the modified by.
     *
     * @param modifiedBy the new modified by
     */
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    /**
     * Gets the modified date.
     *
     * @return the modified date
     */
    public Date getModifiedDate() {
        return modifiedDate;
    }

    /**
     * Sets the modified date.
     *
     * @param modifiedDate the new modified date
     */
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    /**
     * Gets the db fetch type.
     *
     * @return the db fetch type
     */
    public String getDbFetchType() {
        return dbFetchType;
    }

    /**
     * Sets the db fetch type.
     *
     * @param dbFetchType the new db fetch type
     */
    public void setDbFetchType(String dbFetchType) {
        this.dbFetchType = dbFetchType;
    }

}
