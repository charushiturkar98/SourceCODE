/*
 * Creation : 8 Sep 2021
 */
package com.inetpsa.o8d.diagcloud.token.service;

import java.util.Date;
import java.util.List;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.apache.ojb.broker.util.ObjectModification;

import com.inetpsa.fwk.exception.FwkException;
import com.inetpsa.fwk.service.persistence.IPersistentContextKey;
import com.inetpsa.fwk.service.persistence.OJBPersistentContext;
import com.inetpsa.o8d.a2dr.service.AbstractA2DRBusinessService;
import com.inetpsa.o8d.diagcloud.token.beans.TokenPojo;
import com.inetpsa.o8d.diagcloud.token.util.TokenConstants;

/**
 * Class to perform CRUD operations on token object.
 *
 * @author SC44980 CAP-25454
 */
public class TokenIDPDBBusinessService extends AbstractA2DRBusinessService {

    /** The Constant SERVICE_NAME. */
    public static final String SERVICE_NAME = "idp_token_db_management";

    /** The Constant ABORT_ERROR_MSG. */
    private static final String ABORT_ERROR_MSG = "the transaction could not be canceled";

    /**
     * Instantiates a new token IDPDB business service.
     *
     * @throws FwkException the fwk exception
     */
    // sonar issue fixed
    public TokenIDPDBBusinessService() throws FwkException {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.fwk.service.BusinessService#doExecute()
     */
    @Override
    protected void doExecute() throws FwkException {

        logger.debug(">> start Execution of the IDPTokenDBService ");
        /**
         * DB connection
         */
        IPersistentContextKey key = buildPersistentContextKey();
        OJBPersistentContext persistentContext = (OJBPersistentContext) getPersistentContext(key);
        PersistenceBroker broker = null;

        try {
            broker = persistentContext.getBroker();

            TokenPojo token = (TokenPojo) this.getInput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE);

            if (TokenConstants.DB_FETCH_TYPE_INSERT.equals(token.getDbFetchType())) {
                insertTokenData(token, broker, key);
            } else if (TokenConstants.DB_FETCH_TYPE_RETRIEVE.equals(token.getDbFetchType())) {
                retriveTokenData(token, broker, key);
            }

        } catch (FwkException e) {
            logger.error("Fwk exception", e);

            if (broker != null) {
                try {
                    if (broker.isInTransaction()) {
                        abortTransaction(key);
                    }
                } catch (FwkException fwk) {
                    logger.error(ABORT_ERROR_MSG, fwk);
                }
            }
        } finally {
            if (key != null) {
                try {
                    closePersistentContext(key);
                } catch (FwkException fwk) {
                    logger.error("error closing the PersistentContext", fwk);
                }
            }
        }
        logger.debug("<< end Execution of the IDPTokenDBService ");
    }

    /**
     * Insert token.
     *
     * @param createToken the create token
     * @param broker the broker
     * @param key the key
     * @throws FwkException the fwk exception
     */
    private void insertTokenData(TokenPojo createToken, PersistenceBroker broker, IPersistentContextKey key) throws FwkException {
        beginTransaction(key);

        createToken.setCreatedBy("DSS");
        createToken.setCreatedDate(new Date());
        broker.store(createToken, ObjectModification.INSERT);
        commitTransaction(key);

    }

    /**
     * Retrive token.
     *
     * @param token the token
     * @param broker the broker
     * @param key the key
     * @throws FwkException the fwk exception
     */
    private void retriveTokenData(TokenPojo token, PersistenceBroker broker, IPersistentContextKey key) throws FwkException {
        beginTransaction(key);
        Criteria criteria = new Criteria();
        criteria.addEqualTo("KID", token.getKid());
        criteria.addEqualTo("USER_ID", token.getUserName());
        criteria.addEqualTo("CREATED_DATE", token.getCreatedDate());
        QueryByCriteria q = new QueryByCriteria(TokenPojo.class, criteria);
        this.setOutput(TokenPojo.TOKEN_INFORMATION_KEY_FOR_SERVICE, (List<TokenPojo>) broker.getCollectionByQuery(q));
    }

}
