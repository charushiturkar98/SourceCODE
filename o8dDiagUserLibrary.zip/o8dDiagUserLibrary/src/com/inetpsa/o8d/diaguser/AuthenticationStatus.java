package com.inetpsa.o8d.diaguser;

/**
 * Statut d'authentification.
 * 
 * @author E331258
 */
public enum AuthenticationStatus {
    /**
     * Erreur d'authentification.
     */
    AUTH_FAILED,
    /**
     * Succ�s d'authentification.
     */
    AUTH_SUCCESS,
    /**
     * Utilisateur lock� (temporisation).
     */
    LOCKED;
}
