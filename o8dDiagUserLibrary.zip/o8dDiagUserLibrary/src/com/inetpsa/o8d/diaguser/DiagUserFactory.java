package com.inetpsa.o8d.diaguser;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Classe singleton qui sert de fabrique pour les objets DiagUser.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class DiagUserFactory {

    /** Log de la classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(DiagUserFactory.class);

    /** instance unique pour singleton */
    private static final DiagUserFactory INSTANCE = new DiagUserFactory();

    /**
     * Methode qui renvoie l'unique instance.
     * 
     * @return instance unique de la classe.
     */
    public static DiagUserFactory getInstance() {
        long tmstp;
        tmstp = System.currentTimeMillis();
        LOGGER.debug("ETP_1 Input DiagUserFactory getInstance () Timestamp =" + tmstp);
        return INSTANCE;
    }

    /**
     * Initialisation.
     *
     * @throws DiagUserException si une erreur survient
     */
    public void init() throws DiagUserException {
        MetaDataRepository.getInstance().init();
    }

    /**
     * Methode qui renvoie le connecteur DiagUser correspendant au parametre <code>params</code>.
     *
     * @param diagUserCredentials parametres qui determinent le DiagUser � renvoyer
     * @param hostName the host name
     * @return l'instance de connecteur DiagUser.
     * @throws DiagUserException exception en cas de probleme.
     */
    public AbstractDiagUserConnector getDiagUserConnectorInstance(DiagUserCredentials diagUserCredentials, String hostName) throws DiagUserException {
        long tmstp;

        tmstp = System.currentTimeMillis();
        LOGGER.debug("ETP_2 Entree getDiagUserConnectorInstance() Timestamp = " + tmstp + " userName = " + diagUserCredentials.getUserName());

        List<AbstractDiagUserConnector> connectorsList = MetaDataRepository.getInstance().getConnectors();

        tmstp = System.currentTimeMillis();
        LOGGER.debug("ETP_3  getDiagUserConnectorInstance() MetaDataRepository() Timestamp = " + tmstp + " userName = "
                + diagUserCredentials.getUserName());

        AbstractDiagUserConnector result = null;

        for (AbstractDiagUserConnector connector : connectorsList) {
            boolean iscandidat = connector.check(diagUserCredentials.getUserName());
            LOGGER.debug("iscandidat : {} ", iscandidat);
            // on s'arrete � la premiere occurence
            if (iscandidat) {
                // CAP-26498:DiagLot2-Passing hostName
                result = connector.buildNewInstance(diagUserCredentials, hostName);
                break;
            }
        }

        tmstp = System.currentTimeMillis();
        LOGGER.debug("ETP_4 Output getDiagUserConnectorInstance () Timestamp =" + tmstp + "userName =" + diagUserCredentials.getUserName());

        return result;
    }
}
