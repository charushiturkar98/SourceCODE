package com.inetpsa.o8d.diaguser;

/**
 * Types de contr�le pour les OI.
 * 
 * @author E331258
 */
public enum OICheckType {

    /**
     * Abonnement.
     */
    SUBSCRIPTION,
    /**
     * Contrat.
     */
    CONTRACT,
    /**
     * Pas de contr�le en dehors des identifiant/mot de passe.
     */
    NONE
}
