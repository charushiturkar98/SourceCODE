package com.inetpsa.o8d.diaguser;

/**
 * Statut d'authentication et d'autorisation.
 * 
 * @author E331258
 */
public enum DiagUserStatus {

    /**
     * Statut pour une authentification et un contr�le des droits r�ussis.
     */
    AUTHENTICATED_AND_AUTHORIZED(200),
    /**
     * Statut pour une authentification r�ussie mais �chec lors du contr�le des droits.
     */
    NO_PERMISSION(403),
    /**
     * Statut pour un �chec lors de l'authentification.
     */
    AUTHENTICATION_FAILED(401);

    /**
     * Code http correspondant.
     */
    private final int httpCode;

    /**
     * Constructeur.
     * 
     * @param httpCode Code http correspondant
     */
    private DiagUserStatus(int httpCode) {
        this.httpCode = httpCode;
    }

    /**
     * Getter httpCode
     * 
     * @return the httpCode
     */
    public int getHttpCode() {
        return httpCode;
    }
}
