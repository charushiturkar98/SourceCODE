package com.inetpsa.o8d.diaguser;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.clp.LDAPEstablishment;
import com.inetpsa.clp.LDAPLocalization;
import com.inetpsa.clp.LDAPPassport;
import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.LDAPWorkPlace;

/**
 * Classe abstraite qui reference toutes les methodes qui doivent etre implementer pour pouvoir utiliser une multitude de referentiel a partir d'une
 * interface unifiee
 * 
 * @author Hichame ELKHALFI - E298062
 */
public abstract class AbstractDiagUserConnector implements Serializable {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -6776019507839289960L;
    /**
     * Message d'erreur de non impl�mentation.
     */
    protected static final String ERROR_NOT_IMPLEMENTED_MSG = "Method is not implemented";
    /**
     * Message d'erreur d'authentification.
     */
    protected static final String ERROR_AUTH_FAILED_MSG = "Authentication failed for login : ";

    /** Log de la classe */
    protected final Logger logger = LoggerFactory.getLogger(getClass());

    /** definition du connecteur */
    private ConnectorDefinition connectorDefinition;

    /** autorisation par service applicatif */
    protected List<Boolean> availableServicesAppLst = new ArrayList<Boolean>();

    /** nom de l'application */
    protected String applicationId;
    /**
     * Adresse IP de l'utilisateur.
     */
    private DiagUserCredentials diagUserCredentials;

    /**
     * Indique si l'appel au LDAP pour authentification a �t� effectu�.
     */
    protected boolean authenticationDone;

    /**
     * Indique si l'utilisation est valide (couple login/password correct).
     */
    protected boolean validUser;
    // START: CAP-26498-DiagLot2
    protected String hostName;

    /**
     * Getter hostName
     * 
     * @return the hostName
     */
    public String getRequest() {
        return hostName;
    }

    /**
     * Setter hostName
     * 
     * @param hostName the hostName to set
     */
    public void setRequest(String hostName) {
        this.hostName = hostName;
    }
    // END: CAP-26498

    /**
     * Getter connectorDefinition
     * 
     * @return the connectorDefinition
     */
    public ConnectorDefinition getConnectorDefinition() {
        return connectorDefinition;
    }

    /**
     * Setter connectorDefinition
     * 
     * @param connectorDefinition the connectorDefinition to set
     */
    public void setConnectorDefinition(ConnectorDefinition connectorDefinition) {
        this.connectorDefinition = connectorDefinition;
    }

    /**
     * Setter du nom de l'application.
     * 
     * @param applicationId nom de l'application.
     * @throws DiagUserException si l'applicationId fourni n'est pas autoris� pour le connecteur
     */
    public void setApplicationId(String applicationId) throws DiagUserException {
        logger.debug("setApplicationId()" + applicationId);

        if (connectorDefinition.getAvailableApplications().contains(applicationId)) {
            this.applicationId = applicationId;
        } else {
            throw new DiagUserException("L'application '" + applicationId + "' n'est pas disponible pour ce connecteur");
        }
    }

    /**
     * Getter du nom de l'application.
     * 
     * @return Renvoie applicationId.
     */
    public String getApplicationId() {
        logger.debug("getApplicationId()");
        return applicationId;
    }

    /**
     * Getter diagUserCredentials
     * 
     * @return the diagUserCredentials
     */
    public DiagUserCredentials getDiagUserCredentials() {
        return diagUserCredentials;
    }

    /**
     * Setter diagUserCredentials
     * 
     * @param diagUserCredentials the diagUserCredentials to set
     */
    public void setDiagUserCredentials(DiagUserCredentials diagUserCredentials) {
        this.diagUserCredentials = diagUserCredentials;
    }

    /**
     * Retourne le username
     * 
     * @return the username
     */
    public String getUserName() {
        return diagUserCredentials.getUserName();
    }

    /**
     * Retourne le password
     * 
     * @return the password
     */
    public String getPassword() {
        return diagUserCredentials.getPassword();
    }

    /**
     * Retourne le userIpAddress
     * 
     * @return the userIpAddress
     */
    public String getUserIpAddress() {
        return diagUserCredentials.getUserIpAddress();
    }

    /**
     * Representation sous forme de String de l'objet DiagUser.
     * 
     * @return String du DiagUser.
     */
    @Override
    public String toString() {
        logger.debug("toString() >> ");

        String username = diagUserCredentials.getUserName();

        StringBuilder buff = new StringBuilder();
        buff.append(getUserType()).append(" : username='").append(username).append("', ").append("application='").append(getApplicationId())
                .append("'");

        return buff.toString();
    }

    /**
     * Cr�ation d'une nouvelle instance du connecteur.
     * 
     * @param diagUserCredentials parametres de l'utilisateur
     * @return le connecteur
     * @throws DiagUserException si une erreur survient
     */
    protected AbstractDiagUserConnector buildNewInstance(DiagUserCredentials diagUserCredentials, String hostName) throws DiagUserException {
        AbstractDiagUserConnector diagUserConnector = buildNewInstance();
        // logger.info("diagUserConnector " + diagUserConnector);

        diagUserConnector.setConnectorDefinition(getConnectorDefinition());
        // CAP-26498:DiagLot2-Setting hostName
        diagUserConnector.setRequest(hostName);
        diagUserConnector.setDiagUserCredentials(diagUserCredentials);
        logger.info("diagUserConnector1 " + diagUserConnector);
        return diagUserConnector;
    }

    /**
     * Cr�ation d'une nouvelle instance du connecteur.
     * 
     * @return le connecteur
     */
    protected abstract AbstractDiagUserConnector buildNewInstance();

    /**
     * Lancement de l'authentification.
     * 
     * @throws DiagUserException si une erreur survient
     */
    protected abstract void executeAuthentication() throws DiagUserException;

    /**
     * Getter du nom du VIN.
     * 
     * @return Renvoie vin.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getVin() throws DiagUserException;

    /**
     * Setter du nom du VIN.
     * 
     * @param vin le vin.
     * @throws DiagUserException si une erreur survient
     */
    public abstract void setVin(String vin) throws DiagUserException;

    /**
     * Methode qui permet de recuperer l'url d'acces a la shematique.
     * 
     * @return l'url d'acces a la shematique.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getShematiqueURL() throws DiagUserException;

    /**
     * Retourne les urls B2B.
     * 
     * @return enumeration de valeurs trouv�es
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getB2BURLs() throws DiagUserException;

    /**
     * Retourne le type de contrat.
     * 
     * @return type de contrat
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getContractType() throws DiagUserException;

    /**
     * Retourne le numero de client
     * 
     * @return numero de client
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getCustomerNumber() throws DiagUserException;

    /**
     * Retourne 'dealNetworks'
     * 
     * @return enumeration de valeurs
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getDealNetworks() throws DiagUserException;

    /**
     * Retourne la direction
     * 
     * @return direction
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getDirection() throws DiagUserException;

    /**
     * Retourne l'email.
     * 
     * @return email
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getEmail() throws DiagUserException;

    /**
     * Retourne le code employee.
     * 
     * @return code employee
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getEmployeeCode() throws DiagUserException;

    /**
     * Retourne le type employee.
     * 
     * @return type employee
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getEmployeeType() throws DiagUserException;

    /**
     * Retourne l'etablissement.
     * 
     * @return etablissement
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPEstablishment getEstablishment() throws DiagUserException;

    /**
     * Retourne le telephone externe.
     * 
     * @return telephone externe
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getExternalPhone() throws DiagUserException;

    /**
     * Retourne le telephone externe 2.
     * 
     * @return telephone externe 2
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getExternalPhone2() throws DiagUserException;

    /**
     * Retourne le fax.
     * 
     * @return fax
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getFax() throws DiagUserException;

    /**
     * Retourne le prenom.
     * 
     * @return prenom
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getFirstName() throws DiagUserException;

    /**
     * Retourne le prenom 2.
     * 
     * @return prenom 2
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getFirstName2() throws DiagUserException;

    /**
     * Retourne les fonctions.
     * 
     * @return fonctions
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getFunctions() throws DiagUserException;

    /**
     * Retourne les partenaires.
     * 
     * @return partenaires
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getIndustrialPartners() throws DiagUserException;

    /**
     * Retourne le telephone interne.
     * 
     * @return telephone interne
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getInternalPhone() throws DiagUserException;

    /**
     * Retourne le telephone interne 2.
     * 
     * @return telephone interne 2
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getInternalPhone2() throws DiagUserException;

    /**
     * Methode qui permet de recuperer la langue.
     * 
     * @return la langue.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getLangue() throws DiagUserException;

    /**
     * Retourne le nom de famille.
     * 
     * @return nom de famille
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getLastName() throws DiagUserException;

    /**
     * Methode qui permet de recuperer la Locale.
     * 
     * @return la Locale.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getLocale() throws DiagUserException;

    /**
     * Retourne la localisation.
     * 
     * @return localisation
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPLocalization getLocalization() throws DiagUserException;

    /**
     * Retourne le localisation 2.
     * 
     * @return localisation 2
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPLocalization getLocalization2() throws DiagUserException;

    /**
     * Retourne le 'mailFile'.
     * 
     * @return mailfile
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getMailFile() throws DiagUserException;

    /**
     * Retourne le serveur de mail.
     * 
     * @return serveur de mail
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getMailServer() throws DiagUserException;

    /**
     * Retourne la marque.
     * 
     * @return marque
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getMarque() throws DiagUserException;

    /**
     * Retourne le mobile.
     * 
     * @return mobile
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getMobile() throws DiagUserException;

    /**
     * Retourne le passport.
     * 
     * @return passport
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPPassport getPassport() throws DiagUserException;

    /**
     * Retourne les passports.
     * 
     * @return passports
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getPassports() throws DiagUserException;

    /**
     * Methode qui permet de recuperer le code pays.
     * 
     * @return code pays.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getPays() throws DiagUserException;

    /**
     * Retourne la secretaire.
     * 
     * @return secretaire
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPUser getSecretary() throws DiagUserException;

    /**
     * Retourne les suppliers.
     * 
     * @return suppliers
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getSuppliers() throws DiagUserException;

    /**
     * Retourne le tel.
     * 
     * @return tel
     * @throws DiagUserException si une erreur survient
     */
    public abstract Enumeration getTel() throws DiagUserException;

    /**
     * Retourne l'id unix.
     * 
     * @return id unix
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getUnixIdNumber() throws DiagUserException;

    /**
     * Retourne l'uid unix.
     * 
     * @return uid unix
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getUnixUid() throws DiagUserException;

    /**
     * Retourne la validit�
     * 
     * @return validit�
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getValidity() throws DiagUserException;

    /**
     * Retourne l'emplacement de travail.
     * 
     * @return emplacement de travail
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPWorkPlace getWorkPlace() throws DiagUserException;

    /**
     * Retourne l'emplacement de travail 2.
     * 
     * @return emplacement de travail 2
     * @throws DiagUserException si une erreur survient
     */
    public abstract LDAPWorkPlace getWorkPlace2() throws DiagUserException;

    /**
     * Retourne si le user dispose d'une partenaire.
     * 
     * @return vrai si oui, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean hasIndustrialPartner() throws DiagUserException;

    /**
     * Retourne si le user dispose d'un supplier.
     * 
     * @return vrai si oui, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean hasSupplier() throws DiagUserException;

    /**
     * Retourne si le user dispose de droits de visite.
     * 
     * @return vrai si oui, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean hasVisitRight() throws DiagUserException;

    /**
     * Retourne si le user dispose de droits de visite.
     * 
     * @param principal droit principal
     * @param credentials credentials
     * @return vrai si oui, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean hasVisitRight(String principal, String credentials) throws DiagUserException;

    /**
     * Rentourne la description de l'implentation du DiagUser.
     * 
     * @return description de l'implentation du DiagUser.
     */
    public abstract String getDescription();

    /**
     * Methode qui permet de recuperer l'operateur a realise une session diagnostic. Dans le cas des operateurs agrees, le code du point de vente
     * (code RRDI), voir la classe LdapDiagUser. Dans le cas des operateurs independants, le numero de contrat, voir les classes des utilisateurs OI.
     * Voir aussi le docuement : DM086 : Ouverture PPD aux Reparateurs Independants.
     * 
     * @return code RRDI ou le numero de contrat.
     * @throws DiagUserException si une erreur survient
     */
    public abstract String getIdOperator() throws DiagUserException;

    /**
     * Methode qui permet de savoir si un contrat est valide.
     * 
     * @return 'true' ou 'false.
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean isContratValide() throws DiagUserException;

    /**
     * Methode qui permet de savoir si un abonnement VIN est en cours de validite.
     * 
     * @return 'true' ou 'false.
     * @throws DiagUserException si une erreur survient
     */
    public abstract boolean isAbonnementVinValide() throws DiagUserException;

    /**
     * Methode qui permet de conaitre la date de fin du contrat.
     * 
     * @return 'true' ou 'false.
     * @throws DiagUserException si une erreur survient
     */
    public abstract Date getDateFinContrat() throws DiagUserException;

    /**
     * Methode qui permet de recuperer la carte d'identite de l'utilisateur sous forme de chaine de caractere
     * 
     * @return carte d'identite
     * @throws DiagUserException si une erreur survient
     */
    public String getIdentityCardAsString() throws DiagUserException {
        StringBuilder sb = new StringBuilder();

        initIdentityCard();

        if (isUserAuthenticated()) {
            sb.append("USER_ID=").append(diagUserCredentials.getUserName()).append("\nUSER_IDENTITY=").append(getFirstName()).append(" ")
                    .append(getLastName()).append("\n\n");

            List<String> applicationServices = connectorDefinition.getIdentityCardApplicationServices();
            logger.info("applicationServices " + applicationServices);
            for (int i = 0; i < applicationServices.size(); i++) {
                sb.append(applicationServices.get(i)).append("=").append(availableServicesAppLst.get(i)).append("\n");
            }
        }

        return sb.toString();
    }

    /**
     * Methode qui permet d'initialiser les informations d'autorisation d'acces aux differentes applications via les services applicatifs specifiques
     * par type d'utilisateur
     * 
     * @throws DiagUserException si une erreur survient
     */
    protected void initIdentityCard() throws DiagUserException {
        if (!availableServicesAppLst.isEmpty()) {
            return;
        }

        if (isUserAuthenticated()) {
            List<String> applicationServices = connectorDefinition.getIdentityCardApplicationServices();
            logger.info("applicationServices " + applicationServices);

            if (applicationServices != null) {
                // Sauvegarde de l'identifiant d'application avant parcours de l'ensemble
                String appId = getApplicationId();

                for (int i = 0; i < applicationServices.size(); i++) {
                    setApplicationId(applicationServices.get(i));
                    boolean isAuthorized = autorize();
                    availableServicesAppLst.add(isAuthorized);
                    logger.info("availableServicesAppLst " + availableServicesAppLst);
                }

                // Restauration de l'identifiant d'application apr�s parcours de l'ensemble
                if (appId != null) {
                    setApplicationId(appId);
                }
            }
        }
    }

    /**
     * Methode verifie si ce connecteur est le candidat.
     * 
     * @param login login � controler
     * @return 'true' si c'est le candidat, sinon 'false'
     */
    public boolean check(String login) {
        logger.debug("check() >>");

        boolean result = false;

        String pattern = connectorDefinition.getPattern();

        logger.debug("check sur l'id '{}' et le pattern '{}'", login, pattern);

        if (login == null) {
            logger.debug("Le login est null : l'utilisateur n'est pas de type {}", getUserType());
        } else if (Pattern.matches(pattern, login)) {
            result = true;
            logger.debug("l'utilisateur est de type {}", getUserType());
        } else {
            logger.debug("l'utilisateur n'est pas de type {}", getUserType());
        }
        logger.debug("check() <<");
        return result;

    }

    /**
     * Retourne le type d'utilisateur.
     * 
     * @return type d'utilisateur
     */
    public UserType getUserType() {
        return connectorDefinition.getUserType();
    }

    /**
     * Contr�le l'authentification et les droits.
     * 
     * @return le statut
     * @throws DiagUserException si une erreur survient
     */
    public DiagUserStatus authenticateAndAuthorize() throws DiagUserException {
        DiagUserStatus diagUserStatus = null;
        long tmstp;

        tmstp = System.currentTimeMillis();
        logger.debug("ETP_1 Entree authenticateAndAuthorize() Timestamp = " + tmstp + " userName = " + diagUserCredentials.getUserName());

        AuthenticationStatus authenticated = authenticate();
        logger.debug("ETP_2  authenticateAndAuthorize() authenticate() Timestamp = " + tmstp + " userName = " + diagUserCredentials.getUserName());

        if (authenticated == AuthenticationStatus.AUTH_SUCCESS) {
            logger.debug("ETP_3  authenticateAndAuthorize() AuthenticationStatus.AUTH_SUCCESS Timestamp = " + tmstp + " userName = "
                    + diagUserCredentials.getUserName());
            if (autorize()) {
                logger.debug("ETP_4  authenticateAndAuthorize() DiagUserStatus.AUTHENTICATED_AND_AUTHORIZED Timestamp = " + tmstp + " userName = "
                        + diagUserCredentials.getUserName());

                diagUserStatus = DiagUserStatus.AUTHENTICATED_AND_AUTHORIZED;
            } else {
                tmstp = System.currentTimeMillis();
                logger.debug("ETP_5  authenticateAndAuthorize() DiagUserStatus.AUTHENTICATED_AND_NOT_AUTHORIZED Timestamp = " + tmstp + " userName = "
                        + diagUserCredentials.getUserName());
                diagUserStatus = DiagUserStatus.NO_PERMISSION;
            }
        } else if (authenticated == AuthenticationStatus.AUTH_FAILED) {
            logger.debug("ETP_6  authenticateAndAuthorize() AuthenticationStatus.AUTH_FAILED Timestamp = " + tmstp + " userName = "
                    + diagUserCredentials.getUserName());

            diagUserStatus = DiagUserStatus.AUTHENTICATION_FAILED;
        } else {
            // Cas du locked (AuthenticationStatus.LOCKED)
            logger.debug("ETP_7  authenticateAndAuthorize() DiagUserStatus.NO_PERMISSION Timestamp = " + tmstp + " userName = "
                    + diagUserCredentials.getUserName());

            diagUserStatus = DiagUserStatus.NO_PERMISSION;
        }

        // Display Locked RA Users List
        DiagUserAccessLockerManager diagUserAccessLockerManager = DiagUserAccessLockerManager.getInstance();
        diagUserAccessLockerManager.DisplayMapAuthFailures();

        logger.debug("ETP_8  Sortie authenticateAndAuthorize() Timestamp = " + tmstp + " userName = " + diagUserCredentials.getUserName());
        return diagUserStatus;
    }

    /**
     * Execution de l'authentification.
     * 
     * @return le statut d'authentification
     * @throws DiagUserException si une erreur survient
     */
    public AuthenticationStatus authenticate() throws DiagUserException {
        AuthenticationStatus authenticationStatus = null;

        DiagUserAccessLockerManager diagUserAccessLockerManager = DiagUserAccessLockerManager.getInstance();
        logger.info("diagUserAccessLockerManager  " + diagUserAccessLockerManager);
        // On recherche si l'utilisateur a deja effectu� des tentatives
        ConnectionAttempts connectionAttempts = diagUserAccessLockerManager.searchAttempts(this);
        logger.info("connectionAttempts " + connectionAttempts);
        // On v�rifie qu'il n'est pas bloqu�
        if (!diagUserAccessLockerManager.isLocked(this, connectionAttempts)) {
            // On v�rifie si l'utilisateur est authentifi�
            boolean isAuth = isUserAuthenticated();

            // Si l'authentification a �chou�, on ajoute une tentative
            if (!isAuth) {
                authenticationStatus = AuthenticationStatus.AUTH_FAILED;

                diagUserAccessLockerManager.addAttempt(this, connectionAttempts);
            } else {
                authenticationStatus = AuthenticationStatus.AUTH_SUCCESS;
            }
        } else {
            authenticationStatus = AuthenticationStatus.LOCKED;

            logger.warn("Locked - Utilisateur : {}, IP : {}", getUserName(), getUserIpAddress());
        }

        return authenticationStatus;
    }

    /**
     * Methode qui permet de v�rifier l'authentifier d'un operateur.
     * 
     * @return 'true ou 'false'.
     * @throws DiagUserException si une erreur survient
     */
    protected boolean isUserAuthenticated() throws DiagUserException {
        logger.debug("isUserAuthenticated()");

        // Si on n'as pas encore fait d'authentification, on sollicite l'authentification
        // Cela permet de ne pas faire 2 fois l'appel distant
        if (!authenticationDone) {
            executeAuthentication();
        }

        return validUser;
    }

    /**
     * Methode qui execute l'autorisation.
     * 
     * @return 'true' si l'utilisateur est autorise, sinon renvoie 'false'.
     * @throws DiagUserException si une erreur survient
     */
    public boolean autorize() throws DiagUserException {
        logger.debug(">> autorise [{}]", diagUserCredentials.getUserName());

        Autorisation autorisationDefinition = MetaDataRepository.getInstance().getAutorisation(getApplicationId());
        boolean isAutorized = isAuthorized(autorisationDefinition);

        logger.debug("<< autorise [{}]", isAutorized);

        return isAutorized;

    }

    /**
     * Methode qui execute l'autorisation.
     * 
     * @param autorisation autorisation a utiliser
     * @return 'true' si l'utilisateur est autorise, sinon renvoie 'false'.
     * @throws DiagUserException si une erreur survient
     */
    private boolean isAuthorized(Autorisation autorisation) throws DiagUserException {
        logger.debug(">> isAuthorized");

        logger.info("{} => verification autorisation sur un connecteur de type : {}", getApplicationId(), getUserType());

        if (autorisation == null) {
            logger.debug("{} => application non trouvee dans les regles", getApplicationId());
            return false;
        }

        boolean auth = doConnectorPermissionCheck(autorisation);

        logger.debug("<< isAuthorized");

        return auth;
    }

    /**
     * Lance le contr�les des droits du connecteur.
     * 
     * @param autorisation objet {@link Autorisation}
     * @return vrai si authentifi�, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    protected abstract boolean doConnectorPermissionCheck(Autorisation autorisation) throws DiagUserException;
}
