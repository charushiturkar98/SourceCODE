package com.inetpsa.o8d.diaguser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * La classe MetaDataRepository permet la manipulation du fichier de configuration XML.
 * 
 * @author Hichame ELKHALFI - E298062.
 */
public class MetaDataRepository {

    /** Log de la classe */
    private static final Logger LOGGER = LoggerFactory.getLogger(MetaDataRepository.class);

    /**
     * Message d'erreur de cr�ation d'instance de clasee.
     */
    private static final String ERROR_NEWINSTANCE_MSG = "Error getting new instance for : ";

    /**
     * Message pour l'erreur de chargement de fichier
     */
    private static final String ERROR_LOADING_FILE_MSG = "Error loading file ";

    /** nom du fichier de definition des rules */
    private static final String RULES_FILENAME = "diaguser-rules.xml";

    /** singleton de la classe */
    private static final MetaDataRepository INSTANCE = new MetaDataRepository();

    /** liste des connecteurs */
    private List<AbstractDiagUserConnector> connectors;

    /** Map des autorisations */
    private Map<String, Autorisation> autorisations;

    /**
     * Retourne l'instance du singleton.
     * 
     * @return instance du singleton.
     */
    public static MetaDataRepository getInstance() {
        return INSTANCE;
    }

    /**
     * Methode qui parse le fichier de configuration.
     * 
     * @throws DiagUserException exception en cas de probleme.
     */
    public void init() throws DiagUserException {
        LOGGER.debug(">>init()");

        try {
            JAXBContext rulesJaxbContext = JAXBContext.newInstance(Rules.class);
            Unmarshaller unmarshaller = rulesJaxbContext.createUnmarshaller();

            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(RULES_FILENAME);

            if (is == null) {
                throw new DiagUserException(ERROR_LOADING_FILE_MSG + RULES_FILENAME + " : Not found in classpath");
            }

            Rules rules = (Rules) unmarshaller.unmarshal(is);

            autorisations = rules.getAutorisations();
            LOGGER.debug("autorisations : {}", autorisations);

            logDefinitions();

            buildConnectors(rules.getConnectorDefinitions());
        } catch (JAXBException e) {
            LOGGER.error(ERROR_LOADING_FILE_MSG + RULES_FILENAME, e);
            throw new DiagUserException(ERROR_LOADING_FILE_MSG + RULES_FILENAME, e);
        }

        LOGGER.debug("<<init()");
    }

    /**
     * Affichage des definitions d'autorisations dans les logs.
     */
    private void logDefinitions() {
        if (LOGGER.isInfoEnabled()) {
            StringBuilder sb = new StringBuilder("Droits initialises :");

            for (Entry<String, Autorisation> entry : autorisations.entrySet()) {
                sb.append("\n").append(entry.getKey()).append(" :\n");
                sb.append("\tauth_oi = ").append(entry.getValue().isAuthOI()).append("\n");
                sb.append("\toi_check_type = ").append(entry.getValue().getAuthOICheckType()).append("\n");
                sb.append("\tauth_ldap = ").append(entry.getValue().isAuthLDAP()).append("\n");
                sb.append("\trole_group_required = ").append(entry.getValue().isRoleOrGroupRequired()).append("\n");
                sb.append("\tldap groups = ").append(entry.getValue().getLdapGroups()).append("\n");
                sb.append("\tldap roles = ").append(entry.getValue().getLdapRoles()).append("\n");
            }
            LOGGER.info(sb.toString());
            sb.setLength(0); // CAP-29321 Resetting StringBuilder to null
        }
    }

    /**
     * Methode qui instantie les connecteurs a partir de la definition textuelle.
     * 
     * @param connectorDefinitions liste de d�finitions de connecteurs
     * @return liste des connecteurs
     * @throws DiagUserException exception en cas de probleme.
     */
    private List<AbstractDiagUserConnector> buildConnectors(List<ConnectorDefinition> connectorDefinitions) throws DiagUserException {
        connectors = new ArrayList<AbstractDiagUserConnector>();
        LOGGER.debug(">> constructConnectors");

        for (ConnectorDefinition connectorDefinition : connectorDefinitions) {
            AbstractDiagUserConnector diagCon = (AbstractDiagUserConnector) getEmptyNewInstance(connectorDefinition.getClassName());
            diagCon.setConnectorDefinition(connectorDefinition);
            connectors.add(diagCon);
        }

        LOGGER.debug("construction de '{}' connecteurs", connectors.size());
        LOGGER.debug("<< constructConnectors");

        return connectors;
    }

    /**
     * Getter de la liste des connecteurs concrets.
     * 
     * @return liste des connecteurs concrets.
     * @throws DiagUserException exception en cas de probleme.
     */
    public List<AbstractDiagUserConnector> getConnectors() throws DiagUserException {
        return connectors;
    }

    /**
     * Retourne la potilique d'autorisation.
     * 
     * @param applicationName nom de l'application qui souhaite autoriser un utilisateur.
     * @return une potilique d'autorisation.
     * @throws DiagUserException exception en cas de probleme.
     */
    public Autorisation getAutorisation(String applicationName) throws DiagUserException {
        LOGGER.debug(">> getAutorisation({})", applicationName);

        if (applicationName == null || applicationName.length() == 0) {
            throw new DiagUserException("le 'applicationName' ne doit pas etre 'null' ou vide");
        }
        Autorisation autorisation = autorisations.get(applicationName);

        LOGGER.debug("<< getAutorisation({})", applicationName);

        return autorisation;
    }

    /**
     * Permet d'instancier un class a partir de son nom de class.
     * 
     * @param className nom complet de la class.
     * @return instance de la class.
     * @throws DiagUserException en cas de probleme.
     */
    private static Object getEmptyNewInstance(String className) throws DiagUserException {
        LOGGER.debug(">> DiagUtil.getEmptyNewInstance({})", className);

        if (className == null) {
            LOGGER.debug("<< DiagUtil.getEmptyNewInstance: className is null");
            throw new DiagUserException("getEmptyInstance exception : parametre non valide (null)");
        }

        Class<?> clazz;
        Object result = null;

        try {
            clazz = Class.forName(className);
            result = clazz.newInstance();
        } catch (ClassNotFoundException e) {
            LOGGER.error(ERROR_NEWINSTANCE_MSG + className, e);
            throw new DiagUserException(e);
        } catch (InstantiationException e) {
            LOGGER.error(ERROR_NEWINSTANCE_MSG + className, e);
            throw new DiagUserException(e);
        } catch (IllegalAccessException e) {
            LOGGER.error(ERROR_NEWINSTANCE_MSG + className, e);
            throw new DiagUserException(e);
        }

        LOGGER.debug("<< DiagUtil.getEmptyNewInstance({})", className);

        return result;
    }
}
