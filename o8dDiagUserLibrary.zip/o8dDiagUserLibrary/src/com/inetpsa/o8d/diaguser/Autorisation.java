package com.inetpsa.o8d.diaguser;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * Objet XML pour les autorisations.
 * 
 * @author e331258
 */
public class Autorisation {
    /**
     * Les OI sont-ils concern�s par cette autorisation ?
     */
    private boolean authOI;
    /**
     * Type de contr�le � effectuer pour l'OI.
     */
    private OICheckType authOICheckType;
    /**
     * Les utilisateurs LDAP sont-ils concern�s par cette autorisation ?
     */
    private boolean authLDAP;
    /**
     * Faux : pas besoin de role ou groupe pour authentifier l'utilisateur, seuls ses identifiant/mot de passe sont utilis�s Vrai : un contr�le est
     * fait par rapport aux roles et groupes.
     */
    private boolean roleOrGroupRequired;
    /**
     * Groupes LDAP autoris�s.
     */
    private List<String> ldapGroups;
    /**
     * Roles LDAP autoris�s.
     */
    private List<String> ldapRoles;

    /**
     * Getter authOI
     * 
     * @return the authOI
     */
    public boolean isAuthOI() {
        return authOI;
    }

    /**
     * Setter authOI
     * 
     * @param authOI the authOI to set
     */
    @XmlElement(name = "auth_oi")
    public void setAuthOI(boolean authOI) {
        this.authOI = authOI;
    }

    /**
     * Getter authOICheckType
     * 
     * @return the authOICheckType
     */
    public OICheckType getAuthOICheckType() {
        return authOICheckType;
    }

    /**
     * Setter authOICheckType
     * 
     * @param authOICheckType the authOICheckType to set
     */
    @XmlElement(name = "oi_check_type")
    public void setAuthOICheckType(OICheckType authOICheckType) {
        this.authOICheckType = authOICheckType;
    }

    /**
     * Getter authLDAP
     * 
     * @return the authLDAP
     */
    public boolean isAuthLDAP() {
        return authLDAP;
    }

    /**
     * Setter authLDAP
     * 
     * @param authLDAP the authLDAP to set
     */
    @XmlElement(name = "auth_ldap")
    public void setAuthLDAP(boolean authLDAP) {
        this.authLDAP = authLDAP;
    }

    /**
     * Getter roleOrGroupRequired
     * 
     * @return the roleOrGroupRequired
     */
    public boolean isRoleOrGroupRequired() {
        return roleOrGroupRequired;
    }

    /**
     * Setter roleOrGroupRequired
     * 
     * @param roleOrGroupRequired the roleOrGroupRequired to set
     */
    @XmlElement(name = "role_group_required")
    public void setRoleOrGroupRequired(boolean roleOrGroupRequired) {
        this.roleOrGroupRequired = roleOrGroupRequired;
    }

    /**
     * Getter ldapGroups
     * 
     * @return the ldapGroups
     */
    public List<String> getLdapGroups() {
        return ldapGroups;
    }

    /**
     * Setter ldapGroups
     * 
     * @param ldapGroups the ldapGroups to set
     */
    @XmlElement(name = "ldap_group")
    public void setLdapGroups(List<String> ldapGroups) {
        this.ldapGroups = ldapGroups;
    }

    /**
     * Getter ldapRoles
     * 
     * @return the ldapRoles
     */
    public List<String> getLdapRoles() {
        return ldapRoles;
    }

    /**
     * Setter ldapRoles
     * 
     * @param ldapRoles the ldapRoles to set
     */
    @XmlElement(name = "ldap_role")
    public void setLdapRoles(List<String> ldapRoles) {
        this.ldapRoles = ldapRoles;
    }
}
