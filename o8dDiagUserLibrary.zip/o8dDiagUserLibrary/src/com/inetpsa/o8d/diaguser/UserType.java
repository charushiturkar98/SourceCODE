package com.inetpsa.o8d.diaguser;

/**
 * Diff�rents type d'utilisateur.
 * 
 * @author E331258
 */
public enum UserType {

    /**
     * Utilisateur de type LDAP.
     */
    LDAP,
    /**
     * Utilisateur de type OI.
     */
    OI,
    /**
     * Utilisateur de type Bouchon.
     */
    MOCKED
}
