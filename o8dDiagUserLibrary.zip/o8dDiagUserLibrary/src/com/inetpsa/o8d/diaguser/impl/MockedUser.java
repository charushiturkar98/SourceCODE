package com.inetpsa.o8d.diaguser.impl;

import java.util.Date;

import com.inetpsa.o8d.diaguser.AbstractOIConnector;
import com.inetpsa.o8d.diaguser.Autorisation;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Implementation du DiagUserConnecteur pour les utilisateurs invites (mode bouchon). Ils ont un libre acces total.
 * 
 * @author e300260
 */
public class MockedUser extends AbstractOIConnector {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -7931111061787015352L;

    /**
     * Constructeur.
     */
    public MockedUser() {
        // l'utilisateur en mode bouchon est toujours authentifie
        authenticationDone = true;
        validUser = true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#executeAuthentication()
     */
    @Override
    protected void executeAuthentication() throws DiagUserException {
        // Pas d'appel � effectuer dans le cas du mode bouchon.
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isAbonnementVinValide()
     */
    @Override
    public boolean isAbonnementVinValide() throws DiagUserException {
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getContractType()
     */
    @Override
    public String getContractType() throws DiagUserException {
        return "GUEST";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDateFinContrat()
     */
    @Override
    public Date getDateFinContrat() throws DiagUserException {
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDescription()
     */
    @Override
    public String getDescription() {
        return "Guest User connector";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmail()
     */
    @Override
    public String getEmail() throws DiagUserException {
        return "no mail";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFirstName()
     */
    @Override
    public String getFirstName() throws DiagUserException {
        return "guest";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getIdOperator()
     */
    @Override
    public String getIdOperator() {
        return getUserName();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLangue()
     */
    @Override
    public String getLangue() throws DiagUserException {
        return "FR";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLastName()
     */
    @Override
    public String getLastName() throws DiagUserException {
        return "doe";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocale()
     */
    @Override
    public String getLocale() throws DiagUserException {
        return "FR_FR";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPays()
     */
    @Override
    public String getPays() throws DiagUserException {
        return "FR";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isContratValide()
     */
    @Override
    public boolean isContratValide() throws DiagUserException {
        return true;
    }

    /**
     * Methode d'affichage de l'utilisateur
     * 
     * @return contenu de l'objet
     */
    @Override
    public String toString() {
        StringBuilder buff = new StringBuilder();
        buff.append("MockedUser: uid='").append(getUserName()).append("', ").append("application='").append(applicationId).append("'");
        return buff.toString();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#setApplicationId(java.lang.String)
     */
    @Override
    public void setApplicationId(String applicationId) {
        logger.debug("setApplicationId() ");
        this.applicationId = applicationId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractOIConnector#buildNewInstance()
     */
    @Override
    protected AbstractOIConnector buildNewInstance() {
        return new MockedUser();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#doConnectorPermissionCheck(com.inetpsa.o8d.diaguser.Autorisation)
     */
    @Override
    protected boolean doConnectorPermissionCheck(Autorisation autorisation) throws DiagUserException {
        logger.info(">> autorise l'acces de Guest [{}] vers [{}]", getUserName(), getApplicationId());

        return true;
    }
}
