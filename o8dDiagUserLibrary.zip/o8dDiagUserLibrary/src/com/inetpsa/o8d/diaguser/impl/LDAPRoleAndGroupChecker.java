package com.inetpsa.o8d.diaguser.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.clp.LDAPGroup;
import com.inetpsa.clp.LDAPRole;
import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.exception.LDAPException;
import com.inetpsa.o8d.diaguser.Autorisation;
import com.inetpsa.o8d.diaguser.DiagUserException;

/**
 * Contr�leur de roles et groups LDAP.
 * 
 * @author E331258
 */
public final class LDAPRoleAndGroupChecker {

    /**
     * Gestionnaire de logs.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LDAPRoleAndGroupChecker.class);

    /**
     * Constructeur.
     */
    private LDAPRoleAndGroupChecker() {
    }

    /**
     * L'utilisateur est-il membre ?.
     *
     * @param ldapUser utilisateur
     * @param autorisation objet {@link Autorisation}
     * @return vrai si membre, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    protected static boolean isRoleOrGroupMember(LDAPUser ldapUser, Autorisation autorisation) throws DiagUserException {
        boolean found = false;

        found = LDAPRoleAndGroupChecker.isRoleMember(ldapUser, autorisation.getLdapRoles());

        LOGGER.debug("isRoleMember  : {}", found);

        if (!found) {
            found = isGroupMember(ldapUser, autorisation.getLdapGroups());

            LOGGER.debug("isGroupMember : {}", found);
        }

        return found;
    }

    /**
     * L'utilisateur est-il membre ?.
     * CAP-21206: code fix for existing logic
     * @param ldapUser utilisateur
     * @param roleList la liste des roles
     * @return vrai si membre, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    private static boolean isRoleMember(LDAPUser ldapUser, List<String> roleList) throws DiagUserException {
        boolean found = false;

        if (roleList != null) {
            try {
                List<LDAPRole> roles = (List<LDAPRole>) ldapUser.getRoles();

                if (roles != null) {
                    for (int i = 0; i < roleList.size() && !found; i++) {
                        String roleStr = roleList.get(i);

                        found = searchRole(roleStr, roles);
                    }
                }
            } catch (LDAPException e) {
                throw new DiagUserException(e);
            }
        }

        return found;
    }

    /**
     * L'utilisateur est-il membre ?.
     * CAP-21206: code fix for existing logic
     * @param ldapUser utilisateur
     * @param groupList la liste des groupes
     * @return vrai si membre, faux sinon
     * @throws DiagUserException si une erreur survient
     */
    private static boolean isGroupMember(LDAPUser ldapUser, List<String> groupList) throws DiagUserException {
        boolean found = false;

        if (groupList != null) {
            try {
                List<LDAPGroup> groups = (List<LDAPGroup>) ldapUser.getGroups();

                if (groups != null) {
                    for (int i = 0; i < groupList.size() && !found; i++) {
                        String groupStr = groupList.get(i);

                        found = searchGroup(groupStr, groups);
                    }
                }
            } catch (LDAPException e) {
                throw new DiagUserException(e);
            }
        }

        return found;
    }

    /**
     * Recherche un role par son nom dans la liste de roles de l'utilisateur. CAP-21206: code fix for existing logic
     * CAP-21206: code fix for existing logic
     * @param roleStr le nom du role
     * @param roles les roles
     * @return vrai si trouv�, faux sinon
     * @throws LDAPException si une erreur survient
     */
    private static boolean searchRole(String roleStr, List<LDAPRole> roles) throws LDAPException {
        boolean found = false;

        for (LDAPRole role : roles) {
            found = StringUtils.equals(role.getName(), roleStr);
            if (found) {
                break;
            }
        }

        return found;
    }

    /**
     * Recherche un groupe par son nom dans la liste de groupes de l'utilisateur. CAP-21206: code fix for existing logic
     * CAP-21206: code fix for existing logic
     * @param groupStr le nom du groupe
     * @param groups les groupes
     * @return vrai si trouv�, faux sinon
     * @throws LDAPException si une erreur survient
     */
    private static boolean searchGroup(String groupStr, List<LDAPGroup> groups) throws LDAPException {
        boolean found = false;

        for (LDAPGroup group : groups) {
            found = StringUtils.equals(group.getName(), groupStr);
            if (found) {
                break;
            }
        }

        return found;
    }
}
