package com.inetpsa.o8d.diaguser.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.inetpsa.cxl.commons.CxlException;
import com.inetpsa.o8d.diaguser.AbstractOIConnector;
import com.inetpsa.o8d.diaguser.Autorisation;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.OICheckType;
import com.inetpsa.o8d.stuba2dr.webservice.A2DRAuthentifierStub;
import com.inetpsa.o8d.stuba2dr.webservice.OIAbonnementVINChecker;
import com.inetpsa.o8d.stuba2dr.webservices.authenticate.authenticate.Utilisateur;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.Entry;
import com.inetpsa.xml.commerce.apvtechnique.reseau.specific.FichePersonalisee;

/**
 * Implementation du DiagUserConnecteur cette implementation s'interface avec le referentiel Application Operateur Independant qui est un WebSerice.
 * 
 * @author Sébastien PAGANI - E358045
 */
public class RemoteAccessOIUser extends AbstractOIConnector {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 8889818927721576839L;
    /**
     * Cl� pour la locale et la langue.
     */
    private static final String LOCAL_LANGUE_STR = "langue";
    /**
     * Parametre pour le endpoint.
     */
    private static final String A2DR_ENDPOINT_PARAMETER = "A2DR_endpoint";

    /** formatage des date */
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);

    /** Fiche personalisee */
    protected FichePersonalisee fiche;

    /**
     * Getter fiche personnalisee
     * 
     * @return la fiche personalisee.
     */
    public FichePersonalisee getFichePersonalisee() {
        logger.debug("getFichePersonalisee()");
        return fiche;
    }

    /**
     * Setter fiche personalisee.
     * 
     * @param fichePerso fiche personalisee.
     */
    public void setFichePersonalisee(FichePersonalisee fichePerso) {
        logger.debug("setFichePersonalisee()");
        this.fiche = fichePerso;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#executeAuthentication()
     */
    @Override
    protected void executeAuthentication() throws DiagUserException {
        logger.debug("executeAuthentication()");

        String a2drEndPoint = getConnectorDefinition().getExtraParameters().get(A2DR_ENDPOINT_PARAMETER);

        logger.debug("Utilisation de l'adresse: {}", a2drEndPoint);

        Utilisateur utilisateur = new Utilisateur();
        utilisateur.setIdentifiant(getUserName());
        utilisateur.setMotDePasse(getPassword());

        try {
            A2DRAuthentifierStub stub = new A2DRAuthentifierStub(a2drEndPoint);

            fiche = stub.authenticate(utilisateur, applicationId);

            authenticationDone = true;

            if (fiche != null) {
                validUser = true;
            } else {
                validUser = false;
            }
        } catch (CxlException ex) {
            logger.warn("authentification pour '" + getUserName() + "' a echoue", ex);
            authenticationDone = true;
            validUser = false;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDescription()
     */
    @Override
    public String getDescription() {
        logger.debug("getDescription()");
        return "OI_USER connector";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmail()
     */
    @Override
    public String getEmail() throws DiagUserException {
        logger.debug("getEmail()");
        return getEntry("email").getValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFirstName()
     */
    @Override
    public String getFirstName() throws DiagUserException {
        logger.debug("getFirstName()");

        return getEntry("prenom").getValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLangue()
     */
    @Override
    public String getLangue() throws DiagUserException {
        logger.debug("getLangue()");
        return getEntry(LOCAL_LANGUE_STR).getValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLastName()
     */
    @Override
    public String getLastName() throws DiagUserException {
        logger.debug("getLastName()");
        return getEntry("nom").getValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocale()
     */
    @Override
    public String getLocale() throws DiagUserException {
        logger.debug("getLocale()");
        return getEntry(LOCAL_LANGUE_STR).getValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPays()
     */
    @Override
    public String getPays() throws DiagUserException {
        logger.debug("getPays()");
        return getEntry("pays").getValue();
    }

    /**
     * Permet d'extaire un parametre en fournissant sa cle (key).
     * 
     * @param key cle du parametre.
     * @return la valeur de la cle.
     */
    public Entry getEntry(String key) {
        logger.debug("getEntry({})", key);

        for (Enumeration enumeration = fiche.enumerateEntry(); enumeration.hasMoreElements();) {
            Entry entry = (Entry) enumeration.nextElement();

            if (entry.getKey().equals(key)) {
                logger.debug("Key = {}, value = {}", entry.getKey(), entry.getValue());

                return entry;
            }
        }

        logger.warn("getEntry FichePersonnalise pour [{}] est vide ", key);

        // ou cas ou ne trouve pas la cle dans la liste des cles
        // on envoie une entree vide
        // sonar issue solved
        return new Entry();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getIdOperator()
     */
    @Override
    public String getIdOperator() throws DiagUserException {
        logger.debug("getIdOperator()");

        String identifiant = getEntry("contratNumero").getValue();

        /*
         * Remarque sur le docuement DM086; il est ecrit : " Attention : Il existe des utilisateurs du client diagnostic qui n'ont pas ce type
         * information (utilisateurs DTAV, DSIN), donc elle peut etre vide."
         */
        if (identifiant == null) {
            identifiant = "";
        }
        return identifiant;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isContratValide()
     */
    @Override
    public boolean isContratValide() {
        logger.debug("isContratValide()");

        String contratValide = getEntry("contratValide").getValue();

        if (contratValide == null) {
            return false;
        } else {
            return Boolean.parseBoolean(contratValide);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isAbonnementVinValide()
     */
    @Override
    public boolean isAbonnementVinValide() throws DiagUserException {

        // Fonctionnement en mode bouchon
        String radical = getEntry("radicalVin").getValue();
        logger.info("radical : {}", radical);
        if (StringUtils.isNotEmpty(radical)) {
            if (this.vin.substring(0, radical.length()).equals(radical)) {
                return true;
            }

            return false;
        }

        // Fonctionnement nominal
        boolean isAuthorized = false;

        OIAbonnementVINChecker oiAbonnementVINChecker = new OIAbonnementVINChecker();

        try {
            oiAbonnementVINChecker.initConnection();
            oiAbonnementVINChecker.checkAbo(this.vin, getDiagUserCredentials());
            isAuthorized = oiAbonnementVINChecker.isAboValide();
            logger.info("isAuthorized : {}", isAuthorized);
        } catch (IOException e) {
            logger.error("Fatal transport error: ", e);
        } finally {
            oiAbonnementVINChecker.closeConnection();
        }

        return isAuthorized;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDateFinContrat()
     */
    @Override
    public Date getDateFinContrat() throws DiagUserException {
        logger.debug("getDateFinContrat() ");
        String dateFinContrat = getEntry("dateFinContrat").getValue();
        // sonar issue solved
        logger.debug("dateFinContrat >> {}", dateFinContrat);
        try {
            return DATE_FORMATTER.parse(dateFinContrat);
        } catch (ParseException ex) {
            logger.debug("ParseException", ex);
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractOIConnector#buildNewInstance()
     */
    @Override
    public AbstractOIConnector buildNewInstance() {
        return new RemoteAccessOIUser();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#doConnectorPermissionCheck(com.inetpsa.o8d.diaguser.Autorisation)
     */
    @Override
    protected boolean doConnectorPermissionCheck(Autorisation autorisation) throws DiagUserException {
        if (autorisation.isAuthOI()) {
            boolean authorizedUser = false;

            if (isUserAuthenticated()) {
                if (autorisation.getAuthOICheckType() == OICheckType.SUBSCRIPTION) {
                    authorizedUser = isAbonnementVinValide();
                } else if (autorisation.getAuthOICheckType() == OICheckType.CONTRACT) {
                    authorizedUser = isContratValide() && (getDateFinContrat().after(new Date()));
                } else {
                    authorizedUser = true;
                }
            }

            logger.debug("{} => l'utilisateur '{}' est autorise => {}", getApplicationId(), getUserName(), authorizedUser);

            return authorizedUser;
        }

        return false;
    }
}
