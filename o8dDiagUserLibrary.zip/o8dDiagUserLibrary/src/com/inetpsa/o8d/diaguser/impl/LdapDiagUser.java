package com.inetpsa.o8d.diaguser.impl;

import java.util.Date;
import java.util.Enumeration;

import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;

import com.inetpsa.clp.LDAPEstablishment;
import com.inetpsa.clp.LDAPLocalization;
import com.inetpsa.clp.LDAPPassport;
import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.LDAPWorkPlace;
import com.inetpsa.clp.exception.LDAPException;
import com.inetpsa.clp.exception.LDAPInvalidParameterException;
import com.inetpsa.clp.exception.LDAPObjNotFoundException;
import com.inetpsa.o8d.diaguser.AbstractDiagUserConnector;
import com.inetpsa.o8d.diaguser.Autorisation;
import com.inetpsa.o8d.diaguser.DiagUserException;
import com.inetpsa.o8d.diaguser.DiagUserRuntimeException;

/**
 * Implementation du DiagUserConnecteur cette implementation s'interface avec le referentiel PSA - REUNIS.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class LdapDiagUser extends AbstractDiagUserConnector {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = -3040624370416045487L;

    /** LDAPUser utilise */
    private LDAPUser myLdapUser;

    /** VIN sur lequel on travaille */
    private String vin;

    /**
     * Contructeur de la classe LdapDiagUser.
     */
    public LdapDiagUser() {
        try {
            myLdapUser = new LDAPUser();
        } catch (LDAPException ldapEx) {
            throw new DiagUserRuntimeException(ldapEx);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#executeAuthentication()
     */
    @Override
    protected void executeAuthentication() throws DiagUserException {
        logger.debug("executeAuthentication()");

        try {
            myLdapUser.setUid(getUserName());
            myLdapUser.setPassword(getPassword());

            validUser = myLdapUser.authenticate();

            authenticationDone = true;
        } catch (LDAPInvalidParameterException e) {
            logger.warn(ERROR_AUTH_FAILED_MSG + getUserName(), e);
            validUser = false;
            authenticationDone = true;
        } catch (LDAPObjNotFoundException e) {
            logger.warn(ERROR_AUTH_FAILED_MSG + getUserName(), e);
            validUser = false;
            authenticationDone = true;
        } catch (LDAPException e) {
            throw new DiagUserException("Ldap authenticate call failed", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getVin()
     */
    @Override
    public String getVin() {
        logger.debug("getVin()");
        return vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getB2BURLs()
     */
    @Override
    public Enumeration getB2BURLs() throws DiagUserException {
        logger.debug("getB2BURLs()");
        try {
            return myLdapUser.getB2BURLs();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getContractType()
     */
    @Override
    public String getContractType() throws DiagUserException {
        logger.debug("getContractType() ");
        try {
            return myLdapUser.getContractType();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getCustomerNumber()
     */
    @Override
    public String getCustomerNumber() throws DiagUserException {
        logger.debug("getCustomerNumber()");
        try {
            return myLdapUser.getCustomerNumber();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDealNetworks()
     */
    @Override
    public Enumeration getDealNetworks() throws DiagUserException {
        logger.debug("getDealNetworks()");
        try {
            return myLdapUser.getDealNetworks();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDescription()
     */
    @Override
    public String getDescription() {
        logger.debug("getDescription()");
        return "LDAPDiagUser connector";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDirection()
     */
    @Override
    public String getDirection() throws DiagUserException {
        logger.debug("getDirection()");
        try {
            return myLdapUser.getDirection();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmail()
     */
    @Override
    public String getEmail() throws DiagUserException {
        logger.debug("getEmail()");
        try {
            return myLdapUser.getEmail();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmployeeCode()
     */
    @Override
    public String getEmployeeCode() throws DiagUserException {
        logger.debug("getEmployeeCode()");
        try {
            return myLdapUser.getEmployeeCode();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmployeeType()
     */
    @Override
    public String getEmployeeType() throws DiagUserException {
        logger.debug("getEmployeeType()");
        try {
            return myLdapUser.getEmployeeType();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEstablishment()
     */
    @Override
    public LDAPEstablishment getEstablishment() throws DiagUserException {
        logger.debug("getEstablishment()");
        try {
            return myLdapUser.getEstablishment();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getExternalPhone()
     */
    @Override
    public String getExternalPhone() throws DiagUserException {
        logger.debug("getExternalPhone()");
        try {
            return myLdapUser.getExternalPhone();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getExternalPhone2()
     */
    @Override
    public String getExternalPhone2() throws DiagUserException {
        logger.debug("getExternalPhone2()");
        try {
            return myLdapUser.getExternalPhone2();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFax()
     */
    @Override
    public String getFax() throws DiagUserException {
        logger.debug("getFax()");
        try {
            return myLdapUser.getFax();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFirstName()
     */
    @Override
    public String getFirstName() throws DiagUserException {
        logger.debug("getFirstName()");
        try {
            return myLdapUser.getFirstName();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFirstName2()
     */
    @Override
    public String getFirstName2() throws DiagUserException {
        logger.debug("getFirstName2()");
        try {
            return myLdapUser.getFirstName2();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFunctions()
     */
    @Override
    public Enumeration getFunctions() throws DiagUserException {
        logger.debug("getFunctions()");
        try {
            return myLdapUser.getFunctions();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getIndustrialPartners()
     */
    @Override
    public Enumeration getIndustrialPartners() throws DiagUserException {
        logger.debug("getIndustrialPartners()");
        try {
            return myLdapUser.getIndustrialPartners();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getInternalPhone()
     */
    @Override
    public String getInternalPhone() throws DiagUserException {
        logger.debug("getInternalPhone()");
        try {
            return myLdapUser.getInternalPhone();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getInternalPhone2()
     */
    @Override
    public String getInternalPhone2() throws DiagUserException {
        logger.debug("getInternalPhone2()");
        try {
            return myLdapUser.getInternalPhone2();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLangue()
     */
    @Override
    public String getLangue() throws DiagUserException {
        logger.debug("getLangue()");
        try {
            return myLdapUser.getLangue();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLastName()
     */
    @Override
    public String getLastName() throws DiagUserException {
        logger.debug("getLastName()");
        try {
            return myLdapUser.getLastName();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocale()
     */
    @Override
    public String getLocale() throws DiagUserException {
        logger.debug("getLocale()");
        try {
            return myLdapUser.getLocale();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocalization()
     */
    @Override
    public LDAPLocalization getLocalization() throws DiagUserException {
        logger.debug("getLocalization()");
        try {
            return myLdapUser.getLocalization();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocalization2()
     */
    @Override
    public LDAPLocalization getLocalization2() throws DiagUserException {
        logger.debug("getLocalization2()");
        try {
            return myLdapUser.getLocalization2();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMailFile()
     */
    @Override
    public String getMailFile() throws DiagUserException {
        logger.debug("getMailFile()");
        try {
            return myLdapUser.getMailFile();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMailServer()
     */
    @Override
    public String getMailServer() throws DiagUserException {
        logger.debug("getMailServer()");
        try {
            return myLdapUser.getMailServer();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMarque()
     */
    @Override
    public String getMarque() throws DiagUserException {
        logger.debug("getMarque()");
        try {
            return myLdapUser.getMarque();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMobile()
     */
    @Override
    public String getMobile() throws DiagUserException {
        logger.debug("getMobile()");
        try {
            return myLdapUser.getMobile();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPassport()
     */
    @Override
    public LDAPPassport getPassport() throws DiagUserException {
        logger.debug("getPassport()");
        try {
            return myLdapUser.getPassport();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPassports()
     */
    @Override
    public Enumeration getPassports() throws DiagUserException {
        logger.debug("getPassports()");
        try {
            return myLdapUser.getPassports();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPays()
     */
    @Override
    public String getPays() throws DiagUserException {
        long tmstp;
        long tmstp_pays;
        String Country;

        tmstp = System.currentTimeMillis();
        logger.debug("ETP_1 Enter getPays () Timestamp = " + tmstp + " userName = " + this.getUserName());
        try {
            tmstp_pays = System.currentTimeMillis();
            logger.debug("ETP_2 Debut Calculation getPays () Timestamp = " + tmstp + " userName = " + this.getUserName());

            Country = myLdapUser.getPays();

            tmstp_pays = System.currentTimeMillis();
            logger.debug("ETP_3 End Calculation getPays () Timestamp = " + tmstp + " Country " + Country + " userName = " + this.getUserName());

            return Country;

        } catch (LDAPException ex) {
            tmstp = System.currentTimeMillis();
            ex.printStackTrace();
            logger.debug("ETP_4 Exception Exception Calculation getPays () Timestamp = " + tmstp + " userName = " + this.getUserName());
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getSecretary()
     */
    @Override
    public LDAPUser getSecretary() throws DiagUserException {
        logger.debug("getSecretary()");
        try {
            return myLdapUser.getSecretary();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getSuppliers()
     */
    @Override
    public Enumeration getSuppliers() throws DiagUserException {
        logger.debug("getSuppliers()");
        try {
            return myLdapUser.getSuppliers();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getTel()
     */
    @Override
    public Enumeration getTel() throws DiagUserException {
        logger.debug("getTel()");
        try {
            return myLdapUser.getTel();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getUnixIdNumber()
     */
    @Override
    public String getUnixIdNumber() throws DiagUserException {
        logger.debug("getUnixIdNumber()");
        try {
            return myLdapUser.getUnixIdNumber();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getUnixUid()
     */
    @Override
    public String getUnixUid() throws DiagUserException {
        logger.debug("getUnixUid()");
        try {
            return myLdapUser.getUnixUid();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getValidity()
     */
    @Override
    public String getValidity() throws DiagUserException {
        logger.debug("getValidity()");
        try {
            return myLdapUser.getValidity();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getWorkPlace()
     */
    @Override
    public LDAPWorkPlace getWorkPlace() throws DiagUserException {
        logger.debug("getWorkPlace()");
        try {
            return myLdapUser.getWorkPlace();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getWorkPlace2()
     */
    @Override
    public LDAPWorkPlace getWorkPlace2() throws DiagUserException {
        logger.debug("getWorkPlace2()");
        try {
            return myLdapUser.getWorkPlace2();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasIndustrialPartner()
     */
    @Override
    public boolean hasIndustrialPartner() throws DiagUserException {
        logger.debug("hasIndustrialPartner()");
        try {
            return myLdapUser.hasIndustrialPartner();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasSupplier()
     */
    @Override
    public boolean hasSupplier() throws DiagUserException {
        logger.debug("hasSupplier()");
        try {
            return myLdapUser.hasSupplier();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasVisitRight()
     */
    @Override
    public boolean hasVisitRight() throws DiagUserException {
        logger.debug("hasVisitRight()");
        try {
            return myLdapUser.hasVisitRight();
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasVisitRight(java.lang.String, java.lang.String)
     */
    @Override
    public boolean hasVisitRight(String principal, String credentials) throws DiagUserException {
        logger.debug("hasVisitRight(...)");
        try {
            return myLdapUser.hasVisitRight(principal, credentials);
        } catch (LDAPException ex) {
            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getShematiqueURL()
     */
    @Override
    public String getShematiqueURL() {
        logger.debug("getShematiqueURL()");
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getIdOperator()
     */
    @Override
    public String getIdOperator() throws DiagUserException {
        long tmstp = System.currentTimeMillis();
        long tmstp_pass;
        long tmstp_pass_role;
        logger.debug("ETP_1 Input getIdOperator () Timestamp =" + tmstp + "userName =" + this.getUserName());
        try {
            String codeRRDI = null;
            tmstp_pass = System.currentTimeMillis();
            logger.debug("ETP_2 getIdOperator () Start Calculation Passport Timestamp =" + tmstp_pass + "userName =" + this.getUserName());
            LDAPPassport passport = myLdapUser.getPassport();

            tmstp_pass = System.currentTimeMillis();
            logger.debug("ETP_3 getIdOperator () End calculation Passport Timestamp =" + tmstp_pass + "userName =" + this.getUserName());

            if (passport != null) {
                tmstp_pass_role = System.currentTimeMillis();
                logger.debug("ETP_4 getIdOperator () Start calculation PsaRole Timestamp =" + tmstp_pass_role + "userName =" + this.getUserName());
                codeRRDI = (String) passport.getPsaRole("RRDI7").nextElement();
                tmstp_pass_role = System.currentTimeMillis();
                logger.debug("ETP_5 getIdOperator () End compute PsaRole Timestamp =" + tmstp_pass_role + "codeRRDI =" + codeRRDI + "userName ="
                        + this.getUserName());
            } else {
                logger.warn("le passport du user est null");
                logger.debug("the passport of the user" + this.getUserName() + "is null");
            }

            /*
             * Remarque sur le docuement DM086; il est ecrit : " Attention : Il existe des utilisateurs du client diagnostic qui n'ont pas ce type
             * information (utilisateurs DTAV, DSIN...), donc elle peut etre vide.
             */
            if (codeRRDI == null) {
                codeRRDI = StringUtils.EMPTY;
            }
            tmstp_pass = System.currentTimeMillis();
            logger.debug(
                    "ETP_6 Output getIdOperator () End calculation Global Passport Timestamp =" + tmstp_pass + "userName =" + this.getUserName());
            return codeRRDI;
        } catch (LDAPException ex) {
            tmstp = System.currentTimeMillis();
            logger.debug("ETP_7 Exception output getIdOperator () Timestamp =" + tmstp + "userName =" + this.getUserName());
            ex.printStackTrace();

            throw new DiagUserException(ex);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#setVin(java.lang.String)
     */
    @Override
    public void setVin(String vin) {
        logger.debug("LdapUser.setVin()");
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isContratValide()
     */
    @Override
    public boolean isContratValide() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#isAbonnementVinValide()
     */
    @Override
    public boolean isAbonnementVinValide() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDateFinContrat()
     */
    @Override
    public Date getDateFinContrat() throws DiagUserException {
        NotImplementedException realEx = new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG);
        throw new DiagUserException(realEx);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#buildNewInstance()
     */
    @Override
    protected AbstractDiagUserConnector buildNewInstance() {
        return new LdapDiagUser();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#doConnectorPermissionCheck(com.inetpsa.o8d.diaguser.Autorisation)
     */
    @Override
    protected boolean doConnectorPermissionCheck(Autorisation autorisation) throws DiagUserException {
        if (autorisation.isAuthLDAP()) {
            if (autorisation.isRoleOrGroupRequired()) {
                boolean found = LDAPRoleAndGroupChecker.isRoleOrGroupMember(myLdapUser, autorisation);

                logger.debug("{} => l'utilisateur '{}' est trouve => {}", getApplicationId(), getUserName(), found);

                return found;
            } else {
                logger.debug("{} => l'utilisateur '{}' est autorise (pas de role/group particulier necessaire)", getApplicationId(), getUserName());

                return true;
            }
        }

        return false;
    }
}
