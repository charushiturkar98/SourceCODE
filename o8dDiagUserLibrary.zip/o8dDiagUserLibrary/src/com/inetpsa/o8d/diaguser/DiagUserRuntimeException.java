package com.inetpsa.o8d.diaguser;

/**
 * Exception runtime lors de l'utilisation de DiagUser.
 * 
 * @author E331258
 */
public class DiagUserRuntimeException extends RuntimeException {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 4402045804753397414L;

    /**
     * Constructeur.
     * 
     * @param cause Exception cause
     */
    public DiagUserRuntimeException(Throwable cause) {
        super(cause);
    }
}
