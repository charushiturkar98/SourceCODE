package com.inetpsa.o8d.diaguser;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 * D�finition d'un connecteur
 * 
 * @author E298062
 */
public class ConnectorDefinition {
    /**
     * Type d'utilisateur pour le connecteur.
     */
    private UserType userType;
    /**
     * Nom de la classe d'impl�mentation.
     */
    private String className;
    /**
     * Pattern de reconnaissance du type d'utilisateur en fonction de l'identifiant.
     */
    private String pattern;
    /**
     * Param�tres compl�mentaires li�s au connecteur.
     */
    private Map<String, String> extraParameters;
    /**
     * Liste des services applicatifs � afficher dans la carte d'identit� pour le connecteur.
     */
    private List<String> identityCardApplicationServices;
    /**
     * Liste des identifiants d'applications disponibles pour le connecteur.
     */
    private Set<String> availableApplications = new HashSet<String>();

    /**
     * Getter userType
     * 
     * @return the userType
     */
    public UserType getUserType() {
        return userType;
    }

    /**
     * Setter userType
     * 
     * @param userType the userType to set
     */
    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    /**
     * Getter className
     * 
     * @return the className
     */
    public String getClassName() {
        return className;
    }

    /**
     * Setter className
     * 
     * @param className the className to set
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     * Getter pattern
     * 
     * @return the pattern
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Setter pattern
     * 
     * @param pattern the pattern to set
     */
    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    /**
     * Getter extraParameters
     * 
     * @return the extraParameters
     */
    public Map<String, String> getExtraParameters() {
        return extraParameters;
    }

    /**
     * Setter extraParameters
     * 
     * @param extraParameters the extraParameters to set
     */
    @XmlElementWrapper(name = "parameters")
    public void setExtraParameters(Map<String, String> extraParameters) {
        this.extraParameters = extraParameters;
    }

    /**
     * Getter identityCardApplicationServices
     * 
     * @return the identityCardApplicationServices
     */
    public List<String> getIdentityCardApplicationServices() {
        return identityCardApplicationServices;
    }

    /**
     * Setter identityCardApplicationServices
     * 
     * @param identityCardApplicationServices the identityCardApplicationServices to set
     */
    @XmlElement(name = "identity_card_service")
    public void setIdentityCardApplicationServices(List<String> identityCardApplicationServices) {
        this.identityCardApplicationServices = identityCardApplicationServices;
    }

    /**
     * Getter availableApplications
     * 
     * @return the availableApplications
     */
    public Set<String> getAvailableApplications() {
        return availableApplications;
    }

    /**
     * Setter availableApplications
     * 
     * @param availableApplications the availableApplications to set
     */
    @XmlElement(name = "available_app")
    public void setAvailableApplications(Set<String> availableApplications) {
        this.availableApplications = availableApplications;
    }
}
