package com.inetpsa.o8d.diaguser;

import java.text.SimpleDateFormat;

import org.apache.commons.configuration.AbstractConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javolution.util.FastMap;

/**
 * Gestionnaire de lock par ip.
 * 
 * @author E331258
 */
public final class DiagUserAccessLockerManager {

    /**
     * Gestionnaire de logs.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DiagUserAccessLockerManager.class);
    /**
     * Message d'erreur pendant la lecture de la configuration.
     */
    private static final String ERROR_READING_CONFIG_MSG = "Error during configuration file read, using default configuration";
    /**
     * Nombre de millisecondes pour une seconde.
     */
    private static final int MILLISECONDS_FOR_SECOND = 1000;
    /**
     * Nom du fichier de configuration.
     */
    private static final String ACCESS_LOCKER_CONFIGURATION_FILE = "diaguser-access-locker.properties";
    /**
     * Nom de la propri�t� d'activation/d�sactivation du locker.
     */
    private static final String ACCESS_LOCKER_ACTIVATION_PROPERTY_NAME = "diaguser.access.locker.enabled";
    /**
     * Vaeur par d�faut de la propri�t� d'activation/d�sactivation du locker.
     */
    private static final boolean DEFAULT_ACTIVATION_VALUE = true;
    /**
     * Nom de la propri�t� du nombre de tentative limite.
     */
    private static final String ACCESS_LOCKER_ATTEMPT_LIMIT_PROPERTY_NAME = "diaguser.access.locker.attempt.limit";
    /**
     * Vaeur par d�faut de la propri�t� du nombre de tentative limite.
     */
    private static final int DEFAULT_ATTEMPT_LIMIT_VALUE = 3;
    /**
     * Nom de la propri�t� du nombre de secondes de blocage.
     */
    private static final String ACCESS_LOCKER_LOCK_SECONDS_PROPERTY_NAME = "diaguser.access.locker.lock.seconds";
    /**
     * Vaeur par d�faut de la propri�t� du nombre de secondes de blocage.
     */
    private static final int DEFAULT_LOCK_SECONDS_VALUE = 300;

    /**
     * Instance unique du singleton.
     */
    private static final DiagUserAccessLockerManager INSTANCE = new DiagUserAccessLockerManager();
    /**
     * Cache des tentatives d'authentification.
     */
    private final FastMap<String, FastMap<String, ConnectionAttempts>> authAttemptsByIpFailures;

    /**
     * Statut d'activation du Locker.
     */
    private boolean lockerEnabled;
    /**
     * Nombre limite de tentatives.
     */
    private int attemptLimit;
    /**
     * Nombre de millisecondes de blocage.
     */
    private int lockMilliSeconds;

    /**
     * Constructeur.
     */
    private DiagUserAccessLockerManager() {
        // For Javolution 6.0.0+ :
        // authAttemptsByIpFailures = new FastMap<String, FastMap<String, ConnectionAttempts>>(Equalities.LEXICAL_FAST).atomic();
        authAttemptsByIpFailures = new FastMap<String, FastMap<String, ConnectionAttempts>>();

        init();
    }

    /**
     * Methode qui renvoie l'unique instance.
     * 
     * @return instance unique de la classe.
     */
    public static DiagUserAccessLockerManager getInstance() {
        return INSTANCE;
    }

    /**
     * Initialisation du cache.
     */
    private void init() {
        LOGGER.info("init >> ");
        try {
            AbstractConfiguration lockManagerConfiguration = new PropertiesConfiguration(
                    Thread.currentThread().getContextClassLoader().getResource(ACCESS_LOCKER_CONFIGURATION_FILE));

            lockerEnabled = lockManagerConfiguration.getBoolean(ACCESS_LOCKER_ACTIVATION_PROPERTY_NAME, DEFAULT_ACTIVATION_VALUE);
            attemptLimit = lockManagerConfiguration.getInt(ACCESS_LOCKER_ATTEMPT_LIMIT_PROPERTY_NAME, DEFAULT_ATTEMPT_LIMIT_VALUE);
            lockMilliSeconds = lockManagerConfiguration.getInt(ACCESS_LOCKER_LOCK_SECONDS_PROPERTY_NAME, DEFAULT_LOCK_SECONDS_VALUE)
                    * MILLISECONDS_FOR_SECOND;
        } catch (ConfigurationException e) {
            LOGGER.error(ERROR_READING_CONFIG_MSG, e);
            setDefaults();
        } catch (NumberFormatException e) {
            LOGGER.error(ERROR_READING_CONFIG_MSG, e);
            setDefaults();
        }
        LOGGER.info("init << ");
    }

    /**
     * Positionnement de la configuration par d�faut.
     */
    private void setDefaults() {
        lockerEnabled = DEFAULT_ACTIVATION_VALUE;
        attemptLimit = DEFAULT_ATTEMPT_LIMIT_VALUE;
        lockMilliSeconds = DEFAULT_LOCK_SECONDS_VALUE * MILLISECONDS_FOR_SECOND;
    }

    /**
     * Getter authAttemptsByIpFailures
     * 
     * @return the authAttemptsByIpFailures
     */
    public FastMap<String, FastMap<String, ConnectionAttempts>> getAuthAttemptsByIpFailures() {
        return authAttemptsByIpFailures;
    }

    /**
     * Getter lockerEnabled
     * 
     * @return the lockerEnabled
     */
    public boolean isLockerEnabled() {
        return lockerEnabled;
    }

    /**
     * Getter attemptLimit
     * 
     * @return the attemptLimit
     */
    public int getAttemptLimit() {
        return attemptLimit;
    }

    /**
     * Getter lockMilliSeconds
     * 
     * @return the lockMilliSeconds
     */
    public int getLockMilliSeconds() {
        return lockMilliSeconds;
    }

    /**
     * Recherche l'ensemble des tentatives de connexions pour une ip.
     * 
     * @param ip l'adresse ip
     * @return ensemble des tentatives de connexions
     */
    private FastMap<String, ConnectionAttempts> findIp(String ip) {
        return authAttemptsByIpFailures.get(ip);
    }

    /**
     * Recherche les tentatives de connexions d'un utilisateur.
     * 
     * @param diagUserConnector objet connecteur diaguser
     * @param attemptsForIp ensemble des tentatives de connexions
     * @return les tentatives de connexions
     */
    private ConnectionAttempts findUsername(AbstractDiagUserConnector diagUserConnector, FastMap<String, ConnectionAttempts> attemptsForIp) {
        ConnectionAttempts objectFound = null;

        if (attemptsForIp != null) {
            objectFound = attemptsForIp.get(diagUserConnector.getUserName());
        }

        return objectFound;
    }

    /**
     * Recherche les tentatives de connexions d'un utilisateur via une ip.
     * 
     * @param diagUserConnector objet connecteur diaguser
     * @return les tentatives de connexions
     */
    public ConnectionAttempts searchAttempts(AbstractDiagUserConnector diagUserConnector) {
        LOGGER.info("searchAttempts >> ");
        ConnectionAttempts objectFound = null;

        if (lockerEnabled) {
            FastMap<String, ConnectionAttempts> attemptsForIp = findIp(diagUserConnector.getUserIpAddress());

            objectFound = findUsername(diagUserConnector, attemptsForIp);

            if (objectFound != null) {
                LOGGER.debug("nb attempts = {}, last attempt = {}", objectFound.getAttemptsNb(), objectFound.getLastAttemptTs());
            }
        }
        LOGGER.info("searchAttempts << ");
        return objectFound;
    }

    /**
     * Contr�le si un blocage doit �tre realise.
     * 
     * @param diagUserConnector objet connecteur diaguser
     * @param connectionAttempts tentatives de connexions
     * @return vrai si rejete, faux sinon
     */
    public boolean isLocked(AbstractDiagUserConnector diagUserConnector, ConnectionAttempts connectionAttempts) {
        LOGGER.info("isLocked >> ");
        boolean rejected = false;

        if ((connectionAttempts != null) && (connectionAttempts.getAttemptsNb() >= attemptLimit)) {
            long now = System.currentTimeMillis();
            long currentLockTime = now - connectionAttempts.getLastAttemptTs();

            if (currentLockTime <= lockMilliSeconds) {
                rejected = true;
            } else {
                removeAttempts(diagUserConnector);
            }
        }
        LOGGER.info("isLocked << ");
        return rejected;

    }

    /**
     * Ajoute une tentative.
     * 
     * @param diagUserConnector connecteur contenant les informations d'authentification
     * @param connectionAttempts les tentatives actuelles de l'utilisateur
     */
    public void addAttempt(AbstractDiagUserConnector diagUserConnector, ConnectionAttempts connectionAttempts) {
        LOGGER.info("addAttempt >> ");
        if (connectionAttempts == null) {
            FastMap<String, ConnectionAttempts> attemptsForIp = findIp(diagUserConnector.getUserIpAddress());

            if (attemptsForIp == null) {
                // For Javolution 6.0.0+ :
                // attemptsForIp = new FastMap<String, ConnectionAttempts>(Equalities.LEXICAL_FAST).atomic();
                attemptsForIp = new FastMap<String, ConnectionAttempts>();
                authAttemptsByIpFailures.put(diagUserConnector.getUserIpAddress(), attemptsForIp);
            }

            attemptsForIp.put(diagUserConnector.getUserName(), new ConnectionAttempts());
        } else {
            connectionAttempts.incrAttemptsNb();
            connectionAttempts.updateLastAttemptTs();
        }
        LOGGER.info("addAttempt  << ");
    }

    /**
     * Supprime les tentatives en fonction des donn�es d'authentification fournies.
     * 
     * @param diagUserConnector connecteur
     */
    public void removeAttempts(AbstractDiagUserConnector diagUserConnector) {
        LOGGER.info("removeAttempts >> ");
        FastMap<String, ConnectionAttempts> attemptsForIp = findIp(diagUserConnector.getUserIpAddress());

        if (attemptsForIp != null) {
            attemptsForIp.remove(diagUserConnector.getUserName());
        }
        LOGGER.info("removeAttempts << ");
    }

    public void DisplayMapAuthFailures() {

        LOGGER.debug(" Entree DisplayMapAuthFailures() Adresse IP ======> ");

        // Parcours du FastMap
        for (FastMap.Entry<String, FastMap<String, ConnectionAttempts>> e = authAttemptsByIpFailures.head(), end = authAttemptsByIpFailures
                .tail(); (e = e.getNext()) != end;) {

            // Recuperation de la Table de Hachage specifique a chaque Adresse IP
            String key_Ip = e.getKey();
            FastMap<String, ConnectionAttempts> attemptsForIp = e.getValue();

            // Affichage de l'adresse IP
            LOGGER.debug(" DisplayMapAuthFailures() Adresse IP = " + key_Ip);

            // Affichage des Tentatives des Utilisateurs
            // Recuperation de la Table de Hachage specifique a chaque Adresse IP
            // Parcours du FastMap
            for (FastMap.Entry<String, ConnectionAttempts> e_u = attemptsForIp.head(), end_u = attemptsForIp
                    .tail(); (e_u = e_u.getNext()) != end_u;) {

                // Recuperation de la Table de Hachage specifique a chaque Adresse IP
                String key_Username = e_u.getKey();
                ConnectionAttempts conn_u = e_u.getValue();
                SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd");
                // Affichage de l'utilisateur du nombre de tentatives de Connexion de celui-ci et de la date de sa derniere Tentative
                String line = "@IP = " + key_Ip + " Username = " + key_Username + " AttemptsNb = " + conn_u.getAttemptsNb() + " LastAttemptTs = "
                        + conn_u.getLastAttemptTs() + " Date_Tentative = " + dfm.format(conn_u.getLastAttemptTs());
                LOGGER.debug(" DisplayMapAuthFailures()  " + line);

            }

        }

        LOGGER.debug(" Sortie DisplayMapAuthFailures() Adresse IP ======> ");

    }
}
