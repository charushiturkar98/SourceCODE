package com.inetpsa.o8d.diaguser;

/**
 * Exception principale du composant DiagUser.
 * 
 * @author Hichame ELKHALFI - E298062
 */
public class DiagUserException extends Exception {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 2214964354541741212L;

    /**
     * Constructeur par defaut.
     */
    public DiagUserException() {
        super();
    }

    /**
     * Constructeur avec message
     * 
     * @param message message de l'exception
     */
    public DiagUserException(final String message) {
        super(message);
    }

    /**
     * Constructeur avec message et la cause
     * 
     * @param message message de l'exception
     * @param cause cause de l'exception
     */
    public DiagUserException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructeur avec la cause
     * 
     * @param cause de l'exception
     */
    public DiagUserException(final Throwable cause) {
        super(cause);
    }
}
