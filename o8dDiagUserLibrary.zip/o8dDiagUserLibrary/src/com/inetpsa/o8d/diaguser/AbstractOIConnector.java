package com.inetpsa.o8d.diaguser;

import java.util.Enumeration;

import org.apache.commons.lang.NotImplementedException;

import com.inetpsa.clp.LDAPEstablishment;
import com.inetpsa.clp.LDAPLocalization;
import com.inetpsa.clp.LDAPPassport;
import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.LDAPWorkPlace;

/**
 * Classe abstraite pour les OI.
 * 
 * @author E331258
 */
public abstract class AbstractOIConnector extends AbstractDiagUserConnector {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 8752364537780143719L;

    /** VIN sur lequel on travaille */
    protected String vin;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getVin()
     */
    @Override
    public String getVin() {
        logger.debug("getVin()");
        return vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#setVin(java.lang.String)
     */
    @Override
    public void setVin(String vin) {
        logger.debug("setVin()");
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getB2BURLs()
     */
    @Override
    public Enumeration getB2BURLs() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getContractType()
     */
    @Override
    public String getContractType() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getCustomerNumber()
     */
    @Override
    public String getCustomerNumber() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDealNetworks()
     */
    @Override
    public Enumeration getDealNetworks() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getDirection()
     */
    @Override
    public String getDirection() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmployeeCode()
     */
    @Override
    public String getEmployeeCode() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEmployeeType()
     */
    @Override
    public String getEmployeeType() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getEstablishment()
     */
    @Override
    public LDAPEstablishment getEstablishment() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getExternalPhone()
     */
    @Override
    public String getExternalPhone() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getExternalPhone2()
     */
    @Override
    public String getExternalPhone2() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFax()
     */
    @Override
    public String getFax() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFirstName2()
     */
    @Override
    public String getFirstName2() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getFunctions()
     */
    @Override
    public Enumeration getFunctions() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getIndustrialPartners()
     */
    @Override
    public Enumeration getIndustrialPartners() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getInternalPhone()
     */
    @Override
    public String getInternalPhone() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getInternalPhone2()
     */
    @Override
    public String getInternalPhone2() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocalization()
     */
    @Override
    public LDAPLocalization getLocalization() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getLocalization2()
     */
    @Override
    public LDAPLocalization getLocalization2() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMailFile()
     */
    @Override
    public String getMailFile() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMailServer()
     */
    @Override
    public String getMailServer() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMarque()
     */
    @Override
    public String getMarque() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getMobile()
     */
    @Override
    public String getMobile() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPassport()
     */
    @Override
    public LDAPPassport getPassport() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getPassports()
     */
    @Override
    public Enumeration getPassports() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getSecretary()
     */
    @Override
    public LDAPUser getSecretary() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getShematiqueURL()
     */
    @Override
    public String getShematiqueURL() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getSuppliers()
     */
    @Override
    public Enumeration getSuppliers() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getTel()
     */
    @Override
    public Enumeration getTel() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getUnixIdNumber()
     */
    @Override
    public String getUnixIdNumber() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getUnixUid()
     */
    @Override
    public String getUnixUid() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getValidity()
     */
    @Override
    public String getValidity() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getWorkPlace()
     */
    @Override
    public LDAPWorkPlace getWorkPlace() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#getWorkPlace2()
     */
    @Override
    public LDAPWorkPlace getWorkPlace2() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasIndustrialPartner()
     */
    @Override
    public boolean hasIndustrialPartner() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasSupplier()
     */
    @Override
    public boolean hasSupplier() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasVisitRight()
     */
    @Override
    public boolean hasVisitRight() throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.o8d.diaguser.AbstractDiagUserConnector#hasVisitRight(java.lang.String, java.lang.String)
     */
    @Override
    public boolean hasVisitRight(String principal, String credentials) throws DiagUserException {
        throw new DiagUserException(new NotImplementedException(ERROR_NOT_IMPLEMENTED_MSG));
    }
}
