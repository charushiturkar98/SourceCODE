package com.inetpsa.o8d.diaguser;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tentative de connexion.
 * 
 * @author E331258
 */
public class ConnectionAttempts {

    /**
     * Nombre de tentatives.
     */
    private AtomicInteger attemptsNb = new AtomicInteger(1);
    /**
     * Timestamp derni�re tentative.
     */
    private long lastAttemptTs;

    /**
     * Constructor.
     */
    public ConnectionAttempts() {
        attemptsNb = new AtomicInteger(1);
        updateLastAttemptTs();
    }

    /**
     * Getter attemptsNb
     * 
     * @return the attemptsNb
     */
    public int getAttemptsNb() {
        return attemptsNb.get();
    }

    /**
     * Incrementer attemptsNb
     */
    protected void incrAttemptsNb() {
        this.attemptsNb.incrementAndGet();
    }

    /**
     * Getter lastAttemptTs
     * 
     * @return the lastAttemptTs
     */
    public long getLastAttemptTs() {
        return lastAttemptTs;
    }

    /**
     * Updater lastAttemptTs
     */
    protected final void updateLastAttemptTs() {
        this.lastAttemptTs = System.currentTimeMillis();
    }
}
