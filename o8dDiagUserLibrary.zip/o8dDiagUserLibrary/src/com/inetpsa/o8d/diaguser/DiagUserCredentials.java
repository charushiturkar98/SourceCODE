package com.inetpsa.o8d.diaguser;

import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.EnumerationUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.cxl.commons.util.Base64Util;

/**
 * Informations pour l'authentification et le contr�le des droits d'un utilisateur.
 * 
 * @author E331258
 */
public class DiagUserCredentials extends UsernamePasswordCredentials {

    /**
     * Generated serial version UID.
     */
    private static final long serialVersionUID = 625697099244576516L;

    /**
     * Gestionnaire de logs.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DiagUserCredentials.class);

    /**
     * Chaine representant le charset UTF-8.
     */
    private static final String UTF8_CHARSET = "UTF-8";

    /**
     * Expression reguliere representant le contenu d'un header http de basic auth.
     */
    private static final String BASIC_AUTH_REGEXP = "Basic\\s+(.+)";

    /**
     * La pattern associe a l'expression reguliere de reconnaissance du contenu d'une basic auth.
     */
    private static final Pattern BASIC_AUTH_PATTERN = Pattern.compile(BASIC_AUTH_REGEXP);

    /**
     * Auth header find predicate.
     */
    private static final Predicate AUTHORIZATION_HEADER_PREDICATE = new Predicate() {

        /**
         * Auth header.
         */
        private static final String AUTHORIZATION_HEADER = "authorization";

        /**
         * V�rifie si l'objet correspond au header voulu (non case sensitif)
         * 
         * @param object objet a evaluer
         * @return vrai si le pr�dicat est v�rifi�, faux sinon
         */
        public boolean evaluate(Object object) {
            return StringUtils.equalsIgnoreCase(AUTHORIZATION_HEADER, object.toString());
        }
    };

    /**
     * Auth value separator.
     */
    private static final char AUTH_VALUE_SEPARATOR = ':';

    /**
     * Client IP header.
     */
    private static final String CLIENT_IP_HEADER = "Client-IP";
    /**
     * Proxied IP header.
     */
    private static final String PROXIED_HEADER = "X-FORWARDED-FOR";

    /** The Constant MARQUE. */
    private static final String MARQUE = "marque";

    /** The url. */
    private String url;

    /**
     * Adresse IP de l'utilisateur.
     */
    private final String userIpAddress;

    /**
     * for marque in header
     */
    private final String marque;

    /**
     * Ensemble des groupes et r�les
     */
    private Set<String> groupsRolesList;

    /** The token username. */
    // //CAP-26498:DiagLot2-code change for adding token username for diagcloud
    private String tokenUsername;
    /*
     * constructor to intialize marque value
     * 
     * 
     */

    /**
     * Constructeur.
     * 
     * @param username identifiant de l'utilisateur
     * @param password mot de passe de l'utilisateur
     * @param userIpAddress adresse IP de l'utilisateur
     */

    protected DiagUserCredentials(String username, String password, String userIpAddress) {
        super(StringUtils.upperCase(username), password);
        LOGGER.info("DiagUserCredentials >>");
        this.userIpAddress = userIpAddress;
        this.marque = null;
    }

    /**
     * Instantiates a new diag user credentials.
     *
     * @param username the username
     * @param password the password
     * @param userIpAddress the user ip address
     * @param marque the marque
     * @param url the url
     */
    protected DiagUserCredentials(String username, String password, String userIpAddress, String marque, String url) {
        super(StringUtils.upperCase(username), password);
        LOGGER.info("DiagUserCredentials with marque >>");
        this.userIpAddress = userIpAddress;
        this.marque = marque;
        this.url = url;
    }

    /**
     * CAP-26498:DiagLot2-code change for adding extra parameter
     *
     * @param tokenUsername username
     * @param userIpAddress ip address
     * @param marque marque
     * @param url url
     */
    protected DiagUserCredentials(String tokenUsername, String userIpAddress, String marque, String url) {
        super(StringUtils.upperCase(tokenUsername), "");
        LOGGER.info("DiagUserCredentials with marque >>");
        this.userIpAddress = userIpAddress;
        this.marque = marque;
        this.tokenUsername = tokenUsername;
        this.url = url;
    }

    /**
     * Getter userIpAddress
     *
     * @return the userIpAddress
     */
    public String getUserIpAddress() {
        return userIpAddress;
    }

    /**
     * Getter marque marqueuserIpAddress
     */
    public String getMarque() {
        return marque;
    }

    /**
     * Gets the url.
     *
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * Gets the token username.
     *
     * @return the token username
     */
    // CAP-26498:DiagLot2-code change for adding extra parameter
    public String getTokenUsername() {
        return tokenUsername;
    }

    /**
     * Ajoute un groupe ou un role.
     * 
     * @param groupRole groupe ou role
     */
    public void addGroupRole(String groupRole) {
        LOGGER.info("addGroupRole >>");
        if (groupsRolesList == null) {
            groupsRolesList = new HashSet<String>();
        }

        groupsRolesList.add(groupRole);
    }

    /**
     * Construction des �l�ments n�cessaires � l'authentification et au contr�le des droits.
     *
     * @param request objet {@link HttpServletRequest}
     * @param tokenUserName the token user name
     * @param tokenMarque the token marque
     * @return objet {@link DiagUserCredentials}
     * @throws DiagUserException si une erreur survient
     */
    // CAP-26498:DiagLot2-code change for POI credentials
    // DCLOUD-167
    public static DiagUserCredentials createCredentials(HttpServletRequest request, String tokenUserName) throws DiagUserException {
        LOGGER.info("createCredentials >>");
        String authHeader = getAuthHeader(request);
        String ipAddress = getIpAddress(request);
        String marque = getMarqueFromheader(request);

        String requestUri = request.getRequestURI();
        // CAP-26498:DiagLot2-code change for POI credentials: start
        DiagUserCredentials diagUserCredentials = null;

        if (StringUtils.isNotBlank(marque) && StringUtils.isBlank(tokenUserName)) {
            diagUserCredentials = createCredentials(authHeader, ipAddress, marque, requestUri);
        } else if (StringUtils.isNotBlank(tokenUserName)) {
            // DCLOUD-167
            diagUserCredentials = createCredentials(tokenUserName, "", ipAddress, marque, requestUri);
        } else { // CAP-26498:DiagLot2-code change for POI credentials: end
            diagUserCredentials = createCredentials(authHeader, ipAddress);
        }
        LOGGER.info("diagUserCredentials " + diagUserCredentials);
        boolean isProxied = isProxied(request);

        LOGGER.warn("Credentials init for user [{}], from ip [{}], proxied [{}]", diagUserCredentials.getUserName(),
                diagUserCredentials.getUserIpAddress(), isProxied);
        LOGGER.info("createCredentials <<");
        return diagUserCredentials;
    }

    /**
     * Creates the credentials.
     *
     * @param authHeaderValue the auth header value
     * @param ipAddress the ip address
     * @param marque the marque
     * @param url the url
     * @return the diag user credentials
     * @throws DiagUserException the diag user exception
     */
    public static DiagUserCredentials createCredentials(String authHeaderValue, String ipAddress, String marque, String url)
            throws DiagUserException {
        return getCredentials(authHeaderValue, ipAddress, marque, url);
    }

    /**
     * Creates the credentials.
     *
     * @param authHeaderValue the auth header value
     * @param ipAddress the ip address
     * @return the diag user credentials
     * @throws DiagUserException the diag user exception
     */
    public static DiagUserCredentials createCredentials(String authHeaderValue, String ipAddress) throws DiagUserException {

        return getCredentials(authHeaderValue, ipAddress, "", "");
    }

    /**
     * CAP-26498:DiagLot2-code change for adding extra parameter
     *
     * @param tokenUsername username
     * @param password password
     * @param ipAddress ipAddress
     * @param marque marque
     * @param url url
     * @return credentials
     */
    public static DiagUserCredentials createCredentials(String tokenUsername, String password, String ipAddress, String marque, String url) {
        return getCredentials(tokenUsername, password, ipAddress, marque, url);
    }

    /**
     * CAP-26498:DiagLot2-code change for adding extra parameter
     *
     * @param tokenUsername username
     * @param password password
     * @param ipAddress ipAddress
     * @param marque marque
     * @param url url
     * @return credentials
     */
    public static DiagUserCredentials getCredentials(String tokenUsername, String password, String ipAddress, String marque, String url) {
        LOGGER.info("getCredentials >>");
        DiagUserCredentials diagCredentials;
        if (StringUtils.isNotBlank(marque) && StringUtils.isNotBlank(url)) {
            diagCredentials = new DiagUserCredentials(tokenUsername, ipAddress, marque, url);
        } else {
            diagCredentials = new DiagUserCredentials(tokenUsername, password, ipAddress);
        }
        LOGGER.info("getCredentials <<");
        return diagCredentials;
    }

    /**
     * Gets the credentials.
     *
     * @param authHeaderValue the auth header value
     * @param ipAddress the ip address
     * @param marque the marque
     * @param url the url
     * @return the credentials
     * @throws DiagUserException the diag user exception
     */
    private static DiagUserCredentials getCredentials(String authHeaderValue, String ipAddress, String marque, String url) throws DiagUserException {
        LOGGER.info("getCredentials >>");
        Matcher regexpMatcher = BASIC_AUTH_PATTERN.matcher(authHeaderValue);
        LOGGER.info("marque value {}" + marque);
        LOGGER.info("url {}" + url);
        if (!regexpMatcher.matches()) {
            throw new DiagUserException("Basic Auth Header is invalid");
        }

        String authorizationCleaned = regexpMatcher.group(1);

        String authorisationString;
        DiagUserCredentials diagCredentials;

        try {
            authorisationString = new String(Base64Util.decode(authorizationCleaned.getBytes(UTF8_CHARSET)));
        } catch (UnsupportedEncodingException un) {
            LOGGER.warn("Utf-8 is not supported", un);
            authorisationString = new String(Base64Util.decode(authorizationCleaned.getBytes()));
        }

        int atColon = authorisationString.indexOf(AUTH_VALUE_SEPARATOR);

        String username;
        String password;

        if (atColon >= 0) {
            username = authorisationString.substring(0, atColon);
            password = authorisationString.substring(atColon + 1);
        } else {
            username = authorisationString;
            password = StringUtils.EMPTY;
        }

        if ("" != marque && "" != url)
            diagCredentials = new DiagUserCredentials(username, password, ipAddress, marque, url);
        else
            diagCredentials = new DiagUserCredentials(username, password, ipAddress);
        LOGGER.info("diagCredentials " + diagCredentials);
        LOGGER.info("getCredentials <<");
        return diagCredentials;

    }

    /**
     * Construction des �l�ments n�cessaires � l'authentification et au contr�le des droits.
     *
     * @param request the request
     * @return objet {@link DiagUserCredentials}
     * @throws DiagUserException si une erreur survient
     */

    /**
     * R�cup�ration du header d'authentification.
     * 
     * @param request objet {@link HttpServletRequest}
     * @return le contenu du header
     * @throws DiagUserException si le header est absent
     */
    private static String getAuthHeader(HttpServletRequest request) throws DiagUserException {
        String authHeader = null;

        String headerName = (String) CollectionUtils.find(EnumerationUtils.toList(request.getHeaderNames()), AUTHORIZATION_HEADER_PREDICATE);

        LOGGER.debug("Auth header name : {}", headerName);

        if (headerName != null) {
            authHeader = request.getHeader(headerName);
        }

        if (authHeader == null) {
            throw new DiagUserException("Basic Auth Header not found");
        }

        return authHeader;
    }

    /**
     * R�cup�ration de l'adresse IP du client.
     * 
     * @param request objet {@link HttpServletRequest}
     * @return adresse IP
     */
    public static String getIpAddress(HttpServletRequest request) {
        String ipAddress = request.getHeader(CLIENT_IP_HEADER);
        // CAP-19064: log message from debug to warn
        LOGGER.warn("ipAddress : {}", ipAddress);
        if (ipAddress == null) {
            ipAddress = request.getRemoteAddr();
        }

        return ipAddress;
    }

    /**
     * Le client a-t-il utilis� un proxy ?
     *
     * @param request objet {@link HttpServletRequest}
     * @return vrai si oui, faux sinon
     */

    private static boolean isProxied(HttpServletRequest request) {
        boolean proxied = false;
        String proxiedHeader = request.getHeader(PROXIED_HEADER);
        LOGGER.debug("proxiedHeader  : {}", proxiedHeader);
        if (proxiedHeader != null) {
            proxied = true;
        }
        return proxied;
    }

    /**
     * Gets the marque fromheader.
     *
     * @param request the request
     * @return the marque fromheader
     */
    private static String getMarqueFromheader(HttpServletRequest request) {

        String brand = request.getHeader(MARQUE);

        LOGGER.debug("brand : {}", brand);
        if (StringUtils.isEmpty(brand)) {
            brand = null;
        }
        return brand;
    }

}