package com.inetpsa.o8d.diaguser;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Objet XML pour les connecteurs.
 * 
 * @author e331258
 */
@XmlRootElement(name = "rules")
public class Rules {

    /**
     * D�finition des connecteurs.
     */
    private List<ConnectorDefinition> connectorDefinitions;
    /**
     * D�finition des autorisations.
     */
    private Map<String, Autorisation> autorisations;

    /**
     * Getter connectorDefinitions
     * 
     * @return the connectorDefinitions
     */
    public List<ConnectorDefinition> getConnectorDefinitions() {
        return connectorDefinitions;
    }

    /**
     * Setter connectorDefinitions
     * 
     * @param connectorDefinitions the connectorDefinitions to set
     */
    @XmlElement(name = "connector")
    public void setConnectorDefinitions(List<ConnectorDefinition> connectorDefinitions) {
        this.connectorDefinitions = connectorDefinitions;
    }

    /**
     * Getter autorisations
     * 
     * @return the autorisations
     */
    public Map<String, Autorisation> getAutorisations() {
        return autorisations;
    }

    /**
     * Setter autorisations
     * 
     * @param autorisations the autorisations to set
     */
    public void setAutorisations(Map<String, Autorisation> autorisations) {
        this.autorisations = autorisations;
    }
}
