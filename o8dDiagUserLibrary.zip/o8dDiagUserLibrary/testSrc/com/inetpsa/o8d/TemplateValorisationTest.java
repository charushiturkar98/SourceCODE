package com.inetpsa.o8d;

/*
 * Creation : 23 oct. 2014
 */

import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Test coherence des fichiers de configurations et des dictionnaires
 * 
 * @author f_jo
 */
public class TemplateValorisationTest {

    /**
     * LOGGER
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(TemplateValorisationTest.class.getName());

    /**
     * Liste des param�tres � exclure (non inclus dans les dicos)
     */
    private static final List<String> EXCLUDE_PARAMETERS = new ArrayList<String>();

    /**
     * Enumeration des fichiers de configurations contenant des parametres de valorisation
     */
    private static enum CONFIG_FILES {

        /** CXL_CONFIG.properties */
        CXL_CONFIG("psa/valorisation/templates/config/cxl-config.properties"),
        /** diaguser_a2drws_configuration.properties */
        DIAGUSER_A2DRWS_CONFIGURATION("psa/valorisation/templates/config/diaguser_a2drws_configuration.properties"),
        /** ldap.properties */
        LDAP("psa/valorisation/templates/config/ldap.properties"),
        /** DIAGUSER_ACCESS_LOCKER.properties */
        DIAGUSER_ACCESS_LOCKER("psa/valorisation/templates/config/diaguser-access-locker.properties"),
        /** diaguser_rules.xml */
        DIAGUSER_RULES("psa/valorisation/templates/config/diaguser-rules.xml");

        /**
         * Chemin relatif
         */
        protected final String filePath;

        /**
         * Constructeur
         * 
         * @param filePath chemin du fichier
         */
        CONFIG_FILES(final String filePath) {
            this.filePath = filePath;
        }

        /**
         * Getter filePath
         * 
         * @return chemin du fichier
         */
        public String getFilePath() {
            return this.filePath;
        }
    }

    /**
     * Enumeration des dictionnaires
     */
    private static enum DICO_FILES {

        /** dico-dev */
        DICO_DEV("psa/valorisation/dictionaries/dico-dev.properties"),
        /** dico-preprod */
        DICO_PREPROD("psa/valorisation/dictionaries/dico-preprod-diaguser-ediag.properties"),
        /** dico-prod */
        DICO_PROD("psa/valorisation/dictionaries/dico-prod-diaguser-ediag.properties");

        /**
         * Chemin relatif
         */
        protected final String filePath;

        /**
         * Constructeur
         * 
         * @param filePath chemin du fichier
         */
        DICO_FILES(final String filePath) {
            this.filePath = filePath;
        }

        /**
         * Getter filePath
         * 
         * @return chemin du fichier
         */
        public String getFilePath() {
            return this.filePath;
        }
    }

    /**
     * Verification coherence fichiers de config et dictionnaires
     */
    // @Test
    public void testDico() {

        LOGGER.info("--------------------------------------------------------------------------------");
        // Recuperation de la map des variables a valoriser dans les dicos
        Map<String, List<String>> hashConfigFiles = new HashMap<String, List<String>>();

        for (CONFIG_FILES configFile : CONFIG_FILES.values()) {
            String filePath = configFile.getFilePath();
            LOGGER.info("Lecture du fichier " + configFile.name() + " (" + filePath + ")");

            // Recuperation des variables à valoriser du fichier
            List<String> listeVariables = recuperationVariablesDansFichier(filePath);

            hashConfigFiles.put(configFile.name(), listeVariables);
        }
        LOGGER.info("--------------------------------------------------------------------------------");

        // Recuperation du contenu des dicos
        Map<String, List<String>> hashDicoFiles = new HashMap<String, List<String>>();

        for (DICO_FILES dicoFile : DICO_FILES.values()) {
            String filePath = dicoFile.getFilePath();
            LOGGER.info("Lecture du dictionnaire " + dicoFile.name() + "(" + filePath + ")");

            // Récupération des variables définies dans le dico
            List<String> listeVariables = recuperationVariablesDansDico(filePath);

            hashDicoFiles.put(dicoFile.name(), listeVariables);
        }
        LOGGER.info("--------------------------------------------------------------------------------");

        // Comparaison Fichiers de config / Dictionnaires
        verificationCoherenceVariables(hashConfigFiles, hashDicoFiles);

    }

    /**
     * Verification coherence fichier de configuration / dictionnaires
     * 
     * @param hashConfigFiles map des variables issues des fichiers de config
     * @param hashDicoFiles map des variables issues des dictionnaires
     */
    private void verificationCoherenceVariables(Map<String, List<String>> hashConfigFiles, Map<String, List<String>> hashDicoFiles) {
        boolean failure = false;

        // Verification variables des fichiers de config presentent dans les dictionnaires
        for (Map.Entry<String, List<String>> entry : hashConfigFiles.entrySet()) {

            String key = entry.getKey();
            LOGGER.info("Verification du fichier " + key);

            for (String value : entry.getValue()) {
                if (verificationParametreDansDico(value, hashDicoFiles, CONFIG_FILES.valueOf(key).getFilePath())) {
                    failure = true;
                }
            }
        }

        // Fail dans le cas incoherence DICO uniquement
        if (failure) {
            fail("Incoherence detectee. Voir log pour le detail.");
        }
    }

    /**
     * Verication que le parametre est dans les dictionnaires
     * 
     * @param value variable a tester
     * @param hashDicoFiles map des variables issues des dictionnaires
     * @param filePath fichier de config en cours
     * @return booleen (true si variable presente dans tous les dictionnaires; false sinon)
     */
    private boolean verificationParametreDansDico(String value, Map<String, List<String>> hashDicoFiles, String filePath) {
        boolean isFailure = false;
        // Pas de vérification, le paramètre est exclu
        if (EXCLUDE_PARAMETERS.contains(value)) {
            return isFailure;
        }

        for (Map.Entry<String, List<String>> entry : hashDicoFiles.entrySet()) {
            String key = entry.getKey();
            if (!entry.getValue().contains(value)) {
                LOGGER.error("  => Le Dictionnaire [" + key + "] ne contient pas le parametre [" + value + "] present dans [" + filePath + "]");
                isFailure = true;
            }
        }
        return isFailure;
    }

    /**
     * Recuperation des variables du dictionnaire
     * 
     * @param filePath chemin du dictionnaire
     * @return liste des variables
     */
    private List<String> recuperationVariablesDansDico(String filePath) {
        List<String> listeVariables = new ArrayList<String>();
        Properties fileProp = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(filePath);
            fileProp.load(fis);
            for (Map.Entry<Object, Object> entry : fileProp.entrySet()) {
                String key = (String) entry.getKey();
                listeVariables.add(key);
            }
        } catch (IOException e) {
            fail("IOException lors de la recuperation du fichier " + filePath);
        }

        return listeVariables;
    }

    /**
     * Recuperation des variables du fichier de configuration
     * 
     * @param filePath chemin complet du fichier
     * @return List liste des variables "dollar"
     */
    private List<String> recuperationVariablesDansFichier(String filePath) {
        List<String> listeVariables = new ArrayList<String>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(filePath));
            String parametre = null;
            while (br.ready()) {
                String line = br.readLine();
                if (line != null) {
                    int beginParam = line.indexOf("${");
                    if (beginParam != -1) {
                        int endParam = line.indexOf('}', beginParam);
                        if (endParam != -1) {
                            parametre = line.substring(beginParam + 2, endParam);
                            if (!listeVariables.contains(parametre)) {
                                listeVariables.add(parametre);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            fail("IOException lors de la recuperation du fichier " + filePath);
        } finally {
            IOUtils.closeQuietly(br);
        }

        return listeVariables;
    }

}
