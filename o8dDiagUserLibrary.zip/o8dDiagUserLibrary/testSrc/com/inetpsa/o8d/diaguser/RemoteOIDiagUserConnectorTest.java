package com.inetpsa.o8d.diaguser;

import org.junit.Assert;
import org.junit.Test;

/**
 * Classe de test pour les connecteurs OI distants.
 * 
 * @author E331258
 */
public class RemoteOIDiagUserConnectorTest extends AbstractDiagUserConnectorTest {

    // @Test
    public void testLockOI() {
        String username = "AC82264775";
        String bad_password = "bad_password";
        String good_password = "becker";
        String clientIp = "127.0.0.1";
        int attemptLimit = 3;

        // testLock(username, bad_password, good_password, clientIp, attemptLimit);
    }

    @Test
    public void testUnknownOI() {
        String username = "AC00000000";
        String password = "bad_password";
        String clientIp = "127.0.0.1";

        // testUnknown(username, password, clientIp);
    }

    // @Test
    public void testIdentityOI() {
        String username = "AC82264775";
        String good_password = "becker";
        String clientIp = "127.0.0.1";

        String value = "USER_ID=AC82264775\nUSER_IDENTITY=PATRICK BECKER\n\nROLE.OGD.ACCES=true\nOUG.GARAGE=true\nSERAV_APP=true\n"
                + "O7D.ACCES_ADMIN=false\n";

        testIdentity(username, good_password, clientIp, value);
    }

    // @Test
    public void testAuthenticateAndAutorizeOI() {
        String username = "AC82264775";
        String bad_password = "bad_password";
        String clientIp = "127.0.0.1";
        String applicationId = "a2drAuthentification";
        DiagUserStatus diagUserStatus = DiagUserStatus.AUTHENTICATION_FAILED;
        int httpCode = 401;

        /*
         * testAuthenticateAndAutorize(username, null, clientIp, applicationId, diagUserStatus, httpCode);
         * 
         * testAuthenticateAndAutorize(username, bad_password, clientIp, applicationId, diagUserStatus, httpCode);
         */
        String good_password = "becker";
        diagUserStatus = DiagUserStatus.NO_PERMISSION;
        httpCode = 403;

        /*
         * testFailAuthenticateAndAutorize(username, good_password, clientIp);
         * 
         * testAuthenticateAndAutorize(username, good_password, null, applicationId, diagUserStatus, httpCode);
         */
    }

    // @Test
    public void testContrat() {
        String username = "AC82264775";
        String good_password = "becker";
        String clientIp = "127.0.0.1";

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null); // CAP-26498:DiagLot2-
                                                                                                                             // code change for adding
                                                                                                                             // extra parameter
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

            Assert.assertEquals(AuthenticationStatus.AUTH_SUCCESS, authenticationStatus);

            boolean contratValide = diagUserConnector.isContratValide();

            Assert.assertEquals(true, contratValide);
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    // @Test
    public void testVin() {
        String username = "AC82264775";
        String good_password = "becker";
        String clientIp = "127.0.0.1";
        String vin = "VF30U9HZH9S124410";

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

            Assert.assertEquals(AuthenticationStatus.AUTH_SUCCESS, authenticationStatus);

            diagUserConnector.setVin(vin);

            boolean aboVinValide = diagUserConnector.isAbonnementVinValide();

            Assert.assertEquals(false, aboVinValide);

            // TODO : utiliser un compte avec des jetons
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
