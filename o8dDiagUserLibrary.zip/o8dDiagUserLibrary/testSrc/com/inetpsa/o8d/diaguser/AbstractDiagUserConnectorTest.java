package com.inetpsa.o8d.diaguser;

import org.junit.Assert;
import org.junit.BeforeClass;

/**
 * Classe abstraite pour les tests des connecteurs
 * 
 * @author E331258
 */
public abstract class AbstractDiagUserConnectorTest {

    protected DiagUserAccessLockerManager diagUserAccessLockerManager = DiagUserAccessLockerManager.getInstance();

    @BeforeClass
    public static void setUp() throws DiagUserException {
        DiagUserFactory.getInstance().init();
    }

    protected void testEmpty(String clientIp) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(null, null, clientIp);

        try {
            DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);// CAP-26498:DiagLot2- code change for adding extra parameter
            Assert.fail("No auth header : should have failed");
        } catch (DiagUserException e) {
            Assert.assertEquals("Basic Auth Header not found", e.getMessage());
        }
    }

    protected void testInvalid(String clientIp) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(null, null, clientIp);
        mockedHttpServletRequest.setInvalidBasicAuthHeader();

        try {
            DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            Assert.fail("No auth header : should have failed");
        } catch (DiagUserException e) {
            Assert.assertEquals("Basic Auth Header is invalid", e.getMessage());
        }
    }

    protected void testLock(String username, String bad_password, String good_password, String clientIp, int attemptLimit) {
        testEmpty(clientIp);

        testInvalid(clientIp);

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, bad_password, clientIp);

        boolean locked = false;
        int i = 0;

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            ConnectionAttempts connectionAttempts = diagUserAccessLockerManager.searchAttempts(diagUserConnector);

            while (!locked && (i < attemptLimit)) {
                // Tentative d'authentification
                AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

                Assert.assertFalse(authenticationStatus == AuthenticationStatus.AUTH_SUCCESS);

                connectionAttempts = diagUserAccessLockerManager.searchAttempts(diagUserConnector);

                Assert.assertNotNull(connectionAttempts);

                locked = diagUserAccessLockerManager.isLocked(diagUserConnector, connectionAttempts);

                if (connectionAttempts.getAttemptsNb() >= attemptLimit) {
                    Assert.assertTrue(locked);
                } else {
                    Assert.assertFalse(locked);
                }

                i++;
            }

            Assert.assertTrue(locked);
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

        // Temporisation pour tester le d�lai de temporisation li� au lock
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            ConnectionAttempts connectionAttempts = diagUserAccessLockerManager.searchAttempts(diagUserConnector);

            Assert.assertNotNull(connectionAttempts);

            // Tentative
            AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

            Assert.assertEquals(authenticationStatus, AuthenticationStatus.AUTH_SUCCESS);

            connectionAttempts = diagUserAccessLockerManager.searchAttempts(diagUserConnector);

            Assert.assertNull(connectionAttempts);
            Assert.assertFalse(diagUserAccessLockerManager.isLocked(diagUserConnector, connectionAttempts));

            // Test du cache d'authentification
            authenticationStatus = diagUserConnector.authenticate();

            Assert.assertEquals(authenticationStatus, AuthenticationStatus.AUTH_SUCCESS);
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    protected void testUnknown(String username, String password, String clientIp) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

            Assert.assertFalse(authenticationStatus == AuthenticationStatus.AUTH_SUCCESS);
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    protected void testIdentity(String username, String good_password, String clientIp, String value) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            String list = diagUserConnector.getIdentityCardAsString();
            Assert.assertEquals(value, list);
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    protected void testFailAuthenticateAndAutorize(String username, String good_password, String clientIp) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);
        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null);
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            diagUserConnector.authenticateAndAuthorize();
            Assert.fail("Application is null, should fail");
        } catch (DiagUserException e) {
            Assert.assertEquals("le 'applicationName' ne doit pas etre 'null' ou vide", e.getMessage());
        }
    }

    protected void testAuthenticateAndAutorize(String username, String good_password, String clientIp, String applicationId,
            DiagUserStatus diagUserStatus, int httpCode) {
        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        /*
         * try { DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest); AbstractDiagUserConnector
         * diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials);
         * 
         * diagUserConnector.setApplicationId(applicationId); DiagUserStatus status = diagUserConnector.authenticateAndAuthorize();
         * 
         * Assert.assertEquals(diagUserStatus, status); Assert.assertEquals(httpCode, status.getHttpCode()); } catch (DiagUserException e) {
         * e.printStackTrace(); Assert.fail(e.getMessage()); }
         */
    }
}
