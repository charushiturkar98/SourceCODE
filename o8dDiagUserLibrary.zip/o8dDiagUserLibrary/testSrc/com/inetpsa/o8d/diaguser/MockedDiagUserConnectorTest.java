package com.inetpsa.o8d.diaguser;

import org.junit.Assert;

/**
 * Classe de test pour les connecteurs OI bouchons.
 * 
 * @author E331258
 */
public class MockedDiagUserConnectorTest extends AbstractDiagUserConnectorTest {

    // @Test
    public void testLockOI() {
        String username = "tdc_1234";
        String bad_password = "bad_password";
        String clientIp = "127.0.0.1";

        testEmpty(clientIp);

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, bad_password, clientIp);

        try {
            DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest, null); //// CAP-26498:DiagLot2-
                                                                                                                             //// code change for
                                                                                                                             //// adding extra
                                                                                                                             //// parameter
            AbstractDiagUserConnector diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials, null);

            Assert.assertNull(diagUserAccessLockerManager.searchAttempts(diagUserConnector));

            // Premiere tentative
            AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();

            Assert.assertEquals(AuthenticationStatus.AUTH_SUCCESS, authenticationStatus);

            ConnectionAttempts connectionAttempts = diagUserAccessLockerManager.searchAttempts(diagUserConnector);

            Assert.assertNull(connectionAttempts);
            Assert.assertFalse(diagUserAccessLockerManager.isLocked(diagUserConnector, connectionAttempts));
        } catch (DiagUserException e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    // @Test
    public void testIdentityOI() {
        String username = "tdc_1234";
        String bad_password = "bad_password";
        String clientIp = "127.0.0.1";
        String value = "USER_ID=TDC_1234\nUSER_IDENTITY=guest doe\n\nROLE.OGD.ACCES=true\nOUG.GARAGE=true\nSERAV_APP=true\n"
                + "O7D.ACCES_ADMIN=true\nOAU.AUTEUR=true\nODW.WEBDIAG.PPPRODUCTION=true\n";

        testIdentity(username, bad_password, clientIp, value);
    }

    // @Test
    public void testAuthenticateAndAutorizeOI() {
        String username = "tdc_1234";
        String bad_password = "bad_password";
        String clientIp = "127.0.0.1";
        String applicationId = "a2drAuthentification";
        DiagUserStatus diagUserStatus = DiagUserStatus.NO_PERMISSION;
        int httpCode = 403;

        testAuthenticateAndAutorize(username, bad_password, clientIp, applicationId, diagUserStatus, httpCode);

        applicationId = "SERAV_APP";
        diagUserStatus = DiagUserStatus.AUTHENTICATED_AND_AUTHORIZED;
        httpCode = 200;

        testFailAuthenticateAndAutorize(username, bad_password, clientIp);

        testAuthenticateAndAutorize(username, bad_password, clientIp, applicationId, diagUserStatus, httpCode);
    }
}
