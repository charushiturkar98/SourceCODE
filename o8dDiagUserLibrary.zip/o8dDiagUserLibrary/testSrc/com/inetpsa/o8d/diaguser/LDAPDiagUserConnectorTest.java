package com.inetpsa.o8d.diaguser;

/**
 * Classe de test pour les connecteurs LDAP.
 * 
 * @author E331258
 */
public class LDAPDiagUserConnectorTest extends AbstractDiagUserConnectorTest {

    // @Test
    public void testLockLDAP() {
        String username = "znSiXkuf3gtaCgPGeLV6mQ==";
        String bad_password = "bad_password";
        String good_password = "aDINvjn1rXFRKjCcVMnd9Q==";
        String clientIp = "127.0.0.1";
        int attemptLimit = 3;

        testLock(username, bad_password, good_password, clientIp, attemptLimit);
    }

    // @Test
    public void testUnknownLDAP() {
        String username = "ABCDEFG";
        String password = "bad_password";
        String clientIp = "127.0.0.1";

        testUnknown(username, password, clientIp);
    }

    // @Test
    public void testIdentityLDAP() {
        String username = "znSiXkuf3gtaCgPGeLV6mQ==";
        String good_password = "aDINvjn1rXFRKjCcVMnd9Q==";
        String clientIp = "127.0.0.1";
        String value = "USER_ID=znSiXkuf3gtaCgPGeLV6mQ==\nUSER_IDENTITY=null znSiXkuf3gtaCgPGeLV6mQ==\n\nROLE.OAD.ACCES=false\nROLE.OGD.ACCES=false\n"
                + "ROLE.OHD.HISTODIAG_P1=false\nROLE.OHD.HISTODIAG_P2=false\nROLE.OHD.HISTODIAG_PP=false\nOUA.AUTEUR=false\n"
                + "OUG.GARAGE=false\nOUG.GARAGE_ADM=false\nOUH.HISTORY=false\nOUH.HISTORY.PPPRODUCTION=false\n"
                + "OUH.HISTORY.CONCEPTION=false\nSERAV_APP=false\nO7D.ACCES_ADMIN=false\n";

        testIdentity(username, good_password, clientIp, value);
    }

    // @Test
    public void testAuthenticateAndAutorize() {
        String username = "znSiXkuf3gtaCgPGeLV6mQ==";
        String bad_password = "bad_password";
        String clientIp = "127.0.0.1";
        String applicationId = "a2drAuthentification";
        DiagUserStatus diagUserStatus = DiagUserStatus.AUTHENTICATION_FAILED;
        int httpCode = 401;

        testAuthenticateAndAutorize(username, null, clientIp, applicationId, diagUserStatus, httpCode);

        testAuthenticateAndAutorize(username, bad_password, clientIp, applicationId, diagUserStatus, httpCode);

        String good_password = "aDINvjn1rXFRKjCcVMnd9Q==";
        diagUserStatus = DiagUserStatus.NO_PERMISSION;
        httpCode = 403;

        testFailAuthenticateAndAutorize(username, good_password, clientIp);

        testAuthenticateAndAutorize(username, good_password, null, applicationId, diagUserStatus, httpCode);
    }

    // @Test
    public void testContrat() {
        String username = "znSiXkuf3gtaCgPGeLV6mQ==";
        String good_password = "aDINvjn1rXFRKjCcVMnd9Q==";
        String clientIp = "127.0.0.1";

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        /*
         * try { DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest); AbstractDiagUserConnector
         * diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials);
         * 
         * AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();
         * 
         * Assert.assertEquals(AuthenticationStatus.AUTH_SUCCESS, authenticationStatus);
         * 
         * diagUserConnector.isContratValide(); Assert.fail("LDAP : should fail"); } catch (DiagUserException e) { Throwable cause = e.getCause();
         * Assert.assertTrue(cause instanceof NotImplementedException); Assert.assertEquals("Method is not implemented", cause.getMessage()); }
         */
    }

    // @Test
    public void testVin() {
        String username = "znSiXkuf3gtaCgPGeLV6mQ==";
        String good_password = "aDINvjn1rXFRKjCcVMnd9Q==";
        String clientIp = "127.0.0.1";
        String vin = "VF30U9HZH9S124410";

        MockedHttpServletRequest mockedHttpServletRequest = new MockedHttpServletRequest(username, good_password, clientIp);

        /*
         * try { DiagUserCredentials diagUserCredentials = DiagUserCredentials.createCredentials(mockedHttpServletRequest); AbstractDiagUserConnector
         * diagUserConnector = DiagUserFactory.getInstance().getDiagUserConnectorInstance(diagUserCredentials);
         * 
         * AuthenticationStatus authenticationStatus = diagUserConnector.authenticate();
         * 
         * Assert.assertEquals(AuthenticationStatus.AUTH_SUCCESS, authenticationStatus);
         * 
         * diagUserConnector.setVin(vin);
         * 
         * diagUserConnector.isAbonnementVinValide();
         * 
         * Assert.fail("LDAP : should fail"); } catch (DiagUserException e) { Throwable cause = e.getCause(); Assert.assertTrue(cause instanceof
         * NotImplementedException); Assert.assertEquals("Method is not implemented", cause.getMessage()); }
         */
    }
}
